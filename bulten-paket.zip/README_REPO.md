# 📋 Bülten — kendi kendine güncellenen futbol analiz sitesi

Bu depo **GitHub Actions** ile her 30 dakikada bir çalışır, veriyi tazeler ve siteyi
**GitHub Pages** ile yayınlar. Senin bir şey yapmana gerek yok; sadece siteyi açarsın.

## Kuran kişi için: 7 adım
Tam adım adım kılavuz siteye `kurulum.html` olarak yayınlanır (paketteki **KURULUM.html** dosyası).
Özet:

1. **Yeni repo** aç: adı `bulten`, **Public**, README işareti kapalı
2. **`bulten-paket.zip`** dosyasını yükle (Add file → Upload files) — *silinmez, her turda koddan okunur*
3. **`.github/workflows/guncelle.yml`** dosyasını oluştur ve içeriğini yapıştır
4. **Settings → Pages → Source: GitHub Actions**
5. **Actions → Bulten guncelle → Run workflow** (ilk tur 10–20 dk)
6. Site: `https://KULLANICI-ADIN.github.io/bulten/`
7. Telefon tarayıcısında **Ana ekrana ekle**

## Sistem ne yapıyor?
| Adım | Açıklama |
|---|---|
| Kodu paketten açar | `bulten-paket.zip` repoda durur, çalışma alanına açılır |
| Arşivleri hazırlar | 161.000+ maç kapanış arşivi (pakette gelir), açılış arşivi büyütülür (8 dk/tur) |
| Veriyi tazeler | Bugünün fikstürü, oran hareketi, maç başlayanların kapanış oranı + CLV ölçümü |
| Yayınlar | `BULTEN.html` → `index.html`, `CANLI.html` → `canli.html`, maç başına kıyas sayfaları |

## Yayınlanan sayfalar
- `index.html` — tam bülten (bugünün tüm maçları, oranlar ilk ekranda)
- `canli.html` — canlı takip (60 sn'de yenilenir)
- `kurulum.html` — bu kılavuz
- `kiyas/<maç-id>.html` — açılış + kapanış oranı kıyası, aynı oranlı maçların sonuçları
- `telefon.html` — ileri seviye: kendi cihazında çalıştırma
- `guncelle.yml.txt` — otomasyon dosyasının metni (kopyalamak için)

## Veri nerede saklanıyor?
- **Önbellek (actions/cache):** `veri/` klasörünün tamamı, arşivler dahil — her turda geri yüklenir.
- **Repo commit'i:** küçük durum dosyaları + `veri/son_calisma.json` (bot her turda commit eder;
  8 MB'tan büyük veri dosyaları repoya girmez). Bu commit ayrıca GitHub'ın
  "60 gün hareketsizlikte zamanlanmış işi durdurma" kuralına takılmayı önler.

## Elle çalıştırma
Actions → **Bulten guncelle** → **Run workflow**

## Yerelde çalıştırma (isteğe bağlı)
```bash
bash kur.sh              # sabit yolları bulunduğun dizine uyarlar, eksikleri söyler
bash baslat.sh --taze    # veriyi tazele + sunucuyu başlat
# → http://localhost:8000/bulten   (Windows: python baslat.py --taze)
```

## Maliyet
Public repo + GitHub Actions + GitHub Pages = **ücretsiz**.
(Private repoda Actions dakikaları sınırlıdır; 30 dakikalık aralık için public repo gerekir.)

## Sorun giderme
| Belirti | Çözüm |
|---|---|
| İlk tur kırmızı | Actions → çalıştırma → kırmızı adım. Genelde: `bulten-paket.zip` yok ya da Pages kaynağı seçilmemiş |
| Site açılmıyor (404) | Settings → Pages → Source: **GitHub Actions** seçili mi? İlk yayın 1–2 dk sürer |
| “Durumu repoya kaydet” hatası | Settings → Actions → General → Workflow permissions → **Read and write permissions** |
| Veri kayboldu gibi | `actions/cache` önbelleği 7 gün erişilmezse düşer; geçici. Arşivler yeniden kurulur |
| Sıklığı değiştirme | `guncelle.yml` içindeki `cron: '*/30 * * * *'` satırını değiştir |
