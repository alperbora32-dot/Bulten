#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ANALİZ MERKEZİ v2 — her maça derin analiz + açılış oranı eşleşmesi
python3 analiz_app.py  →  http://0.0.0.0:8000
"""
import json, os, re, time, threading, html as H, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import sys
sys.path.insert(0, '/home/user')
import analiz_motoru as M
import motor_v2 as V
import rapor_v2 as R
import tarama as T
import bulten as B
import tam_tarama as TT
import detay as DE

PORT = 8000
TARAMA_CACHE = {}
BULTEN_CACHE = {}
CACHE = {}          # ref -> P (analiz verisi)
LOCK = threading.Lock()
ARCH = "/home/user/veri/all_matches.json"

_ARSIV_CACHE = {"t": 0, "data": None}
def arsiv_istatistik():
    """Arşivin kapsamı: yıl, lig, güncellik."""
    if _ARSIV_CACHE["data"] and time.time() - _ARSIV_CACHE["t"] < 600:
        return _ARSIV_CACHE["data"]
    from collections import Counter
    from datetime import datetime
    ms = json.load(open(ARCH, encoding="utf-8"))
    yil = Counter(); lig = Counter(); ulke = Counter(); ds = []
    for m in ms:
        try: d = datetime.strptime(m.get("date", ""), "%d.%m.%Y")
        except Exception: d = None
        if d:
            yil[d.year] += 1; ds.append(d)
        lg = m.get("league", "")
        lig[lg.strip("/").split("/")[-1]] += 1
        p = lg.strip("/").split("/")
        if len(p) > 1: ulke[p[1]] += 1
    data = dict(n=len(ms), yil=yil, lig=lig, ulke=ulke,
                ilk=min(ds).strftime("%d.%m.%Y") if ds else "-",
                son=max(ds).strftime("%d.%m.%Y") if ds else "-",
                ligsayi=len(lig), ulkesayi=len(ulke),
                mtime=time.strftime("%d.%m.%Y %H:%M", time.localtime(os.path.getmtime(ARCH))))
    _ARSIV_CACHE.update({"t": time.time(), "data": data})
    return data

def arsiv_bilgi():
    try:
        n = len(json.load(open(ARCH, encoding="utf-8")))
        t = os.path.getmtime(ARCH)
        return n, time.strftime("%d.%m.%Y %H:%M", time.localtime(t))
    except Exception:
        return 0, "-"

CSS = """
*{box-sizing:border-box}body{margin:0;background:#0a121e;color:#e8eef5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif}
.wrap{max-width:1120px;margin:0 auto;padding:24px 16px 60px}
h1{font-size:30px;margin:0 0 6px;background:linear-gradient(90deg,#5ee7a0,#4fc3f7);-webkit-background-clip:text;background-clip:text;color:transparent}
.sub{color:#8ba3b8;font-size:14px;margin-bottom:18px}
.card{background:#0f1a27;border:1px solid #1d2d42;border-radius:14px;padding:18px 20px;margin:14px 0}
.step{display:flex;gap:10px;align-items:center;font-weight:700;font-size:15px;margin-bottom:10px}
.stepnum{background:linear-gradient(90deg,#1f9d63,#0e8f8f);width:26px;height:26px;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;font-size:14px}
input[type=text]{width:100%;padding:14px 16px;border-radius:10px;border:1px solid #24384f;background:#0b1522;color:#e8eef5;font-size:15px;outline:none}
input[type=text]:focus{border-color:#4fc3f7;box-shadow:0 0 0 3px rgba(79,195,247,.15)}
button{padding:14px 24px;border-radius:10px;border:0;background:linear-gradient(90deg,#1f9d63,#0e8f8f);color:#fff;font-weight:700;font-size:15px;cursor:pointer}
button:hover{filter:brightness(1.13)}button:disabled{opacity:.5;cursor:wait}
.grid{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(255px,1fr))}
.feat{background:#0c1622;border:1px solid #1d2d42;border-radius:12px;padding:12px 14px;font-size:13px}
.feat b{color:#5ee7a0;display:block;margin-bottom:3px}
.feat span{color:#9fb4c7}
a.lnk{color:#4fc3f7;text-decoration:none}a.lnk:hover{text-decoration:underline}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{border:1px solid #1d2d42;padding:6px 8px}th{background:#16273a;color:#9fd6ff}
tbody tr:nth-child(even){background:#0c1622}
.spin{width:46px;height:46px;border:4px solid #1d2d42;border-top-color:#5ee7a0;border-radius:50%;animation:sp 1s linear infinite;margin:20px auto}
@keyframes sp{to{transform:rotate(360deg)}}
.prog{color:#8ba3b8;font-size:13.5px;text-align:center}
.pill{display:inline-block;background:#16273a;border:1px solid #24384f;border-radius:999px;padding:3px 11px;font-size:12px;color:#9fd6ff;margin:2px}
.err{background:#3a1a1a;border:1px solid #6b2020;color:#ffb3b3;padding:12px 14px;border-radius:10px}
.ok{color:#5ee7a0}h2{font-size:19px;margin:22px 0 10px;color:#cfe6ff}
.legend{display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));font-size:12.5px;color:#a9c1d6}
.legend div{background:#0c1622;border:1px solid #1d2d42;border-radius:9px;padding:9px 11px}
.big-cta{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-top:10px}
"""

def page(title, body, extra=""):
    return (f"<!DOCTYPE html><html lang='tr'><head><meta charset='utf-8'>"
            f"<meta name='viewport' content='width=device-width,initial-scale=1'><title>{H.escape(title)}</title>"
            f"<style>{CSS}</style></head><body><div class='wrap'>{body}</div>{extra}</body></html>")

INDEX = """<h1>⚽ ANALİZ MERKEZİ</h1>
<div class="sub">Bir maç seç → <b>tam olarak aynı oranla açılan</b> tüm maçları {ARSIV} maçlık arşivde bul → sonuçları, istatistikleri ve değer analizini gör.</div>

<div class="card">
  <div class="step"><span class="stepnum">1</span> Takımını ara — maç listesinden seç</div>
  <input type="text" id="t" placeholder="Kyoto, Kashiwa, Galatasaray, Liverpool, Real Madrid…">
  <div class="big-cta"><button onclick="ara()">🔎 TAKIM ARA</button>
  <span class="sub" style="margin:0">veya doğrudan bir maç linki yapıştır ↓</span></div>
</div>

<div class="card">
  <div class="step"><span class="stepnum">2</span> Ya da maç linkini yapıştır (BetExplorer)</div>
  <input type="text" id="q" placeholder="https://www.betexplorer.com/football/japan/j1-league/kyoto-kashiwa-reysol/69OvaPUj/">
  <div class="big-cta"><button onclick="go()">📊 ANALİZ ET</button>
  <span class="sub" style="margin:0">Örnek:
   <a class="lnk" href="/rapor?ref=/football/japan/j1-league/kyoto-kashiwa-reysol/69OvaPUj/">Kyoto – Kashiwa</a> ·
   <a class="lnk" href="/rapor?ref=/football/england/premier-league-2024-2025/liverpool-crystal-palace/lh1OJUtR/">Liverpool – Crystal Palace</a></span></div>
</div>

<div id="sonuc"></div>

<div class="card" style="background:linear-gradient(135deg,#0f2436,#0f1a27);border-color:#1f4d3a">
  <div class="step"><span class="stepnum">⚡</span> Bugünün TÜM maçlarını tara</div>
  <div class="sub" style="margin:0 0 10px">Bugün oynanan/oynanacak <b>tüm maçları</b> arşivle karşılaştırır: her maç için "aynı oranla açılan" maçlar bulunur,
  tarihsel isabet oranı piyasa olasılığıyla kıyaslanır ve <b>sadece istatistiksel olarak anlamlı değer fırsatları</b> listelenir (güven aralığı + örneklem filtresi).</div>
  <div class="big-cta">
    <a href="/bulten"><button>📋 TÜM BÜLTENİ AÇ (bugünün 976 maçı)</button></a>
    <a href="/tarama"><button style="background:linear-gradient(90deg,#b8860b,#8f6b0a)">⚡ SADECE DEĞER FIRSATLARI</button></a>
  </div>
</div>
<div class="card" style="text-align:center">
  <b>Arşiv kapsamını gör:</b> <a class="lnk" href="/arsiv">🗄️ Arşiv Durumu →</a>
  <span class="sub">kaç maç, hangi yıllar, hangi ligler, ne zaman güncellendi</span>
</div>

<h2>Sonuç ekranı nasıl okunur?</h2>
<div class="card">
 <div class="legend">
  <div><b style="color:#5ee7a0">🎯 Aynı oranla açılan maçlar</b><br>Senin maçının oranlarıyla (açılışta birebir veya ± toleransla) başlamış maçlar ve gerçek sonuçları.</div>
  <div><b style="color:#5ee7a0">📊 Sonuç dağılımı</b><br>Ev / Beraberlik / Deplasman yüzdeleri. Zaman ağırlıklı sütun yeni maçlara daha çok önem verir.</div>
  <div><b style="color:#5ee7a0">💰 Değer tablosu</b><br>Piyasa olasılığı vs tarihsel isabet. Fark pozitifse o bahis <b>DEĞERLİ</b>, negatifse PAHALI.</div>
  <div><b style="color:#5ee7a0">🎲 Poisson / 📈 Hareket</b><br>Matematiksel model + bahisçi para akışı (oran hareketi) analizi.</div>
  <div><b style="color:#5ee7a0">🔀 Katman sekmeleri</b><br>Birebir aynı açılış → ±0.02 → ±0.05 → ±0.10 → ±0.15. Tolerans büyüdükçe örneklem artar.</div>
  <div><b style="color:#5ee7a0">🧪 Hareket isabet testi</b><br>Oranı kısalan takım gerçekten daha çok kazanıyor mu? Ölçüyoruz.</div>
 </div>
</div>

<h2>Motorda neler var?</h2>
<div class="grid">
 <div class="feat"><b>Açılış oranı doğrulaması</b><span>Her benzer maçın gerçek bet365 açılış oranı arşivden çekilir — kapanış değil, açılış karşılaştırılır.</span></div>
 <div class="feat"><b>Uyum skoru (0-100)</b><span>Oranların göreli yakınlığı. 100 = birebir aynı oran seti.</span></div>
 <div class="feat"><b>%95 güven aralığı</b><span>Küçük örneklemde yanılma payı dürüstçe gösterilir.</span></div>
 <div class="feat"><b>Kelly kriteri</b><span>Değer bulunan bahis için teorik banko yüzdesi (¼ Kelly).</span></div>
 <div class="feat"><b>Zaman ağırlıklı istatistik</b><span>3 yıl yarı ömürlü ağırlıklandırma; eski maçlar daha az etkiler.</span></div>
 <div class="feat"><b>Yıl & lig istikrarı</b><span>Eğilim yıllara yayılmış mı, yoksa tek sezonluk mu?</span></div>
 <div class="feat"><b>İY/MS matrisi</b><span>İlk yarı skoru ile maç sonucunun ilişkisi.</span></div>
 <div class="feat"><b>Korner sinyali</b><span>Takımların korner üretme/yeme ortalaması, 80+ ülke.</span></div>
 <div class="feat"><b>Hareket isabet testi</b><span>Oran hareketi (steam) sonucu tahmin ediyor mu, backtest.</span></div>
</div>

<script>
function spin(m){document.getElementById('sonuc').innerHTML='<div class="card"><div class="spin"></div><div class="prog" id="pr">'+m+' <b id="t0">0</b> sn<br><span id="step" style="color:#4fc3f7"></span></div></div>';
 let s=0;window._iv=setInterval(()=>{let el=document.getElementById('t0');if(el)el.textContent=s++;},1000);
 const steps=["oran arşivi ve hareketler çekiliyor…","marketler + tüm bahisçiler taranıyor…","arşivde aynı oranla açılan maçlar aranıyor…","adayların gerçek bet365 oranları doğrulanıyor…","benzer maçların AÇILIŞ oranları çekiliyor…","H2H, form ve korner verileri…","istatistik + Poisson + değer tablosu hesaplanıyor…"];
 let si=0;window._sv=setInterval(()=>{let el=document.getElementById('step');if(el)el.textContent="· "+steps[si++%steps.length];},3400);}
function go(){let v=document.getElementById('q').value.trim();if(!v)return;
 if(v.includes('/team/')){let m=v.match(/\\/football\\/team\\/[^\\s]*?\\/[A-Za-z0-9]{8}\\//);if(m){location.href='/takim?p='+encodeURIComponent(m[0]);return;}}
 location.href='/rapor?ref='+encodeURIComponent(v);}
function ara(){let v=document.getElementById('t').value.trim()||document.getElementById('q').value.trim();if(!v)return;
 spin('Takımlar aranıyor…');
 fetch('/api/ara?q='+encodeURIComponent(v)).then(r=>r.text()).then(h=>{clearInterval(window._iv);clearInterval(window._sv);document.getElementById('sonuc').innerHTML=h;});
}
document.addEventListener('keydown',e=>{if(e.key==='Enter'){if(document.activeElement.id==='t')ara();else go();}});
</script>"""

class App(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def send_html(self, body, code=200):
        b = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)
    CACHE_DIR = "/home/user/veri/htmlcache"
    def cached_html(self, ref, kat):
        import os
        p = os.path.join(self.CACHE_DIR, re.sub(r'[^A-Za-z0-9]+', '_', ref) + f"_{kat}.html")
        if os.path.exists(p) and time.time() - os.path.getmtime(p) < 3 * 86400:
            return open(p, encoding="utf-8").read()
        return None
    def store_html(self, ref, kat, html):
        import os
        os.makedirs(self.CACHE_DIR, exist_ok=True)
        p = os.path.join(self.CACHE_DIR, re.sub(r'[^A-Za-z0-9]+', '_', ref) + f"_{kat}.html")
        try: open(p, "w", encoding="utf-8").write(html)
        except Exception: pass
    def get_P(self, ref):
        with LOCK:
            if ref in CACHE: return CACHE[ref]
        P = V.analyze2(ref, progress=lambda *a: None)
        n, _ = arsiv_bilgi()
        P["_arsiv"] = f"{n:,}".replace(",", ".")
        with LOCK:
            CACHE[ref] = P
            if len(CACHE) > 30: CACHE.pop(next(iter(CACHE)))
        return P

    def kiyas_sayfasi(self, q):
        """Bir maçın TÜM eşleşen maçlarını (kırpma yok) listeler: açılış + kapanış kıyası."""
        import saat as SA
        mid = (q.get("mid") or [""])[0]
        if not mid:
            return self.send_html("<div class='card'>mid eksik</div>")
        tt = json.load(open("/home/user/veri/tam_tarama.json", encoding="utf-8"))
        m = next((x for x in tt if x.get("id") == mid), None)
        if not m:
            return self.send_html("<div class='card'>Maç bulunamadı: %s</div>" % H.escape(mid))
        try:
            krec = json.load(open("/home/user/veri/kapanis.json", encoding="utf-8")).get("kapanis", {}).get(mid) or {}
        except Exception:
            krec = {}
        ms, o1s = TT.arsiv()
        es = TT.eslesen(ms, o1s, m["o"], m.get("tol_k") or 0.12) if m.get("o") else []
        ht = DE.ht()

        def ac_satir(c):
            _ht = ht.get(c["id"])
            iy = f"{_ht[0]}:{_ht[1]}" if _ht else ""
            lig = (c.get("league") or "").strip("/").split("/")
            ligad = (lig[2].replace("-", " ").title() if len(lig) > 2 else "")
            return ("<tr><td>%s</td><td>%s - %s</td><td class='b'>%d:%d</td><td class='b'>%s</td>"
                    "<td>%.2f / %.2f / %.2f</td><td class='mini'>%s</td></tr>"
                    % (H.escape(c.get("date", "")), H.escape(c.get("home", "")), H.escape(c.get("away", "")),
                       c.get("hg", 0), c.get("ag", 0), iy, c.get("o1", 0), c.get("ox", 0), c.get("o2", 0),
                       H.escape(ligad)))

        kap = None
        try:
            import kapanis_kiyas as KK
            odds_ = (krec.get("kapanis") if krec.get("kapanis") else None)
            if odds_ and m.get("o"):
                kap = KK.KAPO().kiyas(odds_, lig=m.get("lig"), ulke=None)
        except Exception as e:
            kap = None
        bas = ("<div class='card'><h2 style='margin:0'>%s - %s</h2>"
               "<div class='mini'>%s · %s · açılış %.2f / %.2f / %.2f%s</div></div>"
               % (H.escape(m.get("home", "")), H.escape(m.get("away", "")), H.escape(m.get("lig", "")),
                  H.escape(m.get("saat", "")), m["o"][0], m["o"][1], m["o"][2],
                  (" · kapanış " + " / ".join("%.2f" % x for x in krec["kapanis"])) if krec.get("kapanis") else ""))
        govde = [bas]
        govde.append("<div class='card'><h3>AÇILIŞ ORANI KIYASI — %d maç (tamamı)</h3>"
                     "<table class='kt'><thead><tr><th>Tarih</th><th>Maç</th><th>MS</th><th>İY</th><th>Açılış oranı</th>"
                     "<th>Lig</th></tr></thead><tbody>%s</tbody></table></div>"
                     % (len(es), "".join(ac_satir(c) for c in sorted(es, key=lambda z: z.get("date", ""), reverse=True))))

        def kp_tablo(ad, L, notu=""):
            if not L:
                return ""
            return ("<div class='card'><h3>%s — %d maç</h3><div class='mini'>%s</div>"
                    "<table class='kt'><thead><tr><th>Tarih</th><th>Maç</th><th>MS</th><th>İY</th><th>Kapanış oranı</th>"
                    "<th>Lig</th></tr></thead><tbody>%s</tbody></table></div>"
                    % (ad, len(L), notu,
                       "".join("<tr><td>%s</td><td>%s - %s</td><td class='b'>%s</td><td class='b'>%s</td>"
                               "<td>%s</td><td class='mini'>%s</td></tr>"
                               % (H.escape(z[0]), H.escape(z[1]), H.escape(z[2]), H.escape(z[3]),
                                  H.escape(z[5] or "–"), H.escape(z[4]), H.escape(z[6] or "")) for z in L)))
        if kap:
            O = (m.get("o") if not krec.get("kapanis") else krec["kapanis"])
            govde.append("<div class='card'><h3>📉 KAPANIŞ ORANI KIYASI — kapanış %.2f / %.2f / %.2f (±%%%s)</h3></div>"
                         % (O[0], O[1], O[2], kap.get("tol")))
            govde.append(kp_tablo("KENDİ LİGİ — %s" % H.escape(kap.get("lig_adi", m.get("lig", ""))),
                                  kap.get("ornek") or [], "aynı kapanış oranıyla biten maçlar"))
            govde.append(kp_tablo("TÜM LİGLER", kap.get("ornek_t") or [], "ülke/lig fark etmeksizin aynı kapanış oranıyla biten maçlar"))
        css = ("body{margin:0;background:#f6f7f9;color:#16212e;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif}"
               ".wrap{max-width:1100px;margin:0 auto;padding:14px 12px 60px}"
               ".card{background:#fff;border:1px solid #e3e8ee;border-radius:12px;padding:12px 14px;margin:10px 0}"
               ".mini{font-size:11.5px;color:#68788a}h3{margin:0 0 8px;font-size:14px;color:#0d5c3a}"
               "table.kt{width:100%;border-collapse:collapse}table.kt th{background:#f2f5f8;text-align:left;padding:6px 7px;font-size:12px;position:sticky;top:0}"
               "table.kt td{padding:5px 7px;border-bottom:1px solid #eef1f4;font-size:12.5px}table.kt tr:hover td{background:#f6fbff}"
               "td.b{font-weight:700}a{color:#0969da}")
        nav = ('<div style="max-width:1100px;margin:0 auto;padding:10px 12px 0">'
               '<a href="/bulten">← bülten</a> · <a href="/canli">🔴 canlı takip</a></div>')
        return self.send_html("<!DOCTYPE html><html lang='tr'><head><meta charset='utf-8'>"
                              "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                              "<title>Kıyas — %s</title><style>%s</style></head><body>%s<div class='wrap'>%s</div></body></html>"
                              % (H.escape(m.get("home", "")), css, nav, "".join(govde)))

    def do_GET(self):
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query)
        try:
            if u.path == "/":
                if q.get("ref"):
                    return self.do_report(q)
                n, t = arsiv_bilgi()
                body = INDEX.replace("{ARSIV}", f"{n:,}".replace(",", "."))
                return self.send_html(page("Analiz Merkezi", body))
            if u.path == "/kiyas":
                return self.kiyas_sayfasi(q)
            if u.path == "/canli":
                yol = "/home/user/CANLI.html"
                doc = (open(yol, encoding="utf-8").read() if os.path.exists(yol)
                       else "<div class='card'>Canlı takip henüz üretilmedi. <code>python3 takip.py</code></div>")
                nav = ('<div style="max-width:1100px;margin:0 auto;padding:10px 12px 0">'
                       '<a class="lnk" href="/">← ana sayfa</a> · <a class="lnk" href="/bulten">📋 bülten</a>'
                       ' · <span class="mini">sayfa her 60 sn\'de kendini yeniler</span></div>')
                return self.send_html(doc.replace("<body>", "<body>" + nav, 1))
            if u.path == "/bulten":
                yol = "/home/user/BULTEN.html"
                if os.path.exists(yol):
                    son = open(yol, encoding="utf-8").read()
                else:
                    son = "<div class='card'>Bülten henüz üretilmedi. <code>python3 tam_tarama.py 1 && python3 bulten_tam.py</code></div>"
                nav = ('<div style="max-width:1560px;margin:0 auto;padding:12px 16px 0">'
                       '<a class="lnk" href="/">← ana sayfa</a> · <a class="lnk" href="/tarama">⚡ sadece değer fırsatları</a>'
                       ' · <a class="lnk" href="/arsiv">🗄️ arşiv</a> · <a class="lnk" href="/canli" style="color:#c0392b;font-weight:700">🔴 canlı takip</a></div>')
                return self.send_html(son.replace("<body>", "<body>" + nav, 1))
            if u.path == "/tarama":
                son = None
                with LOCK:
                    son = TARAMA_CACHE.get("html")
                    ts = TARAMA_CACHE.get("t", 0)
                if not son or time.time() - ts > 600:
                    sonuc = T.tarama(0.15, verbose=False)
                    dosya, degerli = T.rapor_html(sonuc, 0.15, "/home/user/Bugunun_Tarama.html")
                    son = open(dosya, encoding="utf-8").read()
                    with LOCK:
                        TARAMA_CACHE.update({"t": time.time(), "html": son, "n": len(sonuc), "d": len(degerli)})
                nav = '<div style="max-width:1250px;margin:0 auto;padding:12px 16px 0"><a class="lnk" href="/">← ana sayfa</a></div>'
                return self.send_html(son.replace("<body>", "<body>" + nav, 1))
            if u.path == "/arsiv":
                st = arsiv_istatistik()
                yil_rows = "".join(
                    f'<tr><td><b>{y}</b></td><td style="text-align:right">{st["yil"][y]:,}</td><td>'.replace(",", ".")
                    + "█" * max(1, int(60 * st["yil"][y] / max(st["yil"].values()))) + "</td></tr>"
                    for y in sorted(st["yil"]))
                ulke_rows = "".join(f'<tr><td>{H.escape(k)}</td><td style="text-align:right">{v:,}</td></tr>'.replace(",", ".")
                                    for k, v in st["ulke"].most_common(25))
                lig_rows = "".join(f'<tr><td>{H.escape(k)}</td><td style="text-align:right">{v}</td></tr>'
                                   for k, v in st["lig"].most_common(20))
                body = (f'<h1>🗄️ Arşiv Durumu</h1>'
                        f'<div class="sub">Arşivdeki oranlar ilgili maçın <b>bet365 kapanış</b> oranlarıdır. Analiz sırasında her aday maçın <b>açılış</b> oranı ayrıca bet365 oran arşivinden çekilir — böylece «aynı oranla açılan maç» eşleşmesi gerçek açılış verisiyle yapılır.</div>'
                        f'<div class="card"><div class="grid">'
                        f'<div class="feat"><b>Toplam maç</b><span style="font-size:22px;color:#5ee7a0">{st["n"]:,}</span></div>'.replace(",", ".")
                        + f'<div class="feat"><b>Tarih aralığı</b><span style="font-size:17px">{st["ilk"]} → {st["son"]}</span></div>'
                        + f'<div class="feat"><b>Lig / ülke</b><span style="font-size:17px">{st["ligsayi"]} lig · {st["ulkesayi"]} ülke</span></div>'
                        + f'<div class="feat"><b>Son güncelleme</b><span style="font-size:17px">{st["mtime"]}</span></div>'
                        + f'</div></div>'
                        + '<div class="card"><h2>Yıllara göre kapsam</h2><table><thead><tr><th>Yıl</th><th style="text-align:right">Maç</th><th>Dağılım</th></tr></thead><tbody>'
                        + yil_rows + '</tbody></table></div>'
                        + '<div class="card"><h2>Ülkeler</h2><table><thead><tr><th>Ülke</th><th style="text-align:right">Maç</th></tr></thead><tbody>'
                        + ulke_rows + '</tbody></table></div>'
                        + '<div class="card"><h2>En çok maçlı ligler</h2><table><thead><tr><th>Lig-sezon</th><th style="text-align:right">Maç</th></tr></thead><tbody>'
                        + lig_rows + '</tbody></table></div>'
                        + '<div style="margin-top:14px"><a class="lnk" href="/">← ana sayfa</a></div>')
                return self.send_html(page("Arşiv Durumu", body))

            if u.path == "/api/ara":
                term = (q.get("q", [""])[0]).strip()
                res = M.search_team(term)
                if not res: return self.send_html('<div class="card">Sonuç bulunamadı. Farklı yazmayı dene (ör. "Atletico").</div>')
                rows = "".join(f'<tr><td><a class="lnk" href="/takim?p={urllib.parse.quote(t["path"])}">{H.escape(t["name"])}</a></td><td>{H.escape(t["country"])}</td></tr>' for t in res)
                return self.send_html('<div class="card"><div class="step"><span class="stepnum">2</span> Takımı seç</div>'
                                      '<table><thead><tr><th>Takım</th><th>Ülke</th></tr></thead><tbody>' + rows + '</tbody></table></div>')
            if u.path == "/takim":
                tp = q.get("p", [""])[0]
                name, ms = M.team_matches(tp, limit=16)
                rows = ""
                for m in ms:
                    lnk = f'/rapor?ref={urllib.parse.quote(m["link"])}' if m["link"] else ""
                    a = f'<a class="lnk" href="{lnk}">analiz →</a>' if lnk else "-"
                    cl = "ok" if m["result"] == "G" else ""
                    rows += (f'<tr><td>{m["date"]}</td><td>{H.escape(m["home"])}</td>'
                             f'<td style="text-align:center"><b>{m["ft"]}</b></td><td>{H.escape(m["away"])}</td>'
                             f'<td style="text-align:center">{m["ht"]}</td><td class="{cl}">{m["result"]}</td><td>{a}</td></tr>')
                body = (f'<h1>{H.escape(name or tp)}</h1><div class="sub">Son maçlar — analiz etmek istediğin maçın satırındaki "analiz →" bağlantısına tıkla.</div>'
                        f'<div class="card"><table><thead><tr><th>Tarih</th><th>Ev</th><th>MS</th><th>Deplasman</th><th>İY</th><th>Sonuç</th><th></th></tr></thead><tbody>{rows}</tbody></table></div>'
                        f'<div style="margin-top:14px"><a class="lnk" href="/">← ana sayfa</a></div>')
                return self.send_html(page("Takım", body))
            if u.path in ("/rapor", "/api/rapor"):
                return self.do_report(q)
            self.send_html("<div class='err'>Sayfa yok</div>", 404)
        except Exception as ex:
            import traceback; traceback.print_exc()
            return self.send_html(f"<div class='err'><b>Hata:</b> {H.escape(str(ex))}<br>"
                                  f"Linkin BetExplorer maç sayfası olduğundan emin ol.</div>", 500)
    def do_report(self, q):
        ref = q.get("ref", [""])[0]
        kat = q.get("kat", ["0.10"])[0]
        if not ref: return self.send_html("<div class='err'>Maç linki gerekli</div>", 400)
        htmlout = self.cached_html(ref, kat)
        if htmlout is None:
            P = self.get_P(ref)
            # istenen katman boşsa veri olan katmana düş (önbelleği doğru anahtarla sakla)
            K = P["kat"]
            if not K.get(kat):
                for alt in ("kapanis", "0.05", "0.10", "0.15", "0.00"):
                    if K.get(alt): kat = alt; break
            htmlout = R.render(P, kat)
            self.store_html(ref, kat, htmlout)
        if q.get("embed"):
            return self.send_html(htmlout)
        nav = ('<div style="max-width:1180px;margin:0 auto;padding:12px 16px 0">'
               '<a class="lnk" href="/">← yeni analiz</a> '
               f'<span class="sub" style="margin-left:8px">katman: <b>{H.escape(kat)}</b></span></div>')
        return self.send_html(htmlout.replace("<body>", "<body>" + nav, 1))

if __name__ == "__main__":
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), App)
    print(f"ANALİZ MERKEZİ v2 → http://0.0.0.0:{PORT}")
    srv.serve_forever()
