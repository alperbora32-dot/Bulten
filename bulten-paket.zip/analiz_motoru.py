#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ANALİZ MOTORU v1.0
Herhangi bir BetExplorer maçı için:
  1) Tüm marketlerde oran arşivi (açılış/kapanış + her hareket)
  2) Tüm bahisçi karşılaştırması
  3) H2H tarihçesi (İY skorlarıyla)
  4) 55.605 maçlık yerel arşivde "aynı oranla açılan/kapanan" maç taraması + bet365 doğrulaması
  5) Derin istatistik (MS/İY dağılımı, İY-MS matrisi, alt-üst, KG, korner)
  6) Poisson modeli (implied olasılık, adil oran, beklenen gol, skor matrisi)
  7) Değer (value) tablosu: tarihsel isabet vs piyasa olasılığı
  8) Form analizi (son maçlar, ev/deplasman ayrımı)
  9) "Steam" hareket analizi (açılıştan kapanışa sert kaymalar)
"""
import json, re, subprocess, time, math, html as H, os, sys, urllib.parse
from concurrent.futures import ThreadPoolExecutor
from collections import Counter

BASE="https://www.betexplorer.com"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
COOKIE="age_verified=true; js_cookie=1; my_timezone=%2B1"
OUT="/home/user/veri"
INDEX=f"{OUT}/all_matches.json"

# ---------------------------------------------------------------- HTTP
_COOL=[0.0]
def curl(u, n=25, ref=None):
    """429/403 durumunda artan beklemeli, dayanıklı indirme."""
    s=""
    for deneme in range(4):
        try:
            cmd=["curl","-s","-m",str(n),"-w","\n%{http_code}","-A",UA,"-H","Cookie: "+COOKIE,
                 "-H","Accept-Language: en-US,en;q=0.9","-H","Accept-Encoding: gzip","--compressed"]
            if ref: cmd+=["-e",ref]
            r=subprocess.run(cmd+[u],capture_output=True,timeout=n+8)
            raw=r.stdout.decode("utf-8","ignore")
            kod=raw.rsplit("\n",1)[-1].strip()
            if kod in ("429","403"):
                _COOL[0]=max(1.5, min(6.0, (_COOL[0] or 1.5)*1.4))
                time.sleep(_COOL[0]+deneme); continue
            s=raw.rsplit("\n",1)[0]
            if s and len(s)>150:
                if _COOL[0]>0: _COOL[0]=max(0.0,_COOL[0]-2.0)
                return s
        except Exception: pass
        time.sleep(0.5+_COOL[0])
    return s

def jsonget(u,n=25):
    try: return json.loads(curl(u,n))
    except Exception: return None

# ---------------------------------------------------------------- ARAMA / TAKIM
def search_team(q):
    h=curl(f"{BASE}/gres/ajax/search.php?text={urllib.parse.quote(q)}&sid=1&lang=en",20)
    out=[]; seen=set()
    for m in re.finditer(r'href="(/football/team/[^"]+)"[^>]*>(.*?)\(([^)]*)\)\s*</a>',h,re.S):
        nm=H.unescape(re.sub(r'<[^>]+>','',m.group(2))).strip()
        if not nm or m.group(1) in seen: continue
        seen.add(m.group(1))
        out.append({"path":m.group(1),"name":nm,"country":m.group(3),"id":m.group(1).strip('/').split('/')[-1]})
    return out[:12]

def team_matches(team_path, limit=12):
    """Takımın maçları: tarih, rakip, skor (İY), sonuç."""
    tp=team_path.rstrip('/')
    if not tp.endswith('/results'): tp=tp+"/results/"
    h=curl(BASE+tp,30).replace('&nbsp;',' ')
    team_name=""
    m=re.search(r'id="headerTitle".*?<h1[^>]*>([^<]*)</h1>',h,re.S)
    if m: team_name=H.unescape(m.group(1)).replace('Results & Fixtures','').strip()
    rows=re.findall(r'<tr data-ttid="\d+"[^>]*>(.*?)</tr>',h,re.S)
    res=[]
    for r in rows[:limit]:
        ic=re.search(r'icon__([wdl])',r)
        cells=re.findall(r'<td[^>]*>(.*?)</td>',r,re.S)
        if len(cells)<5: continue
        txt=[re.sub(r'<[^>]+>','',c).strip() for c in cells]
        sc=re.search(r'(\d+):(\d+)\s*\((\d+):(\d+),\s*(\d+):(\d+)\)',r)
        link=re.search(r'href="(/football/[^"]*/[A-Za-z0-9]{8}/)"',r)
        our=re.findall(r'<strong>([^<]*)</strong>',r)
        home=re.sub(r'<[^>]+>','',cells[2]) if len(cells)>2 else ''
        away=re.sub(r'<[^>]+>','',cells[3]) if len(cells)>3 else ''
        day=re.search(r'h-text-right h-text-no-wrap">\s*([^<]*)<',r)
        if not sc: continue
        fh,fa,hh,ha,sh,sa=[int(x) for x in sc.groups()]
        is_home = (our and re.sub(r'<[^>]+>','',cells[2]).strip()==our[0].strip()) if len(cells)>2 else False
        res.append({"date":day.group(1).strip() if day else "","home":home.strip(),"away":away.strip(),
            "ft":f"{fh}:{fa}","ht":f"{hh}:{ha}","sh":f"{sh}:{sa}",
            "our_is_home":is_home,"our_goals":fh if is_home else fa,"opp_goals":fa if is_home else fh,
            "ht_our":hh if is_home else ha,"ht_opp":ha if is_home else hh,
            "result":{"w":"G","d":"B","l":"M"}.get(ic.group(1) if ic else '','?'),
            "link":link.group(1) if link else ""})
    return team_name,res

# ---------------------------------------------------------------- MAÇ ÇÖZÜMLEME
def resolve_match(ref):
    """ref: tam URL, yol veya 8 karakterlik maç ID'si"""
    ref=ref.strip()
    eid=None; path=None
    if ref.startswith('http'): 
        u=ref; eid=u.strip('/').split('/')[-1]
        path=re.sub(r'^https?://[^/]+','',u)
    elif ref.startswith('/'): path=ref; eid=ref.strip('/').split('/')[-1]
    elif len(ref)==8: eid=ref
    info={"eid":eid,"path":path}
    if path:
        h=curl(BASE+path,30)
        m=re.search(r'id="headerTitle".*?<h1[^>]*>([^<]*)</h1>',h,re.S)
        info["title"]=H.unescape(m.group(1)).strip() if m else ''
        m=re.search(r'data-dt="([^"]*)"',h); info["dt"]=m.group(1) if m else ''
        m=re.search(r'id="js-score">(.*?)</p>',h,re.S); info["score"]=re.sub(r'<[^>]+>','',m.group(1)).strip() if m else ''
        m=re.search(r'id="js-partial">(.*?)</div>',h,re.S); info["partial"]=re.sub(r'<[^>]+>','',m.group(1)).strip() if m else ''
        teams=re.findall(r'href="(/football/team/[^"]+)"[^>]*>.*?list-details__item__title teamsLink">([^<]*)<',h,re.S)
        if len(teams)>=2:
            info["home"]=H.unescape(teams[0][1]).strip(); info["away"]=H.unescape(teams[1][1]).strip()
            info["home_path"]=teams[0][0]; info["away_path"]=teams[1][0]
            info["home_id"]=teams[0][0].strip('/').split('/')[-1]; info["away_id"]=teams[1][0].strip('/').split('/')[-1]
        bp=re.findall(r'breadcrumb__li__mobile"><a href="([^"]+)"[^>]*>([^<]*)</a>',h)
        if len(bp)>=3: info["country"]=bp[-2][1]; info["league"]=bp[-1][1]; info["league_path"]=bp[-1][0]
    return info

# ---------------------------------------------------------------- ORAN ARŞİVİ
def parse_odds(h,market):
    out=[]
    for row in re.findall(r'<tr[^>]*>(.*?)</tr>',h,re.S):
        if 'data-odd' not in row: continue
        line=''
        m=re.search(r'<td class="table-main__doubleparameter">([^<]*)</td>',row)
        if m: line=H.unescape(m.group(1)).strip()
        book=''
        b=re.search(r'class="in-bookmaker-logo-link[^"]*"[^>]*>([^<]*)<',row)
        if b: book=b.group(1).strip()
        for td in re.findall(r'<td[^>]*data-odd="[^"]*"[^>]*>',row):
            g=lambda k:(re.search(k+r'="([^"]*)"',td).group(1) if re.search(k+r'="([^"]*)"',td) else '')
            out.append({"market":market,"line":line,"bookmaker":g('data-bookie') or book,
                        "odd":g('data-odd'),"created":g('data-created'),"pos":g('data-pos'),
                        "oid":g('data-oid'),"bid":g('data-bid') or g('data-bookmaker-id'),
                        "bt":g('data-bt'),"sc":g('data-sc'),"hcp":g('data-hcp')})
    return out

MARKETS=["1x2","ou","ah","ha","dc","bts"]
def fetch_markets(eid, markets=MARKETS):
    def w(bt):
        j=jsonget(f"{BASE}/match-odds/{eid}/1/{bt}/odds/?lang=en",20)
        return bt, parse_odds(j.get("odds",""),bt) if j else []
    with ThreadPoolExecutor(max_workers=6) as ex:
        return dict(ex.map(w,markets))

def archive_odds(rec):
    if not (rec.get('oid') and rec.get('bid')): return None
    j=jsonget(f"{BASE}/archive-odds/{rec['oid']}/{rec['bid']}/{rec['bt']}/{rec['sc']}/{rec['hcp']}/",20)
    return j if isinstance(j,list) and j else None

def odds_archive(markets, bookmaker_prefix="bet365", limit=None):
    tasks=[(bt,r) for bt,recs in markets.items() for r in recs if r["bookmaker"].lower().startswith(bookmaker_prefix)]
    if limit: tasks=tasks[:limit]
    def w(t):
        bt,r=t; a=archive_odds(r)
        return {"market":bt,"line":r["line"],"pos":r["pos"],"odd":r["odd"],"created":r["created"],"hist":a}
    with ThreadPoolExecutor(max_workers=8) as ex:
        res=[x for x in ex.map(w,tasks) if x and x["hist"]]
    return res

# ---------------------------------------------------------------- H2H
def h2h_archive(league_path, home_id, away_id, max_pages=18):
    """Karşılıklı maçlar: hem div (J1) hem tablo (EPL) varyantını destekler."""
    h=curl(BASE+league_path+"mutual-matches/?home="+home_id+"&away="+away_id,30).replace('&nbsp;',' ')
    rows=[]; cur_comp=''
    # --- Varyant A: div tabanlı ---
    for b in re.split(r'<div class="percentage-bar__column"',h)[1:]:
        c=re.search(r'leaguesNames leaguesNames">([^<]*)</a>',b)
        if c: cur_comp=H.unescape(c.group(1)).strip()
        for r in re.split(r'<div class="head-to-head__row"',b)[1:]:
            dt=re.search(r'data-dt="([^"]*)"',r)
            sc=re.search(r'w35"[^>]*>\s*<span>(\d+)</span>\s*<span> : </span>\s*<span>(\d+)</span>',r)
            link=re.search(r'href="(/football/[^"]*/[A-Za-z0-9]{8}/)"',r)
            if not link: continue
            hp=link.group(1).strip('/').split('/')[-2].split('-')[0]
            rows.append({"comp":cur_comp,"dt":dt.group(1) if dt else "",
                "hg":int(sc.group(1)) if sc else None,"ag":int(sc.group(2)) if sc else None,
                "link":link.group(1),"odds":re.findall(r'data-odd="([\d\.]+)"',r)[:3],
                "home_first": hp.startswith('kyoto') or hp[:4]==home_id[:4].lower()})
    # --- Varyant B: tablo tabanlı ---
    if not rows:
        h2=h.replace('&nbsp;',' ')
        for tr in re.findall(r'(<tr[^>]*>.*?</tr>)',h2,re.S):
            if 'head-to-head__header' in tr:
                c=re.search(r'<a href="[^"]*(?:league|cup)[^"]*">([^<]*)</a>',tr)
                cur_comp=H.unescape(c.group(1)).strip() if c else cur_comp
                continue
            a=re.search(r'<td[^>]*>\s*(?:<strong>)?([^<]+?)(?:</strong>)?\s*</td>\s*<td[^>]*>\s*(?:<strong>)?([^<]+?)(?:</strong>)?\s*</td>\s*<td class="h-text-center">\s*<a href="(/football/[^"]+/[A-Za-z0-9]{8}/)"[^>]*>\s*(?:<strong>)?(\d+):(\d+)',tr)
            if not a: continue
            d=re.search(r'(\d{2}\.\d{2}\.\d{4})',tr) or re.search(r'(\d{2}\.\d{2}\.\d{2})',tr)
            rows.append({"comp":cur_comp,"dt":d.group(1) if d else "",
                "hg":int(a.group(4)),"ag":int(a.group(5)),"link":a.group(3),
                "odds":re.findall(r'data-odd="([\d\.]+)"',tr)[:3],
                "home_first":True,
                "home_name":H.unescape(a.group(1)).strip(),"away_name":H.unescape(a.group(2)).strip()})
    # --- İY skorları + tarih ---
    def w(r):
        hh=curl(BASE+r["link"],25).replace('&nbsp;',' ')
        nm=re.findall(r'list-details__item__title teamsLink">([^<]*)<',hh)
        if len(nm)>=2:
            r["home_name"]=H.unescape(nm[0]).strip(); r["away_name"]=H.unescape(nm[1]).strip()
        m=re.search(r'id="js-partial">(.*?)</div>',hh,re.S)
        if m:
            t=re.sub(r'<[^>]+>','',m.group(1)).strip()
            mm=re.match(r'\((\d+):(\d+),\s*(\d+):(\d+)\)',t)
            if mm: r.update(ht_h=int(mm.group(1)),ht_a=int(mm.group(2)))
        if not r.get("dt"):
            m2=re.search(r'data-dt="([^"]*)"',hh)
            if m2: r["dt"]=m2.group(1)
        return r
    with ThreadPoolExecutor(max_workers=10) as ex:
        rows=list(ex.map(w,rows[:max_pages]))
    return rows

# ---------------------------------------------------------------- YEREL ARŞİV
_INDEX=None
def load_index():
    global _INDEX
    if _INDEX is None:
        try: _INDEX=json.load(open(INDEX,encoding="utf-8"))
        except Exception: _INDEX=[]
    return _INDEX

def screen(target, tol=0.22, exclude_id=None):
    ms=load_index()
    return [m for m in ms if m.get("id")!=exclude_id and
            abs(m["o1"]-target["1"])<=tol and abs(m["ox"]-target["0"])<=tol and abs(m["o2"]-target["2"])<=tol]

def b365_row(eid):
    j=jsonget(f"{BASE}/match-odds/{eid}/1/1x2/odds/?lang=en",20)
    if not j: return None
    h=j.get("odds","")
    for row in re.findall(r'<tr[^>]*>(.*?)</tr>',h,re.S):
        if 'bet365' not in row.lower(): continue
        res={}
        for td in re.findall(r'<td[^>]*data-odd="[^"]*"[^>]*>',row):
            pos=re.search(r'data-pos="([^"]*)"',td); odd=re.search(r'data-odd="([^"]*)"',td)
            if not pos or not odd: continue
            g=lambda k:(re.search(k+r'="([^"]*)"',td).group(1) if re.search(k+r'="([^"]*)"',td) else '')
            res[pos.group(1)]={"odd":odd.group(1),"oid":g('data-oid'),"bt":g('data-bt'),"sc":g('data-sc'),
                               "hcp":g('data-hcp'),"bid":g('data-bid') or g('data-bookmaker-id')}
        if {'1','0','2'}<=set(res): return res
    return None

def verify_candidates(cands, limit=90, target=None, ht_limit=None):
    """Adayların gerçek bet365 oran + İY bilgisini çek. target verilirse ona en yakınlar önce."""
    if target:
        t=target
        cands=sorted(cands,key=lambda c:abs(c['o1']-t['1'])+abs(c['ox']-t['0'])+abs(c['o2']-t['2']))
    cands=cands[:limit]
    def w(m):
        b=b365_row(m["id"])
        if not b: return None
        r=dict(m); r["b365"]={k:float(v["odd"]) for k,v in b.items() if k in ('1','0','2')}
        if len(r["b365"])<3: return None
        if ht_ids is not None and m["id"] not in ht_ids: return r
        h=curl(BASE+m["link"],25)
        mm=re.search(r'id="js-partial">(.*?)</div>',h,re.S)
        if mm:
            t=re.sub(r'<[^>]+>','',mm.group(1)).strip()
            x=re.match(r'\((\d+):(\d+),\s*(\d+):(\d+)\)',t)
            if x: r.update(ht_h=int(x.group(1)),ht_a=int(x.group(2)))
        return r
    ht_ids={c["id"] for c in cands[:ht_limit]} if ht_limit is not None else None
    with ThreadPoolExecutor(max_workers=8) as ex:
        return [x for x in ex.map(w,cands) if x]

# ---------------------------------------------------------------- İSTATİSTİK
def deep_stats(ms):
    if not ms: return None
    n=len(ms); hw=sum(1 for c in ms if c['hg']>c['ag']); dr=sum(1 for c in ms if c['hg']==c['ag']); aw=n-hw-dr
    tot=[c['hg']+c['ag'] for c in ms]; ht=[c for c in ms if 'ht_h' in c]
    d=dict(n=n,hw=hw,dr=dr,aw=aw,hwp=100*hw/n,drp=100*dr/n,awp=100*aw/n,
        avg=sum(tot)/n,o15=100*sum(1 for t in tot if t>1.5)/n,o25=100*sum(1 for t in tot if t>2.5)/n,
        o35=100*sum(1 for t in tot if t>3.5)/n,btts=100*sum(1 for c in ms if c['hg']>0 and c['ag']>0)/n,
        gg=100*sum(1 for t in tot if t==0)/n,
        scores=Counter(f"{c['hg']}-{c['ag']}" for c in ms).most_common(8))
    if ht:
        nh=len(ht)
        d.update(htn=nh,ht00=100*sum(1 for c in ht if c['ht_h']==0 and c['ht_a']==0)/nh,
                 ht15=100*sum(1 for c in ht if c['ht_h']+c['ht_a']>1.5)/nh,
                 htkg=100*sum(1 for c in ht if c['ht_h']>0 and c['ht_a']>0)/nh,
                 htw=100*sum(1 for c in ht if c['ht_h']>c['ht_a'])/nh,htx=100*sum(1 for c in ht if c['ht_h']==c['ht_a'])/nh,
                 hta=100*sum(1 for c in ht if c['ht_a']>c['ht_h'])/nh,
                 same=100*sum(1 for c in ht if (c['ht_h']>c['ht_a'])-(c['ht_h']<c['ht_a'])==(c['hg']>c['ag'])-(c['hg']<c['ag']))/nh,
                 matrix=Counter((('1' if c['ht_h']>c['ht_a'] else 'X' if c['ht_h']==c['ht_a'] else '2'),
                                 ('1' if c['hg']>c['ag'] else 'X' if c['hg']==c['ag'] else '2')) for c in ht))
    return d

# ---------------------------------------------------------------- POISSON
def _pois(k,l): return math.exp(-l)*l**k/math.factorial(k)
def poisson_model(o1,ox,o2,gmax=9):
    inv=[1/o1,1/ox,1/o2]; s=sum(inv); p=[x/s for x in inv]   # marj arındırılmış
    best=None
    for lh in [x/25 for x in range(5,101)]:
        for la in [x/25 for x in range(5,101)]:
            ph=px=pa=0.0
            for i in range(gmax):
                pi=_pois(i,lh)
                for j in range(gmax):
                    pr=pi*_pois(j,la)
                    if i>j: ph+=pr
                    elif i==j: px+=pr
                    else: pa+=pr
            e=(ph-p[0])**2+(px-p[1])**2+(pa-p[2])**2
            if best is None or e<best[0]: best=(e,lh,la)
    _,lh,la=best
    mat={}
    for i in range(6):
        for j in range(6): mat[(i,j)]=_pois(i,lh)*_pois(j,la)
    o15=sum(v for (i,j),v in mat.items() if i+j>1.5); o25=sum(v for (i,j),v in mat.items() if i+j>2.5)
    o35=sum(v for (i,j),v in mat.items() if i+j>3.5); bt=sum(v for (i,j),v in mat.items() if i>0 and j>0)
    return dict(p1=p[0],px=p[1],p2=p[2],margin=100*(sum(inv)-1),lh=lh,la=la,total=lh+la,
                o15=100*o15,o25=100*o25,o35=100*o35,btts=100*bt,
                top=sorted(mat.items(),key=lambda x:-x[1])[:8])
def fair(o): return 1/o
def implied(odds_list):
    inv=[1/o for o in odds_list]; s=sum(inv); return [100*x/s for x in inv], 100*(s-1)

# ---------------------------------------------------------------- RAPOR
def sgn(x): return "▲" if x>0.5 else ("▼" if x<-0.5 else "=")
def _html(P,mv,bk,hh,hhx,tbl,form,model,val,mtx,korner):
    st=P["stats"]; i=P["info"]
    small=(lambda g: f"{g['awp']:.0f}") if st else (lambda g:"-")
    return f"""<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{H.escape(i.get('home',''))} - {H.escape(i.get('away',''))} | Analiz</title><style>{CSS}</style></head><body><div class="wrap">
<h1>{H.escape(i.get('home','Ev Sahibi'))} — {H.escape(i.get('away','Deplasman'))}</h1>
<div class="sub">{H.escape(i.get('league',''))} · {H.escape(i.get('country',''))} · {i.get('dt','').replace(',','.').replace('..','. ')} · bet365 kapanış: <b>{P['close_1x2']['1']}/{P['close_1x2']['0']}/{P['close_1x2']['2']}</b></div>
<div class="grid g4">
<div class="kpi"><div class="l">Benzer oranlı maç (±0.05)</div><div class="v">{P['g5']}</div></div>
<div class="kpi alt"><div class="l">±0.10</div><div class="v">{P['g10']}</div></div>
<div class="kpi alt2"><div class="l">±0.15</div><div class="v">{P['g15']}</div></div>
<div class="kpi red"><div class="l">Deplasman kazanma (±0.15)</div><div class="v">%{st['awp']:.0f}</div></div>
</div>
<h2>1 · Oran Hareketleri (açılış → kapanış, tüm marketler)</h2>
<div class="scroll"><table><thead><tr><th>Market</th><th>Çizgi</th><th>Sonuç</th><th>AÇILIŞ</th><th>KAPANIŞ</th><th>En düşük</th><th>En yüksek</th><th>Değişim</th><th>Hareket</th><th>Son kayıt</th></tr></thead><tbody>{mv}</tbody></table></div>
<h2>2 · Karşılıklı Tarihçe (H2H)</h2>
<div class="scroll"><table><thead><tr><th>Tarih</th><th>Turnuva</th><th>MS</th><th>İY</th><th>1X2 Oran</th><th>Link</th></tr></thead><tbody>{hh}</tbody></table></div>
<h2>3 · Aynı Oranlarla Oynanan Maçlar (tüm ligler)</h2>
<div class="note">Yerel arşivde (55.605 maç) bu kapanış oranına en yakın maçlar; gerçek bet365 oranı doğrulanmış <b>{P['g15']}</b> maç gösteriliyor. ±0.05: {P['g5']} · ±0.10: {P['g10']}</div>
<div class="scroll">{tbl(P['sim15'])}</div>
<h2>4 · Derin İstatistik</h2>
<div class="grid g4">
<div class="kpi"><div class="l">Deplasman (favori) kazanma</div><div class="v">%{st['awp']:.0f}</div><div class="bar"><i style="width:{st['awp']:.0f}%"></i></div></div>
<div class="kpi alt"><div class="l">Beraberlik</div><div class="v">%{st['drp']:.0f}</div><div class="bar"><i style="width:{st['drp']:.0f}%"></i></div></div>
<div class="kpi red"><div class="l">Ev sahibi</div><div class="v">%{st['hwp']:.0f}</div><div class="bar"><i style="width:{st['hwp']:.0f}%"></i></div></div>
<div class="kpi alt2"><div class="l">Maç başı gol</div><div class="v">{st['avg']:.2f}</div></div>
</div>
<div class="grid g2">
<div class="card"><b>Alt/Üst & KG (benzer maçlar)</b><ul>
<li>1.5 ÜST <b>%{st['o15']:.0f}</b> · 2.5 ÜST <b>%{st['o25']:.0f}</b> · 3.5 ÜST <b>%{st['o35']:.0f}</b></li>
<li>KG Var <b>%{st['btts']:.0f}</b> · 0-0 <b>%{st['gg']:.0f}</b></li>
<li>En sık skorlar: {" · ".join(f"{k}({v})" for k,v in st['scores'][:5])}</li></ul></div>
<div class="card"><b>İlk Yarı metrikleri</b><ul>
<li>İY 0-0 <b>%{st.get('ht00',0):.0f}</b> · İY 1.5 ÜST <b>%{st.get('ht15',0):.0f}</b> · İY KG <b>%{st.get('htkg',0):.0f}</b></li>
<li>İY'de favori önde <b>%{st.get('hta',0):.0f}</b> · İY beraberlik <b>%{st.get('htx',0):.0f}</b></li>
<li>İY/MS aynı sonuç <b>%{st.get('same',0):.0f}</b></li></ul></div></div>
<h3>İY/MS Matrisi</h3>{mtx}
<h2>5 · Poisson Modeli</h2>{model}
<h2>6 · Değer (Value) Tablosu</h2>
<div class="note">Tarihsel isabet oranı ile piyasa olasılığı karşılaştırması. Fark +3 puan üzeri ise "DEĞER", -3 altı "PAHALI".</div>
{val}
{korner}
<h2>7 · Form Analizi</h2>{form}
<h2>8 · Tüm Bahisçiler</h2>{bk}
<footer>Analiz motoru v1.0 · Kaynak: BetExplorer oran arşivi + 55.605 maçlık 2010-2026 taraması + SoccerSTATS · Bu rapor istatistiksel analizdir, bahis tavsiyesi değildir.</footer>
</div></body></html>"""

CSS="""*{box-sizing:border-box}body{margin:0;background:#0f1720;color:#e8eef5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;line-height:1.5}
.wrap{max-width:1240px;margin:0 auto;padding:24px 16px 60px}
h1{font-size:26px;margin:0 0 4px;background:linear-gradient(90deg,#5ee7a0,#4fc3f7);-webkit-background-clip:text;background-clip:text;color:transparent}
h2{font-size:19px;margin:30px 0 10px;padding-left:10px;border-left:4px solid #5ee7a0}
h3{font-size:15px;margin:18px 0 6px;color:#9fd6ff}
.sub{color:#8ba3b8;font-size:13px;margin-bottom:14px}
.card{background:#16202b;border:1px solid #243244;border-radius:10px;padding:12px 14px;margin:10px 0}
.grid{display:grid;gap:12px}.g2{grid-template-columns:repeat(2,1fr)}.g4{grid-template-columns:repeat(4,1fr)}
@media(max-width:860px){.g2,.g4{grid-template-columns:1fr}}
.kpi{background:linear-gradient(160deg,#182533,#131c25);border:1px solid #2a3a4d;border-radius:10px;padding:10px 12px}
.kpi .v{font-size:22px;font-weight:800;color:#5ee7a0}.kpi .l{font-size:11px;color:#8ba3b8;text-transform:uppercase;letter-spacing:.4px}
.kpi.alt .v{color:#ffce54}.kpi.alt2 .v{color:#4fc3f7}.kpi.red .v{color:#ff7b7b}
.bar{height:8px;background:#1b2836;border-radius:5px;overflow:hidden;margin-top:4px}.bar i{display:block;height:100%;background:linear-gradient(90deg,#5ee7a0,#4fc3f7)}
table{width:100%;border-collapse:collapse;font-size:12.5px;margin:6px 0}
th,td{border:1px solid #243244;padding:5px 7px;text-align:left}
th{background:#1b2836;color:#9fd6ff;position:sticky;top:0}
tbody tr:nth-child(even){background:#141d27}tbody tr:hover{background:#1d2a38}
.od{text-align:center;font-weight:700;color:#ffce54;font-variant-numeric:tabular-nums}
.sc{text-align:center;font-weight:700}.tm{color:#7f95a8;font-size:11px;text-align:center}.lg{color:#a8c0d6;font-size:11.5px}
.up{color:#ff7b7b;text-align:center;font-weight:700}.down{color:#5ee7a0;text-align:center;font-weight:700}.flat{color:#8ba3b8;text-align:center}
.badge{display:inline-block;padding:1px 7px;border-radius:999px;font-size:11px;font-weight:700}
.b-dep{background:#12351f;color:#5ee7a0;border:1px solid #1f6b3c}.b-ev{background:#3a1a1a;color:#ff9c9c;border:1px solid #6b2020}
.b-b{background:#3a3418;color:#ffd76e;border:1px solid #6b5f20}
.chip{display:inline-block;background:#1b2836;border:1px solid #2a3a4d;border-radius:8px;padding:3px 8px;margin:2px;font-size:12px}.chip b{color:#5ee7a0}
.note{background:#1a2430;border-left:4px solid #4fc3f7;padding:9px 12px;border-radius:0 8px 8px 0;font-size:12.5px;color:#b9cde0;margin:8px 0}
.scroll{max-height:560px;overflow:auto;border:1px solid #243244;border-radius:8px}
.mx .hl{background:#1f3a2a;color:#a8f0c8;font-weight:700}.mx .zr{color:#3c4c5c;text-align:center}.mx .pc{color:#7f95a8;font-size:10px}
a.lnk{color:#4fc3f7;text-decoration:none}
footer{margin-top:30px;color:#63798c;font-size:11.5px;border-top:1px solid #243244;padding-top:12px}"""

# ---------------------------------------------------------------- ANA PIPELINE
def analyze(ref, tol_close=0.15, tol_screen=0.22, do_form=True, do_corner=True, progress=print, do_candidates=True):
    t0=time.time()
    info=resolve_match(ref)
    if not info.get("eid"): raise ValueError("Maç ID bulunamadı. BetExplorer maç linkini ver.")
    eid=info["eid"]; progress(f"Maç: {info.get('home')} - {info.get('away')} ({eid})")
    markets=fetch_markets(eid)
    progress(f"Marketler çekildi: "+", ".join(f"{k}:{len(v)}" for k,v in markets.items()))
    oa=odds_archive(markets,"bet365")
    progress(f"Oran hareket arşivi: {len(oa)} hücre")
    # kapanış 1x2 (bet365)
    br=b365_row(eid)
    if br: close={"1":float(br['1']['odd']),"0":float(br['0']['odd']),"2":float(br['2']['odd'])}
    else:
        r12=[r for r in markets.get("1x2",[]) if r["pos"] in ("1","0","2")]
        close={}
        for r in r12: close.setdefault(r["pos"],float(r["odd"] or 0))
        if len(close)<3: raise ValueError("1X2 oranı bulunamadı")
    progress(f"bet365 kapanış 1X2: {close['1']} / {close['0']} / {close['2']}")
    # benzer maçlar (v2 kendi taramasını yapar → do_candidates=False ile atlanır)
    g5=g10=g15=[]; stats={}
    if do_candidates:
        cands=screen(close,tol_screen,eid)
        progress(f"Yerel arşivde {len(cands)} aday (ekran ±{tol_screen}) → bet365 doğrulaması...")
        ver=verify_candidates(cands,limit=90,target=close)
        def G(t): return [c for c in ver if all(abs(c["b365"][k]-close[k])<=t for k in ("1","0","2"))]
        g5,g10,g15=G(0.05),G(0.10),G(tol_close)
        progress(f"Doğrulanan: {len(ver)} | ±0.05:{len(g5)} ±0.10:{len(g10)} ±{tol_close}:{len(g15)}")
        stats=deep_stats(g15) or {}
    # H2H
    h2h=[]
    if info.get("league_path") and info.get("home_id"):
        h2h=h2h_archive(info["league_path"],info["home_id"],info["away_id"])
        progress(f"H2H: {len(h2h)} maç")
    # form
    fh=fa=("",[])
    if do_form and info.get("home_path"):
        try:
            fh=team_matches(info["home_path"]); fa=team_matches(info["away_path"])
        except Exception as e: progress(f"form hatası: {e}")
    # korner
    corner=None
    if do_corner:
        try: corner=fetch_corners(info.get("home"),info.get("away"),info.get("country"))
        except Exception: pass
    pm=poisson_model(close["1"],close["0"],close["2"])
    P=dict(info=info,markets=markets,odds=oa,close_1x2=close,sim5=g5,sim10=g10,sim15=g15,
           g5=len(g5),g10=len(g10),g15=len(g15),stats=stats,h2h=h2h,form_home=fh,form_away=fa,
           poisson=pm,corner=corner,elapsed=round(time.time()-t0,1))
    progress(f"Bitti ({P['elapsed']}s)")
    return P

SS_SLUG={"england":"england","spain":"spain","italy":"italy","germany":"germany","turkey":"turkey","france":"france",
"japan":"japan","netherlands":"netherlands","portugal":"portugal","belgium":"belgium","scotland":"scotland","russia":"russia",
"brazil":"brazil","argentina":"argentina","usa":"usa","mexico":"mexico","greece":"greece","austria":"austria","switzerland":"switzerland",
"denmark":"denmark","norway":"norway","sweden":"sweden","poland":"poland","czech republic":"czechrepublic","romania":"romania",
"ukraine":"ukraine","croatia":"croatia","serbia":"serbia","bulgaria":"bulgaria","hungary":"hungary","slovakia":"slovakia",
"finland":"finland","ireland":"ireland","israel":"israel","china":"china","south korea":"southkorea","australia":"australia",
"saudi arabia":"saudiarabia","egypt":"egypt","morocco":"morocco","chile":"chile","colombia":"colombia","peru":"peru","uruguay":"uruguay",
"ecuador":"ecuador","paraguay":"paraguay","bolivia":"bolivia","venezuela":"venezuela","nigeria":"nigeria","south africa":"southafrica",
"india":"india","indonesia":"indonesia","thailand":"thailand","vietnam":"vietnam","malaysia":"malaysia","singapore":"singapore",
"new zealand":"newzealand","canada":"canada","costa rica":"costarica","honduras":"honduras","guatemala":"guatemala","panama":"panama",
"jamaica":"jamaica","iceland":"iceland","cyprus":"cyprus","belarus":"belarus","slovenia":"slovenia","bosnia and herzegovina":"bosnia",
"albania":"albania","macedonia":"macedonia","kazakhstan":"kazakhstan","uzbekistan":"uzbekistan","iran":"iran","iraq":"iraq",
"qatar":"qatar","united arab emirates":"uae","kuwait":"kuwait","jordan":"jordan","tunisia":"tunisia","algeria":"algeria",
"ghana":"ghana","kenya":"kenya","tanzania":"tanzania","zambia":"zambia","zimbabwe":"zimbabwe","cameroon":"cameroon","senegal":"senegal"}

def fetch_corners(home, away, country=None, league_tid=None):
    """soccerstats.com korner tablosu (cr) — ülke bazlı lig seçimi + isteğe bağlı turnuva id."""
    slug=SS_SLUG.get((country or "").strip().lower())
    if not slug: return None
    tid=league_tid or "cr"
    h=curl(f"https://www.soccerstats.com/table.asp?league={slug}&tid={tid}",25)
    if len(h)<50000: return None
    data={}
    for r in re.findall(r'<tr[^>]*>(.*?)</tr>',h,re.S):
        if 'Statistics' in r: continue
        cells=[H.unescape(re.sub(r'<[^>]+>','',c)).replace('\xa0',' ').strip()
               for c in re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>',r,re.S)]
        cells=[c for c in cells if c]
        if len(cells)<4: continue
        nm=cells[0]
        if not nm or nm[0].isdigit(): continue          # takım adıyla başlamalı
        nums=[]
        for c in cells[1:]:
            m=re.fullmatch(r'(\d+)\.(\d+)',c)
            if m: nums.append(float(c))
            elif re.fullmatch(r'\d+',c): nums.append(float(c))
        if len(nums)<4: continue
        P_,for_,ag,tot=nums[0],nums[1],nums[2],nums[3]
        k=nm.lower()
        if k not in data or P_>data[k]['n']:      # en geniş tablo (tüm maçlar) kazanır
            data[k]=dict(name=nm,n=int(P_),for_=for_,ag=ag,tot=tot)
    def find(name):
        if not name: return None
        n=H.unescape(name).lower()
        if n in data: return data[n]
        key=n.split(" fc")[0].strip()
        best=None
        for k,v in data.items():
            if k.startswith(key[:6]) or key[:6] in k:
                if best is None or v['n']>best['n']: best=v
        return best
    a=find(home); b=find(away)
    if not a or not b: return None
    avg=(a['tot']+b['tot'])/2
    return dict(home=home,away=away,hf=a['for_'],ha_=a['ag'],af=b['for_'],aa=b['ag'],
                home_name=a['name'],away_name=b['name'],tot=round(avg,1),
                pick=("ÜST" if avg>=9.5 else "ALT"), league=slug)

def extract(P):
    """build_report içindeki tabloları üretir (motor içi kullanım)"""
    MKT={"1x2":"MS (1X2)","ou":"Alt/Üst","ah":"Asya Handikap","bts":"KG (Var/Yok)","dc":"Çift Şans","ha":"Beraberlik İade"}
    POS={"1":"Ev","0":"Beraberlik","2":"Deplasman","y":"Var","n":"Yok","10":"1-X","12":"1-2","02":"X-2"}
    mv=""
    for x in sorted(P["odds"],key=lambda z:(z['market'],z['line'])):
        if not x["hist"]: continue
        h0,h1=x["hist"][0],x["hist"][-1]
        op,cl=float(h1["odd"]),float(h0["odd"]); pc=100*(cl-op)/op if op else 0
        a=[float(t["odd"]) for t in x["hist"]]
        mv+=(f"<tr><td>{MKT.get(x['market'],x['market'])}</td><td>{x['line'] or '-'}</td><td>{POS.get(x['pos'],x['pos'])}</td>"
             f"<td class='od'>{op:.2f}</td><td class='od'>{cl:.2f}</td><td class='od'>{min(a):.2f}</td><td class='od'>{max(a):.2f}</td>"
             f"<td class='{'up' if pc>0.5 else 'down' if pc<-0.5 else 'flat'}'>{sgn(pc)} {pc:+.1f}%</td><td class='tm'>{len(a)}</td><td class='tm'>{h1['date']}</td></tr>")
    bk=""
    for bt in ["1x2","ou","bts"]:
        recs=[r for r in P["markets"].get(bt,[]) if r["pos"] in ("1","0","2","y","n")]
        rws=""; seen=set()
        for r in recs:
            k=(r["line"],r["bookmaker"])
            if k in seen or not r["bookmaker"]: continue
            seen.add(k)
            rws+=f"<tr><td>{MKT.get(bt,bt)}</td><td>{r['line'] or '-'}</td><td>{POS.get(r['pos'],r['pos'])}</td><td>{H.escape(r['bookmaker'])}</td><td class='od'>{r['odd']}</td></tr>"
        if rws: bk+=f"<h3>{MKT.get(bt,bt)} — tüm bahisçiler</h3><table><thead><tr><th>Market</th><th>Çizgi</th><th>Sonuç</th><th>Bahisçi</th><th>Oran</th></tr></thead><tbody>{rws}</tbody></table>"
    hh=""
    for r in P["h2h"]:
        if r["hg"] is None: continue
        p=(r["dt"] or "").split(",")
        d=f"{p[0].zfill(2)}.{p[1].zfill(2)}.{p[2]}" if len(p)>=3 else r["dt"]
        hh+=(f"<tr><td>{d}</td><td class='lg'>{H.escape(r['comp'])}</td><td class='sc'>{r['hg']}-{r['ag']}</td>"
             f"<td class='sc'>{r.get('ht_h','?')}-{r.get('ht_a','?')}</td><td class='od'>{' / '.join(r['odds']) if r['odds'] else '-'}</td>"
             f"<td><a class='lnk' href='{BASE}{r['link']}' target='_blank'>maç ↗</a></td></tr>")
    def rows(ms):
        out=""
        for i,c in enumerate(sorted(ms,key=lambda z:z.get('date','')),1):
            b=c["b365"]; res="DEP" if c['hg']<c['ag'] else ("EV" if c['hg']>c['ag'] else "B")
            cl={"EV":"b-ev","DEP":"b-dep","B":"b-b"}[res]
            lig="/".join([x for x in c['league'].split('/') if x][1:3]).replace('-',' ').title()
            out+=(f"<tr><td>{i}</td><td>{c['date']}</td><td class='lg'>{H.escape(lig)}</td><td>{H.escape(c['home'])}</td><td>{H.escape(c['away'])}</td>"
                  f"<td class='od'>{b['1']:.2f}</td><td class='od'>{b['0']:.2f}</td><td class='od'>{b['2']:.2f}</td>"
                  f"<td class='sc'>{c['hg']}-{c['ag']}</td><td class='sc'>{c.get('ht_h','?')}-{c.get('ht_a','?')}</td><td><span class='badge {cl}'>{res}</span></td></tr>")
        return out
    def tbl(ms):
        return "<table><thead><tr><th>#</th><th>Tarih</th><th>Lig</th><th>Ev</th><th>Deplasman</th><th>1</th><th>X</th><th>2</th><th>MS</th><th>İY</th><th>Sonuç</th></tr></thead><tbody>"+rows(ms)+"</tbody></table>"
    form=""
    for who,(tn,tms) in [("Ev sahibi",P["form_home"]),("Deplasman",P["form_away"])]:
        if not tms: continue
        rec="".join(f"<tr><td>{m['date']}</td><td>{H.escape(m['home'])} - {H.escape(m['away'])}</td><td class='sc'>{m['ft']}</td>"
                    f"<td class='sc'>{m['ht']}</td><td><span class='badge {'b-dep' if m['result']=='G' else 'b-b' if m['result']=='B' else 'b-ev'}'>{m['result']}</span></td></tr>" for m in tms[:8])
        g=sum(m['our_goals'] for m in tms); y=sum(m['opp_goals'] for m in tms)
        o25=100*sum(1 for m in tms if sum(int(x) for x in m['ft'].split(':'))>2.5)/len(tms)
        kg=100*sum(1 for m in tms if all(int(x)>0 for x in m['ft'].split(':')))/len(tms)
        form+=(f"<h3>{who}: {H.escape(tn)} <span class='sub'>son {len(tms)} maç · {g} attı / {y} yedi · 2.5Ü %{o25:.0f} · KG %{kg:.0f}</span></h3>"
               f"<table><thead><tr><th>Tarih</th><th>Maç</th><th>MS</th><th>İY</th><th>Sonuç</th></tr></thead><tbody>{rec}</tbody></table>")
    st=P["stats"]; pm=P["poisson"]
    model=""
    if pm:
        model+=(f"<div class='grid g4'><div class='kpi'><div class='l'>Beklenen gol (Ev)</div><div class='v'>{pm['lh']:.2f}</div></div>"
                f"<div class='kpi alt'><div class='l'>Beklenen gol (Dep)</div><div class='v'>{pm['la']:.2f}</div></div>"
                f"<div class='kpi alt2'><div class='l'>Toplam gol beklentisi</div><div class='v'>{pm['total']:.2f}</div></div>"
                f"<div class='kpi red'><div class='l'>Bahisçi marjı</div><div class='v'>%{pm['margin']:.1f}</div></div></div>")
        model+=("<table><thead><tr><th>Model</th><th>Ev</th><th>Beraberlik</th><th>Deplasman</th></tr></thead><tbody>"
                f"<tr><td>Marj arındırılmış olasılık</td><td class='od'>%{100*pm['p1']:.1f}</td><td class='od'>%{100*pm['px']:.1f}</td><td class='od'>%{100*pm['p2']:.1f}</td></tr>"
                f"<tr><td>Adil oran</td><td class='od'>{fair(pm['p1']):.2f}</td><td class='od'>{fair(pm['px']):.2f}</td><td class='od'>{fair(pm['p2']):.2f}</td></tr>"
                f"<tr><td>Gol marketleri (model)</td><td colspan='3' class='od'>1.5Ü %{pm['o15']:.0f} · 2.5Ü %{pm['o25']:.0f} · 3.5Ü %{pm['o35']:.0f} · KG %{pm['btts']:.0f}</td></tr></tbody></table>")
        model+="<h3>Modelin en olası skorları</h3><div class='card'>"+"".join(f"<span class='chip'>{i}-{j} <b>%{100*v:.1f}</b></span>" for (i,j),v in pm['top'])+"</div>"
    val=""
    if st:
        def line(lbl,hist,imp):
            if hist is None or imp is None:
                return f"<tr><td>{lbl}</td><td class='od'>{'-' if imp is None else f'%{imp:.1f}'}</td><td class='od'>{'-' if hist is None else f'%{hist:.1f}'}</td><td class='od'>-</td><td>-</td></tr>"
            e=hist-imp; cls="b-dep" if e>3 else ("b-ev" if e<-3 else "b-b")
            return (f"<tr><td>{lbl}</td><td class='od'>%{imp:.1f}</td><td class='od'>%{hist:.1f}</td><td class='od'>%{e:+.1f}</td>"
                    f"<td><span class='badge {cls}'>{'DEĞER' if e>3 else 'PAHALI' if e<-3 else 'NÖTR'}</span></td></tr>")
        val="<table><thead><tr><th>Market</th><th>Piyasa olasılığı (model)</th><th>Tarihsel isabet</th><th>Fark</th><th>Sinyal</th></tr></thead><tbody>"
        val+=line("Deplasman kazanır",st.get("awp"),100*pm["p2"] if pm else None)
        val+=line("Beraberlik",st.get("drp"),100*pm["px"] if pm else None)
        val+=line("Ev kazanır",st.get("hwp"),100*pm["p1"] if pm else None)
        val+=line("2.5 ÜST",st.get("o25"),pm["o25"] if pm else None)
        val+=line("1.5 ÜST",st.get("o15"),pm["o15"] if pm else None)
        val+=line("KG Var",st.get("btts"),pm["btts"] if pm else None)
        val+=line("İY 0-0",st.get("ht00"),100*math.exp(-0.45*pm["total"]) if pm else None)
        val+=line("İY 1.5 ÜST",st.get("ht15"),None)
        val+=line("İY KG Var",st.get("htkg"),None)
        val+="</tbody></table>"
        # --- ROI / geri test (1X2, düz bahis) ---
        ms=P["sim15"]
        if ms:
            rows_roi=""
            for pos,lbl in [("1","Ev sahibi"),("0","Beraberlik"),("2","Deplasman")]:
                stake=100.0*len(ms); ret=0.0; win=0
                for c in ms:
                    o=c["b365"][pos]
                    hit = (c['hg']>c['ag']) if pos=="1" else ((c['hg']==c['ag']) if pos=="0" else (c['hg']<c['ag']))
                    if hit: ret+=100.0*o; win+=1
                prof=ret-stake; roi=100*prof/stake if stake else 0
                cls="b-dep" if roi>0 else "b-ev"
                rows_roi+=(f"<tr><td>{lbl}</td><td class='od'>{win}/{len(ms)}</td><td class='od'>{100*win/len(ms):.1f}%</td>"
                           f"<td class='od'>{stake:.0f}</td><td class='od'>{ret:.0f}</td><td class='od'>{prof:+.0f}</td>"
                           f"<td><span class='badge {cls}'>%{roi:+.1f}</span></td></tr>")
            val+=("<h3>Geri Test / ROI — 1X2 düz bahis (her maça 100 birim, kapanış oranından)</h3>"
                  "<table><thead><tr><th>Bahis</th><th>İsabet</th><th>Oran</th><th>Toplam bahis</th><th>Getiri</th><th>Kâr/Zarar</th><th>ROI</th></tr></thead><tbody>"
                  +rows_roi+"</tbody></table>"
                  "<div class='note'>Kapanış oranından oynanan düz bahis simülasyonu. Negatif ROI, o oranın piyasa tarafından doğru fiyatlandığını (marj dahil) gösterir.</div>")
    mtx=""
    if st.get("matrix"):
        m=st["matrix"]; n=st["htn"]
        mtx="<table class='mx'><thead><tr><th>İY ↓ / MS →</th><th>Ev</th><th>Beraberlik</th><th>Deplasman</th><th>Toplam</th></tr></thead><tbody>"
        for a,lab in [('1','İY Ev önde'),('X','İY Beraberlik'),('2','İY Dep önde')]:
            tot=sum(m[(a,b)] for b in '1X2')
            mtx+=f"<tr><th>{lab}</th>"+"".join((f"<td class='hl'>{m[(a,b)]} <span class='pc'>({100*m[(a,b)]/n:.0f}%)</span></td>" if m[(a,b)] else "<td class='zr'>–</td>") for b in '1X2')
            mtx+=f"<td class='tt'>{tot} ({100*tot/n:.0f}%)</td></tr>"
        mtx+="</tbody></table>"
    korner=""
    c=P.get("corner")
    if c:
        korner=(f"<div class='note'>🟨 <b>Korner analizi:</b> {H.escape(c['home'])} maç başı <b>{c['hf']}</b> korner üretiyor / {c['ha_']} yiyor · "
                f"{H.escape(c['away'])} <b>{c['af']}</b> üretiyor / {c['aa']} yiyor · beklenen toplam <b>{c['tot']}</b> → <b>KORNER {c['pick']}</b> sinyali</div>")
    return [mv,bk,hh,"",tbl,form,model,val,mtx,korner]

def build_report_html(P):
    args=extract(P)
    return _html(P,*args)


if __name__=="__main__":
    ref=sys.argv[1] if len(sys.argv)>1 else "/football/japan/j1-league/kyoto-kashiwa-reysol/69OvaPUj/"
    P=analyze(ref)
    out="/home/user/analiz_cikti.html"
    open(out,"w",encoding="utf-8").write(build_report_html(P))
    print("RAPOR:",out,"|",P["elapsed"],"sn")
