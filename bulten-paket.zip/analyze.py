#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Birebir/benzer oranlı maçları bul ve sonuç analizi yap"""
import json, re, statistics
from collections import Counter, defaultdict

OUT="/home/user/veri"
TARGET_OPEN  = {"o1":4.10, "ox":3.60, "o2":1.79}   # bet365 açılış (07.09.2026 11:07)
TARGET_CLOSE = {"o1":4.33, "ox":3.75, "o2":1.76}   # bet365 kapanış (11.09.2026 10:53)

def load():
    return json.load(open(f"{OUT}/all_matches.json",encoding="utf-8"))

def key(m):
    return (round(m['o1'],2), round(m['ox'],2), round(m['o2'],2))

def find(matches, tgt, tol):
    """tol: her bacak için mutlak tolerans"""
    out=[]
    for m in matches:
        if abs(m['o1']-tgt['o1'])<=tol and abs(m['ox']-tgt['ox'])<=tol and abs(m['o2']-tgt['o2'])<=tol:
            out.append(m)
    return out

def summarize(ms, label):
    n=len(ms)
    if n==0: return {"label":label,"n":0}
    hw=sum(1 for m in ms if m['hg']>m['ag']); dr=sum(1 for m in ms if m['hg']==m['ag']); aw=n-hw-dr
    tot=[m['hg']+m['ag'] for m in ms]
    o25=sum(1 for t in tot if t>2); o15=sum(1 for t in tot if t>1); o35=sum(1 for t in tot if t>3)
    btts=sum(1 for m in ms if m['hg']>0 and m['ag']>0)
    fav_home = sum(1 for m in ms if m['o1']<m['o2'])
    return {"label":label,"n":n,
            "home_win":hw,"draw":dr,"away_win":aw,
            "hw_pct":round(100*hw/n,1),"d_pct":round(100*dr/n,1),"aw_pct":round(100*aw/n,1),
            "o15_pct":round(100*o15/n,1),"o25_pct":round(100*o25/n,1),"o35_pct":round(100*o35/n,1),
            "btts_pct":round(100*btts/n,1),
            "avg_goals":round(statistics.mean(tot),2),
            "avg_hg":round(statistics.mean([m['hg'] for m in ms]),2),
            "avg_ag":round(statistics.mean([m['ag'] for m in ms]),2)}

if __name__=="__main__":
    ms=load()
    print("taranan maç:",len(ms))
    for tol,name in [(0.0,"BİREBİR AYNI"),(0.02,"±0.02"),(0.05,"±0.05"),(0.10,"±0.10"),(0.15,"±0.15"),(0.20,"±0.20")]:
        k=len(find(ms,TARGET_CLOSE,tol)); o=len(find(ms,TARGET_OPEN,tol))
        print(f"{name:14} -> kapanış profili: {k:5} maç | açılış profili: {o:5} maç")
    print()
    for tol,name in [(0.05,"±0.05"),(0.10,"±0.10")]:
        s=summarize(find(ms,TARGET_CLOSE,tol),f"kapanış {name}")
        print(s)
