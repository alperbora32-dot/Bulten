#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Arşivi CSV'ye aktar + özet istatistik."""
import json, csv, sys
from collections import Counter
from datetime import datetime

ARCH = "/home/user/veri/all_matches.json"
ms = json.load(open(ARCH, encoding="utf-8"))
yil = Counter(); lig = Counter()
ds = []
for m in ms:
    try: ds.append(datetime.strptime(m["date"], "%d.%m.%Y"))
    except Exception: pass
    lig[m["league"].strip("/").split("/")[-1]] += 1
for d in ds: yil[d.year] += 1

out = f"/home/user/Tum_Ligler_{len(ms)}_Mac_Arsivi.csv"
with open(out, "w", newline="", encoding="utf-8-sig") as f:
    w = csv.writer(f, delimiter=";")
    w.writerow(["Tarih", "Ev", "Deplasman", "MS", "Evgol", "Depgol", "Oran1", "OranX", "Oran2", "Lig", "Link"])
    for m in sorted(ms, key=lambda z: (z.get("date", "")[-4:], z.get("date", ""))):
        w.writerow([m.get("date", ""), m.get("home", ""), m.get("away", ""), f"{m.get('hg','')}-{m.get('ag','')}",
                    m.get("hg", ""), m.get("ag", ""), m.get("o1", ""), m.get("ox", ""), m.get("o2", ""),
                    m.get("league", "").strip("/").split("/")[-1],
                    "https://www.betexplorer.com" + m.get("link", "")])

print(f"CSV: {out}")
print(f"Toplam: {len(ms)} maç | {len(lig)} lig-sezon")
if ds:
    print(f"Tarih aralığı: {min(ds).strftime('%d.%m.%Y')} → {max(ds).strftime('%d.%m.%Y')}")
print("Yıllar:", " ".join(f"{y}:{yil[y]}" for y in sorted(yil)))
