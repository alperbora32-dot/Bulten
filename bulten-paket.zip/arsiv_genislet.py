#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARŞİV GENİŞLETİCİ — 2010→2026, tüm ligler, güncel sezon dahil
Kaldığı yerden devam eder (checkpoint). BetExplorer sonuç sayfalarını tarar.
Kullanım: python3 arsiv_genislet.py [dakika_bütçesi]
"""
import json, re, subprocess, sys, time, os, gzip
from concurrent.futures import ThreadPoolExecutor

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
COOKIE="age_verified=true; js_cookie=1; my_timezone=%2B1; be_lang=en"
BASE="https://www.betexplorer.com"; OUT="/home/user/veri"
ARCH=f"{OUT}/all_matches.json"; CKPT=f"{OUT}/crawl_checkpoint.json"

PAUSE=[0.0]
def curl(u,n=35):
    """429 durumunda artan bekleme; yavaş mod."""
    for deneme in range(4):
        try:
            r=subprocess.run(["curl","-s","-m",str(n),"-w","\n%{http_code}","-A",UA,"-H","Cookie: "+COOKIE,
                              "-H","Accept-Language: en-US,en;q=0.9","-H","Accept-Encoding: gzip","--compressed",u],
                             capture_output=True,timeout=n+10)
            raw=r.stdout.decode("utf-8","ignore")
            kod=raw.rsplit("\n",1)[-1].strip()
            s=raw.rsplit("\n",1)[0]
            if kod=="429" or kod=="403":
                PAUSE[0]=min(45.0,(PAUSE[0] or 3.0)*2)
                time.sleep(PAUSE[0]+ (deneme*2))
                continue
            if len(s)>3000:
                if PAUSE[0]>0: PAUSE[0]=max(0.0,PAUSE[0]-1.5)
                return s
        except Exception: pass
        time.sleep(1.0)
    return ""

def parse_results(html_text,url):
    if '&nbsp;' in html_text: html_text=html_text.replace('&nbsp;',' ')
    rows=[]
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>',html_text,re.S):
        if 'in-match' not in tr: continue
        m=re.search(r'href="(/football/[^"]*/[A-Za-z0-9]{8}/)"[^>]*class="in-match"><span>(?:<strong>)?([^<]*)(?:</strong>)?</span> - <span>(?:<strong>)?([^<]*)(?:</strong>)?</span>',tr)
        if not m: continue
        link,home,away=m.group(1),m.group(2),m.group(3)
        if not home.strip() or not away.strip(): continue
        sm=re.search(r'>(\d+):(\d+)</a>',tr)
        if not sm: continue
        odds=re.findall(r'data-odd="([\d\.]+)"',tr)
        if len(odds)<3: continue
        dm=re.search(r'h-text-right h-text-no-wrap">([^<]*)</td>',tr)
        dtarih=dm.group(1).strip() if dm else ""
        if re.fullmatch(r'\d{2}\.\d{2}\.',dtarih): dtarih=dtarih+"2026"   # güncel sezon sayfalarında yıl yok
        rows.append({"url":url,"link":link,"id":link.strip('/').split('/')[-1],
                     "home":home.strip(),"away":away.strip(),"hg":int(sm.group(1)),"ag":int(sm.group(2)),
                     "o1":float(odds[0]),"ox":float(odds[1]),"o2":float(odds[2]),
                     "date":dtarih,"league":url})
    return rows

def base_league(p):
    return re.sub(r'-\d{4}(-\d{4})?/$','/',p)

def season_of(p):
    y=re.findall(r'-(\d{4})(?:-(\d{4}))?/',p)
    if not y: return datetime_now_year()
    a,b=y[0]
    return int(a)

def datetime_now_year(): return 2026

if __name__=="__main__":
    budget=float(sys.argv[1])*60 if len(sys.argv)>1 else 1500.0
    t_start=time.time()
    # --- mevcut arşiv ---
    base=json.load(open(ARCH,encoding="utf-8")) if os.path.exists(ARCH) else []
    have={m["id"] for m in base}
    print(f"Mevcut arşiv: {len(base)} maç",flush=True)

    L=json.load(open(f"{OUT}/leagues.json",encoding="utf-8"))
    ckpt=json.load(open(CKPT,encoding="utf-8")) if os.path.exists(CKPT) else {"done":[],"new":[]}
    done=set(ckpt["done"])

    # --- görev listesi (öncelik sıralı) ---
    bases=sorted({base_league(p) for p in L})
    t1=[b+"results/" for b in bases]                       # 1) GÜNCEL sezon (2026-27)
    lset=set(L)
    t2=[]                                                   # 2) 2025-26 + 2024-25
    for p in L:
        if re.search(r'-(2025|2024)-',p): t2.append(p+"results/")
    MAJ=('england','spain','italy','germany','france','turkey','netherlands','portugal','brazil',
         'argentina','japan','usa','mexico','russia','greece','belgium','scotland','europe','china','australia')
    t3=[p+"results/" for p in L if any('/football/'+c+'/' in p for c in MAJ) and re.search(r'-(201[0-6])-',p)]
    t4=[p+"results/" for p in L if re.search(r'-(201[7-9]|202[0-3])-',p) and p not in t3]
    tasks=[]; seen=set()
    for t in (t1,t2,t3,t4):
        for u in t:
            if u not in done and u not in seen:
                seen.add(u); tasks.append(u)
    print(f"Kuyruk: {len(tasks)} sayfa  (T1 güncel:{len(t1)} T2 son2:{len(t2)} T3 2010-16:{len(t3)} T4 diğer:{len(t4)})",flush=True)

    new=[]; n=0
    def work(u):
        try:
            h=curl(BASE+u)
            return u,(parse_results(h,u) if h else [])
        except Exception:
            return u,[]
    t0=time.time(); stop=False
    CH=120
    for i in range(0,len(tasks),CH):
        if stop: break
        chunk=tasks[i:i+CH]
        with ThreadPoolExecutor(max_workers=5) as ex:
            for u,rows in ex.map(work,chunk):
                time.sleep(0.25)
                n+=1; done.add(u)
                if rows:
                    for r in rows:
                        if r["id"] not in have:
                            have.add(r["id"]); new.append(r)
                if time.time()-t0>budget: stop=True
        print(f"  {n}/{len(tasks)} sayfa | +{len(new)} yeni maç | {round(time.time()-t0)}s",flush=True)
        json.dump({"done":list(done),"new":new},open(CKPT,"w",encoding="utf-8"))
        json.dump(base+new,open(ARCH,"w",encoding="utf-8"),ensure_ascii=False)
    allm=base+new
    json.dump(allm,open(ARCH,"w",encoding="utf-8"),ensure_ascii=False)
    json.dump({"done":list(done),"new":[]},open(CKPT,"w",encoding="utf-8"))
    print(f"BİTTİ: {len(base)} → {len(allm)} maç (+{len(new)}) | süre {round(time.time()-t_start)}s",flush=True)
