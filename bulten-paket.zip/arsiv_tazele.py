#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARŞİV TAZELE — bugünün biten maçlarını (İY skoru dahil) arşive ekler.
Böylece arşiv "bugüne kadar" güncel olur ve İY verisi kendi içinde büyür.
Kullanım: python3 arsiv_tazele.py [YYYY-MM-DD]
"""
import json, sys, datetime, time

sys.path.insert(0, "/home/user")
import tam_tarama as TT

gun = datetime.date.fromisoformat(sys.argv[1]) if len(sys.argv) > 1 else datetime.date(2026, 9, 11)
maclar = TT.gun_maclari(gun)
TT.oran_tamamla(maclar)
biten = [m for m in maclar if m.get("durum") == "bitti" and m.get("skor")]
a = json.load(open(TT.ARCH, encoding="utf-8"))
var = {m["id"] for m in a}
yeni = []
for m in biten:
    if m["id"] in var or not m.get("o"):
        continue
    seg = [x for x in m["link"].split("/") if x]
    url = "/" + "/".join(seg[:3]) + "/results/" if len(seg) >= 3 else m["link"]
    hg, ag = [int(x) for x in m["skor"].split(":")]
    kayit = {"url": url, "link": m["link"], "id": m["id"], "home": m["home"], "away": m["away"],
             "hg": hg, "ag": ag, "o1": m["o"][0], "ox": m["o"][1], "o2": m["o"][2],
             "date": gun.strftime("%d.%m.%Y"), "league": url, "kaynak": "fikstur"}
    if m.get("iy"):
        try:
            ih, ia = [int(x) for x in m["iy"].split(":")]
            kayit["ht_h"], kayit["ht_a"] = ih, ia
        except Exception:
            pass
    yeni.append(kayit)

if yeni:
    a.extend(yeni)
    json.dump(a, open(TT.ARCH, "w", encoding="utf-8"), ensure_ascii=False)
print(f"{gun}: biten {len(biten)} maç | arşive eklenen {len(yeni)} | arşiv {len(a)-len(yeni)} → {len(a)}", flush=True)
iyli = sum(1 for x in yeni if "ht_h" in x)
print(f"  (İY skoru taşıyan yeni kayıt: {iyli})", flush=True)
