#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BASLAT (Python sürümü) — Windows / macOS / Linux / Termux hepsinde çalışır.

Kullanım:
    python baslat.py            → canlı takipçi + web sunucusu başlar
    python baslat.py --taze     → önce veriyi tazeler, sonra başlatır
    python baslat.py --durdur   → çalışanları durdurur
    python baslat.py --sadece-sunucu   → takipçiyi başlatmadan sadece sunucu

Erişim: http://localhost:8000/bulten   ·   http://localhost:8000/canli
"""
import json, os, subprocess, sys, time, urllib.request

KOK = os.path.dirname(os.path.abspath(__file__))
os.chdir(KOK)
PID = os.path.join(KOK, 'veri', 'pids.json')
LOG = os.path.join(KOK, 'veri', 'baslat.log')
PORT = 8000


def _oku():
    try:
        return json.load(open(PID, encoding='utf-8'))
    except Exception:
        return {}


def _yaz(d):
    os.makedirs(os.path.join(KOK, 'veri'), exist_ok=True)
    json.dump(d, open(PID, 'w', encoding='utf-8'))


def durdur():
    d = _oku()
    for ad, p in list(d.items()):
        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/F', '/PID', str(p)], capture_output=True)
            else:
                os.kill(int(p), 15)
            print('  durduruldu:', ad, p)
        except Exception as e:
            print('  (zaten kapalı olabilir)', ad, str(e)[:40])
    _yaz({})


def kontrol():
    """numpy var mı? yoksa kurmayı dener."""
    try:
        import numpy  # noqa
        return True
    except Exception:
        pass
    print('→ numpy yok, kuruluyor…')
    for komut in (['pip', 'install', 'numpy'], ['pip3', 'install', 'numpy'],
                  ['pkg', 'install', '-y', 'python-numpy'], ['apt-get', 'install', '-y', 'python3-numpy']):
        try:
            subprocess.run(komut, check=True, timeout=900)
            import numpy  # noqa
            return True
        except Exception:
            continue
    print('✗ numpy kurulamadı. Elle: pip install numpy')
    return False


def tazele():
    adimlar = [('fikstür + skor temizliği', 'veri_temizle.py'),
               ('oran hareketi', 'oran_hareket.py'),
               ('oynanmış maç kapanışları', 'kapanis_topla.py'),
               ('İY verisi', 'ht_topla.py'),
               ('bülten üretimi', 'bulten_v3.py')]
    for ad, dosya in adimlar:
        if not os.path.exists(dosya):
            continue
        print(f'  · {ad}…', flush=True)
        try:
            r = subprocess.run([sys.executable, dosya], cwd=KOK, timeout=1800,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            son = [x for x in (r.stdout or '').strip().split('\n') if x.strip()]
            print('    ' + (son[-1][:150] if son else 'tamam'))
        except Exception as e:
            print('    atlandı:', str(e)[:80])


def basla(takip=True):
    log = open(LOG, 'a', encoding='utf-8')
    d = _oku()
    if takip and not os.path.exists(os.path.join(KOK, 'veri', 'takip_durum.json')):
        pass
    if takip:
        p = subprocess.Popen([sys.executable, '-u', 'takip.py', 'dongu', '240'], cwd=KOK,
                             stdout=log, stderr=subprocess.STDOUT)
        d['takip'] = p.pid
        print('  · canlı takipçi başladı (4 dk aralık), pid', p.pid)
    s = subprocess.Popen([sys.executable, '-u', 'analiz_app.py'], cwd=KOK,
                         stdout=log, stderr=subprocess.STDOUT)
    d['sunucu'] = s.pid
    _yaz(d)
    print('  · web sunucusu başladı, pid', s.pid)

    for _ in range(20):
        time.sleep(1)
        try:
            urllib.request.urlopen(f'http://127.0.0.1:{PORT}/bulten', timeout=4)
            break
        except Exception:
            continue
    print()
    print('✔ HAZIR — tarayıcıdan aç:')
    print(f'    http://localhost:{PORT}/bulten    ← tam bülten')
    print(f'    http://localhost:{PORT}/canli     ← canlı takip (60 sn yenilenir)')
    print('  Günlük tazeleme:  python baslat.py --taze')
    print('  Durdurma       :  python baslat.py --durdur')
    print(f'  Günlük dosyası : {LOG}')
    print('\n(Kapatmak için Ctrl+C — arka plan işleri durdurmak için --durdur)')
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        print('\n(bu pencere kapandı; arka plan işleri sürüyor → python baslat.py --durdur)')


if __name__ == '__main__':
    if '--durdur' in sys.argv:
        durdur()
        sys.exit(0)
    print('═══ 1) kurulum kontrolü ═══')
    if not kontrol():
        sys.exit(1)
    if '--taze' in sys.argv:
        print('═══ 2) veri tazeleme ═══')
        tazele()
    print('═══ 3) başlatılıyor ═══')
    basla(takip='--sadece-sunucu' not in sys.argv)
