#!/bin/bash
# ============================================================================
#  BASLAT — Bülten sistemini tek komutla ayağa kaldırır
#  Kullanım:   bash baslat.sh            → sunucu + canlı takip başlar
#              bash baslat.sh --taze     → önce veriyi tazele (fikstür/oran), sonra başlat
#              bash baslat.sh --durdur   → çalışanları durdur
#  Erişim:     http://localhost:8000/bulten   (telefonun tarayıcısından)
#              http://localhost:8000/canli    (kendini 60 sn'de yenileyen canlı sayfa)
# ============================================================================
cd "$(dirname "$0")" || exit 1
LOG=veri/baslat.log
mkdir -p veri

durdur() {
  echo "⏹  çalışanlar durduruluyor…"
  python3 baslat.py --durdur 2>/dev/null || {
    pgrep -f "takip\.py" 2>/dev/null | xargs -r kill 2>/dev/null
    pgrep -f "analiz_app\.py" 2>/dev/null | xargs -r kill 2>/dev/null
  }
  sleep 1
  echo "   durduruldu"
}

if [ "$1" = "--durdur" ]; then durdur; exit 0; fi

# ---- python kontrolü ----
if ! command -v python3 >/dev/null 2>&1; then
  echo "✗ python3 bulunamadı."
  echo "  Termux (Android):  pkg update && pkg install python"
  echo "  Debian/Ubuntu   :  sudo apt install python3 python3-pip"
  exit 1
fi
python3 - <<'PY' || { echo "✗ numpy yok → kuruluyor…"; (echo "$PREFIX" | grep -q com.termux && pkg install -y python-numpy) || pip install --quiet numpy; }
import numpy
PY

# ---- kurulum kontrolü: yollar bu dizine uyarlanmış mı? ----
if grep -q "/home/user" bulten_v3.py 2>/dev/null && [ "$(pwd)" != "/home/user" ]; then
  echo "⚠ Betiklerde sabit yol var — önce şunu çalıştır:  bash kur.sh"
  exit 1
fi

echo "═══ 1) eski süreçler kapatılıyor ═══"
durdur

if [ "$1" = "--taze" ]; then
  echo "═══ 2) veri tazeleme (fikstür + oranlar) ═══"
  python3 -u veri_temizle.py 2>&1 | tail -5
  python3 -u oran_hareket.py devam 2>&1 | tail -2
  python3 -u kapanis_topla.py 2>&1 | tail -2
  python3 -u bulten_v3.py 2>&1 | tail -2
fi

echo "═══ 3) canlı takip başlatılıyor (4 dk aralık) ═══"
nohup python3 -u takip.py dongu 240 >> "$LOG" 2>&1 &
sleep 1

echo "═══ 4) web sunucusu başlatılıyor (port 8000) ═══"
nohup python3 -u analiz_app.py >> "$LOG" 2>&1 &
sleep 4

# ---- durum ----
if python3 -c "
import urllib.request,sys
try:
    urllib.request.urlopen('http://127.0.0.1:8000/bulten',timeout=5); sys.exit(0)
except Exception: sys.exit(1)
"; then
  echo
  echo "✔ HAZIR — tarayıcıdan aç:"
  echo "    http://localhost:8000/bulten    ← tam bülten (telefonda en iyisi)"
  echo "    http://localhost:8000/canli     ← canlı takip (60 sn'de yenilenir)"
  echo "    http://localhost:8000/          ← ana sayfa"
  IP=$(python3 -c "
import socket
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
try:
    s.connect(('8.8.8.8',80)); print(s.getsockname()[0])
except Exception: pass" 2>/dev/null)
  [ -n "$IP" ] && echo "    Aynı wifi'deki başka cihazdan:  http://$IP:8000/bulten"
  echo
  echo "  Günlük tazeleme:  bash baslat.sh --taze     (ya da: bash guncelle.sh)"
  echo "  Durdurma        :  bash baslat.sh --durdur"
else
  echo "✗ sunucu başlamadı — günlük: $LOG"
fi
