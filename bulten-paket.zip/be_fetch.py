import re, json, subprocess, html, sys, time

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
CJ="/tmp/be_cookies.txt"

def curl(url, ref=None, out=None):
    cmd=["curl","-s","-m","60","-A",UA,"-b",CJ,"-c",CJ,"-H","Accept-Language: en-US,en;q=0.9"]
    if ref: cmd+=["-e",ref]
    if out: cmd+=["-o",out]
    cmd.append(url)
    r=subprocess.run(cmd,capture_output=True,text=True)
    if out: return open(out,encoding='utf-8',errors='ignore').read()
    return r.stdout

MATCH="https://www.betexplorer.com/football/japan/j1-league/kyoto-kashiwa-reysol/69OvaPUj/"
page=curl(MATCH, out="/tmp/m1b.html")
ts=re.search(r"match_load_tabs\('([^']+)', '([^']+)', '([^']+)', '([^']+)'", page)
print("token match:", ts.groups() if ts else None)
eid, bt, tok, tok2 = ts.group(1), ts.group(2), ts.group(3), ts.group(4)
mutual=re.search(r'id="mutual_par" type="hidden" value="([^"]+)"',page).group(1)
print("mutual_par:", mutual)
import base64
print("decoded:", base64.b64decode(mutual).decode())

for bet in ["1x2","ou","ah","dnb","dc","bts"]:
    url=f"https://www.betexplorer.com/gres/ajax/match-content.php?e={eid}&t=new&ts={tok}&bt={bet}&lang=en"
    h=curl(url, ref=MATCH, out=f"/tmp/mc_{bet}.html")
    print(f"[{bet}] len={len(h)}")
    open(f"/home/user/veri/be_{bet}.html","w",encoding="utf-8").write(h)
    time.sleep(1)

# mutual matches
murl=f"https://www.betexplorer.com/gres/ajax/mutual-matches.php?{mutual}&new=true&bt=1x2&lang=en"
mh=curl(murl, ref=MATCH, out="/tmp/mm2.html")
print("mutual len", len(mh))
open("/home/user/veri/be_mutual.html","w",encoding="utf-8").write(mh)
