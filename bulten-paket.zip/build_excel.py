#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Dev oran arşivi Excel dosyası"""
import json, re, statistics
from collections import Counter
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

OUT="/home/user/veri"
wb=Workbook(); 
H=Font(bold=True,color="FFFFFF",size=11); HF=PatternFill("solid",fgColor="1F3864")
SF=PatternFill("solid",fgColor="D9E1F2"); BF=PatternFill("solid",fgColor="FCE4D6")
GF=PatternFill("solid",fgColor="E2EFDA")
thin=Side(style="thin",color="BFBFBF"); BD=Border(left=thin,right=thin,top=thin,bottom=thin)
CENTER=Alignment(horizontal="center",vertical="center")

def head(ws,cols,row=1):
    for i,c in enumerate(cols,1):
        cell=ws.cell(row=row,column=i,value=c); cell.font=H; cell.fill=HF; cell.alignment=CENTER; cell.border=BD
    ws.freeze_panes=ws.cell(row=row+1,column=1)

def width(ws,widths):
    for i,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width=w

# ---------------- 1) HEDEF MAÇ: bet365 TÜM MARKETLER (açılış/kapanış) ----------------
ws=wb.active; ws.title="Hedef Mac bet365"
ws["A1"]="KYOTO SANGA — KASHIWA REYSOL | 11.09.2026 11:00 (TSİ) | Sanga Stadium | J1 League 2026/27"
ws["A1"].font=Font(bold=True,size=13,color="1F3864"); ws.merge_cells("A1:H1")
ws["A2"]="BET365 TÜM MARKETLER — AÇILIŞ → KAPANIŞ (BetExplorer oran arşivi)"
ws["A2"].font=Font(bold=True,size=11,color="C00000"); ws.merge_cells("A2:H2")
head(ws,["Market","Çizgi/Handikap","Sonuç","AÇILIŞ","Açılış Tarihi","KAPANIŞ","Kapanış Tarihi","Hareket Sayısı"],row=3)
tp=json.load(open(f"{OUT}/target_profile.json",encoding="utf-8"))
MKT={"1x2":"MS (1X2)","ou":"Alt/Üst","ah":"Asya Handikap","bts":"Karşılıklı Gol (KG)","dc":"Çift Şans","ha":"Beraberlikte İade"}
r=4
for x in tp:
    ws.cell(row=r,column=1,value=MKT.get(x['market'],x['market']))
    ws.cell(row=r,column=2,value=x['line'] or "-")
    ws.cell(row=r,column=3,value=x['pos_tr'] or "-")
    ws.cell(row=r,column=4,value=float(x['open'])).number_format="0.00"
    ws.cell(row=r,column=5,value=x['open_t']); ws.cell(row=r,column=6,value=float(x['close'])).number_format="0.00"
    ws.cell(row=r,column=7,value=x['close_t']); ws.cell(row=r,column=8,value=x['n'])
    for c in range(1,9):
        ws.cell(row=r,column=c).border=BD
        if c in (4,6): ws.cell(row=r,column=c).fill=BF; ws.cell(row=r,column=c).font=Font(bold=True)
    r+=1
# 1x2 üç sonuç ayrıca (profilde tek satır kalmışsa düzelt)
# 1X2 üç sonucu net satırlar olarak ekle
for pos,ac,kp in [("Ev Sahibi (Kyoto)","4.10","4.33"),("Beraberlik","3.60","3.75"),("Deplasman (Kashiwa)","1.79","1.76")]:
    ws.cell(row=r,column=1,value="MS (1X2)")
    ws.cell(row=r,column=2,value="-")
    ws.cell(row=r,column=3,value=pos)
    ws.cell(row=r,column=4,value=float(ac)).number_format="0.00"
    ws.cell(row=r,column=5,value="07.09. 11:07")
    ws.cell(row=r,column=6,value=float(kp)).number_format="0.00"
    ws.cell(row=r,column=7,value="11.09. ~10:53")
    ws.cell(row=r,column=8,value=13)
    for c in range(1,9):
        ws.cell(row=r,column=c).border=BD
        if c in (4,6): ws.cell(row=r,column=c).fill=BF; ws.cell(row=r,column=c).font=Font(bold=True)
    r+=1
width(ws,[16,14,16,10,14,10,14,12])

# ---------------- 2) TÜM BAHİSÇİLER (hedef maç) ----------------
ws2=wb.create_sheet("Hedef Mac tum bahisciler")
raw=json.load(open(f"{OUT}/raw_data.json",encoding="utf-8"))
cur=raw["current"]
head(ws2,["Market","Çizgi","Bahisçi","Oran","Ne zaman"],1)
r=2
seen=set()
for bt,recs in cur["markets"].items():
    for o in recs:
        key=(bt,o["line"],o["bookmaker"],o["odd"],o["pos"])
        if key in seen: continue
        seen.add(key)
        ws2.cell(row=r,column=1,value=MKT.get(bt,bt)); ws2.cell(row=r,column=2,value=o["line"] or "-")
        ws2.cell(row=r,column=3,value=o["bookmaker"] or "-")
        try: 
            c=ws2.cell(row=r,column=4,value=float(o["odd"])); c.number_format="0.00"
        except: ws2.cell(row=r,column=4,value=o["odd"])
        ws2.cell(row=r,column=5,value=o["created"])
        for c in range(1,6): ws2.cell(row=r,column=c).border=BD
        r+=1
width(ws2,[16,10,18,10,18])

# ---------------- 3) H2H TARİHÇE ----------------
ws3=wb.create_sheet("H2H tarihce 2008-2026")
head(ws3,["Tarih","Turnuva","Ev Sahibi","Skor","Deplasman","İY (1.Yarı)","2.Yarı","1X2 Oranları (1/X/2)"],1)
h2h=json.load(open(f"{OUT}/h2h_archive.json",encoding="utf-8"))
det={x['id']:x for x in json.load(open(f"{OUT}/h2h_data.json",encoding="utf-8"))["h2h"]}
def dstr(dt):
    p=dt.split(',') if dt else []
    return f"{p[0].zfill(2)}.{p[1].zfill(2)}.{p[2]}" if len(p)>=3 else ""
r=2
for x in h2h:
    d=dstr(x['dt'])
    ws3.cell(row=r,column=1,value=d); ws3.cell(row=r,column=2,value=x['comp'])
    home=away=''; 
    if len(x['teams'])>=1 and x['teams'][0]: home=x['teams'][0]; away=x['teams'][1] if len(x['teams'])>1 else ''
    # linkten ev/dep tespiti
    m=re.search(r'/([a-z0-9\-]+)/([a-z0-9\-]+)/[A-Za-z0-9]{8}/$',x['link'])
    if m:
        sc=x['score'].split('-')
        # sayfa başlığından: ev sahibi link başı
        hp=m.group(1)
        home = "Kyoto" if hp.startswith('kyoto') else ("Kashiwa Reysol" if 'kashiwa' in hp else home)
        away = "Kashiwa Reysol" if hp.startswith('kyoto') else ("Kyoto" if 'kashiwa' in hp else away)
    ws3.cell(row=r,column=3,value=home); ws3.cell(row=r,column=4,value=x['score'])
    ws3.cell(row=r,column=5,value=away)
    if x['link'].strip('/').split('/')[-1] in det:
        i=det[x['link'].strip('/').split('/')[-1]]['info']
        ws3.cell(row=r,column=6,value=i.get('partial',''))
    o=x['odds']; ws3.cell(row=r,column=8,value=" / ".join(o) if o else "")
    for c in range(1,9): ws3.cell(row=r,column=c).border=BD
    r+=1
width(ws3,[12,22,16,8,16,18,14,20])

# ---------------- 4) EŞLEŞEN MAÇLAR ----------------
ws4=wb.create_sheet("Eslesen maclar (71)")
head(ws4,["#","Tarih","Lig","Ev Sahibi","Deplasman","bet365 AÇILIŞ (1/X/2)","bet365 KAPANIŞ (1/X/2)","MS","İY","2.Yarı","KG","2.5Ü","Sonuç"],1)
S=json.load(open(f"{OUT}/analysis_group.json",encoding="utf-8"))
def lig(l):
    p=[x for x in l.split('/') if x]
    return f"{p[1].title()} / {p[2].replace('-',' ').title()}"
r=2
for i,c in enumerate(sorted(S,key=lambda z:z['link']),1):
    v={p:float(d['odd']) for p,d in c['b365'].items()}
    opening=""
    if 'open_hist' in c:
        if set(c['open_hist'])=={'1','0','2'}:
            opening=" / ".join(c['open_hist'][p]['open']['odd'] for p in ('1','0','2'))
        else:
            opening="|".join([f"{p}:{c['open_hist'][p]['open']['odd']}" for p in ("1","0","2") if p in c["open_hist"]])+" (eksik)"
    ws4.cell(row=r,column=1,value=i); ws4.cell(row=r,column=2,value=c['date'])
    ws4.cell(row=r,column=3,value=lig(c['league']))
    ws4.cell(row=r,column=4,value=c['home']); ws4.cell(row=r,column=5,value=c['away'])
    ws4.cell(row=r,column=6,value=opening or "-")
    ws4.cell(row=r,column=7,value=f"{v['1']:.2f} / {v['0']:.2f} / {v['2']:.2f}")
    ws4.cell(row=r,column=8,value=f"{c['hg']}-{c['ag']}")
    if 'ht_h' in c:
        ws4.cell(row=r,column=9,value=f"{c['ht_h']}-{c['ht_a']}")
        ws4.cell(row=r,column=10,value=f"{c['hg']-c['ht_h']}-{c['ag']-c['ht_a']}")
    ws4.cell(row=r,column=11,value="Var" if c['hg']>0 and c['ag']>0 else "Yok")
    ws4.cell(row=r,column=12,value="Üst" if c['hg']+c['ag']>2.5 else "Alt")
    sonuc="EV" if c['hg']>c['ag'] else ("DEPLASMAN" if c['hg']<c['ag'] else "BERABERLİK")
    cell=ws4.cell(row=r,column=13,value=sonuc)
    cell.fill=GF if sonuc=="DEPLASMAN" else (PatternFill("solid",fgColor="FFF2CC") if sonuc=="BERABERLİK" else BF)
    for cc in range(1,14): ws4.cell(row=r,column=cc).border=BD
    r+=1
width(ws4,[5,11,26,18,18,20,20,8,8,8,7,7,12])

# ---------------- 5) İSTATİSTİK ----------------
ws5=wb.create_sheet("Istatistik analiz")
S_all=json.load(open(f"{OUT}/shortlist_final.json",encoding="utf-8"))
T={"1":4.33,"0":3.75,"2":1.76}
def vals(c): return {p:float(d['odd']) for p,d in c['b365'].items() if p in ('1','0','2')}
def block(g,label,row):
    n=len(g)
    ws5.cell(row=row,column=1,value=label).font=Font(bold=True,size=12,color="1F3864")
    row+=1
    hw=sum(1 for c in g if c['hg']>c['ag']); dr=sum(1 for c in g if c['hg']==c['ag']); aw=n-hw-dr
    tot=[c['hg']+c['ag'] for c in g]
    ht=[c for c in g if 'ht_h' in c]
    rows=[
      ("Maç sayısı",n),("Ev kazandı",f"{hw} ({100*hw/n:.1f}%)"),("Beraberlik",f"{dr} ({100*dr/n:.1f}%)"),
      ("Deplasman kazandı (favori)",f"{aw} ({100*aw/n:.1f}%)"),
      ("Ortalama toplam gol",f"{statistics.mean(tot):.2f}"),("Ev ortalama gol",f"{statistics.mean([c['hg'] for c in g]):.2f}"),
      ("Dep ortalama gol",f"{statistics.mean([c['ag'] for c in g]):.2f}"),
      ("1.5 ÜST",f"{100*sum(1 for t in tot if t>1.5)/n:.1f}%"),("2.5 ÜST",f"{100*sum(1 for t in tot if t>2.5)/n:.1f}%"),
      ("3.5 ÜST",f"{100*sum(1 for t in tot if t>3.5)/n:.1f}%"),("KG Var",f"{100*sum(1 for c in g if c['hg']>0 and c['ag']>0)/n:.1f}%"),
      ("İY 0-0",f"{100*sum(1 for c in ht if c['ht_h']==0 and c['ht_a']==0)/len(ht):.1f}%"),
      ("İY 1.5 ÜST",f"{100*sum(1 for c in ht if c['ht_h']+c['ht_a']>1.5)/len(ht):.1f}%"),
      ("İY KG Var",f"{100*sum(1 for c in ht if c['ht_h']>0 and c['ht_a']>0)/len(ht):.1f}%"),
      ("İY'de favori (dep) önde",f"{100*sum(1 for c in ht if c['ht_a']>c['ht_h'])/len(ht):.1f}%"),
      ("İY/MS aynı sonuç",f"{100*sum(1 for c in ht if (c['ht_h']>c['ht_a'])-(c['ht_h']<c['ht_a'])==(c['hg']>c['ag'])-(c['hg']<c['ag']))/len(ht):.1f}%"),
    ]
    for k,v in rows:
        ws5.cell(row=row,column=1,value=k).font=Font(bold=True); ws5.cell(row=row,column=2,value=v)
        row+=1
    # İY/MS matrisi
    ws5.cell(row=row,column=1,value="İY/MS Matrisi (İY → MS)").font=Font(bold=True,italic=True)
    row+=1
    combos=Counter(f"{'EV' if c['ht_h']>c['ht_a'] else ('B' if c['ht_h']==c['ht_a'] else 'DEP')} → {'EV' if c['hg']>c['ag'] else ('B' if c['hg']==c['ag'] else 'DEP')}" for c in ht)
    for k,v in combos.most_common():
        ws5.cell(row=row,column=1,value=k); ws5.cell(row=row,column=2,value=f"{v} ({100*v/len(ht):.1f}%)"); row+=1
    return row+2
row=1
row=block([c for c in S_all if all(abs(vals(c)[k]-T[k])<=0.05 for k in T)],"GRUP A+ : bet365 KAPANIŞ ±0.05 (en yakın eşleşme)",row)
row=block([c for c in S_all if all(abs(vals(c)[k]-T[k])<=0.10 for k in T)],"GRUP A : bet365 KAPANIŞ ±0.10",row)
row=block([c for c in S_all if all(abs(vals(c)[k]-T[k])<=0.15 for k in T)],"GRUP B : bet365 KAPANIŞ ±0.15",row)
width(ws5,[34,64])

# ---------------- 6) TARAMA EVRENİ ----------------
ws6=wb.create_sheet("Tarama evreni")
head(ws6,["Parametre","Değer"],1)
ms=json.load(open(f"{OUT}/all_matches.json",encoding="utf-8"))
leagues=len(set(m['league'] for m in ms))
rows=[("Taranan lig-dönem sayfası","689"),("Taranan ülke", "28"),("Toplam maç (2010-2026 arşivi)",f"{len(ms):,}".replace(',','.')),
      ("Lig/kupa çeşidi",str(leagues)),("Veri kaynağı","BetExplorer oran arşivi (tüm bahisçiler)"),
      ("Hedef maç bet365 kapanış","4.33 / 3.75 / 1.76"),("Hedef maç bet365 açılış","4.10 / 3.60 / 1.79"),
      ("±0.05 eşleşme (kapanış)",str(sum(1 for c in S_all if all(abs(vals(c)[k]-T[k])<=0.05 for k in T)))),
      ("±0.10 eşleşme (kapanış)",str(sum(1 for c in S_all if all(abs(vals(c)[k]-T[k])<=0.10 for k in T)))),
      ("±0.15 eşleşme (kapanış)",str(sum(1 for c in S_all if all(abs(vals(c)[k]-T[k])<=0.15 for k in T)))),
      ("Aynı oran setiyle AÇILAN (birebir ±0.05, açılış)",str(sum(1 for c in S_all if 'open_hist' in c and set(c['open_hist'])=={'1','0','2'} and all(abs(float(c['open_hist'][k]['open']['odd'])-{'1':4.10,'0':3.60,'2':1.79}[k])<=0.05 for k in ('1','0','2'))))),
      ("Aynı oran setiyle AÇILAN (±0.10, açılış)",str(sum(1 for c in S_all if 'open_hist' in c and set(c['open_hist'])=={'1','0','2'} and all(abs(float(c['open_hist'][k]['open']['odd'])-{'1':4.10,'0':3.60,'2':1.79}[k])<=0.10 for k in ('1','0','2'))))),
      ("Aynı oran setiyle AÇILAN (±0.15, açılış)",str(sum(1 for c in S_all if 'open_hist' in c and set(c['open_hist'])=={'1','0','2'} and all(abs(float(c['open_hist'][k]['open']['odd'])-{'1':4.10,'0':3.60,'2':1.79}[k])<=0.15 for k in ('1','0','2'))))),
     ]
r=2
for k,v in rows:
    ws6.cell(row=r,column=1,value=k).font=Font(bold=True); ws6.cell(row=r,column=2,value=v)
    ws6.cell(row=r,column=1).border=BD; ws6.cell(row=r,column=2).border=BD; r+=1
width(ws6,[42,42])

wb.save("/home/user/Kyoto_Kashiwa_Oran_Arsivi.xlsx")
print("kaydedildi: Kyoto_Kashiwa_Oran_Arsivi.xlsx")
print("sayfalar:",wb.sheetnames)
