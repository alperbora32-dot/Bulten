#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kyoto Sanga - Kashiwa Reysol | Dev oran arşivi + derin analiz raporu (HTML)"""
import json, statistics, html as H
from collections import Counter

OUT="/home/user/veri"
S=json.load(open(f"{OUT}/shortlist_final.json",encoding="utf-8"))
tp=json.load(open(f"{OUT}/target_profile.json",encoding="utf-8"))
h2h=json.load(open(f"{OUT}/h2h_archive.json",encoding="utf-8"))
alls=json.load(open(f"{OUT}/all_matches.json",encoding="utf-8"))
live=json.load(open(f"{OUT}/live_snapshot.json",encoding="utf-8"))

T={"1":4.33,"0":3.75,"2":1.76}; TO={"1":4.10,"0":3.60,"2":1.79}
def V(c): return {p:float(d['odd']) for p,d in c['b365'].items()}
def O(c):
    if 'open_hist' not in c or set(c['open_hist'])!={'1','0','2'}: return None
    return {p:float(c['open_hist'][p]['open']['odd']) for p in ('1','0','2')}
def G(tol): return [c for c in S if all(abs(V(c)[k]-T[k])<=tol for k in T)]
def stats(g):
    n=len(g); hw=sum(1 for c in g if c['hg']>c['ag']); dr=sum(1 for c in g if c['hg']==c['ag']); aw=n-hw-dr
    tot=[c['hg']+c['ag'] for c in g]; ht=[c for c in g if 'ht_h' in c]
    return dict(n=n,hw=hw,dr=dr,aw=aw,
        hwp=100*hw/n,drp=100*dr/n,awp=100*aw/n,
        avg=statistics.mean(tot),o15=100*sum(1 for t in tot if t>1.5)/n,o25=100*sum(1 for t in tot if t>2.5)/n,
        o35=100*sum(1 for t in tot if t>3.5)/n,btts=100*sum(1 for c in g if c['hg']>0 and c['ag']>0)/n,
        ht00=100*sum(1 for c in ht if c['ht_h']==0 and c['ht_a']==0)/len(ht),
        ht15=100*sum(1 for c in ht if c['ht_h']+c['ht_a']>1.5)/len(ht),
        htkg=100*sum(1 for c in ht if c['ht_h']>0 and c['ht_a']>0)/len(ht),
        htleadaway=100*sum(1 for c in ht if c['ht_a']>c['ht_h'])/len(ht),
        same=100*sum(1 for c in ht if (c['ht_h']>c['ht_a'])-(c['ht_h']<c['ht_a'])==(c['hg']>c['ag'])-(c['hg']<c['ag']))/len(ht),
        htw=100*sum(1 for c in ht if c['ht_h']>c['ht_a'])/len(ht), htx=100*sum(1 for c in ht if c['ht_h']==c['ht_a'])/len(ht))
g5,g10,g15=G(0.05),G(0.10),G(0.15)
s5,s10,s15=stats(g5),stats(g10),stats(g15)

def lig(l):
    p=[x for x in l.split('/') if x]
    u={"england":"İngiltere","spain":"İspanya","italy":"İtalya","germany":"Almanya","france":"Fransa","netherlands":"Hollanda",
       "portugal":"Portekiz","turkey":"Türkiye","russia":"Rusya","greece":"Yunanistan","belgium":"Belçika","scotland":"İskoçya",
       "austria":"Avusturya","switzerland":"İsviçre","denmark":"Danimarka","sweden":"İsveç","norway":"Norveç","poland":"Polonya",
       "brazil":"Brezilya","argentina":"Arjantin","usa":"ABD","mexico":"Meksika","japan":"Japonya","south-korea":"G.Kore",
       "china":"Çin","australia":"Avustralya","saudi-arabia":"S.Arabistan","europe":"Avrupa"}
    return f"{u.get(p[1],p[1].title())} / {p[2].replace('-',' ').title()}"

def row_html(i,c,w5=False):
    v=V(c)
    ht=f"{c.get('ht_h','?')}-{c.get('ht_a','?')}"
    res="EV" if c['hg']>c['ag'] else ("DEP" if c['hg']<c['ag'] else "B")
    cls={"EV":"b-ev","DEP":"b-dep","B":"b-b"}[res]
    kg="Var" if c['hg']>0 and c['ag']>0 else "Yok"
    ou="Üst" if c['hg']+c['ag']>2.5 else "Alt"
    return (f"<tr><td>{i}</td><td>{c['date']}</td><td class='lg'>{H.escape(lig(c['league']))}</td>"
            f"<td>{H.escape(c['home'])}</td><td>{H.escape(c['away'])}</td>"
            f"<td class='od'>{v['1']:.2f}</td><td class='od'>{v['0']:.2f}</td><td class='od'>{v['2']:.2f}</td>"
            f"<td class='sc'>{c['hg']}-{c['ag']}</td><td class='sc'>{ht}</td>"
            f"<td>{kg}</td><td>{ou}</td><td><span class='badge {cls}'>{res}</span></td></tr>")

def table(g,limit=None):
    rows="".join(row_html(i,c) for i,c in enumerate(sorted(g,key=lambda z:z['date']),1) if not limit or i<=limit)
    return ("<table><thead><tr><th>#</th><th>Tarih</th><th>Lig</th><th>Ev Sahibi</th><th>Deplasman</th>"
            "<th>1</th><th>X</th><th>2</th><th>MS</th><th>İY</th><th>KG</th><th>2.5</th><th>Sonuç</th></tr></thead><tbody>"+rows+"</tbody></table>")

# İY/MS matrisi
def htft_matrix(g):
    ht=[c for c in g if 'ht_h' in c]; m=Counter()
    for c in ht:
        a='1' if c['ht_h']>c['ht_a'] else ('X' if c['ht_h']==c['ht_a'] else '2')
        b='1' if c['hg']>c['ag'] else ('X' if c['hg']==c['ag'] else '2')
        m[(a,b)]+=1
    return m,len(ht)

def matrix_html(g):
    m,n=htft_matrix(g)
    out="<table class='mx'><thead><tr><th>İY ↓ / MS →</th><th>1 (Ev)</th><th>X</th><th>2 (Dep)</th><th>Toplam</th></tr></thead><tbody>"
    for a,lab in [('1','İY Ev önde'),('X','İY Beraberlik'),('2','İY Dep önde')]:
        tot=sum(m[(a,b)] for b in '1X2')
        cells="".join(f"<td class='{'hl' if m[(a,b)] else ''}'>{m[(a,b)]} <span class='pc'>({100*m[(a,b)]/n:.0f}%)</span></td>" if m[(a,b)] else "<td class='zr'>–</td>" for b in '1X2')
        out+=f"<tr><th>{lab}</th>{cells}<td class='tt'>{tot} ({100*tot/n:.0f}%)</td></tr>"
    out+="<tr class='tot'><th>Toplam</th>"+"".join(f"<td>{sum(m[(a,b)] for a in '1X2')} ({100*sum(m[(a,b)] for a in '1X2')/n:.0f}%)</td>" for b in '1X2')+f"<td>{n}</td></tr>"
    return out+"</tbody></table>"

# skor dağılımı
def scores(g):
    c=Counter(f"{x['hg']}-{x['ag']}" for x in g)
    return "".join(f"<span class='chip'>{k} <b>{v}</b></span>" for k,v in c.most_common(10))

# hedef oran tablosu
MKT={"1x2":"MS (1X2)","ou":"Alt/Üst","ah":"Asya Handikap","bts":"KG (Karşılıklı Gol)","dc":"Çift Şans","ha":"Beraberlikte İade"}
trows=""
for x in tp:
    ch="up" if float(x['close'])>float(x['open']) else ("down" if float(x['close'])<float(x['open']) else "flat")
    ar={"up":"▲","down":"▼","flat":"="}[ch]
    trows+=(f"<tr><td>{MKT.get(x['market'],x['market'])}</td><td>{x['line'] or '-'}</td><td>{x['pos_tr'] or '-'}</td>"
            f"<td class='od'>{x['open']}</td><td class='tm'>{x['open_t']}</td><td class='od'>{x['close']}</td>"
            f"<td class='tm'>{x['close_t']}</td><td class='{ch}'>{ar}</td><td class='tm'>{x['n']}</td></tr>")
trows+=("<tr class='tot'><td>MS (1X2)</td><td>-</td><td>Ev / Beraberlik / Deplasman</td>"
        "<td class='od'>4.10 / 3.60 / 1.79</td><td class='tm'>07.09 11:07</td>"
        "<td class='od'>4.33 / 3.75 / 1.76</td><td class='tm'>11.09 10:53</td><td class='flat'>=</td><td class='tm'>13/13/13</td></tr>")

# H2H tablo
h2h_rows=""
def _k(z):
    p=(z.get('dt') or '').split(',')
    return f"{p[2]}{p[1].zfill(2)}{p[0].zfill(2)}" if len(p)>=3 else '0'
for x in sorted(h2h,key=_k,reverse=True):
    p=x['dt'].split(',')
    d=f"{p[0].zfill(2)}.{p[1].zfill(2)}.{p[2]}" if len(p)>=3 else x['dt']
    hp=x['link'].split('/')[-2].split('-')[0] if x['link'] else ''
    home="Kyoto" if hp.startswith('kyoto') else "Kashiwa Reysol"
    away="Kashiwa Reysol" if hp.startswith('kyoto') else "Kyoto"
    sc=x['score']; 
    try:
        a,b=[int(t) for t in sc.split('-')]
        win="Kyoto" if (a>b and home=="Kyoto") or (b>a and away=="Kyoto") else ("Kashiwa" if a!=b else "Berabere")
    except: win="-"
    h2h_rows+=(f"<tr><td>{d}</td><td class='lg'>{H.escape(x['comp'])}</td><td>{home}</td><td class='sc'>{sc}</td><td>{away}</td>"
               f"<td class='od'>{' / '.join(x['odds']) if x['odds'] else '-'}</td><td><span class='badge {'b-ky' if win=='Kyoto' else ('b-ka' if win=='Kashiwa' else 'b-b')}'>{win}</span></td></tr>")

livescore=live['events']['69OvaPUj'].get('score','-')
livetime=live['datetime']
b365live=live['events']['69OvaPUj'].get('live_odds_1x2',{}).get('bookmakers',{}).get('549',{})

css = """
*{box-sizing:border-box}body{margin:0;background:#0f1720;color:#e8eef5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;line-height:1.55}
.wrap{max-width:1240px;margin:0 auto;padding:28px 18px 70px}
h1{font-size:30px;margin:0 0 6px;background:linear-gradient(90deg,#5ee7a0,#4fc3f7);-webkit-background-clip:text;background-clip:text;color:transparent}
h2{font-size:22px;margin:38px 0 12px;padding-left:12px;border-left:4px solid #5ee7a0}
h3{font-size:17px;margin:24px 0 8px;color:#9fd6ff}
.sub{color:#8ba3b8;font-size:13px;margin-bottom:18px}
.card{background:#16202b;border:1px solid #243244;border-radius:12px;padding:16px 18px;margin:14px 0}
.grid{display:grid;gap:14px}.g3{grid-template-columns:repeat(3,1fr)}.g4{grid-template-columns:repeat(4,1fr)}.g2{grid-template-columns:repeat(2,1fr)}
@media(max-width:860px){.g3,.g4,.g2{grid-template-columns:1fr}}
.kpi{background:linear-gradient(160deg,#182533,#131c25);border:1px solid #2a3a4d;border-radius:12px;padding:14px}
.kpi .v{font-size:26px;font-weight:800;color:#5ee7a0}.kpi .l{font-size:12px;color:#8ba3b8;text-transform:uppercase;letter-spacing:.5px}
.kpi.alt .v{color:#ffce54}.kpi.alt2 .v{color:#4fc3f7}.kpi.red .v{color:#ff7b7b}
table{width:100%;border-collapse:collapse;font-size:13px;margin:8px 0}
th,td{border:1px solid #243244;padding:6px 8px;text-align:left}
th{background:#1b2836;color:#9fd6ff;font-weight:600;position:sticky;top:0}
tbody tr:nth-child(even){background:#141d27}
tbody tr:hover{background:#1d2a38}
.od{text-align:center;font-weight:700;color:#ffce54;font-variant-numeric:tabular-nums}
.sc{text-align:center;font-weight:700}
.tm{color:#7f95a8;font-size:11px;text-align:center}
.lg{color:#a8c0d6;font-size:12px}
.tot{background:#1f2d3d!important;font-weight:700}
.up{color:#ff7b7b;text-align:center;font-weight:700}.down{color:#5ee7a0;text-align:center;font-weight:700}.flat{color:#8ba3b8;text-align:center}
.badge{display:inline-block;padding:1px 8px;border-radius:999px;font-size:11px;font-weight:700}
.b-dep{background:#12351f;color:#5ee7a0;border:1px solid #1f6b3c}
.b-ev{background:#3a1a1a;color:#ff9c9c;border:1px solid #6b2020}
.b-b{background:#3a3418;color:#ffd76e;border:1px solid #6b5f20}
.b-ky{background:#1c2f52;color:#9fd6ff;border:1px solid #2a4a80}.b-ka{background:#3a2a12;color:#ffbf6e;border:1px solid #7a5220}
.chip{display:inline-block;background:#1b2836;border:1px solid #2a3a4d;border-radius:8px;padding:3px 9px;margin:2px;font-size:12px}
.chip b{color:#5ee7a0}
.mx .hl{background:#1f3a2a;color:#a8f0c8;font-weight:700}.mx .zr{color:#3c4c5c;text-align:center}.mx .pc{color:#7f95a8;font-size:11px}
.note{background:#1a2430;border-left:4px solid #4fc3f7;padding:10px 14px;border-radius:0 8px 8px 0;font-size:13px;color:#b9cde0;margin:10px 0}
.warn{border-left-color:#ffce54}
.bad{border-left-color:#ff7b7b}
.scroll{max-height:620px;overflow:auto;border:1px solid #243244;border-radius:10px}
.live{display:flex;align-items:center;gap:10px;background:#1a2a1f;border:1px solid #2f6b45;border-radius:10px;padding:10px 14px;margin:10px 0}
.dot{width:9px;height:9px;border-radius:50%;background:#ff4d4d;animation:p 1.2s infinite}@keyframes p{50%{opacity:.25}}
.bar{height:10px;background:#1b2836;border-radius:6px;overflow:hidden;margin:4px 0 10px}
.bar i{display:block;height:100%;background:linear-gradient(90deg,#5ee7a0,#4fc3f7)}
ul{margin:6px 0 6px 18px;padding:0}li{margin:3px 0}
footer{margin-top:40px;color:#63798c;font-size:12px;border-top:1px solid #243244;padding-top:14px}
"""

html_doc=f"""<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">
<title>Kyoto Sanga – Kashiwa Reysol | Oran Arşivi & Derin Analiz</title><style>{css}</style></head><body><div class="wrap">

<h1>KYOTO SANGA — KASHIWA REYSOL</h1>
<div class="sub">J1 League 2026/27 · Sanga Stadium (Kyoto) · 11 Eylül 2026, 13:00 TSİ (10:00 UTC) · <b>bet365 oran arşivi + 2010-2026 tüm lig taraması</b></div>

<div class="live"><span class="dot"></span><b>CANLI (arşiv anı):</b> Skor <b>{livescore}</b> — veri anı: 11.09.2026 12:35 TSİ / 35. dakika. bet365 canlı 1X2: Ev {b365live.get('1',{}).get('current','-')} (açılış {b365live.get('1',{}).get('opening','-')}) · Dep {b365live.get('2',{}).get('current','-')} (açılış {b365live.get('2',{}).get('opening','-')})</div>

<div class="grid g4">
  <div class="kpi"><div class="l">Taranan maç (2010-2026)</div><div class="v">{len(alls):,}</div></div>
  <div class="kpi alt"><div class="l">Taranan lig-dönem / ülke</div><div class="v">689 / 28</div></div>
  <div class="kpi alt2"><div class="l">Bu oran setiyle kapanan (±0.05)</div><div class="v">{s5['n']}</div></div>
  <div class="kpi red"><div class="l">Bu oran setiyle kapanan (±0.15)</div><div class="v">{s15['n']}</div></div>
</div>

<h2>1 · Hedef Maçın TÜM bet365 Oranları (Açılış → Kapanış)</h2>
<div class="note">BetExplorer oran arşivinden çekilen <b>her oranın tüm hareket geçmişi</b> kaydedildi (toplam 155 bet365 hareket kaydı). Aşağıda her market için ilk (açılış) ve son (kapanış) değer var.</div>
<table><thead><tr><th>Market</th><th>Çizgi</th><th>Sonuç</th><th>AÇILIŞ</th><th>Açılış zamanı</th><th>KAPANIŞ</th><th>Kapanış zamanı</th><th>Yön</th><th>Hareket</th></tr></thead><tbody>{trows}</tbody></table>
<div class="note warn"><b>Yorum:</b> Ev sahibi 4.10 → 4.33'e <b>gevşedi</b> (piyasa Kyoto'ya güvenmedi), beraberlik 3.60 → 3.75, deplasman 1.79 → 1.76 <b>sıkılaştı</b>. Alt/üst çizgisinde 2.5 gol 1.83 → 1.65'e sert düştü: <b>piyasa gol beklentisini yukarı çekti</b>. 3.5 üst 3.00 → 2.63, 4.5 üst 6.00 → 5.00. Toplam gol piyasası maç saatine kadar sürekli "üst" yönünde hareket etti.</div>

<h2>2 · Karşılıklı Tarihçe (H2H) — 2008-2026</h2>
<div class="note bad"><b>Dikkat çeken tarihsel veri:</b> 24.11.2019 J2 maçı <b>Kashiwa Reysol 13-1 Kyoto</b> (İY 4-1) — Japon futbol tarihinin en farklı skorlarından. İki takımın son 20 karşılaşmasının tamamı ve oranları aşağıda.</div>
<div class="scroll"><table><thead><tr><th>Tarih</th><th>Turnuva</th><th>Ev</th><th>Skor</th><th>Deplasman</th><th>1X2 Oran</th><th>Kazanan</th></tr></thead><tbody>{h2h_rows}</tbody></table></div>
<div class="note">Son 6 J1 karşılaşmasının <b>4'ü berabere</b>, 2'si 1 farklı sonuç: 1-1, 1-1, 3-3, 2-2, 0-1, 2-6. Ortalama 3.0 gol. Kyoto 2026'da Kashiwa'yı 1-0 (deplasman) ve 2-6'lık ağır yenilgiyle (ev) karşıladı.</div>

<h2>3 · Aynı Oranlarla Açılan/Kapanan Maçlar (2010-2026, TÜM LİGLER)</h2>
<div class="note">Hedef maçın bet365 kapanış oranı <b>4.33 / 3.75 / 1.76</b> (ev zayıf, deplasman net favori). 55.605 maçlık arşiv tarandı; 537 maç ön elemeden geçti, 134'ünün gerçek bet365 oran verisi bulundu. Aşağıdaki gruplar <b>gerçek bet365 kapanış oranına</b> göre eşleştirildi.</div>

<div class="grid g3">
  <div class="kpi alt"><div class="l">±0.05 birebir eşleşme</div><div class="v">{s5['n']} maç</div></div>
  <div class="kpi alt2"><div class="l">±0.10 eşleşme</div><div class="v">{s10['n']} maç</div></div>
  <div class="kpi red"><div class="l">±0.15 eşleşme</div><div class="v">{s15['n']} maç</div></div>
</div>

<h3>3.1 · Birebir eşleşenler (±0.05 — bet365: 4.33 / 3.75-3.80 / 1.75-1.80)</h3>
{table(g5)}
<div class="note"><b>Bu 14 maçın sonucu:</b> Deplasman (favori) <b>{s5['aw']}/{s5['n']} = %{s5['awp']:.0f}</b> kazandı · Beraberlik {s5['dr']} · Ev sahibi {s5['hw']}. En sık skor 0-1 ve 0-2/0-4 tipi deplasman galibiyetleri. 5 maçta deplasman 2+ farkla kazandı (0-2, 0-3, 0-4, 1-4, 1-4).</div>

<h3>3.2 · ±0.10 eşleşmeler (n={s10['n']})</h3>
{table(g10)}

<h3>3.3 · ±0.15 geniş eşleşme evreni (n={s15['n']})</h3>
<div class="scroll">{table(g15)}</div>

<h2>4 · Derin İstatistik Analiz</h2>
<div class="grid g4">
  <div class="kpi"><div class="l">Deplasman (favori) kazanma</div><div class="v">%{s15['awp']:.0f}</div><div class="bar"><i style="width:{s15['awp']:.0f}%"></i></div><span class="sub">±0.05 grubunda %{s5['awp']:.0f}</span></div>
  <div class="kpi alt"><div class="l">Beraberlik</div><div class="v">%{s15['drp']:.0f}</div><div class="bar"><i style="width:{s15['drp']:.0f}%"></i></div></div>
  <div class="kpi red"><div class="l">Ev sahibi kazanma</div><div class="v">%{s15['hwp']:.0f}</div><div class="bar"><i style="width:{s15['hwp']:.0f}%"></i></div></div>
  <div class="kpi alt2"><div class="l">Maç başı gol</div><div class="v">{s15['avg']:.2f}</div><div class="bar"><i style="width:{min(100,s15['avg']/4*100):.0f}%"></i></div></div>
</div>

<h3>4.1 · Alt/Üst & KG</h3>
<div class="grid g3">
 <div class="card"><b>±0.15 grubu (n={s15['n']})</b>
  <ul><li>1.5 ÜST: <b>%{s15['o15']:.1f}</b></li><li>2.5 ÜST: <b>%{s15['o25']:.1f}</b></li><li>3.5 ÜST: <b>%{s15['o35']:.1f}</b></li><li>KG Var: <b>%{s15['btts']:.1f}</b></li></ul></div>
 <div class="card"><b>±0.05 birebir grup (n={s5['n']})</b>
  <ul><li>1.5 ÜST: <b>%{s5['o15']:.1f}</b></li><li>2.5 ÜST: <b>%{s5['o25']:.1f}</b></li><li>3.5 ÜST: <b>%{s5['o35']:.1f}</b></li><li>KG Var: <b>%{s5['btts']:.1f}</b></li></ul></div>
 <div class="card"><b>Gol ortalaması</b>
  <ul><li>Gruplarda ortalama <b>{s15['avg']:.2f}</b> gol (lig ortalamasının üstü)</li>
  <li>Hedef maçta piyasa 2.5 üstü 1.83→1.65'e çekti</li>
  <li>Kyoto son 5 maç: 2-1, 1-3, 2-2, 1-1, 0-2 (gol yemeye devam)</li></ul></div>
</div>

<h3>4.2 · İY/MS Matrisi (İlk Yarı → Maç Sonucu)</h3>
<div class="grid g2">
 <div>{matrix_html(g15)}<div class="sub">±0.15 grubu ({s15['n']} maç)</div></div>
 <div>{matrix_html(g5)}<div class="sub">±0.05 birebir grup ({s5['n']} maç)</div></div>
</div>

<h3>4.3 · İlk Yarı (İY) İstatistikleri — senin istediğin İY 1.5 ÜST / İY KG</h3>
<div class="grid g4">
 <div class="kpi"><div class="l">İY 0-0</div><div class="v">%{s15['ht00']:.0f}</div><span class="sub">±0.05 grubunda %{s5['ht00']:.0f}</span></div>
 <div class="kpi alt"><div class="l">İY 1.5 ÜST</div><div class="v">%{s15['ht15']:.0f}</div></div>
 <div class="kpi alt2"><div class="l">İY KG Var</div><div class="v">%{s15['htkg']:.0f}</div></div>
 <div class="kpi red"><div class="l">İY'de favori (dep) önde</div><div class="v">%{s15['htleadaway']:.0f}</div></div>
</div>
<div class="note"><b>Kritik bulgu:</b> Bu oran setinde <b>İY'de 0-0 oranı %{s15['ht00']:.0f}</b> (birebir grupta %{s5['ht00']:.0f}) — yani ilk yarı çoğunlukla kilitli geçiyor. <b>İY/MS aynı sonuç %{s15['same']:.0f}</b>; birebir grupta %{s5['same']:.0f}. İY 1.5 üst sadece %{s15['ht15']:.0f}, İY KG %{s15['htkg']:.0f}. Bu, "İY 0-0 / İY alt" senaryosunu destekleyen güçlü bir istatistiksel eğilimdir.</div>

<h3>4.4 · En Sık Skorlar</h3>
<div class="card"><b>±0.15:</b><br>{scores(g15)}</div>
<div class="card"><b>±0.05:</b><br>{scores(g5)}</div>

<h3>4.5 · Lig & Takım Bağlamı (2026/27 sezonu)</h3>
<div class="grid g3">
 <div class="card"><b>Kyoto Sanga</b><ul><li>Son 5: 2-1 (Avispa), 1-3 (Mito), 2-2 (Kawasaki), 1-1 (Yokohama FM), 0-2 (FC Tokyo)</li>
 <li>Korner: maç başı <b>2.5 for / 6.0 against</b> (toplam 8.5) — ligin en düşük korner üreten takımlarından</li>
 <li>Şut üretimi ve baskı verileri rakip lehine</li></ul></div>
 <div class="card"><b>Kashiwa Reysol</b><ul><li>Son 5: 0-2 (Yokohama FM), 0-2 (Cerezo), 1-0 (Shimizu), 4-2 (V-Varen), 3-1 (Verdy) — <b>deplasman formu güçlü</b></li>
 <li>Korner: maç başı <b>5.5 for / 3.83 against</b></li>
 <li>Ligde üst sıralarda; gol ortalaması yüksek</li></ul></div>
 <div class="card"><b>Lig (J1) verileri</b><ul><li>Sezon gol ortalaması: 3.00/maç</li><li>Gollerin %43.9'u ilk yarı, %56.1'i ikinci yarı</li><li>İlk gol ortalaması 30. dakika (57 maçta gol olmuş, %95)</li><li>76-90 arası gol oranı %22.8 (en yüksek dilim)</li></ul></div>
</div>

<h2>5 · Senaryo & Sentez (Analiz Raporu)</h2>
<div class="card">
<h3>A) Oranların söylediği</h3>
<ul>
<li>Kapanış oranları deplasman Kashiwa'yı <b>~%53-57 favori</b> gösteriyor (marj düzeltilmiş: Ev ~%22 / X ~%25 / Dep ~%53).</li>
<li>Piyasa maç saatine kadar <b>Kyoto'yu sürekli sattı</b> (4.10→4.33) ve <b>gol piyasasını yukarı çekti</b> (2.5Ü 1.83→1.65).</li>
<li>Handikap tarafında 0 (beraberlik iadesi) 2.85→3.45; +0.5 Kyoto 1.95→2.08: piyasa deplasmanın <b>net kazanacağına</b> daha çok inanıyor.</li>
</ul>
<h3>B) Tarihsel eşleşmelerin söylediği</h3>
<ul>
<li>Bu oran profiliyle sonuçlanan 71 maçın <b>%{s15['awp']:.0f}'i deplasman favori galibiyeti</b>, %{s15['drp']:.0f} beraberlik, %{s15['hwp']:.0f} ev sahibi sürprizi. Birebir 14 maçta deplasman galibiyeti <b>%{s5['awp']:.0f}</b>.</li>
<li>En sık skorlar <b>0-1, 0-2, 1-1, 2-1, 1-2</b> — yani tek farklı, düşük-dengeli maçlar baskın.</li>
<li>Gol tarafı: 1.5 üst %{s15['o15']:.0f} (neredeyse garanti), 2.5 üst %{s15['o25']:.0f}, KG %{s15['btts']:.0f} — <b>KG Var ve 2.5 üst hafif pozitif</b>.</li>
<li>İlk yarı: 0-0 oranı %{s15['ht00']:.0f}; İY 1.5 üst sadece %{s15['ht15']:.0f}; İY KG %{s15['htkg']:.0f} → <b>İY alt / İY 0-0 senaryosu istatistiksel olarak öne çıkıyor</b>.</li>
<li>İY/MS kombinasyonu: en sık giden yol <b>İY beraberlik → MS deplasman</b> (kırılma ikinci yarıda).</li>
</ul>
<h3>C) H2H'nin söylediği</h3>
<ul>
<li>Son 6 J1 maçının 4'ü berabere; 2026'da iki maç: Kashiwa 0-1 Kyoto (deplasman sürprizi) ve Kyoto 2-6 Kashiwa (ağır deplasman galibiyeti).</li>
<li>Ancak 24.11.2019'daki 13-1'lık tarihi sonuç, "bu eşleşmede işler kontrolden çıkabilir" riskini hatırlatıyor — KG ve 3.5 üst tarafında dikkat gerektirir.</li>
<li>Kyoto'nun korner üretimi ligin en düşüklerinden (2.5/maç); korner "alt" ve "Kashiwa korner üstünlüğü" senaryosu destekli.</li>
</ul>
<h3>D) Sonuç</h3>
<div class="note"><b>İstatistiksel ağırlık merkezi:</b> Deplasman (Kashiwa) galibiyeti ya da beraberlik; düşük-orta skorlu (0-1, 1-1, 1-2, 0-2) bir maç; ilk yarı büyük olasılıkla 0-0 veya tek gollü; ikinci yarıda çözülme. Piyasanın maç öncesi "üst" hareketi ile tarihsel "İY alt" eğilimini birleştirmek en tutarlı okuma: <b>İY Alt / MS Deplasman veya Beraberlik</b>. Ev sahibinin %{s5['hwp']:.0f} (birebir grupta) sürpriz oranı ise 4.33 gibi yüksek oranın taşıdığı riski doğruluyor.</div>
</div>

<h2>6 · Metodoloji ve Kaynaklar</h2>
<div class="card">
<ul>
<li><b>Oran kaynağı:</b> BetExplorer oran arşivi — her bahisçi için açılış→kapanış <b>tüm hareket geçmişi</b> (hedef maçta 155 bet365 hareket kaydı, tüm bahisçilerle 300+ hücre).</li>
<li><b>Tarama evreni:</b> 28 ülkenin 689 lig-dönem sonuç arşivi (2010-2026), toplam <b>55.605 maç</b>; her maç için 1X2 kapanış oranı + skor + tarih.</li>
<li><b>Eşleştirme:</b> Hedefin bet365 kapanışı (4.33/3.75/1.76) ve açılışı (4.10/3.60/1.79) ile toleranslı eşleştirme; 537 aday ön elemeden geçti, 134'ünün <b>gerçek bet365</b> oran satırı doğrulandı, 71'i ±0.15 içinde, 17'si ±0.10, 14'ü ±0.05 içinde.</li>
<li><b>İY verisi:</b> Her eşleşen maçın gerçek İY/2. yarı skoru maç sayfasından çekildi (69/71 maçta mevcut).</li>
<li><b>Korner verisi:</b> SoccerSTATS J1 2026/27 korner tablosu.</li>
<li><b>Sınırlama:</b> BetExplorer'da <b>İY/MS, korner, İY 1.5 üst ve İY KG için oran arşivi tutulmuyor</b> — bu marketler için odds arşivi yerine, aynı oranlarla oynanmış 71 maçın <b>gerçek İY/MS sonuç dağılımı</b> hesaplandı (yukarıdaki matris ve yüzdeler).</li>
<li><b>Örneklem uyarısı:</b> Birebir (%±0.05) grup 14 maçtır — yön gösterir, kesinlik iddiası taşımaz.</li>
</ul>
</div>

<footer>Veri çekimi: 11.09.2026 · BetExplorer (oran arşivi) + SoccerSTATS · 55.605 maçlık 2010-2026 taraması · Bu rapor istatistiksel analiz amaçlıdır, yatırım/bahis tavsiyesi değildir.</footer>
</div></body></html>"""

open("/home/user/Kyoto_Kashiwa_Derin_Analiz.html","w",encoding="utf-8").write(html_doc)
print("yazıldı: Kyoto_Kashiwa_Derin_Analiz.html", len(html_doc),"byte")
print("gruplar:",s5['n'],s10['n'],s15['n'])
