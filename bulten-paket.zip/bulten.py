#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TAM BÜLTEN — bugünün tüm maçları, oran + eşleşme + değer sinyali ile."""
import sys, math, time, html as H
from collections import defaultdict
sys.path.insert(0, "/home/user")
import tarama as T

def bulten_html(sonuc, tol=0.15, dosya="/home/user/Bugun_Bulteni.html"):
    n_tum = len(sonuc)
    n_ornek = sum(1 for m in sonuc if m.get("n", 0) >= 8)
    n_deger = sum(1 for m in sonuc if m.get("en_iyi") and m["en_iyi"]["ci"][0] > m["en_iyi"]["piyasa"] and m["en_iyi"]["edge"] >= 3)
    # lig gruplu
    gruplar = defaultdict(list)
    for m in sonuc:
        gruplar[m.get("liga") or "Diğer"].append(m)

    CSS = """*{box-sizing:border-box}
body{margin:0;background:#0a121e;color:#e8eef5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px;line-height:1.45}
.wrap{max-width:1400px;margin:0 auto;padding:20px 14px 70px}
h1{font-size:26px;margin:0 0 4px;background:linear-gradient(90deg,#5ee7a0,#4fc3f7);-webkit-background-clip:text;background-clip:text;color:transparent}
.sub{color:#8ba3b8;font-size:13px;margin-bottom:14px}
.card{background:#0f1a27;border:1px solid #1d2d42;border-radius:14px;padding:14px 16px;margin:12px 0}
.kpi{display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}
.kpi div{background:#0c1622;border:1px solid #1d2d42;border-radius:10px;padding:10px 12px}
.kpi b{display:block;color:#8ba3b8;font-size:11px;text-transform:uppercase;letter-spacing:.4px;margin-bottom:3px}
.kpi span{font-size:20px;font-weight:800}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th,td{border:1px solid #1d2d42;padding:5px 7px;text-align:left;white-space:nowrap}
th{background:#16273a;color:#9fd6ff;font-size:12px;position:sticky;top:0;z-index:2}
tbody tr:nth-child(even){background:#0c1622}
tbody tr:hover{background:#15263a}
.od{text-align:center;font-variant-numeric:tabular-nums;font-weight:600}
.mini{color:#8ba3b8;font-size:11.5px}
.git{color:#5ee7a0}.yit{color:#ffd479}.kit{color:#ff8a8a}
.badge{display:inline-block;padding:1px 7px;border-radius:6px;font-size:11px;font-weight:700}
.b-yuksek{background:#124a2e;color:#5ee7a0}
.b-orta{background:#3d3410;color:#ffd479}
.b-zayif{background:#24354a;color:#9fb4c7}
.b-yok{background:#1a1f27;color:#5d6b7a}
tr.sinyal{background:#0e2a1e !important}
tr.sinyal:hover{background:#143a29 !important}
.ligbas{background:#16273a;color:#9fd6ff;font-weight:700;font-size:12.5px}
.bar{display:inline-block;height:9px;border-radius:3px;vertical-align:middle}
.legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;color:#a9c1d6;margin-top:8px}
.legend b{color:#e8eef5}
a{color:#4fc3f7;text-decoration:none}
@media print{body{background:#fff;color:#000}.card{border-color:#ccc}th{background:#eee;color:#000}}
"""
    out = [f"<div class='wrap'><h1>📋 GÜNÜN BÜLTENİ — {T.BUGUN}</h1>",
           f"<div class='sub'>Tüm maçlar listelendi · her satırda o maçın oranına en yakın maçların gerçek sonuç dağılımı · "
           f"tolerans ±{tol} · arşiv <b>67.464 maç</b> (2011→2026)</div>"]

    out.append(f"""<div class='card'><div class='kpi'>
<div><b>Toplam maç</b><span>{n_tum}</span></div>
<div><b>8+ örnekli maç</b><span>{n_ornek}</span></div>
<div><b>Değer sinyali</b><span class='git'>{n_deger}</span></div>
<div><b>Lig sayısı</b><span>{len(gruplar)}</span></div>
</div>
<div class='legend'>
<span>🟩 <b>Yeşil satır</b> = istatistiksel değer sinyali (güven aralığı alt sınırı piyasa olasılığını geçiyor, 8+ maç)</span>
<span>📊 <b>Ev/Ber/Dep</b> = o oranla açılan maçlarda gerçek sonuç dağılımı</span>
<span>🎯 <b>En iyi</b> = en yüksek fark (piyasa vs tarihsel)</span>
<span>📈 <b>ROI</b> = o tarafa düz bahis getirisi</span>
</div></div>""")

    # ---- ana tablo: lig gruplu ----
    out.append("<div class='card'><table><thead><tr>"
               "<th>Saat</th><th>Maç</th><th>Oran 1</th><th>X</th><th>2</th>"
               "<th>Örnek</th><th>Ev%</th><th>Ber%</th><th>Dep%</th>"
               "<th>En iyi</th><th>Fark</th><th>%95 GA</th><th>Güven</th><th>ROI</th><th>Ort.gol</th><th>2.5Ü</th><th>KG</th>"
               "</tr></thead><tbody>")
    for lig in sorted(gruplar, key=lambda l: (-len(gruplar[l]), l)):
        ms = sorted(gruplar[lig], key=lambda m: m.get("saat", ""))
        out.append(f"<tr class='ligbas'><td colspan='17'>{H.escape(lig)} <span class='mini'>({len(ms)} maç)</span></td></tr>")
        for m in ms:
            p = m.get("en_iyi")
            n = m.get("n", 0)
            sinyal = bool(p and n >= 8 and p["ci"][0] > p["piyasa"] and p["edge"] >= 3)
            cls = " class='sinyal'" if sinyal else ""
            if n >= 8 and p:
                hist = m.get("hist3") or [p["hist"]]   # tek sütun varsa
                d = m.get("dagilim", [0, 0, 0])
                gv = ("YÜKSEK" if n >= 40 and sinyal else ("ORTA" if n >= 18 and sinyal else ("DÜŞÜK" if sinyal else "—")))
                gy = f"<span class='badge b-yuksek'>{gv}</span>" if gv == "YÜKSEK" else (
                     f"<span class='badge b-orta'>{gv}</span>" if gv == "ORTA" else (
                     f"<span class='badge b-zayif'>{gv}</span>" if gv == "DÜŞÜK" else "<span class='mini'>—</span>"))
                out.append(
                    f"<tr{cls}><td class='od'>{m.get('saat','')}</td>"
                    f"<td><b>{H.escape(m['home'])}</b> - {H.escape(m['away'])}</td>"
                    f"<td class='od'>{m['o'][0]:.2f}</td><td class='od'>{m['o'][1]:.2f}</td><td class='od'>{m['o'][2]:.2f}</td>"
                    f"<td class='od'>{n}</td>"
                    f"<td class='od'>{d[0]:.0f}</td><td class='od'>{d[1]:.0f}</td><td class='od'>{d[2]:.0f}</td>"
                    f"<td class='od'><b>{p['ad']}</b></td>"
                    f"<td class='od {'git' if p['edge'] > 0 else 'kit'}'>{p['edge']:+.1f}</td>"
                    f"<td class='od mini'>{p['ci'][0]:.0f}–{p['ci'][2]:.0f}</td>"
                    f"<td>{gy}</td>"
                    f"<td class='od {'git' if p['roi'] > 0 else 'kit'}'>{p['roi']:+.0f}%</td>"
                    f"<td class='od'>{m.get('avg',0):.2f}</td>"
                    f"<td class='od'>{m.get('o25',0):.0f}%</td>"
                    f"<td class='od'>{m.get('btts',0):.0f}%</td></tr>")
            else:
                out.append(
                    f"<tr><td class='od'>{m.get('saat','')}</td>"
                    f"<td>{H.escape(m['home'])} - {H.escape(m['away'])}</td>"
                    f"<td class='od'>{m['o'][0]:.2f}</td><td class='od'>{m['o'][1]:.2f}</td><td class='od'>{m['o'][2]:.2f}</td>"
                    f"<td class='od mini'>{n}</td><td colspan='4' class='mini'>yeterli benzer maç yok (8+ gerekli)</td>"
                    f"<td colspan='6' class='mini'>—</td></tr>")
    out.append("</tbody></table></div>")

    out.append(f"<div class='card mini'>Yöntem: her maçın 1X2 oranı, 67.464 maçlık arşivde ±{tol} toleransla taranır. "
               "Eşleşen maçların gerçek sonuçlarından Ev/Ber/Dep dağılımı, %95 Wilson güven aralığı, ROI (o orandan düz bahis) hesaplanır. "
               "Değer farkı = tarihsel isabet − marj arındırılmış piyasa olasılığı. "
               "Yeşil satırlar: güven aralığının ALT sınırı bile piyasadan yüksek olan maçlar — yani istatistiksel olarak savunulabilir fırsatlar.</div></div>")
    html = (f"<!DOCTYPE html><html lang='tr'><head><meta charset='utf-8'>"
            f"<meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>Günün Bülteni {T.BUGUN}</title><style>{CSS}</style></head><body>{''.join(out)}</body></html>")
    open(dosya, "w", encoding="utf-8").write(html)
    return dosya


def zenginlestir(sonuc):
    """Her maça tam dağılım (Ev/Ber/Dep %) ekle."""
    ms, o1s = T.arsiv()
    for m in sonuc:
        if not m.get("n"): continue
        e = T.eslesen(ms, o1s, m["o"], 0.15)
        n = len(e)
        if n:
            hw = sum(1 for c in e if c["hg"] > c["ag"]); dr = sum(1 for c in e if c["hg"] == c["ag"])
            m["dagilim"] = [100 * hw / n, 100 * dr / n, 100 * (n - hw - dr) / n]
    return sonuc


if __name__ == "__main__":
    t0 = time.time()
    sonuc = T.tarama(0.15, verbose=False)
    zenginlestir(sonuc)
    dosya = bulten_html(sonuc)
    print(f"Bülten: {dosya} | {len(sonuc)} maç | {round(time.time()-t0)} sn")
