#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TAM BÜLTEN (tek dosya) — bugünün TÜM maçları, her biri için oran karşılaştırması."""
import json, html as H, sys, csv, os

VERI = "/home/user/veri/tam_tarama.json"
BUGUN = "11.09.2026"

def yukle():
    d = json.load(open(VERI, encoding="utf-8"))
    return [m for m in d if m["gun"] == "2026-09-11"]

def kayitlar(ms):
    out = []
    for m in ms:
        r = {"s": m.get("saat", ""), "l": m.get("lig", ""), "lt": m.get("lig_tam", ""),
             "h": m.get("home", ""), "a": m.get("away", ""), "k": m.get("skor", ""),
             "o": [round(x, 2) for x in m["o"]] if m.get("o") else None,
             "n": m.get("n", 0), "tol": m.get("tol_k"), "g": m["gun"],
             "lnk": "https://www.betexplorer.com" + m.get("link", "")}
        if m.get("o"):
            r["ag"] = round(m.get("avg", 0), 2); r["o25"] = round(m.get("o25", 0))
            r["kg"] = round(m.get("btts", 0)); r["marj"] = round(m.get("marj", 0), 1)
            r["d"] = [round(x, 1) for x in (m.get("dagilim") or [0, 0, 0])]
            p = m.get("en_iyi")
            if p and m.get("n"):
                r.update(ad=p["ad"], oran=round(p["oran"], 2), piy=round(p["piyasa"], 1),
                         hist=round(p["hist"], 1), edge=round(p["edge"], 1),
                         ci=[round(p["ci"][0], 1), round(p["ci"][2], 1)], roi=round(p["roi"], 1),
                         sinyal=int(m["n"] >= 18 and p["ci"][0] > p["piyasa"] and p["edge"] >= 3
                                    and (m.get("tol_k") or 9) <= 0.20),
                         kalite=("kesin" if (m.get("tol_k") or 9) <= 0.05 else
                                 "iyi" if (m.get("tol_k") or 9) <= 0.15 else
                                 "geniş" if (m.get("tol_k") or 9) <= 0.28 else "gevşek"),
                         kelly=round(p.get("kelly", 0), 1),
                         ornek=[{"d": c.get("date", ""), "h": c.get("home", ""), "a": c.get("away", ""),
                                 "sk": f"{c['hg']}:{c['ag']}",
                                 "o": [round(c["o1"], 2), round(c["ox"], 2), round(c["o2"], 2)]}
                                for c in (m.get("ornek") or [])])
        out.append(r)
    out.sort(key=lambda r: (-(r.get("sinyal", 0)), -(r.get("edge") if r.get("edge") is not None else -99)))
    return out

CSS = """*{box-sizing:border-box}
body{margin:0;background:#0a121e;color:#e8eef5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px}
.wrap{max-width:1560px;margin:0 auto;padding:16px 12px 60px}
h1{font-size:23px;margin:0 0 4px;background:linear-gradient(90deg,#5ee7a0,#4fc3f7);-webkit-background-clip:text;background-clip:text;color:transparent}
.sub{color:#8ba3b8;font-size:12.5px;margin-bottom:10px}
.kpi{display:grid;gap:9px;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));margin:10px 0}
.kpi div{background:#0f1a27;border:1px solid #1d2d42;border-radius:10px;padding:8px 11px}
.kpi b{display:block;color:#8ba3b8;font-size:10px;text-transform:uppercase;letter-spacing:.4px}
.kpi span{font-size:18px;font-weight:800}
.arac{display:flex;gap:7px;flex-wrap:wrap;align-items:center;background:#0f1a27;border:1px solid #1d2d42;border-radius:12px;padding:10px 12px;margin:10px 0;position:sticky;top:0;z-index:9}
input,select{padding:8px 10px;border-radius:9px;border:1px solid #24384f;background:#0b1522;color:#e8eef5;font-size:12.5px;outline:none}
input[type=text]{min-width:210px;flex:1}
button{padding:8px 14px;border-radius:9px;border:0;background:linear-gradient(90deg,#1f9d63,#0e8f8f);color:#fff;font-weight:700;font-size:12.5px;cursor:pointer}
button.alt{background:#22344a}button:hover{filter:brightness(1.15)}
table{width:100%;border-collapse:collapse;font-size:12px}
th,td{border:1px solid #1d2d42;padding:5px 6px;text-align:left;white-space:nowrap}
th{background:#16273a;color:#9fd6ff;font-size:11px;cursor:pointer;position:sticky;top:54px;z-index:4}
th:hover{background:#1d3450}
tbody tr:nth-child(even){background:#0c1622}
tbody tr:hover{background:#15263a}
tr.sin{background:#0e2a1e !important;box-shadow:inset 3px 0 0 #5ee7a0}
tr.sin:hover{background:#143a29 !important}
tr.oyok{opacity:.45}
.od{text-align:center;font-variant-numeric:tabular-nums}
.mini{color:#8ba3b8;font-size:11px}
.git{color:#5ee7a0}.yit{color:#ffd479}.kit{color:#ff8a8a}
.bg{display:inline-block;padding:1px 6px;border-radius:6px;font-size:10.5px;font-weight:700}
.bg.y{background:#124a2e;color:#5ee7a0}.bg.o{background:#3d3410;color:#ffd479}.bg.z{background:#24354a;color:#9fb4c7}
a{color:#4fc3f7;text-decoration:none}a:hover{text-decoration:underline}
.det td{background:#0c1622}
@media print{body{background:#fff;color:#000}.arac,button{display:none}th{background:#eee;color:#000;position:static}
table{font-size:9px}tr.sin{background:#e6f7ec !important}.kpi div{border-color:#ccc}a{color:#000}}"""

def uret(dosya="/home/user/BULTEN.html"):
    ms = yukle()
    K = kayitlar(ms)
    veri = json.dumps(K, ensure_ascii=False, separators=(",", ":"))
    n_tum = len(K)
    n_oran = sum(1 for r in K if r["o"])
    n_kar = sum(1 for r in K if r.get("n"))
    n_sin = sum(1 for r in K if r.get("sinyal"))
    n_yuk = sum(1 for r in K if r.get("n", 0) >= 40 and r.get("sinyal"))
    ligler = sorted({r["l"] for r in K if r["l"]})

    doc = f"""<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>TAM BÜLTEN — {BUGUN} · {n_tum} maç</title><style>{CSS}</style></head><body><div class="wrap">
<h1>📋 TAM BÜLTEN — {BUGUN}</h1>
<div class="sub">Bugünün <b>TÜM {n_tum} maçı</b> · {n_oran} maçın 1X2 oranı bulundu · <b>{n_kar} maç karşılaştırıldı</b>
(her maç için arşivde aynı oranla oynanan maçlar bulundu) · arşiv <b>67.464 maç</b> (2011→2026)<br>
<b>Tek dosya — internet gerekmez.</b> Ara, filtrele, sütun başlığına tıkla, maça tıkla → eşleşen maçlar.</div>
<div class="kpi">
<div><b>Toplam maç</b><span>{n_tum}</span></div>
<div><b>Oranı bulunan</b><span>{n_oran}</span></div>
<div><b>Karşılaştırılan</b><span>{n_kar}</span></div>
<div><b>Değer sinyali</b><span class="git">{n_sin}</span></div>
<div><b>Yüksek güven</b><span class="git">{n_yuk}</span></div>
<div><b>Lig</b><span>{len(ligler)}</span></div>
</div>
<div class="arac">
  <input type="text" id="q" placeholder="Takım / lig ara (ör. Ried, Ekstraklasa)">
  <select id="flt">
    <option value="hepsi">Tüm maçlar ({n_tum})</option>
    <option value="sinyal">🟩 Sadece değer sinyalleri ({n_sin})</option>
    <option value="kar">Karşılaştırılanlar ({n_kar})</option>
    <option value="siki">Sıkı eşleşme (tolerans ≤0.15)</option>
    <option value="oransiz">Oranı bulunamayanlar ({n_tum-n_oran})</option>
  </select>
  <select id="lig"><option value="">Tüm ligler</option>{"".join(f'<option value="{H.escape(l)}">{H.escape(l)}</option>' for l in ligler)}</select>
  <button onclick="window.print()">🖨️ Yazdır</button>
  <button class="alt" onclick="sifirla()">↺ Sıfırla</button>
  <span class="mini" id="sayac"></span>
</div>
<table id="tbl"><thead><tr>
<th data-k="s">Saat</th><th data-k="l">Lig</th><th data-k="h">Maç</th><th data-k="k">Skor</th>
<th data-k="o1">1</th><th data-k="o2">X</th><th data-k="o3">2</th>
<th data-k="n">Örnek</th><th data-k="tol">Tol.</th><th data-k="d1">Ev%</th><th data-k="d2">Ber%</th><th data-k="d3">Dep%</th>
<th data-k="ad">En iyi</th><th data-k="edge">Fark</th><th data-k="ci">%95 GA</th><th data-k="guv">Güven</th>
<th data-k="roi">ROI</th><th data-k="ag">Ort.gol</th><th data-k="o25">2.5Ü</th><th data-k="kg">KG</th><th data-k="marj">Marj</th>
</tr></thead><tbody id="tb"></tbody></table>
<div class="mini" style="margin-top:12px">
<b>Nasıl okunur:</b> Her maç için 1X2 oranı 67.464 maçlık arşivde taranır; <b>Örnek</b> = aynı oranla oynanmış maç sayısı,
<b>Tol.</b> = kullanılan tolerans (küçükse eşleşme çok isabetli). <b>Ev%/Ber%/Dep%</b> = o maçların gerçek sonuç dağılımı,
<b>Fark</b> = tarihsel isabet − piyasa olasılığı, <b>ROI</b> = o taraftan düz bahis getirisi.
🟩 <b>Yeşil satır</b>: 18+ örnekli, tolerans ≤0.20 ve güven aralığının alt sınırı bile piyasa olasılığından yüksek = savunulabilir fırsat.
<b>Tolerans kalitesi:</b> <span class="git">kesin</span> (±≤0.05) · iyi (±≤0.15) · <span class="yit">geniş</span> (±≤0.28) · gevşek. Küçük tolerans = eşleşme o kadar isabetli.
<br>Oranı bulunamayan maçlar listede soluk görünür (BetExplorer bu maçlara oran yayınlamamış).</div>
</div>
<script>
const D={veri};
let sir="edge",ters=true;
function deger(r,k){{
 if(k==="o1")return r.o?r.o[0]:-99; if(k==="o2")return r.o?r.o[1]:-99; if(k==="o3")return r.o?r.o[2]:-99;
 if(k==="d1")return r.d?r.d[0]:-99; if(k==="d2")return r.d?r.d[1]:-99; if(k==="d3")return r.d?r.d[2]:-99;
 if(k==="ci")return r.ci?r.ci[0]:-99; if(k==="ad")return r.ad||"";
 if(k==="guv")return r.n>=40?(r.sinyal?3:1):(r.n>=18?(r.sinyal?2:1):0);
 return r[k]!==undefined&&r[k]!==null?r[k]:-99;
}}
function guv(r){{ if(!r.n) return "<span class='mini'>—</span>";
 if(r.n>=40&&r.sinyal) return "<span class='bg y'>YÜKSEK</span>";
 if(r.n>=18&&r.sinyal) return "<span class='bg o'>ORTA</span>";
 if(r.sinyal) return "<span class='bg z'>DÜŞÜK</span>";
 return "<span class='mini'>sinyal yok</span>";}}
function ciz(){{
 const q=document.getElementById("q").value.toLowerCase().trim();
 const f=document.getElementById("flt").value, lg=document.getElementById("lig").value;
 let L=D.filter(r=>{{
  if(f==="sinyal"&&!r.sinyal)return false;
  if(f==="kar"&&!r.n)return false;
  if(f==="siki"&&!(r.n&&r.tol<=0.15))return false;
  if(f==="oransiz"&&r.o)return false;
  if(lg&&r.l!==lg)return false;
  if(q&&!((r.h+" "+r.a+" "+r.l+" "+r.lt).toLowerCase().includes(q)))return false;
  return true;}});
 L.sort((a,b)=>{{const x=deger(a,sir),y=deger(b,sir);
  if(typeof x==="string")return ters?y.localeCompare(x,"tr"):x.localeCompare(y,"tr");
  return ters?y-x:x-y;}});
 let h="";
 for(const r of L){{
  const idx=D.indexOf(r);
  h+=`<tr class="${{r.sinyal?"sin":""}}${{!r.o?" oyok":""}}" onclick="det(this,${{idx}})">`
   +`<td class="od">${{r.s}}</td><td class="mini">${{r.l}}</td>`
   +`<td><b>${{r.h}}</b> - ${{r.a}}</td><td class="od">${{r.k||""}}</td>`;
  if(!r.o){{ h+=`<td colspan="17" class="mini">BetExplorer bu maç için oran yayınlamamış</td>`; }}
  else {{
   h+=`<td class="od">${{r.o[0].toFixed(2)}}</td><td class="od">${{r.o[1].toFixed(2)}}</td><td class="od">${{r.o[2].toFixed(2)}}</td>`;
   if(r.n){{ h+=`<td class="od">${{r.n}}</td><td class="od mini ${{r.kalite==="kesin"?"git":(r.kalite==="iyi"?"":"yit")}}">±${{r.tol}}<br><span style="font-size:9.5px">${{r.kalite}}</span></td>`
     +`<td class="od">${{r.d[0].toFixed(0)}}</td><td class="od">${{r.d[1].toFixed(0)}}</td><td class="od">${{r.d[2].toFixed(0)}}</td>`
     +`<td class="od"><b>${{r.ad}}</b></td><td class="od ${{r.edge>0?"git":"kit"}}">${{r.edge>0?"+":""}}${{r.edge.toFixed(1)}}</td>`
     +`<td class="od mini">${{r.ci[0].toFixed(0)}}–${{r.ci[1].toFixed(0)}}</td><td>${{guv(r)}}</td>`
     +`<td class="od ${{r.roi>0?"git":"kit"}}">${{r.roi>0?"+":""}}${{r.roi.toFixed(0)}}%</td>`; }}
   else h+=`<td colspan="9" class="mini">arşivde eşleşme bulunamadı</td>`;
   h+=`<td class="od">${{r.ag.toFixed(2)}}</td><td class="od">${{r.o25}}%</td><td class="od">${{r.kg}}%</td><td class="od mini">${{r.marj}}%</td>`;
  }}
  h+=`</tr>`;
 }}
 document.getElementById("tb").innerHTML=h;
 document.getElementById("sayac").textContent=L.length+" maç";
}}
function det(tr,i){{
 const r=D[i]; if(!r||!r.ornek||!r.ornek.length)return;
 const nx=tr.nextElementSibling;
 if(nx&&nx.classList.contains("det")){{nx.remove();return;}}
 let h=`<td colspan="21"><div class="mini" style="margin:4px 0"><b>${{r.h}} - ${{r.a}}</b> ·
   bu oranla oynanan ${{r.n}} maçtan son ${{r.ornek.length}} tanesi (tolerans ±${{r.tol}}) ·
   <a href="${{r.lnk}}" target="_blank">BetExplorer'da aç ↗</a></div>
   <table><tr><th>Tarih</th><th>Ev</th><th>Deplasman</th><th>MS</th><th>Oran 1/X/2</th><th>Sonuç</th></tr>`;
 for(const c of r.ornek){{const s=c.sk.split(":");const son=+s[0]>+s[1]?"Ev":(+s[0]===+s[1]?"Beraberlik":"Deplasman");
  h+=`<tr><td>${{c.d}}</td><td>${{c.h}}</td><td>${{c.a}}</td><td class="od"><b>${{c.sk}}</b></td>`
   +`<td class="od">${{c.o[0].toFixed(2)}} / ${{c.o[1].toFixed(2)}} / ${{c.o[2].toFixed(2)}}</td><td>${{son}}</td></tr>`;}}
 h+="</table></td>";
 const y=document.createElement("tr");y.className="det";y.innerHTML=h;tr.after(y);
}}
function sifirla(){{document.getElementById("q").value="";document.getElementById("flt").value="hepsi";document.getElementById("lig").value="";ciz();}}
document.querySelectorAll("th").forEach(th=>th.onclick=()=>{{const k=th.dataset.k;
 if(sir===k)ters=!ters;else{{sir=k;ters=true;}}ciz();}});
document.getElementById("q").oninput=ciz;
document.getElementById("flt").onchange=ciz;
document.getElementById("lig").onchange=ciz;
ciz();
</script></body></html>"""
    open(dosya, "w", encoding="utf-8").write(doc)

    # Excel + CSV
    bas = ["Saat", "Lig", "Ev", "Deplasman", "Skor", "1", "X", "2", "Örnek", "Tolerans", "Ev%", "Ber%", "Dep%",
           "En iyi", "Fark", "GA alt", "GA üst", "Güven", "ROI%", "Kelly%", "Ort.gol", "2.5Ü%", "KG%", "Marj%", "Sinyal", "Link"]
    def sat(r):
        g = ("YÜKSEK" if r.get("n", 0) >= 40 and r.get("sinyal") else "ORTA" if r.get("n", 0) >= 18 and r.get("sinyal")
             else "DÜŞÜK" if r.get("sinyal") else "")
        return [r["s"], r["l"], r["h"], r["a"], r["k"],
                (r["o"][0] if r["o"] else ""), (r["o"][1] if r["o"] else ""), (r["o"][2] if r["o"] else ""),
                r.get("n", ""), r.get("tol", ""),
                (r["d"][0] if r.get("d") else ""), (r["d"][1] if r.get("d") else ""), (r["d"][2] if r.get("d") else ""),
                r.get("ad", ""), r.get("edge", ""),
                (r["ci"][0] if r.get("ci") else ""), (r["ci"][1] if r.get("ci") else ""), g,
                r.get("roi", ""), r.get("kelly", ""), r.get("ag", ""), r.get("o25", ""), r.get("kg", ""),
                r.get("marj", ""), "DEĞERLİ" if r.get("sinyal") else "", r["lnk"]]
    with open("/home/user/BULTEN.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";"); w.writerow(bas)
        for r in K: w.writerow(sat(r))
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        wb = Workbook(); ws = wb.active; ws.title = "Tam Bülten"
        ws.append(bas)
        for c in range(1, len(bas) + 1):
            cell = ws.cell(1, c); cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1F4E79"); cell.alignment = Alignment(horizontal="center")
        yesil = PatternFill("solid", fgColor="C6EFCE")
        for r in K:
            ws.append(sat(r))
            if r.get("sinyal"):
                for c in range(1, len(bas) + 1): ws.cell(ws.max_row, c).fill = yesil
        ws.freeze_panes = "A2"; ws.auto_filter.ref = ws.dimensions
        for col, w_ in zip("ABCDEFGHIJKLMNOPQRSTUVWXYZ", [7, 24, 20, 20, 8, 7, 7, 7, 7, 9, 6, 6, 6, 12, 7, 7, 7, 9, 8, 7, 9, 7, 6, 7, 10, 45]):
            ws.column_dimensions[col].width = w_
        wb.save("/home/user/BULTEN.xlsx")
    except Exception as ex:
        print("xlsx:", ex)
    print(f"OK BULTEN.html | {n_tum} maç | {n_oran} oranlı | {n_kar} karşılaştırıldı | {n_sin} sinyal | {len(doc)//1024} KB")
    return dosya

if __name__ == "__main__":
    uret()
