#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TEK DOSYA BÜLTEN — internet gerektirmeyen, aranabilir, filtrelenebilir,
yazdırılabilir bağımsız HTML.  Kullanım: python3 bulten_tek_dosya.py"""
import json, time, html as H, sys
sys.path.insert(0, "/home/user")
import tarama as T
import bulten as B

def uret(dosya="/home/user/BULTEN.html"):
    t0 = time.time()
    sonuc = T.tarama(0.15, verbose=False)
    B.zenginlestir(sonuc)
    kayitlar = []
    for m in sonuc:
        p = m.get("en_iyi")
        n = m.get("n", 0)
        rec = {"s": m.get("saat", ""), "l": m.get("liga", ""), "h": m.get("home", ""), "a": m.get("away", ""),
               "o": [round(x, 2) for x in m["o"]], "n": n,
               "d": [round(x, 1) for x in (m.get("dagilim") or [0, 0, 0])],
               "ag": round(m.get("avg", 0), 2), "o25": round(m.get("o25", 0)),
               "kg": round(m.get("btts", 0)), "lnk": "https://www.betexplorer.com" + m.get("link", "")}
        if p and n >= 8:
            rec.update(ad=p["ad"], oran=round(p["oran"], 2), piy=round(p["piyasa"], 1), hist=round(p["hist"], 1),
                       edge=round(p["edge"], 1), ci=[round(p["ci"][0], 1), round(p["ci"][2], 1)],
                       roi=round(p["roi"], 1),
                       sinyal=int(p["ci"][0] > p["piyasa"] and p["edge"] >= 3),
                       guv=("YUKSEK" if n >= 40 and p["ci"][0] > p["piyasa"] and p["edge"] >= 3 else
                            ("ORTA" if n >= 18 and p["ci"][0] > p["piyasa"] and p["edge"] >= 3 else "DUSUK")),
                       ornek=[{"d": c.get("date", ""), "h": c.get("home", ""), "a": c.get("away", ""),
                               "sk": f"{c['hg']}:{c['ag']}", "o": [round(c["o1"], 2), round(c["ox"], 2), round(c["o2"], 2)]}
                              for c in m.get("ornek", [])[:6]])
        kayitlar.append(rec)
    kayitlar.sort(key=lambda r: (-(r.get("sinyal", 0)), -(r.get("edge") or 0)))
    veri = json.dumps(kayitlar, ensure_ascii=False, separators=(",", ":"))
    n_sin = sum(1 for r in kayitlar if r.get("sinyal"))
    n_tam = sum(1 for r in kayitlar if r["n"] >= 8)
    ligler = sorted({r["l"] for r in kayitlar})

    html_doc = f"""<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>GÜNÜN BÜLTENİ — {T.BUGUN}</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;background:#0a121e;color:#e8eef5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px}}
.wrap{{max-width:1500px;margin:0 auto;padding:18px 14px 60px}}
h1{{font-size:24px;margin:0 0 4px;background:linear-gradient(90deg,#5ee7a0,#4fc3f7);-webkit-background-clip:text;background-clip:text;color:transparent}}
.sub{{color:#8ba3b8;font-size:12.5px;margin-bottom:12px}}
.kpi{{display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));margin:12px 0}}
.kpi div{{background:#0f1a27;border:1px solid #1d2d42;border-radius:10px;padding:9px 12px}}
.kpi b{{display:block;color:#8ba3b8;font-size:10.5px;text-transform:uppercase;letter-spacing:.4px;margin-bottom:2px}}
.kpi span{{font-size:19px;font-weight:800}}
.arac{{display:flex;gap:8px;flex-wrap:wrap;align-items:center;background:#0f1a27;border:1px solid #1d2d42;border-radius:12px;padding:11px 13px;margin:12px 0;position:sticky;top:0;z-index:5}}
input,select{{padding:9px 11px;border-radius:9px;border:1px solid #24384f;background:#0b1522;color:#e8eef5;font-size:13px;outline:none}}
input:focus,select:focus{{border-color:#4fc3f7}}
input[type=text]{{min-width:230px;flex:1}}
button{{padding:9px 15px;border-radius:9px;border:0;background:linear-gradient(90deg,#1f9d63,#0e8f8f);color:#fff;font-weight:700;font-size:12.5px;cursor:pointer}}
button:hover{{filter:brightness(1.15)}}
button.alt{{background:#22344a}}
table{{width:100%;border-collapse:collapse;font-size:12.5px}}
th,td{{border:1px solid #1d2d42;padding:6px 7px;text-align:left;white-space:nowrap}}
th{{background:#16273a;color:#9fd6ff;font-size:11.5px;cursor:pointer;user-select:none;position:sticky;top:56px;z-index:3}}
th:hover{{background:#1d3450}}
tbody tr{{border-left:3px solid transparent}}
tbody tr:nth-child(even){{background:#0c1622}}
tbody tr:hover{{background:#15263a}}
tr.sin{{background:#0e2a1e !important;border-left-color:#5ee7a0}}
tr.sin:hover{{background:#143a29 !important}}
.od{{text-align:center;font-variant-numeric:tabular-nums}}
.mini{{color:#8ba3b8;font-size:11px}}
.git{{color:#5ee7a0}}.yit{{color:#ffd479}}.kit{{color:#ff8a8a}}
.bg{{display:inline-block;padding:1px 7px;border-radius:6px;font-size:10.5px;font-weight:700}}
.bg.y{{background:#124a2e;color:#5ee7a0}}.bg.o{{background:#3d3410;color:#ffd479}}.bg.z{{background:#24354a;color:#9fb4c7}}
a{{color:#4fc3f7;text-decoration:none}}a:hover{{text-decoration:underline}}
.det{{display:none;background:#0c1622}}
.det table{{font-size:11.5px;margin:4px 0}}
@media print{{body{{background:#fff;color:#000}}th{{background:#eee;color:#000;position:static}}
 table{{font-size:10px}} .arac{{display:none}} button{{display:none}} tr.sin{{background:#e8f8ee !important}}
 .kpi div,.wrap{{border-color:#ccc}} a{{color:#000}}}}
</style></head><body><div class="wrap">
<h1>📋 GÜNÜN BÜLTENİ — {T.BUGUN}</h1>
<div class="sub">Tüm maçlar · her maçın oranına en yakın maçların <b>gerçek sonuç dağılımı</b> · arşiv <b>67.464 maç</b> (2011→2026) · tolerans ±0.15<br>
<b>Bu dosya kendi kendine yeterlidir — internet olmadan da açılır.</b> Aramak için kutuyu kullan, sütun başlıklarına tıklayarak sırala.</div>
<div class="kpi">
<div><b>Toplam maç</b><span>{len(kayitlar)}</span></div>
<div><b>8+ örnekli</b><span>{n_tam}</span></div>
<div><b>Değer sinyali</b><span class="git">{n_sin}</span></div>
<div><b>Lig</b><span>{len(ligler)}</span></div>
</div>
<div class="arac">
  <input type="text" id="q" placeholder="Takım veya lig ara… (ör. Wisla, Ekstraklasa)">
  <select id="flt">
    <option value="hepsi">Tüm maçlar</option>
    <option value="sinyal">🟩 Sadece değer sinyalleri</option>
    <option value="ornek">8+ örnekli maçlar</option>
  </select>
  <select id="lig"><option value="">Tüm ligler</option>{"".join(f'<option value="{H.escape(l)}">{H.escape(l)}</option>' for l in ligler)}</select>
  <button onclick="yazdir()">🖨️ Yazdır</button>
  <button class="alt" onclick="sifirla()">↺ Sıfırla</button>
  <span class="mini" id="sayac"></span>
</div>
<table id="tbl"><thead><tr>
<th data-k="s">Saat</th><th data-k="l">Lig</th><th data-k="h">Maç</th>
<th data-k="o1">Oran 1</th><th data-k="o2">X</th><th data-k="o3">2</th>
<th data-k="n">Örnek</th><th data-k="d1">Ev%</th><th data-k="d2">Ber%</th><th data-k="d3">Dep%</th>
<th data-k="ad">En iyi</th><th data-k="edge">Fark</th><th data-k="ci">%95 GA</th><th data-k="guv">Güven</th>
<th data-k="roi">ROI</th><th data-k="ag">Ort.gol</th><th data-k="o25">2.5Ü</th><th data-k="kg">KG</th>
</tr></thead><tbody id="tb"></tbody></table>
<div class="mini" style="margin-top:14px">Yöntem: her maçın 1X2 oranı 67.464 maçlık arşivde ±0.15 toleransla taranır. Eşleşen maçların gerçek sonuçlarından
Ev/Ber/Dep dağılımı, %95 Wilson güven aralığı, ROI (o orandan düz bahis) ve değer farkı (tarihsel isabet − marj arındırılmış piyasa olasılığı) hesaplanır.
<b>Yeşil satır</b>: güven aralığının alt sınırı bile piyasa olasılığından yüksek — istatistiksel olarak savunulabilir fırsat. Satıra tıkla → eşleşen maçların listesi.</div>
</div>
<script>
const D={veri};
let sir="edge", ters=true;
function skor(r,k){{
  if(k==="o1")return r.o[0];if(k==="o2")return r.o[1];if(k==="o3")return r.o[2];
  if(k==="d1")return r.d[0];if(k==="d2")return r.d[1];if(k==="d3")return r.d[2];
  if(k==="ci")return r.ci?r.ci[0]:-99;
  if(k==="ad")return r.ad||"";
  return r[k]!==undefined?r[k]:-99;
}}
function guvBadge(g){{if(!g)return"<span class='mini'>—</span>";
  if(g==="YUKSEK")return"<span class='bg y'>YÜKSEK</span>";
  if(g==="ORTA")return"<span class='bg o'>ORTA</span>";return"<span class='bg z'>DÜŞÜK</span>";}}
function ciz(){{
  const q=document.getElementById("q").value.toLowerCase().trim();
  const f=document.getElementById("flt").value, lg=document.getElementById("lig").value;
  let L=D.filter(r=>{{
    if(f==="sinyal"&&!r.sinyal)return false;
    if(f==="ornek"&&r.n<8)return false;
    if(lg&&r.l!==lg)return false;
    if(q&&!((r.h+" "+r.a+" "+r.l).toLowerCase().includes(q)))return false;
    return true;}});
  L.sort((a,b)=>{{const x=skor(a,sir),y=skor(b,sir);
    if(typeof x==="string")return ters?y.localeCompare(x):x.localeCompare(y);
    return ters?y-x:x-y;}});
  let h="";
  for(const r of L){{
    const ok=r.n>=8&&r.ad;
    h+=`<tr class="${{r.sinyal?"sin":""}}" onclick="det(this,${{D.indexOf(r)}})">`
      +`<td class="od">${{r.s}}</td><td class="mini">${{r.l}}</td>`
      +`<td><b>${{r.h}}</b> - ${{r.a}}</td>`
      +`<td class="od">${{r.o[0].toFixed(2)}}</td><td class="od">${{r.o[1].toFixed(2)}}</td><td class="od">${{r.o[2].toFixed(2)}}</td>`
      +`<td class="od">${{r.n}}</td><td class="od">${{r.d[0].toFixed(0)}}</td><td class="od">${{r.d[1].toFixed(0)}}</td><td class="od">${{r.d[2].toFixed(0)}}</td>`;
    if(ok){{
      h+=`<td class="od"><b>${{r.ad}}</b></td><td class="od ${{r.edge>0?"git":"kit"}}">${{r.edge>0?"+":""}}${{r.edge.toFixed(1)}}</td>`
        +`<td class="od mini">${{r.ci[0].toFixed(0)}}–${{r.ci[1].toFixed(0)}}</td><td>${{guvBadge(r.guv)}}</td>`
        +`<td class="od ${{r.roi>0?"git":"kit"}}">${{r.roi>0?"+":""}}${{r.roi.toFixed(0)}}%</td>`;
    }}else h+=`<td colspan="5" class="mini">yeterli benzer maç yok</td>`;
    h+=`<td class="od">${{r.ag.toFixed(2)}}</td><td class="od">${{r.o25}}%</td><td class="od">${{r.kg}}%</td></tr>`;
  }}
  document.getElementById("tb").innerHTML=h;
  document.getElementById("sayac").textContent=L.length+" maç gösteriliyor";
}}
function det(tr,i){{
  const r=D[i];
  if(!r.ornek)return;
  const nx=tr.nextElementSibling;
  if(nx&&nx.classList.contains("det")){{nx.remove();return;}}
  let h=`<td colspan="18"><div class="mini">${{r.h}} - ${{r.a}} ile aynı oranla oynanan maçlar:</div><table><tr><th>Tarih</th><th>Ev</th><th>Deplasman</th><th>MS</th><th>Oran</th><th>Sonuç</th></tr>`;
  for(const c of r.ornek){{const s=c.sk.split(":");const son=+s[0]>+s[1]?"Ev":(+s[0]===+s[1]?"Beraberlik":"Deplasman");
    h+=`<tr><td>${{c.d}}</td><td>${{c.h}}</td><td>${{c.a}}</td><td class="od"><b>${{c.sk}}</b></td><td class="od">${{c.o[0].toFixed(2)}}/${{c.o[1].toFixed(2)}}/${{c.o[2].toFixed(2)}}</td><td>${{son}}</td></tr>`;}}
  h+="</table></td>";
  const y=document.createElement("tr");y.className="det";y.innerHTML=h;tr.after(y);
}}
function yazdir(){{window.print();}}
function sifirla(){{document.getElementById("q").value="";document.getElementById("flt").value="hepsi";document.getElementById("lig").value="";ciz();}}
document.querySelectorAll("th").forEach(th=>th.onclick=()=>{{
  const k=th.dataset.k; if(sir===k)ters=!ters; else{{sir=k;ters=true;}} ciz();}});
document.getElementById("q").oninput=ciz;
document.getElementById("flt").onchange=ciz;
document.getElementById("lig").onchange=ciz;
ciz();
</script></body></html>"""
    open(dosya, "w", encoding="utf-8").write(html_doc)
    print(f"OK {dosya} | {len(kayitlar)} maç | {n_sin} sinyal | {len(html_doc)//1024} KB | {round(time.time()-t0)} sn")
    return dosya

if __name__ == "__main__":
    uret()
