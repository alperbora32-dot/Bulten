#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TAM BÜLTEN v2 — aynı oranlı maçların TAM market kırılımı ile."""
import json, html as H, sys, csv, os, time
sys.path.insert(0, "/home/user")
import tam_tarama as TT
import detay as DE
import korner as KO

VERI = "/home/user/veri/tam_tarama.json"
BUGUN = "2026-09-11"

def kayit_uret(gunler=None):
    """gunler=None → bugün; liste verilirse o günler."""
    d = json.load(open(VERI, encoding="utf-8"))
    g = [m for m in d if m.get("o") and (m["gun"] in gunler if gunler else m["gun"] == BUGUN)]
    SKOR = TT.skor_yukle()
    ms, o1s = TT.arsiv()
    ht = DE.ht()
    KOR = KO._yukle()
    out = []
    for m in g:
        e = TT.eslesen(ms, o1s, m["o"], m["tol_k"]) if m.get("tol_k") else []
        det = DE.grup_detay(e) if e else None
        p = m.get("en_iyi")
        r = {"s": m.get("saat", ""), "l": m.get("lig", ""), "lt": m.get("lig_tam", ""),
             "h": m.get("home", ""), "a": m.get("away", ""), "k": m.get("skor", ""),
             "o": [round(x, 2) for x in m["o"]], "n": m.get("n", 0), "tol": m.get("tol_k"),
             "lnk": "https://www.betexplorer.com" + m.get("link", ""), "gun": m.get("gun"),
             "mid": m.get("id")}
        sk = SKOR.get(m.get("id")) or ({"ms": m.get("skor", ""), "iy": m.get("iy", ""),
                                        "durum": m.get("durum", "bitti")} if m.get("skor") else
                                       {"ms": "", "iy": "", "durum": m.get("durum", "bekliyor")})
        r["canli"] = sk
        # --- korner ---
        try:
            kr = KO.bul(m.get("ulke"), m.get("home"), m.get("away"), KOR)
            if kr and kr.get("tot"): r["kor"] = kr
        except Exception:
            pass
        try:
            kr = KO.bul(m.get("ulke"), m.get("home"), m.get("away"), KOR)
            if kr and kr.get("tot"): r["kor"] = kr
        except Exception:
            pass
        if det:
            r["det"] = det
            r["d"] = det["ms"]
            r["marj"] = round(m.get("marj", 0), 1)
            son = [{"d": c.get("date", ""), "h": c.get("home", ""), "a": c.get("away", ""),
                    "sk": f"{c['hg']}:{c['ag']}",
                    "iy": (f"{c['ht_h']}:{c['ht_a']}" if "ht_h" in c else
                           (f"{ht[c['id']][0]}:{ht[c['id']][1]}" if ht.get(c["id"]) else "")),
                    "o": [round(c["o1"], 2), round(c["ox"], 2), round(c["o2"], 2)]}
                   for c in sorted(e, key=lambda z: z.get("date", ""))[-250:]]
            r["ornek"] = son
        if p and m.get("n"):
            r.update(ad=p["ad"], oran=round(p["oran"], 2), piy=round(p["piyasa"], 1), hist=round(p["hist"], 1),
                     edge=round(p["edge"], 1), ci=[round(p["ci"][0], 1), round(p["ci"][2], 1)],
                     roi=round(p["roi"], 1), kelly=round(p.get("kelly", 0), 1),
                     sinyal=int(m["n"] >= 18 and p["ci"][0] > p["piyasa"] and p["edge"] >= 3
                                and (m.get("tol_k") or 9) <= 0.20),
                     kalite=("kesin" if (m.get("tol_k") or 9) <= 0.05 else "iyi" if (m.get("tol_k") or 9) <= 0.15
                             else "genis" if (m.get("tol_k") or 9) <= 0.28 else "gevsek"))
        out.append(r)
    out.sort(key=lambda r: (-(r.get("sinyal", 0)), -(r.get("edge") if r.get("edge") is not None else -99)))
    return out

KUYRUK = [("0.00", "Birebir"), ("0.02", "±0.02"), ("0.05", "±0.05"), ("0.10", "±0.10"), ("0.20", "±0.20")]

def kuyruk_hesapla(m, ms, o1s):
    """Her maç için 5 tolerans katmanında eşleşme + dağılım (hızlı)."""
    if not m.get("o"): return None
    out = []
    for tol, ad in KUYRUK:
        e = TT.eslesen(ms, o1s, m["o"], tol)
        n = len(e)
        if n == 0: out.append(None); continue
        hw = sum(1 for c in e if c["hg"] > c["ag"]); dr = sum(1 for c in e if c["hg"] == c["ag"])
        tot = [c["hg"] + c["ag"] for c in e]
        htli = [c for c in e if DE.ht().get(c["id"]) or "ht_h" in c]
        d = {"n": n, "tol": tol, "ad": ad,
             "ms": [round(100 * hw / n, 1), round(100 * dr / n, 1), round(100 * (n - hw - dr) / n, 1)],
             "u15": round(100 * sum(1 for t in tot if t > 1.5) / n, 1),
             "u25": round(100 * sum(1 for t in tot if t > 2.5) / n, 1),
             "u35": round(100 * sum(1 for t in tot if t > 3.5) / n, 1),
             "kg": round(100 * sum(1 for c in e if c["hg"] > 0 and c["ag"] > 0) / n, 1),
             "ort": round(sum(tot) / n, 2)}
        if len(htli) >= max(5, 0.45 * n):
            m2 = len(htli)
            def hv(c):
                v = DE.ht().get(c["id"])
                return (c["ht_h"], c["ht_a"]) if "ht_h" in c else (v[0], v[1]) if v else None
            hvler = [hv(c) for c in htli]; hvler = [x for x in hvler if x]
            if hvler:
                mm = len(hvler)
                d["htn"] = mm
                d["ht00"] = round(100 * sum(1 for x in hvler if x == (0, 0)) / mm, 1)
                d["htu15"] = round(100 * sum(1 for x in hvler if x[0] + x[1] > 1.5) / mm, 1)
                d["htkg"] = round(100 * sum(1 for x in hvler if x[0] > 0 and x[1] > 0) / mm, 1)
        out.append(d)
    return out

HTML_BAS = """<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>TAM BULTEN v2</title><style>__CSS__</style></head><body><div class="wrap">
__HEAD__
<div class="arac">
  <input type="text" id="q" placeholder="Takım / lig ara…">
  <select id="flt">__FILTRE__</select>
  <select id="lig"><option value="">Tüm ligler</option>__LIGLER__</select>
  <button onclick="window.print()">🖨️ Yazdır</button>
  <button class="alt" onclick="sifirla()">↺ Sıfırla</button>
  <span class="mini" id="sayac"></span>
</div>
<table id="tbl"><thead><tr>
<th data-k="s">Saat</th><th data-k="l">Lig</th><th data-k="h">Maç</th>
<th data-k="o1">1</th><th data-k="o2">X</th><th data-k="o3">2</th>
<th data-k="n">Örnek</th><th data-k="tol">Tol.</th>
<th data-k="d1">Ev%</th><th data-k="d2">Ber%</th><th data-k="d3">Dep%</th>
<th data-k="u15">1.5Ü</th><th data-k="u25">2.5Ü</th><th data-k="u35">3.5Ü</th><th data-k="kg">KG</th>
<th data-k="iy1">İY 1%</th><th data-k="iyx">İY X%</th><th data-k="iy2">İY 2%</th>
<th data-k="ht00">İY 0-0</th><th data-k="htu15">İY 1.5Ü</th><th data-k="iykg">İY KG</th>
<th data-k="ayni">İY=MS</th><th data-k="kor">Korner</th>
<th data-k="ad">En iyi</th><th data-k="edge">Fark</th><th data-k="ci">%95 GA</th><th data-k="guv">Güven</th><th data-k="roi">ROI</th>
</tr></thead><tbody id="tb">__SATIRLAR__</tbody></table>
<div class="mini" style="margin-top:12px">__DIPNOT__</div></div>
<script>const D=__VERI__;__JS__</script></body></html>"""

JS = r"""
let sir="edge",ters=true;
function dg(r,k){
 if(k=="o1")return r.o[0];if(k=="o2")return r.o[1];if(k=="o3")return r.o[2];
 if(k=="d1")return r.d?r.d[0]:-99;if(k=="d2")return r.d?r.d[1]:-99;if(k=="d3")return r.d?r.d[2]:-99;
 if(k=="ci")return r.ci?r.ci[0]:-99;
 if(k=="ad")return r.ad||"";
 if(k=="guv")return r.n>=40&&r.sinyal?3:(r.n>=18&&r.sinyal?2:(r.sinyal?1:0));
 if(["u15","u25","u35","kg","ht00","htu15","ayni","iy1","iyx","iy2","iykg","z00_u15","h2_gt1"].includes(k))
  return r.det&&r.det[k]!==undefined?r.det[k]:-99;
 if(k=="kor")return r.kor?r.kor.tot:-99;
 return r[k]!==undefined&&r[k]!==null?r[k]:-99;}
function guv(r){if(!r.n)return "<span class='mini'>—</span>";
 if(r.n>=40&&r.sinyal)return "<span class='bg y'>YÜKSEK</span>";
 if(r.n>=18&&r.sinyal)return "<span class='bg o'>ORTA</span>";
 if(r.sinyal)return "<span class='bg z'>DÜŞÜK</span>";
 return "<span class='mini'>—</span>";}
function pc(v,c){if(v===undefined||v===null||isNaN(v))return "<span class='mini'>–</span>";
 const col=c||(v>=55?"git":(v<=35?"kit":""));return `<span class="${col}">${v.toFixed(0)}%</span>`;}
function bar(v,color){if(v===undefined)return "";
 const w=Math.max(0,Math.min(100,v));return `<span style="display:inline-block;background:#16273a;border-radius:3px;width:52px;height:8px;vertical-align:middle;margin-right:4px"><span style="display:block;background:${color};height:8px;border-radius:3px;width:${w}%"></span></span>`;}
function ciz(){
 const q=document.getElementById("q").value.toLowerCase().trim();
 const f=document.getElementById("flt").value,lg=document.getElementById("lig").value;
 let L=D.filter(r=>{
  if(f=="sinyal"&&!r.sinyal)return false;
  if(f=="kar"&&!r.n)return false;
  if(f=="iy"&&!(r.det&&r.det.htn))return false;
  if(f=="siki"&&!(r.n&&r.tol<=0.15))return false;
  if(lg&&r.l!==lg)return false;
  if(q&&!((r.h+" "+r.a+" "+r.l+" "+r.lt).toLowerCase().includes(q)))return false;
  return true;});
 L.sort((a,b)=>{const x=dg(a,sir),y=dg(b,sir);
  if(typeof x=="string")return ters?y.localeCompare(x,"tr"):x.localeCompare(y,"tr");
  return ters?y-x:x-y;});
 let h="";
 for(const r of L){
  const idx=D.indexOf(r);
  const t=r.det||{};
  h+=`<tr class="${r.sinyal?"sin":""}" onclick="det(this,${idx})">`
   +`<td class="od">${r.s}</td><td class="mini">${r.l}</td><td><b>${r.h}</b> - ${r.a}</td>`
   +`<td class="od">${r.o[0].toFixed(2)}</td><td class="od">${r.o[1].toFixed(2)}</td><td class="od">${r.o[2].toFixed(2)}</td>`
   +`<td class="od">${r.n||"–"}</td><td class="od mini ${r.kalite=="kesin"?"git":(r.kalite=="iyi"?"":"yit")}">${r.tol!==null?"±"+r.tol:"–"}</td>`
   +`<td class="od">${r.d?r.d[0].toFixed(0):"–"}</td><td class="od">${r.d?r.d[1].toFixed(0):"–"}</td><td class="od">${r.d?r.d[2].toFixed(0):"–"}</td>`
   +`<td class="od">${t.iy1!==undefined?pc(t.iy1):"–"}</td><td class="od">${t.iyx!==undefined?pc(t.iyx):"–"}</td><td class="od">${t.iy2!==undefined?pc(t.iy2):"–"}</td>`;
  h+=`<td class="od">${t.u15!==undefined?pc(t.u15):"–"}</td><td class="od">${t.u25!==undefined?pc(t.u25):"–"}</td>`
   +`<td class="od">${t.u35!==undefined?pc(t.u35):"–"}</td><td class="od">${t.kg!==undefined?pc(t.kg):"–"}</td>`
   +`<td class="od">${t.ht00!==undefined?pc(t.ht00):"–"}</td><td class="od">${t.htu15!==undefined?pc(t.htu15):"–"}</td>`
   +`<td class="od">${t.htkg!==undefined?pc(t.htkg):"–"}</td>`
   +`<td class="od">${t.ayni!==undefined?pc(t.ayni):"–"}</td>`
   +`<td class="od">${r.kor?`<b>${r.kor.tot}</b> <span class="mini ${r.kor.tot>=9.5?"git":"kit"}">${r.kor.pick}</span>`:"–"}</td>`;
  if(r.ad){h+=`<td class="od"><b>${r.ad}</b></td><td class="od ${r.edge>0?"git":"kit"}">${r.edge>0?"+":""}${r.edge.toFixed(1)}</td>`
    +`<td class="od mini">${r.ci?r.ci[0].toFixed(0)+"–"+r.ci[1].toFixed(0):"–"}</td><td>${guv(r)}</td>`
    +`<td class="od ${r.roi>0?"git":"kit"}">${r.roi>0?"+":""}${r.roi.toFixed(0)}%</td>`;}
  else h+=`<td colspan="5" class="mini">—</td>`;
  h+=`</tr>`;
 }
 document.getElementById("tb").innerHTML=h;
 document.getElementById("sayac").textContent=L.length+" maç";
}
function detayPanel(r){
 const t=r.det||{};
 const L=[];
 L.push(iymsPanel(t));
 L.push(skorPanel(t));
 L.push(ekPanel(t));
 L.push(`<div class="pbox"><b>🎯 MAÇ SONUCU</b><table class="pt"><tr><th>Ev</th><th>Beraberlik</th><th>Deplasman</th></tr>
  <tr><td>${pc(t.ms?t.ms[0]:0)}</td><td>${pc(t.ms?t.ms[1]:0)}</td><td>${pc(t.ms?t.ms[2]:0)}</td></tr></table></div>`);
 if(t.gol){L.push(`<div class="pbox"><b>⚽ TOPLAM GOL DAĞILIMI</b> (ort. ${t.ort})
  <table class="pt"><tr><th>0</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5+</th></tr>
  <tr>${t.gol.map(g=>`<td>${g.toFixed(0)}%</td>`).join("")}</tr></table></div>`);}
 if(t.u15!==undefined){L.push(`<div class="pbox"><b>📊 ALT / ÜST</b>
  <table class="pt"><tr><th>Çizgi</th><th>ÜST</th><th>ALT</th></tr>
  <tr><td>1.5</td><td class="git">${t.u15.toFixed(0)}%</td><td class="kit">${(100-t.u15).toFixed(0)}%</td></tr>
  <tr><td>2.5</td><td class="git">${t.u25.toFixed(0)}%</td><td class="kit">${(100-t.u25).toFixed(0)}%</td></tr>
  <tr><td>3.5</td><td>${t.u35.toFixed(0)}%</td><td>${(100-t.u35).toFixed(0)}%</td></tr>
  <tr><td>4.5</td><td>${(t.u45||0).toFixed(0)}%</td><td>${(100-(t.u45||0)).toFixed(0)}%</td></tr>
  </table><div class="mini">Zaman ağırlıklı: 1.5Ü ${t.w_u15}% · 2.5Ü ${t.w_u25}% · 3.5Ü ${t.w_u35}%</div></div>`);}
 if(t.kg!==undefined){L.push(`<div class="pbox"><b>🥅 KARŞILIKLI GOL</b>
  <table class="pt"><tr><th>KG Var</th><th>KG Yok</th><th>0-0</th></tr>
  <tr><td class="git">${t.kg}%</td><td>${t.kg_yok}%</td><td>${(t.gol?t.gol[0]:0).toFixed(0)}%</td></tr></table>
  <div class="mini">Ort. gol: ev ${t.ev_g} · dep ${t.dep_g}</div></div>`);}
 if(t.htn){L.push(`<div class="pbox"><b>🕐 İLK YARI</b> <span class="mini">(${t.htn} maçta İY verisi)</span>
  <table class="pt"><tr><th>İY 0-0</th><th>İY 0.5Ü</th><th>İY 1.5Ü</th><th>İY KG</th></tr>
  <tr><td>${t.ht00}%</td><td>${t.htu05}%</td><td>${t.htu15}%</td><td>${t.htkg}%</td></tr></table>
  <table class="pt" style="margin-top:5px"><tr><th>İY Ev</th><th>İY Ber</th><th>İY Dep</th><th>İY ort.gol</th></tr>
  <tr><td>${t.htev}%</td><td>${t.htber}%</td><td>${t.htdep}%</td><td>${t.htort}</td></tr></table></div>`);
  L.push(`<div class="pbox"><b>🕑 2. YARI</b>
  <table class="pt"><tr><th>2Y 0.5Ü</th><th>2Y 1.5Ü</th><th>2Y ort.gol</th></tr>
  <tr><td>${t.h2u05}%</td><td>${t.h2u15}%</td><td>${t.h2ort}</td></tr></table></div>`);
  if(t.matrix){const lbl=["Ev","Ber","Dep"];
   let mx=`<div class="pbox"><b>🔀 İY → MS MATRİSİ</b> <span class="mini">İY'de önde götüren maçı bitirdi: <b>${t.ht_koruma}%</b> · döndü: ${t.donus}% · İY=MS: ${t.ayni}%</span>
   <table class="pt mx"><tr><th>İY ↓ / MS →</th><th>Ev</th><th>Beraberlik</th><th>Deplasman</th></tr>`;
   for(let i=0;i<3;i++){mx+=`<tr><th>İY ${lbl[i]}</th>`+t.matrix[i].map(v=>`<td>${v.toFixed(0)}%</td>`).join("")+`</tr>`;}
   mx+=`</table></div>`;L.push(mx);}
 }
 if(t.skor&&t.skor.length){L.push(`<div class="pbox"><b>🔢 EN SIK SKORLAR (MS)</b><div>${t.skor.map(s=>`<span class="pill">${s}</span>`).join("")}</div>
  ${t.htskor?`<b style="display:block;margin-top:6px">EN SIK İY SKORLARI</b><div>${t.htskor.map(s=>`<span class="pill">${s}</span>`).join("")}</div>`:""}</div>`);}
 return L.join("") + kornerPanel(arguments[1]||{});
}
function iymsPanel(t){
 if(!t.iyms||!Object.keys(t.iyms).length)return "";
 const M=(t.matrix&&t.matrix.length===3)?t.matrix:null;
 const lbl=["Ev","Ber","Dep"], renk=["#4fc3f7","#ffd479","#5ee7a0"];
 let best=Object.entries(t.iyms).sort((a,b)=>b[1].p-a[1].p)[0];
 let h=`<div class="pbox" style="min-width:330px"><b>🎯 İLK YARI / MAÇ SONUCU YÜZDELERİ</b>
  ${t.iy1!==undefined?`<span class="mini">İY sonuç: 1 %${t.iy1} · X %${t.iyx} · 2 %${t.iy2}</span>`:""}`;
 if(M){
  h+=`<table class="pt mx"><tr><th>İY ↓ / MS →</th><th>Ev</th><th>Beraberlik</th><th>Deplasman</th><th>İY toplam</th></tr>`;
  for(let i=0;i<3;i++){
   const top=M[i].reduce((a,b)=>a+b,0);
   h+=`<tr><th>İY ${lbl[i]}</th>`+M[i].map(v=>`<td style="background:${v>=20?"#143a29":v>=10?"#16273a":"transparent"}"><b>${v.toFixed(1)}%</b></td>`).join("")+`<td class="mini">${top.toFixed(1)}%</td></tr>`;
  }
  h+=`</table>`;
 }
 // 9 kombinasyon + adil oran
 h+=`<table class="pt" style="margin-top:5px"><tr><th>Kombinasyon</th><th>Yüzde</th><th>Adil oran</th><th>Kaç maç</th></tr>`;
 for(const k of Object.keys(t.iyms).sort((a,b)=>t.iyms[b].p-t.iyms[a].p)){
  const v=t.iyms[k];
  h+=`<tr${k==best[0]?' style="background:#143a29"':""}><td><b>${k}</b></td><td>${v.p.toFixed(1)}%</td><td class="git">${v.adil||"–"}</td><td class="mini">${v.n}</td></tr>`;
 }
 h+=`</table><div class="mini">Adil oran = 100/yüzde (komisyonsuz gerçek fiyat)</div></div>`;
 // İY skor dağılımı
 if(t.skor_iy_pct&&t.skor_iy_pct.length){
  h+=`<div class="pbox"><b>🕐 EN SIK İLK YARI SKORLARI</b><table class="pt"><tr><th>Skor</th><th>%</th></tr>`;
  for(const [k,v] of t.skor_iy_pct) h+=`<tr><td><b>${k}</b></td><td>${v.toFixed(1)}%</td></tr>`;
  h+=`</table></div>`;
 }
 return h;
}
function skorPanel(t){
 if(!t.skor_pct||!t.skor_pct.length)return "";
 let h=`<div class="pbox"><b>🔢 EN SIK MAÇ SONUCU SKORLARI</b><table class="pt"><tr><th>Skor</th><th>%</th></tr>`;
 for(const [k,v] of t.skor_pct.slice(0,12)) h+=`<tr><td><b>${k}</b></td><td>${v.toFixed(1)}%</td></tr>`;
 h+=`</table></div>`;
 if(t.en_sik_ev&&t.en_sik_ev.length){
  h+=`<div class="pbox"><b>En sık skorlar (taraf bazlı)</b><table class="pt"><tr><th>Ev kazanır</th><th>%</th></tr>`;
  for(const [k,v] of t.en_sik_ev) h+=`<tr><td>${k}</td><td>${v.toFixed(1)}%</td></tr>`;
  h+=`</table><table class="pt" style="margin-top:4px"><tr><th>Beraberlik</th><th>%</th></tr>`;
  for(const [k,v] of (t.en_sik_ber||[])) h+=`<tr><td>${k}</td><td>${v.toFixed(1)}%</td></tr>`;
  h+=`</table><table class="pt" style="margin-top:4px"><tr><th>Deplasman kazanır</th><th>%</th></tr>`;
  for(const [k,v] of (t.en_sik_dep||[])) h+=`<tr><td>${k}</td><td>${v.toFixed(1)}%</td></tr>`;
  h+=`</table></div>`;
 }
 return h;
}
function ekPanel(t){
 let h="";
 if(t.z00_n){
  h+=`<div class="pbox"><b>0️⃣ İY 0-0 BİTİNCE NE OLUYOR?</b> <span class="mini">(${t.z00_n} maç)</span>
   <table class="pt"><tr><th>Maçta 0.5Ü</th><th>1.5Ü</th><th>2.5Ü</th><th>KG</th><th>Ort. gol</th></tr>
   <tr><td class="git">${t.z00_u05}%</td><td>${t.z00_u15}%</td><td>${t.z00_u25}%</td><td>${t.z00_kg}%</td><td><b>${t.z00_gol}</b></td></tr>
   </table></div>`;
 }
 if(t.h2_gt1!==undefined){
  h+=`<div class="pbox"><b>🕑 2. YARI PROFİLİ</b>
   <table class="pt"><tr><th>2Y 0 gol</th><th>2Y 2+ gol</th><th>Ev attı</th><th>Dep attı</th><th>İkisi de</th></tr>
   <tr><td>${t.h2_0}%</td><td>${t.h2_gt1}%</td><td>${t.ev_2y}%</td><td>${t.dep_2y}%</td><td>${t.her_iki_2y}%</td></tr></table></div>`;
 }
 if(t.onde_ev_kazandi!==undefined||t.onde_dep_kazandi!==undefined){
  h+=`<div class="pbox"><b>🔄 İY'DE ÖNDE GÖTÜREN</b><table class="pt"><tr><th></th><th>Kazandı</th><th>Berabere</th><th>Kaybetti</th></tr>`;
  if(t.onde_ev_kazandi!==undefined) h+=`<tr><th>İY ev önde</th><td class="git">${t.onde_ev_kazandi}%</td><td>${t.onde_ev_beraber}%</td><td class="kit">${t.onde_ev_kaybetti}%</td></tr>`;
  if(t.onde_dep_kazandi!==undefined) h+=`<tr><th>İY dep önde</th><td class="git">${t.onde_dep_kazandi}%</td><td>${t.onde_dep_beraber}%</td><td class="kit">${t.onde_dep_kaybetti}%</td></tr>`;
  h+=`</table></div>`;
 }
 if(t.cs!==undefined){
  h+=`<div class="pbox"><b>🧱 GOL YEME / ATAMAMA</b><table class="pt"><tr><th>Ev gol yemedi</th><th>Ev gol atamadı</th><th>Dep gol atamadı</th></tr>
   <tr><td>${t.cs}%</td><td>${t.fts}%</td><td>${t.fts_dep}%</td></tr></table></div>`;
 }
 if(t.adil&&Object.keys(t.adil).length){
  const A=t.adil, L=[["1 (Ev)",A["1"]],["X (Ber)",A["X"]],["2 (Dep)",A["2"]],["1.5Ü",A.u15],["1.5A",A.a15],["2.5Ü",A.u25],["2.5A",A.a25],["3.5Ü",A.u35],["3.5A",A.a35],["KG Var",A.kg],["KG Yok",A.kg_yok]];
  h+=`<div class="pbox"><b>⚖️ ADİL ORANLAR (tarihsel)</b><table class="pt"><tr><th>Market</th><th>Adil</th></tr>`;
  for(const [k,v] of L) if(v) h+=`<tr><td>${k}</td><td class="git">${v}</td></tr>`;
  h+=`</table><div class="mini">Bu maçların gerçek sonuçlarından türetilen komisyonsuz fiyat.</div></div>`;
 }
 return h;
}
function kornerPanel(r){
 if(!r.kor)return "";
 const K=r.kor;
 let h=`<div class="pbox"><b>🟨 KORNER ANALİZİ</b>`;
 const Poi=(lam,k)=>{let t=1,f=1;for(let i=1;i<=k;i++){f*=lam/i;t+=Math.exp(-lam)*f;}return 100*(1-t);};
 if(K.tot!==undefined&&K.tot!==null){
  const mk=(x)=>{const u=(100-Poi(K.tot,Math.floor(x)));return `Üst %${u.toFixed(0)} · Alt %${(100-u).toFixed(0)}`;};
  h+=`<div class="mini" style="margin-top:6px"><b>Korner marketleri (Poisson, beklenti ${K.tot}):</b> `+
   [8.5,9.5,10.5].map(x=>`<span class="pill">${x} → ${mk(x)}</span>`).join('')+`</div>`;
 }
 if(K.ev_k!==undefined){
  h+=`<table class="pt"><tr><th></th><th>Korner (lehine)</th><th>Yediği</th><th>Beklenen</th></tr>
   <tr><th>${K.ev}</th><td>${K.ev_for}</td><td>${K.ev_ag}</td><td><b>${K.ev_k}</b></td></tr>
   <tr><th>${K.dep}</th><td>${K.dep_for}</td><td>${K.dep_ag}</td><td><b>${K.dep_k}</b></td></tr></table>
   <table class="pt" style="margin-top:5px"><tr><th>Beklenen toplam</th><th>Sinyal</th><th>Lig ort.</th></tr>
   <tr><td><b>${K.tot}</b></td><td class="${K.tot>=9.5?"git":"kit"}"><b>${K.pick}</b></td><td class="mini">${K.lig_ort||"–"}</td></tr></table>
   <div class="mini">Beklenen toplam = ev (ürettiği+rakibin yediği)/2 + dep (ürettiği+rakibin yediği)/2</div>`;
 } else {
  h+=`<table class="pt"><tr><th>Beklenen toplam</th><th>Sinyal</th><th>Kaynak</th></tr>
   <tr><td><b>${K.tot||"–"}</b></td><td class="${(K.tot||0)>=9.5?"git":"kit"}"><b>${K.pick||"–"}</b></td>
   <td class="mini">${K.kaynak||"lig ortalaması"}</td></tr></table>
   <div class="mini">${K.ev?`${K.ev} · `:""}${K.dep?`${K.dep} `:"Takım bazlı veri yok"} — takım eşleşmesi bulunamadı, lig ortalaması kullanıldı.</div>`;
 }
 h+=`</div>`;
 return h;
}
function det(tr,i){
 const r=D[i];
 if(!r)return;
 const nx=tr.nextElementSibling;
 if(nx&&nx.classList.contains("det")){nx.remove();return;}
 let h=`<td colspan="31">${detayPanel(r,r)}`;
 if(r.ornek&&r.ornek.length){
  h+=`<div class="pbox" style="margin-top:8px"><b>📋 BU ORANLA OYNANAN MAÇLAR</b>
   <span class="mini">(son ${r.ornek.length} tanesi · toplam ${r.n} · tolerans ±${r.tol})</span>
   <table class="pt" style="margin-top:5px"><tr><th>Tarih</th><th>Ev</th><th>Deplasman</th><th>MS</th><th>İY</th><th>Oran 1/X/2</th><th>Sonuç</th></tr>`;
  for(const c of r.ornek){const s=c.sk.split(":");const son=+s[0]>+s[1]?"Ev":(+s[0]===+s[1]?"Beraberlik":"Deplasman");
   h+=`<tr><td>${c.d}</td><td>${c.h}</td><td>${c.a}</td><td class="od"><b>${c.sk}</b></td><td class="od">${c.iy||"–"}</td>`
    +`<td class="od">${c.o[0].toFixed(2)}/${c.o[1].toFixed(2)}/${c.o[2].toFixed(2)}</td><td>${son}</td></tr>`;}
  h+=`</table></div>`;
 }
 h+=`<div class="mini" style="margin-top:6px"><a href="${r.lnk}" target="_blank">BetExplorer'da aç ↗</a></div></td>`;
 const y=document.createElement("tr");y.className="det";y.innerHTML=h;tr.after(y);
}
function sifirla(){document.getElementById("q").value="";document.getElementById("flt").value="hepsi";document.getElementById("lig").value="";ciz();}
document.querySelectorAll("th").forEach(th=>th.onclick=()=>{const k=th.dataset.k;if(sir===k)ters=!ters;else{sir=k;ters=true;}ciz();});
document.getElementById("q").oninput=ciz;document.getElementById("flt").onchange=ciz;document.getElementById("lig").onchange=ciz;ciz();
"""

CSS = """*{box-sizing:border-box}
body{margin:0;background:#0a121e;color:#e8eef5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:12.5px}
.wrap{max-width:1620px;margin:0 auto;padding:16px 12px 60px}
h1{font-size:23px;margin:0 0 4px;background:linear-gradient(90deg,#5ee7a0,#4fc3f7);-webkit-background-clip:text;background-clip:text;color:transparent}
.sub{color:#8ba3b8;font-size:12.5px;margin-bottom:10px}
.kpi{display:grid;gap:9px;grid-template-columns:repeat(auto-fit,minmax(125px,1fr));margin:10px 0}
.kpi div{background:#0f1a27;border:1px solid #1d2d42;border-radius:10px;padding:8px 11px}
.kpi b{display:block;color:#8ba3b8;font-size:10px;text-transform:uppercase;letter-spacing:.4px}
.kpi span{font-size:18px;font-weight:800}
.arac{display:flex;gap:7px;flex-wrap:wrap;align-items:center;background:#0f1a27;border:1px solid #1d2d42;border-radius:12px;padding:10px 12px;margin:10px 0;position:sticky;top:0;z-index:9}
input,select{padding:8px 10px;border-radius:9px;border:1px solid #24384f;background:#0b1522;color:#e8eef5;font-size:12.5px;outline:none}
input[type=text]{min-width:200px;flex:1}
button{padding:8px 14px;border-radius:9px;border:0;background:linear-gradient(90deg,#1f9d63,#0e8f8f);color:#fff;font-weight:700;font-size:12.5px;cursor:pointer}
button.alt{background:#22344a}button:hover{filter:brightness(1.15)}
table{width:100%;border-collapse:collapse;font-size:12px}
th,td{border:1px solid #1d2d42;padding:4px 6px;text-align:left;white-space:nowrap}
th{background:#16273a;color:#9fd6ff;font-size:11px;cursor:pointer;position:sticky;top:52px;z-index:4}
th:hover{background:#1d3450}
tbody tr:nth-child(even){background:#0c1622}tbody tr:hover{background:#15263a}
tr.sin{background:#0e2a1e !important;box-shadow:inset 3px 0 0 #5ee7a0}
tr.sin:hover{background:#143a29 !important}
tr.det{background:#0b1420 !important}
tr.det>td{padding:10px 12px;white-space:normal}
.od{text-align:center;font-variant-numeric:tabular-nums}
.mini{color:#8ba3b8;font-size:11px}
.git{color:#5ee7a0;font-weight:700}.kit{color:#ff8a8a}
.bg{display:inline-block;padding:1px 6px;border-radius:6px;font-size:10.5px;font-weight:700}
.bg.y{background:#124a2e;color:#5ee7a0}.bg.o{background:#3d3410;color:#ffd479}.bg.z{background:#24354a;color:#9fb4c7}
.pbox{background:#0f1a27;border:1px solid #22344a;border-radius:11px;padding:9px 11px;margin:6px 8px 6px 0;display:inline-block;vertical-align:top;min-width:190px}
.pbox b{color:#9fd6ff;display:block;margin-bottom:5px;font-size:11.5px}
table.pt{width:auto;font-size:11.5px;margin:0}
table.pt th,table.pt td{padding:3px 7px;text-align:center;background:transparent;position:static;cursor:default}
table.pt th{background:#16273a;color:#9fd6ff}
table.mx th{text-align:center}
.pill{display:inline-block;background:#16273a;border:1px solid #24384f;border-radius:6px;padding:1px 7px;font-size:11px;color:#cfe6ff;margin:2px}
a{color:#4fc3f7;text-decoration:none}a:hover{text-decoration:underline}
@media print{body{background:#fff;color:#000}.arac,button{display:none}th{background:#eee;color:#000;position:static}
table{font-size:8.5px}tr.sin{background:#e6f7ec !important}.pbox{border-color:#ccc}tr.det{display:table-row !important}}"""


def _pc(v, col=None):
    """JS pc() ile birebir aynı yüzde hücresi."""
    if v is None: return "<span class='mini'>–</span>"
    try: v = float(v)
    except Exception: return "<span class='mini'>–</span>"
    if col is None: col = "git" if v >= 55 else ("kit" if v <= 35 else "")
    return f'<span class="{col}">{v:.0f}%</span>'


def _guv(r):
    n = r.get("n", 0); sin = r.get("sinyal")
    if not n: return "<span class='mini'>—</span>"
    if n >= 40 and sin: return "<span class='bg y'>YÜKSEK</span>"
    if n >= 18 and sin: return "<span class='bg o'>ORTA</span>"
    if sin: return "<span class='bg z'>DÜŞÜK</span>"
    return "<span class='mini'>—</span>"


def _satir_html(r):
    """JS ciz() satır şablonunun Python eşleniği (statik görünüm için)."""
    t = r.get("det") or {}
    o = r.get("o") or [0, 0, 0]
    d = r.get("d")
    idx = r.get("_idx", 0)
    h = [f'<tr class="{"sin" if r.get("sinyal") else ""}" onclick="det(this,{idx})">']
    h.append(f'<td class="od">{H.escape(str(r.get("s","")))}</td><td class="mini">{H.escape(str(r.get("l","")))}</td>'
             f'<td><b>{H.escape(str(r.get("h","")))}</b> - {H.escape(str(r.get("a","")))}</td>')
    h.append("".join(f'<td class="od">{x:.2f}</td>' for x in o))
    h.append(f'<td class="od">{r.get("n") or "–"}</td>')
    kal = "git" if r.get("kalite") == "kesin" else ("" if r.get("kalite") == "iyi" else "yit")
    tol = r.get("tol")
    h.append(f'<td class="od mini {kal}">{"±"+str(tol) if tol is not None else "–"}</td>')
    h.append("".join(f'<td class="od">{x:.0f}</td>' if x is not None else '<td class="od">–</td>' for x in (d or [None, None, None])))
    for k in ("iy1", "iyx", "iy2", "u15", "u25", "u35", "kg", "ht00", "htu15", "htkg", "ayni"):
        h.append(f'<td class="od">{_pc(t.get(k))}</td>')
    kor = r.get("kor")
    if kor:
        h.append(f'<td class="od"><b>{kor.get("tot")}</b> <span class="mini {"git" if (kor.get("tot") or 0) >= 9.5 else "kit"}">{H.escape(str(kor.get("pick","")))}</span></td>')
    else:
        h.append('<td class="od">–</td>')
    if r.get("ad"):
        e = r.get("edge", 0); ri = r.get("roi", 0)
        isaret = lambda v: ("+" if v > 0 else "") + f"{v:.1f}"
        ci = r.get("ci") or [0, 0]
        h.append(f'<td class="od"><b>{H.escape(str(r["ad"]))}</b></td>'
                 f'<td class="od {"git" if e>0 else "kit"}">{isaret(e)}</td>'
                 f'<td class="od mini">{ci[0]:.0f}–{ci[1]:.0f}</td><td>{_guv(r)}</td>'
                 f'<td class="od {"git" if ri>0 else "kit"}">{("+" if ri>0 else "")}{ri:.0f}%</td>')
    else:
        h.append('<td colspan="5" class="mini">—</td>')
    h.append('</tr>')
    return "".join(h)


def statik_satirlar(K):
    """Listeyi JS varsayılan sırasıyla (Fark azalan) statik HTML olarak basar."""
    S = sorted(K, key=lambda r: -(r["edge"] if r.get("ad") and r.get("edge") is not None else -99))
    parca = []
    for i, r in enumerate(S):
        r = dict(r); r["_idx"] = K.index(r) if r in K else i
        parca.append(_satir_html(r))
    return "".join(parca)


def render(K, dosya="/home/user/BULTEN.html"):
    n_tum = len(K); n_iy = sum(1 for r in K if (r.get("det") or {}).get("htn"))
    n_sin = sum(1 for r in K if r.get("sinyal")); n_yuk = sum(1 for r in K if r.get("sinyal") and r["n"] >= 40)
    ligler = sorted({r["l"] for r in K if r["l"]})
    veri = json.dumps(K, ensure_ascii=False, separators=(",", ":"))
    head = (f"<h1>📋 TAM BULTEN — {BUGUN}</h1>"
            f"<div class='sub'>Bugünün tüm maçları · her maç için <b>aynı oranla oynanan maçların tam market kırılımı</b>: "
            f"MS, toplam gol dağılımı, Alt/Üst 1.5-2.5-3.5-4.5, KG, İY 0-0, İY 1.5Ü, İY/MS matrisi, 2. yarı<br>"
            f"<b>Satıra tıkla → derin panel açılır.</b> Tek dosya, internet gerekmez.</div>"
            f"<div class='kpi'>"
            f"<div><b>Maç</b><span>{n_tum}</span></div>"
            f"<div><b>İY verili grup</b><span>{n_iy}</span></div>"
            f"<div><b>Değer sinyali</b><span class='git'>{n_sin}</span></div>"
            f"<div><b>Yüksek güven</b><span class='git'>{n_yuk}</span></div>"
            f"<div><b>Lig</b><span>{len(ligler)}</span></div></div>")
    filtre = (f'<option value="hepsi">Tüm maçlar ({n_tum})</option>'
              f'<option value="sinyal">🟩 Değer sinyalleri ({n_sin})</option>'
              f'<option value="iy">İY verisi olanlar ({n_iy})</option>'
              f'<option value="kar">Karşılaştırılanlar ({sum(1 for r in K if r.get("n"))})</option>'
              f'<option value="siki">Sıkı eşleşme (≤0.15)</option>'
              f'<option value="oransiz">Oranı olmayanlar ({sum(1 for r in K if not r.get("o"))})</option>')
    ligopt = "".join(f'<option value="{H.escape(l)}">{H.escape(l)}</option>' for l in ligler)
    dipnot = ("<b>Nasıl okunur:</b> Örnek = aynı oranla oynanmış maç sayısı · Tol. = tolerans (küçük = isabetli eşleşme) · "
              "1.5Ü/2.5Ü/3.5Ü = o maçlarda üst gelme yüzdesi · KG = karşılıklı gol · İY 0-0 ve İY 1.5Ü = ilk yarı davranışı · "
              "İY=MS = ilk yarı liderinin maçı da kazanma yüzdesi. Detay için satıra tıkla.")
    doc = (HTML_BAS.replace("__CSS__", CSS).replace("__HEAD__", head)
           .replace("__FILTRE__", filtre).replace("__LIGLER__", ligopt)
           .replace("__VERI__", veri).replace("__JS__", JS).replace("__SATIRLAR__", statik_satirlar(K)).replace("__DIPNOT__", dipnot))
    open(dosya, "w", encoding="utf-8").write(doc)
    return doc, n_sin, n_iy

def disa_aktar(K):
    import csv as _csv
    bas = ["Saat","Lig","Ev","Deplasman","1","X","2","Örnek","Tolerans","Ev%","Ber%","Dep%",
           "Ort.gol","1.5Ü%","2.5Ü%","3.5Ü%","4.5Ü%","KG%","0-0%",
           "İY 0-0%","İY 0.5Ü%","İY 1.5Ü%","İY KG%","İY Ev%","İY Ber%","İY Dep%","İY ort.gol",
           "2Y ort.gol","2Y 0.5Ü%","İY=MS%","İY lider korudu%",
           "Gol dagilimi 0/1/2/3/4/5+","En sik skorlar","En sik IY skorlar",
           "En iyi taraf","Fark","GA alt","GA ust","Güven","ROI%","Kelly%","Sinyal","Link"]
    def sat(r):
        d = r.get("det") or {}
        g = "YUKSEK" if r.get("n",0)>=40 and r.get("sinyal") else ("ORTA" if r.get("n",0)>=18 and r.get("sinyal") else ("DUSUK" if r.get("sinyal") else ""))
        return [r["s"], r["l"], r["h"], r["a"], r["o"][0], r["o"][1], r["o"][2], r.get("n",""), r.get("tol",""),
                *(r.get("d") or ["","",""]),
                d.get("ort",""), d.get("u15",""), d.get("u25",""), d.get("u35",""), d.get("u45",""), d.get("kg",""),
                (d.get("gol") or ["",""])[0] if d.get("gol") else "",
                d.get("ht00",""), d.get("htu05",""), d.get("htu15",""), d.get("htkg",""),
                d.get("htev",""), d.get("htber",""), d.get("htdep",""), d.get("htort",""),
                d.get("h2ort",""), d.get("h2u05",""), d.get("ayni",""), d.get("ht_koruma",""),
                "/".join(f"{x:.0f}" for x in (d.get("gol") or [])) if d.get("gol") else "",
                " ".join(d.get("skor") or []), " ".join(d.get("htskor") or []),
                r.get("ad",""), r.get("edge",""), (r.get("ci") or ["",""])[0], (r.get("ci") or ["",""])[1],
                g, r.get("roi",""), r.get("kelly",""), "DEGERLI" if r.get("sinyal") else "", r["lnk"]]
    with open("/home/user/BULTEN.csv","w",newline="",encoding="utf-8-sig") as f:
        w=_csv.writer(f,delimiter=";"); w.writerow(bas)
        for r in K: w.writerow(sat(r))
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        wb=Workbook(); ws=wb.active; ws.title="Bulten"
        ws.append(bas)
        for c in range(1,len(bas)+1):
            cell=ws.cell(1,c); cell.font=Font(bold=True,color="FFFFFF")
            cell.fill=PatternFill("solid",fgColor="1F4E79"); cell.alignment=Alignment(horizontal="center")
        yesil=PatternFill("solid",fgColor="C6EFCE"); mavi=PatternFill("solid",fgColor="DDEBF7")
        for r in K:
            ws.append(sat(r))
            if r.get("sinyal"):
                for c in range(1,len(bas)+1): ws.cell(ws.max_row,c).fill=yesil
            elif (r.get("det") or {}).get("htn"):
                for c in (20,21,22,23,24,25,26,27,28,29,30,31): ws.cell(ws.max_row,c).fill=mavi
        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
        gen=[8,22,20,20,7,7,7,7,9,6,6,6,8,8,8,8,8,7,7,8,9,9,8,8,8,8,9,8,9,8,10,18,28,24,12,7,7,7,8,8,8,10,45]
        for i,w_ in enumerate(gen[:len(bas)],start=1):
            ws.column_dimensions[ws.cell(1,i).column_letter].width=w_
        wb.save("/home/user/BULTEN.xlsx")
        return "xlsx ok"
    except Exception as ex:
        return f"xlsx: {ex}"

if __name__ == "__main__":
    t0 = time.time()
    K = kayit_uret()
    doc, n_sin, n_iy = render(K)
    print(f"BULTEN.html | {len(K)} maç | {n_sin} sinyal | İY verili grup {n_iy} | {len(doc)//1024} KB | {round(time.time()-t0,1)}s")
    print(disa_aktar(K))
