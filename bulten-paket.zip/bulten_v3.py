#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TAM BÜLTEN v3 — NET TABLO + YENİ ÖZELLİKLER
  Tablo: gruplu/renkli başlıklar, 5 görünüm modu (Sade/Değer/Gol/İlk Yarı/Tümü),
         zebra satır, sabit başlık, sıralama okları, mini grafikler, uyarı ikonları
  Yeni özellikler:
     • Öneri notu (0-100) — örneklem + fark + eşleşme hassasiyeti + GA + ROI bileşimi
     • "Neden bu sinyal?" otomatik açıklaması
     • Poisson model (beklenen gol → 1X2 / 2.5Ü / KG) ve model-piyasa farkı
     • Kupon sepeti: toplam oran, tarihsel birleşik isabet, beklenen geri dönüş, kelly
     • Günün en iyi 5 fırsatı (kartlar)
     • Piyasa kalibrasyonu + oran bandı analizi + lig özeti (statik paneller)
     • Açık/koyu tema, yazdırma modu, CSV indirme
Veri hattı bulten_v2.kayit_uret ile aynı (tek kaynak).
"""
import json, math, html as H, sys, time
import numpy as np
sys.path.insert(0, "/home/user")
import bulten_v2 as V2
import tam_tarama as TT
import detay as DE
from bulten_v2 import kayit_uret, BUGUN
import os, kapanis_kiyas as KK
import saat as SA

BUGUN_TR = "11.09.2026"


# ------------------------------------------------------------------ yardımcılar
from decimal import Decimal, ROUND_HALF_UP


KALAD = {"kesin": "Eşleşme çok sıkı (≤0.05)", "iyi": "Eşleşme iyi (≤0.15)",
         "genis": "Eşleşme geniş (≤0.28)", "gevsek": "Eşleşme gevşek (>0.28)"}


def _f0(v):
    """JS toFixed(0) gibi yuvarlar (yarım yukarı)."""
    try:
        return str(int(Decimal(str(float(v))).quantize(Decimal("1"), rounding=ROUND_HALF_UP)))
    except Exception:
        return "0"


def _jf(x):
    """JS sayı yazımı gibi: 3.0 → '3', 2.65 → '2.65'."""
    try:
        f = float(x)
        return str(int(f)) if f.is_integer() else str(f)
    except Exception:
        return str(x)


def _esc(s):
    """JS esc() ile birebir aynı kaçış."""
    return str(s if s is not None else "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def poisson(lh, la, N=9):
    """Bağımsız Poisson ile 1X2 / 2.5Ü / KG modeli."""
    f = [math.exp(-lh) * lh ** i / math.factorial(i) for i in range(N)]
    g = [math.exp(-la) * la ** j / math.factorial(j) for j in range(N)]
    ev = be = de = u25 = kg = 0.0
    for i in range(N):
        for j in range(N):
            p = f[i] * g[j]
            if i > j: ev += p
            elif i == j: be += p
            else: de += p
            if i + j > 2.5: u25 += p
            if i > 0 and j > 0: kg += p
    return [round(ev * 100, 1), round(be * 100, 1), round(de * 100, 1), round(u25 * 100, 1), round(kg * 100, 1)]


def oneri_notu(r):
    """0-100 bileşik öneri notu: fark + örneklem + hassasiyet + GA + ROI."""
    if not r.get("ad"):
        return None
    edge = min(max(r.get("edge", 0.0), 0.0), 25.0)                    # 25
    n = min(r.get("n", 0), 50) / 50 * 25.0                            # 25
    tol = r.get("tol")
    tol = 0.30 if tol is None else tol
    tol_p = max(0.0, (0.30 - tol) / 0.30) * 20.0                      # 20
    ci = (r.get("ci") or [0, 0])[0]
    ci_p = min(max(ci, 0.0), 80.0) / 80.0 * 20.0                      # 20
    roi_p = min(max(r.get("roi", 0.0), 0.0), 50.0) / 50.0 * 10.0      # 10
    return round(min(100.0, edge + n + tol_p + ci_p + roi_p), 1)


def neden_metni(r):
    """Sinyalin tek cümlelik gerekçesi."""
    if not r.get("ad"):
        return "Bu maçın oranıyla eşleşen yeterli arşiv maçı bulunamadı."
    n = r.get("n", 0); ad = r.get("ad", ""); hist = r.get("hist", 0); piy = r.get("piy", 0)
    edge = r.get("edge", 0); roi = r.get("roi", 0)
    t = f"Aynı oranla açılan <b>{n} maçın %{hist}</b>'inde <b>{ad}</b> geldi; piyasa bunu <b>%{piy}</b> fiyatlıyor → fark <b>{edge:+.1f} puan</b>."
    if roi:
        t += f" Bu bahis geçmişte ROI <b>{roi:+.0f}%</b> vermiş."
    k = (r.get("det") or {}).get("iykg")
    if ad == "Beraberlik" and k is not None:
        t += f" İlgili maçlarda İY karşılıklı gol %{k}."
    elif ad == "Deplasman" and r.get("det", {}).get("htdep") is not None:
        t += f" İlk yarıda deplasman önde bitirme %{r['det']['htdep']}."
    return t


def uyarilar(r):
    """(önemli uyarılar, bilgi notları) — satırda ⚠ yalnızca önemli olanlar için çıkar."""
    u, b = [], []
    n = r.get("n") or 0
    if r.get("ad"):
        if n < 18: u.append(f"zayıf örneklem (n={n})")
        if (r.get("tol") or 0) > 0.20: u.append(f"gevşek eşleşme (±{r['tol']})")
        if r.get("roi", 0) <= 0: b.append(f"ROI negatif ({r.get('roi',0):+.0f}%)")
    d = r.get("det") or {}
    if not d.get("htn"): b.append("İY verisi yok")
    if (r.get("kor") or {}).get("takim_yok"): b.append("korner lig ortalaması")
    return u, b


def model_pazar(lh, la, ht_pay=0.45, rho=0.0):
    """Poisson (İY+2Y ayrık) ile TÜM marketlerin model yüzdeleri — tarihsel etiketlerle aynı."""
    lh_ht, la_ht = lh * ht_pay, la * ht_pay
    lh_2y, la_2y = lh - lh_ht, la - la_ht
    N = 7
    f = lambda L: [math.exp(-L) * L ** i / math.factorial(i) for i in range(N)]
    fh, ga, sh, sa = f(lh_ht), f(la_ht), f(lh_2y), f(la_2y)
    kayit, toplam = [], 0.0
    for i in range(N):
        for j in range(N):
            ph = fh[i] * ga[j]
            if ph < 1e-9:
                continue
            for k in range(N):
                for l in range(N):
                    p = ph * sh[k] * sa[l]
                    if p < 1e-9:
                        continue
                    toplam += p
                    kayit.append((p, i + k, j + l, i, j))       # p, MS ev, MS dep, İY ev, İY dep
    # --- Dixon-Coles düzeltmesi (0-0, 1-0, 0-1, 1-1 hücreleri) ---
    if rho:
        yeni = []
        for p, h, a, hh, ha in kayit:
            tau = 1.0
            if h == 0 and a == 0: tau = 1 - lh * la * rho
            elif h == 1 and a == 0: tau = 1 + la * rho
            elif h == 0 and a == 1: tau = 1 + lh * rho
            elif h == 1 and a == 1: tau = 1 - rho
            yeni.append((max(1e-12, p * tau), h, a, hh, ha))
        toplam = sum(x[0] for x in yeni)
        kayit = yeni
    out = {}
    for kat, iy_gerek, rows in DE.PAZAR_TANIM:
        for ad, fn in rows:
            out[ad] = round(100 * sum(p for p, h, a, hh, ha in kayit if fn(h, a, hh, ha)) / toplam, 1)
    for i in range(3):
        for j in range(3):
            def fn(h, a, hh, ha, i=i, j=j):
                ki = 0 if hh > ha else (1 if hh == ha else 2)
                kj = 0 if h > a else (1 if h == a else 2)
                return ki == i and kj == j
            out[f"İY {['1','X','2'][i]} → MS {['1','X','2'][j]}"] = round(
                100 * sum(p for p, h, a, hh, ha in kayit if fn(h, a, hh, ha)) / toplam, 1)
    out["İY 0-0 → 2.5Ü"] = round(100 * sum(p for p, h, a, hh, ha in kayit if hh == 0 and ha == 0 and h + a > 2.5) / toplam, 1)
    out["İY 0-0 → KG"] = round(100 * sum(p for p, h, a, hh, ha in kayit if hh == 0 and ha == 0 and h > 0 and a > 0) / toplam, 1)
    out["İY 1-0 → Ev kazanır"] = round(100 * sum(p for p, h, a, hh, ha in kayit if hh > ha and h > a) / toplam, 1)
    out["İY 0-1 → Dep kazanır"] = round(100 * sum(p for p, h, a, hh, ha in kayit if ha > hh and a > h) / toplam, 1)
    return out


def ulke_index(ms):
    """Ülke bazı maç indeksi."""
    idx = {}
    for m in ms:
        u = (m.get("url") or m.get("league") or "")
        seg = [x for x in u.split("/") if x]
        if len(seg) < 2 or seg[0] != "football":
            continue
        idx.setdefault("/" + "/".join(seg[:2]) + "/", []).append(m)
    return idx


def lig_index(ms):
    """Lig bazı (sezon eki atılmış) maç indeksi."""
    idx = {}
    for m in ms:
        u = (m.get("url") or m.get("league") or "")
        seg = [x for x in u.split("/") if x]
        if len(seg) < 3 or seg[0] != "football":
            continue
        idx.setdefault("/" + "/".join(seg[:3]) + "/", []).append(m)
    return idx


def _grup_ozet(e, anahtar, kullanilan, ad):
    """Aynı oranla oynanan maç grubunun tam özeti + son maç listesi."""
    if not e:
        return {"n": 0, ad: anahtar}
    n = len(e)
    ht = [c for c in e if "ht_h" in c]
    from collections import Counter
    cs = Counter(f"{c['hg']}-{c['ag']}" for c in e)
    hw = sum(1 for c in e if c["hg"] > c["ag"]); dr = sum(1 for c in e if c["hg"] == c["ag"])
    d = {"n": n, ad: anahtar, "tol_l": kullanilan,
         "ms": [round(100 * hw / n, 1), round(100 * dr / n, 1), round(100 * (n - hw - dr) / n, 1)],
         "ort": round(sum(c["hg"] + c["ag"] for c in e) / n, 2),
         "u25": round(100 * sum(1 for c in e if c["hg"] + c["ag"] > 2.5) / n, 1),
         "kg": round(100 * sum(1 for c in e if c["hg"] > 0 and c["ag"] > 0) / n, 1),
         "skor": [[k, round(100 * v / n, 1)] for k, v in cs.most_common(6)]}
    if ht:
        m = len(ht)
        d["iy"] = {"n": m, "x": round(100 * sum(1 for c in ht if c["ht_h"] == c["ht_a"]) / m, 1),
                   "00": round(100 * sum(1 for c in ht if c["ht_h"] == 0 and c["ht_a"] == 0) / m, 1),
                   "u05": round(100 * sum(1 for c in ht if c["ht_h"] + c["ht_a"] > 0.5) / m, 1),
                   "u15": round(100 * sum(1 for c in ht if c["ht_h"] + c["ht_a"] > 1.5) / m, 1),
                   "kg": round(100 * sum(1 for c in ht if c["ht_h"] > 0 and c["ht_a"] > 0) / m, 1)}
    # son maçların listesi (yeni → eski)
    def _tarih(z):
        t = (z.get("date") or "").strip()
        try:
            from datetime import datetime as _dt
            return _dt.strptime(t, "%d.%m.%Y").toordinal()
        except Exception:
            return 10 ** 9 if t.lower() in ("yesterday", "today") else 0
    son = []
    for c in sorted(e, key=_tarih)[-400:][::-1]:
        sk = f"{c['hg']}-{c['ag']}"
        son.append({"d": c.get("date", ""), "h": c.get("home", ""), "a": c.get("away", ""), "sk": sk,
                    "iy": (f"{c['ht_h']}:{c['ht_a']}" if "ht_h" in c else ""),
                    "o": [round(c["o1"], 2), round(c["ox"], 2), round(c["o2"], 2)]})
    d["ornek"] = son
    return d


def grup_esle(grup, o, tol, min_n=5, en_gevsek=0.45):
    """Toleransı kademeli genişleterek aynı oranlı maçları bulur."""
    if not grup:
        return [], None
    e, kullanilan = [], None
    for t in sorted({tol, max(tol, 0.12), 0.2, 0.3, 0.45, en_gevsek}):
        if t > en_gevsek:
            continue
        e = [m for m in grup if abs(m["o1"] - o[0]) <= t and abs(m["ox"] - o[1]) <= t and abs(m["o2"] - o[2]) <= t
             and m.get("date") != TT.BUGUN_TR]
        kullanilan = t
        if len(e) >= min_n:
            break
    return e, kullanilan


def lig_karsilastir(link, idx, o, tol):
    """Aynı LİGDE aynı oranla oynanan maçlar (sonuç listesiyle)."""
    seg = [x for x in (link or "").split("/") if x]
    if len(seg) < 3:
        return None
    anahtar = "/" + "/".join(seg[:3]) + "/"
    e, k = grup_esle(idx.get(anahtar) or [], o, tol if tol is not None else 0.10)
    return _grup_ozet(e, anahtar, k, "lig")


def ulke_karsilastir(link, uidx, o, tol):
    """Aynı ÜLKEDE (tüm ligler) aynı oranla oynanan maçlar."""
    seg = [x for x in (link or "").split("/") if x]
    if len(seg) < 2:
        return None
    anahtar = "/" + "/".join(seg[:2]) + "/"
    e, k = grup_esle(uidx.get(anahtar) or [], o, tol if tol is not None else 0.10, min_n=8, en_gevsek=0.30)
    return _grup_ozet(e, anahtar, k, "ulke")


_PRIOR_CACHE = {}


def pazar_prior(ms, ornek=40000):
    """Tüm arşivden market bazlı önsel (prior) yüzdeler — Bayesçi küçültme için."""
    if _PRIOR_CACHE:
        return _PRIOR_CACHE
    try:
        d = json.load(open("/home/user/veri/prior_cache.json", encoding="utf-8"))
        _PRIOR_CACHE.update(d); DE._PRIOR = d
        return d
    except Exception:
        pass
    t0 = time.time()
    adim = max(1, len(ms) // ornek)
    alt = ms[::adim]
    kayit, pri = None, {}
    kayit, _ = None, None
    n = len(alt)
    for kat, iy_gerek, rows in DE.PAZAR_TANIM:
        kaynak = [c for c in alt if ("ht_h" in c)] if iy_gerek else alt
        if not kaynak:
            continue
        L = len(kaynak)
        for ad, f in rows:
            pri[ad] = round(100 * sum(1 for c in kaynak if f(c["hg"], c["ag"], c.get("ht_h", 0), c.get("ht_a", 0))) / L, 1)
    htli = [c for c in alt if "ht_h" in c]
    if htli:
        M = len(htli)
        for i in range(3):
            for j in range(3):
                def f(h, a, hh, ha, i=i, j=j):
                    ki = 0 if hh > ha else (1 if hh == ha else 2)
                    kj = 0 if h > a else (1 if h == a else 2)
                    return ki == i and kj == j
                pri[f"İY {['1','X','2'][i]} → MS {['1','X','2'][j]}"] = round(
                    100 * sum(1 for c in htli if f(c["hg"], c["ag"], c["ht_h"], c["ht_a"])) / M, 1)
        for ad, f in [("İY 0-0 → 2.5Ü", lambda c: c["ht_h"] == 0 and c["ht_a"] == 0 and c["hg"] + c["ag"] > 2.5),
                      ("İY 0-0 → KG", lambda c: c["ht_h"] == 0 and c["ht_a"] == 0 and c["hg"] > 0 and c["ag"] > 0),
                      ("İY 1-0 → Ev kazanır", lambda c: c["ht_h"] > c["ht_a"] and c["hg"] > c["ag"]),
                      ("İY 0-1 → Dep kazanır", lambda c: c["ht_a"] > c["ht_h"] and c["ag"] > c["hg"])]:
            pri[ad] = round(100 * sum(1 for c in htli if f(c)) / M, 1)
    try:
        json.dump(pri, open("/home/user/veri/prior_cache.json", "w", encoding="utf-8"), ensure_ascii=False)
    except Exception:
        pass
    _PRIOR_CACHE.update(pri); DE._PRIOR = pri
    print(f"  önsel tablo hazır ({len(pri)} market, {len(alt)} maç, {round(time.time()-t0,1)}s)", flush=True)
    return pri


def zenginlestir(K, arsiv=None):
    """v3 alanları: öneri notu, gerekçe, uyarı, Poisson, sonuç, form, bootstrap, pazar, lig."""
    ms, o1s = (None, None)
    if arsiv:
        ms, o1s = arsiv
    fidx = form_index(ms) if ms else {}
    lidx = lig_index(ms) if ms else {}
    uidx = ulke_index(ms) if ms else {}
    for r in K:
        d = r.get("det") or {}
        r["not"] = oneri_notu(r)
        r["neden"] = neden_metni(r)
        r["uyari"], r["bilgi"] = uyarilar(r)
        if d.get("ev_g") is not None and d.get("dep_g") is not None and d.get("ort", 0) > 0:
            poi = poisson(d["ev_g"], d["dep_g"])
            r["poi"] = poi
            # modelin en olası tam skorları
            lh, la = d["ev_g"], d["dep_g"]; N = 7
            f = [math.exp(-lh) * lh ** i / math.factorial(i) for i in range(N)]
            gg = [math.exp(-la) * la ** j / math.factorial(j) for j in range(N)]
            sl = sorted(((f[i] * gg[j], i, j) for i in range(N) for j in range(N)), reverse=True)[:5]
            r["poi_skor"] = [[f"{i}-{j}", round(p * 100, 1), (round(100 / (p * 100), 2) if p > 0 else None)]
                             for p, i, j in sl]
            if r.get("ad"):
                idx = {"Ev": 0, "Beraberlik": 1, "Deplasman": 2}.get(r["ad"], 0)
                r["poi_fark"] = round(poi[idx] - (r.get("piy") or 0), 1)
        # --- maç sonucu (bitmişse) ---
        r["sonuc"] = sonuc_belirle(r)
        # --- takım formları ---
        if fidx:
            fh = form_ozet(fidx, r.get("h")); fa = form_ozet(fidx, r.get("a"))
            if fh or fa:
                r["form"] = {"h": fh, "a": fa}
        # --- bootstrap: güven aralığı + farkın şans olma olasılığı ---
        if ms and r.get("ad") and (r.get("n") or 0) >= 8 and r.get("tol") is not None:
            try:
                e = TT.eslesen(ms, o1s, r["o"], r["tol"])
                ad = r["ad"]
                kaz = [1 if ((c["hg"] > c["ag"]) if ad == "Ev" else ((c["hg"] == c["ag"]) if ad == "Beraberlik" else (c["hg"] < c["ag"]))) else 0
                       for c in e]
                bs = bootstrap(kaz, r.get("piy") or 0)
                if bs:
                    r["bst"] = [bs[0], bs[1]]; r["pdeger"] = bs[2]
            except Exception:
                pass
        # --- TÜM PAZARLAR: tarihsel + model + adil ---
        paz = d.get("pazar") or []
        if paz:
            mp = {}
            pay = max(0.3, min(0.6, (d.get("htort") / d["ort"]) if (d.get("htort") and d.get("ort")) else 0.45))
            if d.get("ev_g") is not None and d.get("dep_g") is not None:
                try:
                    mp = model_pazar(d["ev_g"], d["dep_g"], pay, d.get("rho") or 0.0)
                except Exception:
                    mp = {}
            kuc = {x[1]: x[4] for x in (d.get("pazar_k") or [])}
            piy = {"1 (Ev)": (r.get("piy") if r.get("ad") == "Ev" else None)}
            if r.get("ad"):
                # piyasa implici değerleri 1/X/2 için r.d'den türetilemez; sadece öne çıkan taraf biliniyor
                pass
            satirlar = []
            for (k, ad, p, a) in paz:
                pa = kuc.get(ad, p)
                m2 = mp.get(ad)
                # konsensüs: düzeltilmiş tarihsel + model (piyasa 1X2'de eklenir)
                if m2 is None:
                    ko = pa
                else:
                    ko = round(0.55 * pa + 0.45 * m2, 1)
                satirlar.append([k, ad, p, a, m2, pa, ko])
            r["paz"] = satirlar
            for _k in ("pazar", "pazar_k", "matrix_n"):
                d.pop(_k, None)
        # --- AYNI LİGDE AYNI ORAN ---
        if lidx:
            try:
                lc = lig_karsilastir(r.get("lnk", "").replace("https://www.betexplorer.com", ""), lidx,
                                     r["o"], r.get("tol") if r.get("tol") is not None else 0.10)
                if lc and lc.get("n"):
                    r["lig_cmp"] = lc
                uc = ulke_karsilastir(r.get("lnk", "").replace("https://www.betexplorer.com", ""), uidx,
                                      r["o"], r.get("tol") if r.get("tol") is not None else 0.10)
                if uc and uc.get("n") and not (lc and lc.get("n") and uc["n"] <= lc["n"]):
                    r["ulke_cmp"] = uc
            except Exception:
                pass
    return K



# ---------------------------------------------------------------- sonuç · form · bootstrap
def sonuc_belirle(r):
    """Maç bittiyse öne çıkan tarafın sonucu."""
    c = r.get("canli") or {}
    if c.get("durum") != "bitti" or not c.get("ms") or not r.get("ad"):
        return None
    try:
        h, a = [int(x) for x in c["ms"].split(":")]
    except Exception:
        return None
    ad = r["ad"]
    kazandi = (h > a) if ad == "Ev" else ((h == a) if ad == "Beraberlik" else (h < a))
    return "KAZANDI" if kazandi else "KAYBETTİ"


def _norm(t):
    t = (t or "").lower()
    for a, b in (("ı", "i"), ("ş", "s"), ("ğ", "g"), ("ü", "u"), ("ö", "o"), ("ç", "c"), ("ä", "a"),
                 ("é", "e"), ("è", "e"), ("á", "a"), ("í", "i"), ("ó", "o"), ("ú", "u"), ("ñ", "n")):
        t = t.replace(a, b)
    return " ".join("".join(ch if ch.isalnum() or ch == " " else " " for ch in t).split())


def form_index(arsiv):
    """Takım adı -> maç listesi (arşivden)."""
    from datetime import datetime as _dt
    idx = {}
    for m in arsiv:
        try:
            d = _dt.strptime(m.get("date", ""), "%d.%m.%Y")
        except Exception:
            continue
        for side, team in (("h", m.get("home")), ("a", m.get("away"))):
            idx.setdefault(_norm(team), []).append((d, m, side))
    return idx


def form_ozet(idx, takim, n=6):
    """Son n maç: seri, gol ortalaması, KG, 2.5Ü."""
    kayit = sorted(idx.get(_norm(takim)) or [], key=lambda z: z[0], reverse=True)[:n]
    if not kayit:
        return None
    maclar, g, y, b, m_ = [], 0, 0, 0, 0
    kg = u25 = 0
    atilan = yenilen = 0
    for d, mm, side in kayit:
        ev_mi = side == "h"
        at, ye = (mm["hg"], mm["ag"]) if ev_mi else (mm["ag"], mm["hg"])
        atilan += at; yenilen += ye
        if at > ye: g += 1; s_ = "G"
        elif at == ye: b += 1; s_ = "B"
        else: m_ += 1; s_ = "M"
        if at > 0 and ye > 0: kg += 1
        if at + ye > 2.5: u25 += 1
        maclar.append({"d": d.strftime("%d.%m.%Y"), "r": mm.get("away") if ev_mi else mm.get("home"),
                       "ev": ev_mi, "sk": f"{at}-{ye}", "s": s_})
    return {"n": len(kayit), "g": g, "b": b, "m": m_, "seri": "".join(x["s"] for x in maclar),
            # "at" ve "ye" takımın maç başına attığı/yediği gol; "top" ise
            # maç başına toplam gol ortalamasıdır. Üçünü ayrı tutmak, takımın
            # hücum ve savunma profilini tek bir toplam değere indirgememeyi sağlar.
            "at": round(atilan / len(kayit), 2), "ye": round(yenilen / len(kayit), 2),
            "top": round((atilan + yenilen) / len(kayit), 2),
            "kg": round(100 * kg / len(kayit), 0), "u25": round(100 * u25 / len(kayit), 0), "maclar": maclar}


def bootstrap(kazanclar, piyasa, B=2000, tohum=7):
    """Oran (proportion) için parametrik bootstrap: %95 aralık + farkın şans olma olasılığı."""
    n = len(kazanclar)
    if n < 8:
        return None
    rng = np.random.default_rng(tohum)
    p_hat = float(np.mean(kazanclar))
    ornek = rng.binomial(n, p_hat, B) / n * 100
    lo, hi = np.percentile(ornek, [2.5, 97.5])
    sans = float((ornek <= piyasa).mean() * 100)     # piyasa şansının altında kalma olasılığı
    return round(float(lo), 1), round(float(hi), 1), round(sans, 1)



# ------------------------------------------------------------------ statik paneller
def kalibrasyon(K):
    """Piyasa yüzdesi kovaları: piyasa ne diyorsa tarihte ne olmuş?"""
    kovalar = [(0, 30), (30, 40), (40, 50), (50, 60), (60, 100)]
    satir = []
    for a, b in kovalar:
        grp = [r for r in K if r.get("ad") and a <= (r.get("piy") or 0) < b]
        if not grp: continue
        py = sum(r["piy"] for r in grp) / len(grp)
        hc = sum(r["hist"] for r in grp) / len(grp)
        roi = sum(r.get("roi", 0) for r in grp) / len(grp)
        satir.append((f"%{a}–{b if b<100 else '+'}", len(grp), py, hc, hc - py, roi))
    if not satir: return ""
    h = ("<div class='pbox'><b>📐 PİYASA KALİBRASYONU</b> <span class='mini'>piyasanın verdiği şans ile tarihte gerçekleşen şans</span>"
         "<table class='pt'><tr><th>Piyasa şansı</th><th>Maç</th><th>Piyasa %</th><th>Gerçekleşen %</th><th>Fark</th><th>Ort. ROI</th></tr>")
    for ad, n, py, hc, fk, roi in satir:
        cls = "git" if fk > 0 else "kit"
        h += f"<tr><td><b>{ad}</b></td><td>{n}</td><td>{py:.1f}</td><td><b>{hc:.1f}</b></td><td class='{cls}'>{fk:+.1f}</td><td class='{cls}'>{roi:+.0f}%</td></tr>"
    h += "</table><div class='mini'>Fark pozitifse o bantta tarihsel gerçekleşme piyasadan yüksek (değer işareti).</div></div>"
    return h


def bantlar(K):
    """Seçim oranı bantlarına göre tarihsel performans."""
    bant = [(0, 1.6), (1.6, 2.0), (2.0, 2.4), (2.4, 2.8), (2.8, 3.2), (3.2, 99)]
    satir = []
    for a, b in bant:
        grp = [r for r in K if r.get("ad") and a <= (r.get("oran") or 0) < b]
        if not grp: continue
        hc = sum(r["hist"] for r in grp) / len(grp)
        roi = sum(r.get("roi", 0) for r in grp) / len(grp)
        sin = sum(1 for r in grp if r.get("sinyal"))
        satir.append((f"{a:.2f}–{b:.2f}" if b < 99 else f"{a:.2f}+", len(grp), hc, roi, sin))
    if not satir: return ""
    h = ("<div class='pbox'><b>🎚️ ORAN BANDI ANALİZİ</b> <span class='mini'>seçilen tarafın oranına göre tarihsel isabet</span>"
         "<table class='pt'><tr><th>Oran bandı</th><th>Maç</th><th>İsabet %</th><th>Ort. ROI</th><th>Sinyal</th></tr>")
    for ad, n, hc, roi, sin in satir:
        cls = "git" if roi > 0 else "kit"
        h += f"<tr><td><b>{ad}</b></td><td>{n}</td><td>{hc:.1f}</td><td class='{cls}'>{roi:+.0f}%</td><td>{sin}</td></tr>"
    h += "</table></div>"
    return h


def lig_ozeti(K):
    """Lig bazlı maç / sinyal / ortalama fark."""
    d = {}
    for r in K:
        l = r.get("l") or "?"
        x = d.setdefault(l, [0, 0, []])
        x[0] += 1
        if r.get("sinyal"): x[1] += 1
        if r.get("ad"): x[2].append(r.get("edge") or 0)
    sirali = sorted(d.items(), key=lambda z: (-z[1][1], -len(z[1][2])))[:8]
    h = ("<div class='pbox'><b>🏆 LİG ÖZETİ</b> <span class='mini'>en çok sinyal çıkan ligler</span>"
         "<table class='pt'><tr><th>Lig</th><th>Maç</th><th>Sinyal</th><th>Ort. fark</th></tr>")
    for l, (n, s, edg) in sirali:
        ort = sum(edg) / len(edg) if edg else 0
        h += f"<tr><td>{_esc(l)}</td><td>{n}</td><td class='git'><b>{s}</b></td><td>{ort:+.1f}</td></tr>"
    h += "</table></div>"
    return h



def gunun_ozeti(K):
    """Otomatik yazılmış gün özeti (analiz uzmanı dili)."""
    n = len(K); sin = [r for r in K if r.get("sinyal")]
    yuk = [r for r in sin if (r.get("n") or 0) >= 40]
    en = sorted(sin, key=lambda r: -(r.get("not") or 0))[:3]
    taraf = {"Ev": 0, "Beraberlik": 0, "Deplasman": 0}
    for r in sin: taraf[r.get("ad", "Ev")] = taraf.get(r.get("ad", "Ev"), 0) + 1
    ort_edge = sum(r.get("edge", 0) for r in sin) / len(sin) if sin else 0
    ort_roi = sum(r.get("roi", 0) for r in sin) / len(sin) if sin else 0
    gevsek = sum(1 for r in sin if (r.get("tol") or 0) > 0.20)
    iy = sum(1 for r in K if (r.get("det") or {}).get("htn"))
    p = []
    p.append(f"Bugün listede <b>{n} maç</b> var; bunların <b>{sum(1 for r in K if r.get('n'))}</b>'ü arşivdeki aynı oranlı maçlarla karşılaştırıldı.")
    p.append(f"<b>{len(sin)}</b> maçta değer sinyali çıktı ({len(yuk)}'i yüksek güven); ortalama fark <b>{ort_edge:+.1f} puan</b>, ortalama ROI <b>{ort_roi:+.0f}%</b>.")
    if en:
        p.append("En yüksek notlular: " + " · ".join(
            f"<b>{_esc(r['h'])}–{_esc(r['a'])}</b> ({_esc(r['ad'])} @ {r['oran']:.2f}, not {r.get('not',0):.0f}, {r['n']} maç)" for r in en) + ".")
    p.append(f"Sinyallerin taraf dağılımı: {taraf.get('Ev',0)} ev · {taraf.get('Beraberlik',0)} beraberlik · {taraf.get('Deplasman',0)} deplasman. "
             f"İY verisi {iy} grupta mevcut.")
    if gevsek:
        p.append(f"⚠ <b>{gevsek}</b> sinyalde oran eşleşmesi gevşek (±0.20 üzeri) — bu satırlarda örneklem geniş ama oranlar birebir değil, dikkatli bak.")
    p.append("Satırlara tıklayarak İY/MS matrisi, skor dağılımı, korner ve Poisson modelini görebilirsin; sepet için soldaki kutuları işaretle.")
    return ("<div class='pbox' style='margin-bottom:10px;background:linear-gradient(90deg,#12283a,#16273a)'>"
            "<b>🗒️ GÜNÜN ÖZETİ</b><ul style='margin:7px 0 0 16px;padding:0;font-size:12.8px;line-height:1.75'>"
            + "".join(f"<li>{x}</li>" for x in p) + "</ul></div>")


def taraf_panel(K):
    """Sinyallerde taraf + market dağılımı."""
    sin = [r for r in K if r.get("sinyal")]
    if not sin: return ""
    d = {}
    for r in sin:
        x = d.setdefault(r.get("ad", "?"), [0, 0.0, 0.0, 0.0])
        x[0] += 1; x[1] += r.get("edge", 0); x[2] += r.get("roi", 0); x[3] += (r.get("n") or 0)
    h = ("<div class='pbox'><b>⚖️ SİNYAL DAĞILIMI</b> <span class='mini'>hangi taraf daha çok değer üretiyor</span>"
         "<table class='pt'><tr><th>Taraf</th><th>Sinyal</th><th>Ort. fark</th><th>Ort. ROI</th><th>Ort. örneklem</th></tr>")
    for ad, (n, e, ro, nn) in sorted(d.items(), key=lambda z: -z[1][0]):
        h += (f"<tr><td><b>{ad}</b></td><td>{n}</td><td class='git'>{e/n:+.1f}</td>"
              f"<td class='{'git' if ro>0 else 'kit'}'>{ro/n:+.0f}%</td><td>{nn/n:.0f}</td></tr>")
    h += "</table></div>"
    return h


def performans_panel(K):
    """Bugün biten sinyallerin canlı skor performansı."""
    biten = [r for r in K if r.get("sonuc")]
    sin = [r for r in biten if r.get("sinyal")]
    if not biten:
        return ("<div class='pbox'><b>⏱️ CANLI TAKİP</b><div class='mini' style='margin-top:6px'>Bugünün maçları henüz başlamadı ya da skor gelmedi. "
                "Sayfa yeniden üretildiğinde biten maçlar ve sinyal sonuçları burada listelenir.</div></div>")
    def blok(ad, L):
        if not L: return ""
        kaz = sum(1 for r in L if r["sonuc"] == "KAZANDI")
        yuzde = 100 * kaz / len(L)
        return (f"<tr><th>{ad}</th><td>{len(L)}</td><td class='git'><b>{kaz}</b></td>"
                f"<td class='kit'>{len(L)-kaz}</td><td><b>%{yuzde:.0f}</b></td></tr>")
    h = ("<div class='pbox'><b>✅ BUGÜNÜN PERFORMANSI</b> <span class='mini'>biten maçlarda öne çıkan taraf ne yaptı?</span>"
         "<table class='pt'><tr><th>Grup</th><th>Biten maç</th><th>Kazandı</th><th>Kaybetti</th><th>İsabet</th></tr>")
    h += blok("Değer sinyalleri", sin)
    h += blok("Tüm karşılaştırmalar", biten)
    h += "</table>"
    if sin:
        kaz = [r for r in sin if r["sonuc"] == "KAZANDI"]
        h += ("<div class='mini' style='margin-top:6px'>Bugün sinyal verilen ve biten maçlar: "
              + " · ".join(f"<b>{_esc(r['h'])}–{_esc(r['a'])}</b> {_esc(r['ad'])} @{r['oran']:.2f} → "
                           f"<b class='{'git' if r['sonuc']=='KAZANDI' else 'kit'}'>{r['sonuc']}</b>"
                           for r in sin[:12]) + "</div>")
    return h + "</div>"


def yarin_panel(K_y, K_13=None):
    """Yarın ve ertesi gün için kompakt önizleme."""
    if not K_y:
        return ""
    kars = [r for r in K_y if r.get("n")]
    sin = sorted([r for r in K_y if r.get("sinyal")], key=lambda r: -(r.get("edge") or 0))
    h = (f"<div class='pbox'><b>📅 YARIN (12.09) ÖNİZLEME</b> <span class='mini'>{len(K_y)} maç · {len(kars)} karşılaştırıldı · "
         f"<b class='git'>{len(sin)} sinyal</b>" + (f" · 13.09: {len(K_13)} maç" if K_13 else "") + "</span>")
    if sin:
        h += ("<table class='pt'><tr><th>Saat</th><th>Maç</th><th>Oran 1/X/2</th><th>Taraf</th><th>Aynı oranlı</th>"
              "<th>Tarihsel %</th><th>Fark</th></tr>")
        for r in sin[:14]:
            h += (f"<tr><td>{_esc(r.get('s'))}</td><td class='mini'>{_esc(r.get('l'))} — <b>{_esc(r.get('h'))}</b> - {_esc(r.get('a'))}</td>"
                  f"<td>{r['o'][0]:.2f}/{r['o'][1]:.2f}/{r['o'][2]:.2f}</td><td><b>{_esc(r.get('ad'))}</b> @{r.get('oran'):.2f}</td>"
                  f"<td>{r.get('n')}</td><td>{r.get('hist')}%</td><td class='git'>+{r.get('edge')}</td></tr>")
        h += "</table>"
    else:
        h += "<div class='mini' style='margin-top:6px'>Yarın için değer kriterini geçen maç yok.</div>"
    return h + "<div class='mini' style='margin-top:5px'>Yarının maçları günü geldiğinde tam derinlikle (İY/MS, korner, form) işlenecek.</div></div>"



# ------------------------------------------------------------------ statik Sade tablo (JS'siz de görünür)
ETIKET_PY = {"durum": "Durum", "oran": "Oran", "n": "Aynı oranlı", "ad": "Öne çıkan", "edge": "Fark",
             "guv": "Güven", "not": "Not", "sonuclar": "Sonuçlar", "skorlar": "En sık skor", "tol": "Hassasiyet",
             "ci": "GA", "roi": "ROI", "kelly": "Kelly", "ort": "Ort.gol", "u15": "1.5Ü", "u25": "2.5Ü",
             "u35": "3.5Ü", "kg": "KG", "ht00": "İY 0-0", "iy1": "İY 1"}


def _dc(html, cid, sira=0):
    """Hücreye mobil etiket (data-c / data-etiket) ekler."""
    par = html.split("<td")
    if len(par) <= sira + 1:
        return html
    et = f' data-etiket="{ETIKET_PY[cid]}:"' if cid in ETIKET_PY else ""
    par[sira + 1] = f' data-c="{cid}"{et}' + par[sira + 1]
    return "<td".join(par)


def _stk(html, left, son=False):
    """Sabit (sticky) kolon için sınıf/stil ekler — JS ile birebir."""
    html = html.replace('<td class="', '<td class="stk ' + ('son ' if son else ''), 1)
    return html.replace('<td', f'<td style="left:{left}"', 1)


def _f1(v):
    try:
        return str(Decimal(str(float(v))).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))
    except Exception:
        return "0"


def _sade_satir(r, i):
    """Sade (varsayılan) satır — JS ciz() ile birebir aynı sıra: ck · maç · durum · oran · n · lig-içi · sonuçlar · skorlar · öne çıkan · fark · güven · not"""
    t = r.get("det") or {}
    o = r.get("o") or [0, 0, 0]
    ad = r.get("ad")
    kal = {"kesin": "kesin", "iyi": "iyi", "genis": "genis", "gevsek": "gevsek"}.get(r.get("kalite"), "")
    sec = {"Ev": 0, "Beraberlik": 1, "Deplasman": 2}.get(ad)
    oran_h = "".join(f'<span class="{"sec-aktif" if sec == j else ""}">{o[j]:.2f}</span>' for j in range(3))
    _ha, _hb = r.get("ha"), (r.get("ha_buyuk") or 0.0)
    if _ha and abs(_hb) >= 1:
        oran_h += (f'<span class="mini {"git" if _hb < 0 else "kit"}" title="Açılış → şimdi: Ev {_ha[0]:+.1f}% · '
                   f'X {_ha[1]:+.1f}% · Dep {_ha[2]:+.1f}%">{"↓" if _hb < 0 else "↑"} {abs(_hb):.1f}%</span>')

    # --- öne çıkan taraf hücreleri (ad · fark · güven) ---
    if ad:
        e = r.get("edge", 0.0)
        ad_h = f'<td class="od"><b>{_esc(ad)}</b></td><td class="od {"git" if e > 0 else "kit"}">{e:+.1f}</td><td>{V2._guv(r)}</td>'
        nv = r.get("not")
        nv = int(nv + 0.5) if nv is not None else None
        not_h = (f'<td class="od"><span class="not n{min(100, nv)}">{nv}</span></td>'
                 if nv is not None else '<td class="od">–</td>')
    else:
        ad_h = '<td class="od mini">—</td><td class="od mini">—</td><td class="od mini">—</td>'
        not_h = '<td class="od">–</td>'

    # --- durum / sonuç ---
    c = r.get("canli") or {}
    if r.get("sonuc"):
        ok = r["sonuc"] == "KAZANDI"
        dur_h = (f'<td class="od"><b class="{"git" if ok else "kit"}">{"✅" if ok else "❌"} {r["sonuc"]}</b>'
                 f' <span class="mini">{c.get("ms","")}'
                 f'{(" (İY " + c["iy"] + ")") if c.get("iy") else ""}</span></td>')
    elif c.get("durum") == "canlı":
        dur_h = (f'<td class="od uyk">🔴 {c.get("ms","")} canlı'
                 f'{(" (İY " + c["iy"] + ")") if c.get("iy") else ""}</td>')
    elif r.get("basladi"):
        dur_h = f'<td class="od uyk">🔴 canlı ~{int(r.get("dakika", 0))}\'</td>'
    else:
        dur_h = '<td class="od mini">🟢 yaklaşan</td>'

    # --- aynı oranlı maç sayısı ---
    n_h = (f'<td class="od"><b>{r.get("n") or "–"}</b>'
           f'<span class="nok {kal}" title="{KALAD.get(kal, "eşleşme yok")}"></span></td>')

    # --- LİGDE AYNI ORAN ---
    LC = r.get("lig_cmp") or {}
    ulke_kyn = False
    if not LC.get("n"):
        LC = r.get("ulke_cmp") or {}
        ulke_kyn = bool(LC.get("n"))
    if LC.get("n"):
        lms = LC.get("ms") or [0, 0, 0]
        mx = max(lms); et = ["Ev", "Ber", "Dep"][lms.index(mx)]
        chips = "".join(f'<span class="skorCip">{x[0]}</span>' for x in (LC.get("skor") or [])[:3])
        ip = (f'Ligde aynı oranla oynanan {LC["n"]} maç · tolerans ±{LC.get("tol_l")} · en sık: '
              + ", ".join(f"{x[0]} %{x[1]}" for x in (LC.get("skor") or [])[:4]))
        ulke_etiket = ' <span class="mini">(ülke)</span>' if ulke_kyn else ''
        ligc_h = (f'<td class="od ligc" title="{_esc(ip)}"><b>{LC["n"]}</b> maç'
                  f'{ulke_etiket} '
                  f'<span class="{"git" if mx >= 50 else ""}">{et} %{_f0(mx)}</span>'
                  f'<div class="mini" style="margin-top:2px">{chips}</div></td>')
    else:
        ligc_h = '<td class="od mini">–</td>'

    # --- aynı oranlı maçların sonuçları (yeni → eski) ---
    oo = r.get("ornek") or []
    if oo:
        kes = list(reversed(oo))[:10]
        parca, kaz = [], 0
        for cc in kes:
            try:
                p_ = cc["sk"].split(":"); hh, aa = int(p_[0]), int(p_[1])
            except Exception:
                continue
            son = "1" if hh > aa else ("X" if hh == aa else "2")
            tut = (hh > aa) if ad == "Ev" else ((hh == aa) if ad == "Beraberlik" else (hh < aa))
            if tut: kaz += 1
            ip2 = (f'{cc.get("d","")} · {cc.get("h","")} - {cc.get("a","")} · İY {cc.get("iy") or "–"} · '
                   f'oran {_jf(cc["o"][0])}/{_jf(cc["o"][1])}/{_jf(cc["o"][2])}')
            parca.append(f'<span class="sk s{"x" if son == "X" else son}" title="{_esc(ip2)}">{cc["sk"]}</span>')
        sonuc_h = ('<td class="sonucStr">' + "".join(parca)
                   + f'<span class="mini"> {kaz}/{len(kes)} tanesi öne çıkanı verdi</span></td>')
    else:
        sonuc_h = '<td class="od mini">–</td>'

    # --- en sık skorlar ---
    sp = t.get("skor_pct") or []
    si = t.get("skor_iy_pct") or []
    if sp or si:
        snf = lambda k: ("one" if k == 0 else ("two" if k == 1 else "uc"))
        par = [f'<span class="skorCip {snf(k)}" title="Maç sonucu skoru {x[0]}: maçların %{x[1]}">{x[0]} <b>%{_f1(x[1])}</b></span>'
               for k, x in enumerate(sp[:3])]
        if si:
            par.append('<div class="mini" style="margin-top:2px">İY: ' + "".join(
                f'<span class="skorCip" title="İlk yarı {x[0]}: %{x[1]}">{x[0]} %{_f0(x[1])}</span>' for x in si[:3]) + '</div>')
        skor_h = '<td class="skorStr">' + "".join(par) + '</td>'
    else:
        skor_h = '<td class="od mini">–</td>'

    # --- uyarı / bilgi ikonu ---
    uy = r.get("uyari") or []
    bl = r.get("bilgi") or []
    uy_h = (f'<span class="uy" title="{_esc(" · ".join(uy + bl))}">⚠</span>' if uy else
            (f'<span class="bil" title="{_esc(" · ".join(bl))}">i</span>' if bl else ""))
    ck = (f'<td class="ck" onclick="event.stopPropagation();secim({i})"><input type="checkbox" onchange="secim({i})"></td>'
          if ad else '<td class="ck mini">–</td>')

    return ("".join([]) + f'<tr class="{"sin" if r.get("sinyal") else ""}" onclick="det(this,{i})">'
            + _dc(_stk(ck, "0px"), "sec")
            + _dc(_stk(f'<td class="mac2"><span class="t">{_esc(r.get("s"))}{" ⁺¹" if r.get("gk") else ""} · {_esc(r.get("l"))}</span>'
                       f'<b>{_esc(r.get("h"))}</b> - {_esc(r.get("a"))} {uy_h}</td>', "30px", son=True), "macb")
            + _dc(dur_h, "durum")
            + _dc(f'<td class="od oran">{oran_h}</td>', "oran")
            + _dc(n_h, "n")
            + _dc(ligc_h, "ligc")
            + _dc(sonuc_h, "sonuclar")
            + _dc(skor_h, "skorlar")
            + _dc(_dc(_dc(ad_h, "ad"), "edge", 1), "guv", 2)
            + _dc(not_h, "not")
            + '</tr>')


def statik_satirlar(K):
    S = sorted(K, key=lambda r: -(r["not"] if (r.get("ad") and r.get("not") is not None) else -1))
    idx = {id(r): i for i, r in enumerate(K)}
    return "".join(_sade_satir(r, idx[id(r)]) for r in S)


def statik_baslik():
    """JS'siz görünüm için sade başlık (JS çalışınca yerini dinamik başlık alır)."""
    return ("<tr>"
            "<th class='ck'></th>"
            "<th class='sir stk' data-k='mac' style='width:300px;left:30px'>Maç (saat · lig)</th>"
            "<th class='sir' data-k='s'>Durum / Sonuç</th>"
            "<th class='sir' data-k='ligc' title='Aynı ligde aynı açılış oranı'>Lig</th>"
            "<th class='sir' data-k='o1'>Oran 1 / X / 2</th>"
            "<th class='sir' data-k='n'>Aynı oranlı maç</th>"
            "<th>Aynı oranlı sonuçlar (yeni → eski)</th>"
            "<th>En sık skorlar</th>"
            "<th class='sir' data-k='ad'>Öne çıkan</th>"
            "<th class='sir' data-k='edge'>Değer farkı</th>"
            "<th class='sir' data-k='guv'>Güven</th>"
            "<th class='sir' data-k='not'>Not</th></tr>")


# ------------------------------------------------------------------ JS: v2 panel fonksiyonlarını devral
def _js_f(ad, yeni_ad=None):
    s = V2.JS
    i = s.find("function " + ad + "(")
    if i < 0:
        return ""
    j = s.find("\nfunction ", i + 5)
    blok = s[i:(j if j > 0 else len(s))].rstrip()
    if yeni_ad:
        blok = blok.replace("function " + ad + "(", "function " + yeni_ad + "(", 1)
    return blok


DEVRALINAN = "\n".join(filter(None, [
    _js_f("pc"), _js_f("guv"), _js_f("bar"),
    _js_f("iymsPanel"), _js_f("skorPanel"), _js_f("ekPanel"), _js_f("kornerPanel"),
    _js_f("detayPanel", "zenginPanel"),
]))

CSS = """
:root{--bg:#f6f7f9;--pn:#ffffff;--pn2:#f0f2f5;--line:#e3e6ea;--line2:#d5d9df;--tx:#1c2126;--mut:#6b7580;
--git:#1a7f37;--kit:#c0392b;--uy:#b7791f;--mav:#0969da;--mor:#7c3aed;--cam:#0d9488;--g1:#0969da14;--g2:#1a7f3714;--g3:#b7791f14}
[data-tema="koyu"]{--bg:#0f1115;--pn:#16191f;--pn2:#1d2128;--line:#272c34;--line2:#333941;--tx:#e8ecf1;--mut:#98a2ad;
--git:#4ec97a;--kit:#f2756a;--uy:#e3b341;--mav:#5aa3f5;--g1:#5aa3f51a;--g2:#4ec97a1a;--g3:#e3b3411a}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--tx);font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,Arial,sans-serif;-webkit-font-smoothing:antialiased}
.wrap{max-width:1560px;margin:0 auto;padding:18px 16px 40px}
h1{font-size:19px;font-weight:650;margin:0 0 2px;letter-spacing:-.2px}
.sub{color:var(--mut);font-size:12.5px;margin-bottom:12px}.sub b{color:var(--tx)}
.git{color:var(--git)}.kit{color:var(--kit)}.uyk{color:var(--uy)}.mini{color:var(--mut);font-size:11.5px}
.arac{display:flex;gap:8px;flex-wrap:nowrap;overflow-x:auto;align-items:center;background:var(--pn);border:1px solid var(--line);border-radius:10px;padding:7px 9px;margin-bottom:10px;position:sticky;top:0;z-index:30}
.aracIc{display:flex;gap:10px;flex-wrap:wrap;align-items:center;padding:2px 0}
.aracIc input[type=text]{width:200px}
input[type=text],input[type=number],select{background:var(--pn);color:var(--tx);border:1px solid var(--line2);border-radius:7px;padding:6px 9px;font-size:13px}
input:focus,select:focus{outline:2px solid var(--mav);outline-offset:-1px;border-color:var(--mav)}
button{background:var(--pn);color:var(--tx);border:1px solid var(--line2);border-radius:7px;padding:6px 11px;cursor:pointer;font-size:13px;transition:.12s}
button:hover{border-color:var(--mav);color:var(--mav)}
button.ana{background:var(--mav);border-color:var(--mav);color:#fff;font-weight:600}button.ana:hover{filter:brightness(1.08);color:#fff}
.modlar{display:flex;gap:2px;background:var(--pn2);border:1px solid var(--line);border-radius:8px;padding:2px}
.modlar button{border:none;background:transparent;padding:5px 11px;border-radius:6px;font-size:12.5px;color:var(--mut)}
.modlar button:hover{color:var(--tx)}
.modlar button.aktif{background:var(--pn);color:var(--tx);font-weight:650;box-shadow:0 1px 2px #0000000d}
.bg{padding:1px 7px;border-radius:20px;font-size:11px;font-weight:650;display:inline-block;border:1px solid transparent}
.bg.y{background:var(--g2);color:var(--git);border-color:#1a7f3733}
.bg.o{background:var(--g3);color:var(--uy);border-color:#b7791f33}
.bg.z{background:var(--pn2);color:var(--mut)}
.tabloKap{background:var(--pn);border:1px solid var(--line);border-radius:12px;overflow:auto;max-height:76vh;box-shadow:0 1px 3px #00000008}
table{border-collapse:separate;border-spacing:0;width:100%}
thead th{position:sticky;top:0;background:var(--pn);color:var(--mut);font-size:11px;font-weight:600;text-align:center;padding:9px 6px;border-bottom:1px solid var(--line2);white-space:nowrap;z-index:5;letter-spacing:.2px}
thead tr.grupSatir th{background:var(--pn2);color:var(--mut);font-size:10px;letter-spacing:.6px;padding:4px;border-bottom:1px solid var(--line)}
thead th.sir{cursor:pointer}thead th.sir:hover{color:var(--tx)}
tbody td{padding:10px 7px;border-bottom:1px solid var(--line);font-size:13.5px;vertical-align:middle}
tbody tr{background:var(--pn)}tbody tr:hover{background:var(--g1)}
tbody tr.sin{box-shadow:inset 3px 0 0 var(--git)}
tbody tr.acik{background:var(--g1)}
td.od,th.od{text-align:center;font-variant-numeric:tabular-nums;white-space:nowrap}
td.mac2{min-width:200px;line-height:1.35}
td.mac2 .t{display:block;font-size:11.5px;color:var(--mut);font-weight:500}
td.mac2 b{font-weight:600}
td.oran span{display:inline-block;min-width:34px;padding:1px 3px;border-radius:5px;color:var(--mut);font-size:12.5px}
td.oran span.sec-aktif{background:var(--g2);color:var(--git);font-weight:700;font-size:13px}
td.ck{text-align:center;width:30px}td.ck input{cursor:pointer;width:15px;height:15px}
.nok{display:inline-block;width:6px;height:6px;border-radius:50%;margin-left:5px;vertical-align:middle}
.nok.kesin{background:var(--git)}.nok.iyi{background:var(--mav)}.nok.genis{background:var(--uy)}.nok.gevsek{background:var(--kit)}
.uy{cursor:help;color:var(--uy)}
.bil{cursor:help;display:inline-block;width:14px;height:14px;line-height:14px;text-align:center;border-radius:50%;background:var(--g1);color:var(--mav);font-size:11px;font-weight:700}
span.not{display:inline-block;min-width:30px;padding:2px 6px;border-radius:6px;font-weight:650;font-size:12px;background:var(--pn2);color:var(--mut)}
span.not.n70,span.not.n80,span.not.n90,span.not.n100{background:var(--g2);color:var(--git)}
span.not.n50,span.not.n60{background:var(--g1);color:var(--mav)}
span.not.n30,span.not.n40{background:var(--g3);color:var(--uy)}
span.not.n0,span.not.n10,span.not.n20{background:#c0392b14;color:var(--kit)}
td.hk span{display:inline-block;margin-right:5px;font-size:12px;font-weight:600}
.hkKart{display:inline-block;background:var(--g1);border:1px solid var(--line);border-radius:10px;padding:6px 10px;margin:4px 6px 0 0;text-align:center;min-width:118px;vertical-align:top}
.hkSat{margin-top:4px}
td.oran .mini{display:block;margin-top:2px;font-weight:600}
td.tgol{text-align:left;line-height:1.35;white-space:nowrap}
td.tgol .tg{display:block;font-size:11.5px;color:var(--mut)}
td.tgol .tg b{color:var(--tx);font-size:12.5px}
.golOzet{display:flex;gap:7px;flex-wrap:wrap;margin:6px 0 8px}
.golOzet .golKart{display:inline-flex;align-items:baseline;gap:5px;background:var(--g1);border:1px solid var(--line);border-radius:8px;padding:5px 8px}
.golOzet .golKart strong{font-size:14px;color:var(--mav)}
.anaKap{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:10px;margin-bottom:10px}
.anaBlok{background:var(--pn);border:1px solid var(--line);border-radius:12px;padding:11px 13px}
.anaBlok.genis{grid-column:1/-1}
.anaBas{font-weight:800;font-size:13.5px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.anaBas .rozet{background:var(--pn2);border-radius:6px;padding:1px 7px;font-size:11.5px;color:var(--mut);font-weight:600}
.anaIc{margin-top:7px}
.b3{display:flex;gap:6px;margin:6px 0}
.b3i{flex:1;background:var(--pn2);border-radius:8px;padding:5px 6px;font-size:12px;text-align:center;line-height:1.35}
.b3i i{display:block;height:7px;border-radius:4px;margin-bottom:3px}
.b3i.one i{background:#2e9e6e}.b3i.two i{background:#c9a227}.b3i.uc i{background:#b7392f}
.miniK{display:grid;grid-template-columns:auto auto;gap:3px 12px;font-size:12.5px;margin-top:2px}
.miniK>span{color:var(--mut)}.miniK>b{text-align:right;font-variant-numeric:tabular-nums}
.skorKut{background:var(--pn2);border-radius:9px;padding:7px 9px;margin-top:6px}
.tblSar{max-height:360px;overflow:auto;border:1px solid var(--line);border-radius:9px;margin-top:5px;background:var(--pn)}
.tblSar table{width:100%;border-collapse:collapse;font-size:12.5px}
.tblSar th{position:sticky;top:0;background:var(--pn2);z-index:2;font-size:11.5px;padding:5px 7px;text-align:left;color:var(--mut)}
.tblSar td{padding:4px 7px;border-bottom:1px solid var(--line)}
.tblSar tr:hover td{background:var(--g1)}
.tamNot{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-top:5px}
.tamA{background:var(--g1);border:1px solid var(--line);border-radius:7px;padding:2px 8px;font-size:12px;color:var(--mav);text-decoration:none}
.skorKut .b{font-size:11.5px;color:var(--mut);font-weight:700;letter-spacing:.03em}
.anaTab{width:100%;border-collapse:collapse;margin-top:5px;font-size:12.5px}
.anaTab th{background:var(--pn2);font-size:11.5px;padding:4px 6px;color:var(--mut)}
.anaTab td{padding:4px 6px;border-bottom:1px solid var(--line)}
.anaTab td.b{font-weight:700}
.uyarKut{background:var(--g3);border:1px solid var(--line);border-radius:9px;padding:7px 9px;font-size:12.5px;margin-top:6px}
.skorCip{display:inline-block;padding:1px 7px;margin:1px;border-radius:6px;font-size:12px;font-weight:600;background:var(--pn2);color:var(--tx)}
.skorCip.one{background:var(--g2);color:var(--git)}.skorCip.two{background:var(--g3);color:var(--uy)}.skorCip.uc{background:var(--g1);color:var(--mav)}
span.sk{display:inline-block;padding:1px 6px;margin:1px;border-radius:6px;font-size:11.5px;font-weight:650;font-variant-numeric:tabular-nums;background:var(--pn2);color:var(--mut)}
span.sk.s1{background:var(--g2);color:var(--git)}span.sk.sx{background:var(--g3);color:var(--uy)}span.sk.s2{background:var(--g1);color:var(--mav)}
td.sonucStr,td.skorStr{cursor:help}
.pbox{background:var(--pn);border:1px solid var(--line);border-radius:12px;padding:14px 16px;font-size:13px}
.paneller{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:12px;padding:14px;background:var(--bg);border-radius:12px;margin:8px 0}
table.pt{border-collapse:collapse;width:100%;margin-top:8px;font-size:12.5px}
table.pt th,table.pt td{border-bottom:1px solid var(--line);padding:6px 8px;text-align:center}
table.pt th{color:var(--mut);font-weight:600;font-size:11.5px}
table.pt tr:hover td{background:var(--g1)}
.pill{display:inline-block;background:var(--pn2);border:1px solid var(--line);border-radius:20px;padding:2px 10px;margin:2px;font-size:12px}
.panelKat,.altKat{margin-top:12px;background:var(--pn);border:1px solid var(--line);border-radius:12px;padding:0;overflow:hidden}
.panelKat>summary,.altKat>summary{cursor:pointer;padding:12px 16px;font-size:13.5px;list-style:none}
.panelKat>summary::-webkit-details-marker,.altKat>summary::-webkit-details-marker{display:none}
.panelKat>summary::before,.altKat>summary::before{content:'›';color:var(--mav);font-size:16px;font-weight:700;margin-right:8px;display:inline-block;transition:.15s}
.panelKat[open]>summary::before,.altKat[open]>summary::before{transform:rotate(90deg)}
.altKat{margin:10px 0;border-color:var(--line2)}.altKat>summary{font-size:13px;padding:9px 14px}
.altKat>*:not(summary){padding:0 14px;margin-bottom:12px}
.panelKat>*:not(summary){margin:14px}
.kartlar{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px}
.kart{background:var(--pn);border:1px solid var(--line);border-left:3px solid var(--git);border-radius:10px;padding:12px 14px;cursor:pointer;transition:.15s}
.kart:hover{box-shadow:0 3px 10px #00000012;transform:translateY(-1px)}
.kart .bas{font-size:11px;color:var(--mut);text-transform:uppercase;letter-spacing:.4px}
.kart .mac{font-weight:650;margin:4px 0 2px}
.kart .sat{display:flex;gap:12px;font-size:12.5px;margin-top:6px;flex-wrap:wrap}
.katBar{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0 4px}
.katBar button{font-size:12px;padding:4px 10px;border-radius:20px;color:var(--mut)}
.katBar button.aktif{background:var(--mav);border-color:var(--mav);color:#fff;font-weight:600}
#kuponBar{position:fixed;right:14px;bottom:14px;background:var(--pn);border:1px solid var(--line2);border-radius:10px;padding:9px 13px;display:none;gap:12px;align-items:center;z-index:60;box-shadow:0 6px 24px #0000001f;flex-wrap:wrap;max-width:76vw;font-size:12.5px}
#ipucu{position:fixed;z-index:80;display:none;max-width:440px;background:var(--pn);border:1px solid var(--line2);border-radius:10px;padding:11px 13px;box-shadow:0 8px 26px #00000026;font-size:12.5px}
#ipucu .cip{display:inline-block;padding:2px 7px;margin:2px;border-radius:6px;font-weight:650;background:var(--pn2)}
#ipucu .cip.s1{background:var(--g2);color:var(--git)}#ipucu .cip.sx{background:var(--g3);color:var(--uy)}#ipucu .cip.s2{background:var(--g1);color:var(--mav)}
.densRahat td{padding:11px 8px}.densSiki td{padding:5px;font-size:12px}
td.stk,th.stk{position:sticky;z-index:3;background:var(--pn)}
thead th.stk{z-index:8}
th.stk.son,td.stk.son{box-shadow:8px 0 10px -8px #0000001a}
/* ---------------- MOBİL (telefon) ---------------- */
@media (max-width:820px){
 .wrap{padding:12px 10px 30px}
 h1{font-size:17px}
 .sub{font-size:12px;line-height:1.5}
 .arac{flex-wrap:wrap;overflow:visible;padding:8px;gap:6px;position:static}
 .modlar{width:100%;overflow-x:auto;justify-content:flex-start}
 .modlar button{padding:7px 10px;font-size:12.5px;white-space:nowrap}
 .arac button{flex:1 1 auto}
 .tabloKap{max-height:none;overflow:visible;border:none;background:transparent;box-shadow:none}
 table,thead,tbody,tr,td{display:block;width:auto}
 thead{display:none}
 tbody tr{background:var(--pn);border:1px solid var(--line);border-radius:12px;padding:10px 12px;margin-bottom:10px;box-shadow:0 1px 2px #00000008}
 tbody tr.sin{border-left:3px solid var(--git)}
 tbody tr:hover{background:var(--pn)}
 td{border:none!important;padding:2px 0!important;text-align:left!important}
 td.stk{position:static!important;left:auto!important;box-shadow:none!important}
 td.ck{width:auto;float:right;margin-top:-26px}
 td.ck input{width:20px;height:20px}
 td.mac2{font-size:14.5px;margin-bottom:4px}
 td.mac2 .t{font-size:12px}
 td[data-c="durum"],td[data-c="oran"],td[data-c="n"],td[data-c="ad"],td[data-c="edge"],td[data-c="guv"],td[data-c="not"],td[data-c="u25"],td[data-c="kg"],td[data-c="ht00"],td[data-c="iy1"]{display:inline-block;margin-right:12px}
 td[data-c="durum"]::before,td[data-c="oran"]::before,td[data-c="n"]::before,td[data-c="ad"]::before,td[data-c="edge"]::before,
 td[data-c="guv"]::before,td[data-c="not"]::before,td[data-c="sonuclar"]::before,td[data-c="skorlar"]::before,
 td[data-c="u25"]::before,td[data-c="kg"]::before,td[data-c="ht00"]::before,td[data-c="iy1"]::before,td[data-c="tol"]::before{
  content:attr(data-etiket);color:var(--mut);font-size:11px;margin-right:4px;font-weight:500}
 td[data-c="sonuclar"],td[data-c="skorlar"],td[data-c="tol"],td[data-c="ort"],td[data-c="u15"],td[data-c="u35"],td[data-c="tgol"]{margin-top:5px;font-size:12px}
 td[data-c="ci"],td[data-c="kelly"],td[data-c="roi"],td[data-c="w25"],td[data-c="spark"],td[data-c="mat3"],
 td[data-c="htort"],td[data-c="h2ort"],td[data-c="iyx"],td[data-c="iy2"],td[data-c="htu15"],td[data-c="iykg"],td[data-c="ayni"],td[data-c="d"]{display:none}
 .panelKat,.altKat{margin-top:10px}
 .paneller{grid-template-columns:1fr;padding:10px;gap:10px}
 .pbox{padding:12px;overflow-x:auto}
 .pbox table.pt{min-width:320px}
 .kartlar{grid-template-columns:1fr}
 #kuponBar{left:8px;right:8px;bottom:8px;max-width:none}
 #ipucu{max-width:calc(100vw - 24px)}
 .katBar{overflow-x:auto;flex-wrap:nowrap;padding-bottom:4px}
}
@media print{.arac,#kuponBar,.modlar,.kartlar,button,.katBar{display:none!important}
 body{background:#fff}.wrap{max-width:100%}.tabloKap{max-height:none;border:none;box-shadow:none}
 tbody td{font-size:10px;padding:3px}thead th{background:#eee}}
"""

JS = r"""
const $=(id)=>document.getElementById(id);
D.forEach((r,i)=>{r.__i=i;});
const SEC=new Set();
let sir='not',ters=true,mod='sade';
const esc=(s)=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const KALAD={kesin:'Eşleşme çok sıkı (≤0.05)',iyi:'Eşleşme iyi (≤0.15)',genis:'Eşleşme geniş (≤0.28)',gevsek:'Eşleşme gevşek (>0.28)'};

function dg(r,k){
 const idx={o1:0,o2:1,o3:2,d1:0,d2:1,d3:2};
 if(k=='s'){const t=(r.s||'00:00').split(':');const v=((+t[0])||0)*60+((+t[1])||0);return v+(r.gk?1440:0);}
 if(k in idx) return k[0]=='o'? r.o[idx[k]] : (r.d? r.d[idx[k]] : -99);
 if(k=='guv') return (r.n>=40&&r.sinyal)?3:((r.n>=18&&r.sinyal)?2:(r.sinyal?1:0));
 if(k=='tol') return (r.tol===null||r.tol===undefined)?-99:r.tol;
 if(k=='kor') return r.kor? r.kor.tot : -99;
 if(k=='mac') return (r.h+' '+r.a).toLowerCase();
 if(k=='ort') return (r.det&&r.det.ort!==undefined)? r.det.ort : -99;
 if(k=='tgol'){
  const f=r.form||{}, h=f.h||{}, a=f.a||{};
  const ht=h.top!==undefined?Number(h.top):Number(h.at||0)+Number(h.ye||0);
  const at=a.top!==undefined?Number(a.top):Number(a.at||0)+Number(a.ye||0);
  return (Number.isFinite(ht)?ht:0)+(Number.isFinite(at)?at:0);
 }
 if(k=='w25') return (r.det&&r.det.w_u25!==undefined)? r.det.w_u25 : -99;
 const v=r[k];
 return (v===undefined||v===null)?-99:v;
}
const _t=(r,k)=>{const v=r.det? r.det[k]:undefined; return `<td class="od">${pc(v)}</td>`;};

const HUC={
 sec:r=> r.ad? `<td class="ck" onclick="event.stopPropagation()"><input type="checkbox" ${SEC.has(r.__i)?'checked':''} onchange="secim(${r.__i})"></td>` : '<td class="ck mini">–</td>',
 s:r=>`<td class="od saat">${esc(r.s)}${r.gk?'<span class="mini" title="Türkiye saatiyle ertesi gün (sabaha karşı)"> ⁺¹</span>':''}</td>`,
 l:r=>`<td class="lig" title="${esc(r.lt||r.l)}">${esc(r.l)}</td>`,
 macb:r=>{const uy=(r.uyari&&r.uyari.length), bl=(r.bilgi&&r.bilgi.length);
  const ik=uy?`<span class="uy" title="${esc([...r.uyari,...r.bilgi].join(' · '))}">⚠</span>`:(bl?`<span class="bil" title="${esc(r.bilgi.join(' · '))}">i</span>`:'');
  return `<td class="mac2"><span class="t">${esc(r.s)}${r.gk?' ⁺¹':''} · ${esc(r.l)}</span><b>${esc(r.h)}</b> - ${esc(r.a)} ${ik}</td>`;},
 mac:r=>`<td class="mac2"><b>${esc(r.h)}</b><span class="mini"> - </span>${esc(r.a)}${(r.uyari&&r.uyari.length)?` <span class="uy" title="${esc([...(r.uyari||[]),...(r.bilgi||[])].join(' · '))}">⚠</span>`:((r.bilgi&&r.bilgi.length)?` <span class="bil" title="${esc(r.bilgi.join(' · '))}">i</span>`:'')}</td>`,
 durum:r=>{const c=r.canli||{};
  if(r.sonuc){const ok=r.sonuc=='KAZANDI';
   return `<td class="od"><b class="${ok?'git':'kit'}">${ok?'✅':'❌'} ${r.sonuc}</b> <span class="mini">${c.ms||''}${c.iy?' (İY '+c.iy+')':''}</span></td>`;}
  if(c.durum=='canlı') return `<td class="od uyk">🔴 ${c.ms||''} canlı${c.iy?' (İY '+c.iy+')':''}</td>`;
  if(r.basladi) return `<td class="od uyk">🔴 canlı ~${r.dakika||0}'</td>`;
  return '<td class="od mini">🟢 yaklaşan</td>';},
 oran:r=>{const a={'Ev':0,'Beraberlik':1,'Deplasman':2}[r.ad];
  const hk=(r.ha&&Math.abs(r.ha_buyuk)>=1)?`<span class="mini ${r.ha_buyuk<0?'git':'kit'}" title="Açılış → şimdi: Ev ${r.ha[0]>0?'+':''}${r.ha[0]}% · X ${r.ha[1]>0?'+':''}${r.ha[1]}% · Dep ${r.ha[2]>0?'+':''}${r.ha[2]}%">${r.ha_buyuk<0?'↓':'↑'} ${Math.abs(r.ha_buyuk).toFixed(1)}%</span>`:'';
  return `<td class="od oran">${r.o.map((x,j)=>`<span class="${a===j?'sec-aktif':''}">${x.toFixed(2)}</span>`).join('')}${hk}</td>`;},
 hareket:r=>{if(!r.ha) return '<td class="od mini">–</td>';
  const L=['Ev','X','Dep'], m=r.ha.map((v,i)=>({v,i})).filter(x=>Math.abs(x.v)>=0.5).sort((x,y)=>Math.abs(y.v)-Math.abs(x.v)).slice(0,2);
  const ip='Açılış → şimdi: '+L.map((x,i)=>x+' '+(r.ha[i]>0?'+':'')+r.ha[i]+'%').join(' · ')+(r.ha_iyi?' | en iyi şimdi: '+r.ha_iyi.join(' / '):'');
  if(!m.length) return `<td class="od hk mini" title="${esc(ip)}">⇄ sabit</td>`;
  return `<td class="od hk" title="${esc(ip)}">`+m.map(x=>`<span class="${x.v<0?'git':'kit'}">${x.v<0?'↓':'↑'}${L[x.i]} ${x.v>0?'+':''}${x.v.toFixed(1)}%</span>`).join(' ')+'</td>';},
 n:r=>`<td class="od"><b>${r.n||'–'}</b>${r.kalite?`<span class="nok ${r.kalite}" title="${KALAD[r.kalite]||''}"></span>`:''}</td>`,
 tgol:r=>{
  const f=r.form||{}, h=f.h, a=f.a;
  const sayi=v=>{const n=Number(v); return Number.isFinite(n)?n.toFixed(2):'–';};
  const toplam=x=>x?(x.top!==undefined?x.top:Number(x.at||0)+Number(x.ye||0)):null;
  const takim=(etiket,ad,x)=>x
   ? `<span class="tg"><b>${etiket}</b> ${esc(ad)} · attı <b>${sayi(x.at)}</b> · yedi <b>${sayi(x.ye)}</b> · toplam <b>${sayi(toplam(x))}</b></span>`
   : `<span class="tg"><b>${etiket}</b> veri yok</span>`;
  return `<td class="od tgol" title="Son ${(h&&h.n)||(a&&a.n)||'–'} maç: takımın attığı, yediği ve toplam gol ortalaması">${takim('Ev',r.h,h)}${takim('Dep',r.a,a)}</td>`;
 },
 tol:r=>`<td class="od">${(r.tol===null||r.tol===undefined)?'–':'±'+r.tol}</td>`,
 d:r=>r.d? `<td class="od d3">${r.d.map(v=>`<span class="${v>=55?'git':(v<=35?'kit':'')}">${v.toFixed(0)}</span>`).join('')}</td>` : '<td class="od mini">–</td>',
 ad:r=>r.ad? `<td class="od"><b>${esc(r.ad)}</b></td>` : '<td class="od mini">—</td>',
 edge:r=>r.ad? `<td class="od ${r.edge>0?'git':'kit'}">${r.edge>0?'+':''}${r.edge.toFixed(1)}</td>` : '<td class="od mini">—</td>',
 ci:r=>r.ci? `<td class="od mini">${r.ci[0].toFixed(0)}–${r.ci[1].toFixed(0)}</td>` : '<td class="od mini">–</td>',
 guv:r=>`<td>${guv(r)}</td>`,
 roi:r=>r.ad? `<td class="od ${r.roi>0?'git':'kit'}">${r.roi>0?'+':''}${r.roi.toFixed(0)}%</td>` : '<td class="od mini">—</td>',
 kelly:r=>(r.kelly===undefined||r.kelly===null)? '<td class="od mini">–</td>' : `<td class="od">${r.kelly}%</td>`,
 not:r=>(r.not===null||r.not===undefined)? '<td class="od mini">–</td>' : `<td class="od"><span class="not n${Math.min(100,Math.round(r.not))}">${Math.round(r.not)}</span></td>`,
 ort:r=>_t(r,'ort'), u15:r=>_t(r,'u15'), u25:r=>_t(r,'u25'), u35:r=>_t(r,'u35'), kg:r=>_t(r,'kg'),
 ht00:r=>_t(r,'ht00'), htu05:r=>_t(r,'htu05'), htu15:r=>_t(r,'htu15'), iykg:r=>_t(r,'htkg'),
 ayni:r=>_t(r,'ayni'), htort:r=>_t(r,'htort'), h2ort:r=>_t(r,'h2ort'), w25:r=>_t(r,'w_u25'),
 iy1:r=>r.det? `<td class="od">${pc(r.det.iy1)}</td>` : '<td class="od mini">–</td>',
 iyx:r=>r.det? `<td class="od">${pc(r.det.iyx)}</td>` : '<td class="od mini">–</td>',
 iy2:r=>r.det? `<td class="od">${pc(r.det.iy2)}</td>` : '<td class="od mini">–</td>',
 spark:r=>{const g=r.det&&r.det.gol; if(!g) return '<td class="od mini">–</td>';
  return '<td class="spark" style="text-align:center">'+g.map((v,i)=>`<span class="sb" style="height:${Math.max(3,Math.round(v/2))}px" title="${i} gol: %${v.toFixed(0)}"></span>`).join('')+'</td>';},
 mat3:r=>{const m=r.det&&r.det.matrix; if(!m) return '<td class="od mini">–</td>'; const L=['1','X','2'];
  return '<td class="m3" style="text-align:center">'+m.map((row,i)=>row.map((v,j)=>`<span title="İY ${L[i]} → MS ${L[j]}: %${v}" style="background:rgba(63,185,80,${(v/45).toFixed(2)})">${v>=1?v.toFixed(0):''}</span>`).join('')).join('')+'</td>';},
 kor:r=>r.kor? `<td class="od"><b>${r.kor.tot}</b> <span class="mini ${r.kor.tot>=9.5?'git':'kit'}">${esc(r.kor.pick)}</span></td>` : '<td class="od mini">–</td>',
 skorlar:r=>{const t=(r.det||{}); const sp=t.skor_pct||[]; const si=t.skor_iy_pct||[];
  if(!sp.length&&!si.length) return '<td class="od mini">–</td>';
  const sınıf=i=>i===0?'one':(i===1?'two':'uc');
  let h='<td class="skorStr">';
  h+=sp.slice(0,3).map((x,i)=>`<span class="skorCip ${sınıf(i)}" title="Maç sonucu skoru ${x[0]}: maçların %${x[1]}">${x[0]} <b>%${x[1].toFixed(1)}</b></span>`).join('');
  if(si.length) h+='<div class="mini" style="margin-top:2px">İY: '+si.slice(0,3).map(x=>`<span class="skorCip" title="İlk yarı ${x[0]}: %${x[1]}">${x[0]} %${x[1].toFixed(0)}</span>`).join('')+'</div>';
  return h+'</td>';},
 kapk:r=>{const K=r.kk; if(!K) return '<td class="od mini">–</td>';
  const L=K.k||K.t; if(!L||!L.n) return '<td class="od mini">–</td>';
  const ms=L.ms, mx=Math.max(...ms), i=ms.indexOf(mx), et=['Ev','Ber','Dep'][i];
  const ch=(L.skor||[]).slice(0,3).map(x=>`<span class="skorCip">${x[0]}</span>`).join('');
  return `<td class="od ligc" title="${esc(K.kyn)} kapanış ${K.o.join(' / ')} · ${K.k?'KENDİ LİGİ ('+esc(K.ln)+')':'TÜM LİGLER'} ${L.n} maç · tolerans ±%${K.tol} (tüm ligler) / ±%${K.tolg} (lig) · MS Ev %${ms[0]} / X %${ms[1]} / Dep %${ms[2]} · ort ${L.ort} gol · 2.5Ü %${L.u25} · KG %${L.kg} · en sık: ${(L.skor||[]).map(x=>x[0]+' %'+x[1]).join(', ')}${L.iy?` · İY ${L.iy.n} maç: 0-0 %${L.iy.s00} · 1.5Ü %${L.iy.s15} · KG %${L.iy.kg} · ort ${L.iy.ort} gol · İY-MS aynı %${L.iy.ayni} · İY skorları: ${(L.iy.skor||[]).map(x=>x[0]+' %'+x[1]).join(', ')}`:''}">
   <b>${L.n}</b> maç${K.k?'':' <span class="mini">(tüm ligler)</span>'} <span class="${mx>=50?'git':''}">${et} %${mx.toFixed(0)}</span>
   <div>${ch}</div>
   ${L.iy?`<div class="mini" style="color:#0d5c3a">İY: 0-0 %${L.iy.s00} · 1.5Ü %${L.iy.s15}</div>`:''}
   <div class="mini">${esc(K.kyn)} · ${esc((K.k?K.ln:(K.lu?K.lu:'tüm ligler')))}</div></td>`;},
 ligc:r=>{let L=r.lig_cmp, ulke=false;
  if(!L||!L.n){ L=r.ulke_cmp; ulke=true; if(!L||!L.n) return '<td class="od mini">–</td>'; }
  const ms=L.ms, mx=Math.max(...ms), i=ms.indexOf(mx);
  const et=['Ev','Ber','Dep'][i];
  const ch=(L.skor||[]).slice(0,3).map(x=>`<span class="skorCip">${x[0]}</span>`).join('');
  return `<td class="od ligc" title="Ligde aynı oranla oynanan ${L.n} maç · tolerans ±${L.tol_l} · en sık: ${(L.skor||[]).slice(0,4).map(x=>x[0]+' %'+x[1]).join(', ')}">
   <b>${L.n}</b> maç${ulke?' <span class="mini">(ülke)</span>':''} <span class="${mx>=50?'git':''}">${et} %${mx.toFixed(0)}</span>
   <div class="mini" style="margin-top:2px">${ch}</div></td>`;},
 sonuclar:r=>{const o=r.ornek; if(!o||!o.length) return '<td class="od mini">–</td>';
  const L=[...o].reverse().slice(0,10);
  const kaz=L.filter(c=>{const p=c.sk.split(':').map(Number); return {'Ev':p[0]>p[1],'Beraberlik':p[0]==p[1],'Deplasman':p[0]<p[1]}[r.ad];}).length;
  return `<td class="sonucStr">`+L.map(c=>{const p=c.sk.split(':').map(Number);
   const son=p[0]>p[1]?'1':(p[0]==p[1]?'X':'2');
   const renk=son=='1'?'s1':(son=='X'?'sx':'s2');
   return `<span class="sk ${renk}" title="${c.d} · ${esc(c.h)} - ${esc(c.a)} · İY ${c.iy||'–'} · oran ${c.o[0]}/${c.o[1]}/${c.o[2]}">${c.sk}</span>`;}).join('')
   +`<span class="mini"> ${kaz}/${L.length} tanesi öne çıkanı verdi</span></td>`;},
 uy:r=>(r.uyari&&r.uyari.length)? `<td class="mini uyk">⚠ ${esc(r.uyari[0])}</td>`
   : ((r.bilgi&&r.bilgi.length)? `<td class="mini"><span class="bil" title="${esc(r.bilgi.join(' · '))}">i</span> ${esc(r.bilgi[0])}</td>` : '<td class="mini">✓</td>')
};

const KOL=[
 {id:'sec',t:'',g:'',k:null,w:'30px',st:'0px',ip:'Kupon (sepet) için işaretle'},
 {id:'s',t:'Saat',g:'MAÇ',k:'s',w:'56px',st:'30px'},
 {id:'l',t:'Lig',g:'MAÇ',k:'l',w:'100px',st:'86px'},
 {id:'macb',t:'Maç',g:'MAÇ',k:'mac',w:'300px',st:'30px',son:1,ip:'Saat · lig · takımlar — sabit kolon'},
 {id:'mac',t:'Maç',g:'MAÇ',k:'mac',w:'230px',st:'186px',son:1},
 {id:'durum',t:'Durum / Sonuç',g:'MAÇ',k:'s',w:'150px',ip:'Maç bitti mi, sinyal tuttu mu?'},
 {id:'oran',t:'Açılış oranı 1 / X / 2',g:'ORAN',k:'o1',w:'118px',ip:'Koyu yeşil olan = öne çıkan taraf'},
 {id:'hareket',t:'Hareket',g:'ORAN',k:'hk',w:'104px',ip:'Açılış → şimdiki oran değişimi. ↓ = oran düştü (para o tarafa geliyor), ↑ = oran yükseldi (uzaklaşılıyor)'},
 {id:'n',t:'Aynı oranlı maç',g:'KARŞILAŞTIRMA',k:'n',w:'84px',ip:'Arşivde aynı oranlarla açılmış maç sayısı; nokta = eşleşme kalitesi'},
 {id:'tgol',t:'Takım gol ort.',g:'GOL',k:'tgol',w:'220px',ip:'Son 6 maçta takımın maç başına attığı / yediği / toplam gol ortalaması'},
 {id:'tol',t:'Eşleşme hassasiyeti',g:'KARŞILAŞTIRMA',k:'tol',w:'92px',ip:'Küçük tolerans = oranlar birebir aynı'},
 {id:'d',t:'Tarihsel sonuç % Ev / Ber / Dep',g:'TARİHSEL SONUÇ',k:'d1',w:'130px'},
 {id:'ad',t:'Öne çıkan taraf',g:'TARİHSEL SONUÇ',k:'ad',w:'94px'},
 {id:'ligc',t:'Ligde aynı oran',g:'TARİHSEL SONUÇ',k:null,w:'150px',ip:'Aynı ligde aynı oranla açılmış maçlar: kaç maç, hangi taraf, en sık skorlar'},
 {id:'kapk',t:'Kapanış kıyası',g:'KAPANIŞ',k:'kk',w:'128px',ip:'Aynı KAPANIŞ oranıyla bitmiş maçlar (önce kendi ligi, yoksa tüm ligler): kaç maç, hangi taraf, en sık skorlar'},
 {id:'sonuclar',t:'Aynı oranlı maçların sonuçları (yeni → eski)',g:'TARİHSEL SONUÇ',k:null,w:'186px',ip:'Bu oranla oynanan maçların gerçek skorları' },
 {id:'skorlar',t:'En sık skorlar',g:'TARİHSEL SONUÇ',k:null,w:'196px',ip:'Bu oranla oynanan maçlarda en sık çıkan maç sonuçları ve İY skorları'},
 {id:'edge',t:'Değer farkı (puan)',g:'DEĞER',k:'edge',w:'86px',ip:'Tarihsel % − piyasa %'},
 {id:'ci',t:'Güven aralığı %95',g:'DEĞER',k:'ci',w:'94px'},
 {id:'roi',t:'ROI',g:'DEĞER',k:'roi',w:'62px',ip:'Bu oranla oynansaydı geçmiş getiri'},
 {id:'kelly',t:'Kelly',g:'DEĞER',k:'kelly',w:'60px',ip:'Kasanın yüzde kaçı'},
 {id:'guv',t:'Güven',g:'DEĞER',k:'guv',w:'80px'},
 {id:'not',t:'Öneri notu',g:'DEĞER',k:'not',w:'74px',ip:'0-100 bileşik puan'},
 {id:'uy',t:'Uyarı',g:'DEĞER',k:null,w:'110px'},
 {id:'ort',t:'Ort. gol',g:'GOL',k:'ort',w:'66px'},
 {id:'u15',t:'1.5 Üst',g:'GOL',k:'u15',w:'60px'},
 {id:'u25',t:'2.5 Üst',g:'GOL',k:'u25',w:'60px'},
 {id:'u35',t:'3.5 Üst',g:'GOL',k:'u35',w:'60px'},
 {id:'kg',t:'KG',g:'GOL',k:'kg',w:'54px'},
 {id:'ht00',t:'İY 0-0',g:'GOL',k:'ht00',w:'62px'},
 {id:'w25',t:'2.5Ü son 3 yıl',g:'GOL',k:'w25',w:'88px',ip:'Zaman ağırlıklı (yakın maçlar daha ağır)'},
 {id:'spark',t:'Gol dağılımı 0→5+',g:'GOL',k:null,w:'96px'},
 {id:'iy1',t:'İY 1 %',g:'İLK YARI',k:'iy1',w:'58px'},
 {id:'iyx',t:'İY X %',g:'İLK YARI',k:'iyx',w:'58px'},
 {id:'iy2',t:'İY 2 %',g:'İLK YARI',k:'iy2',w:'58px'},
 {id:'htu05',t:'İY 0.5 Üst',g:'İLK YARI',k:'htu05',w:'68px'},
 {id:'htu15',t:'İY 1.5 Üst',g:'İLK YARI',k:'htu15',w:'68px'},
 {id:'iykg',t:'İY KG',g:'İLK YARI',k:'htkg',w:'58px'},
 {id:'ayni',t:'İY=MS',g:'İLK YARI',k:'ayni',w:'60px',ip:'İlk yarı lideri maçı da kazandı'},
 {id:'htort',t:'İY gol ort.',g:'İLK YARI',k:'htort',w:'72px'},
 {id:'h2ort',t:'2Y gol ort.',g:'İLK YARI',k:'h2ort',w:'72px'},
 {id:'mat3',t:'İY/MS matrisi',g:'İLK YARI',k:null,w:'104px',ip:'Satır: İY sonucu · Kolon: MS sonucu'},
 {id:'kor',t:'Korner (beklenen + sinyal)',g:'KORNER',k:'kor',w:'128px'}
];
const GORUNUM={
 sade:['sec','macb','durum','oran','n','ligc','sonuclar','skorlar','ad','edge','guv','not'],
 deger:['sec','macb','durum','oran','hareket','n','tol','d','ligc','kapk','sonuclar','skorlar','ad','edge','ci','roi','kelly','guv','not'],
 gol:['sec','macb','durum','oran','n','tgol','ort','u15','u25','u35','kg','ht00','w25','spark'],
 ilkyari:['sec','macb','durum','oran','n','iy1','iyx','iy2','ht00','htu15','iykg','ayni','mat3'],
 tum:['sec','macb','durum','oran','hareket','n','tol','d','ligc','kapk','ad','edge','ci','roi','guv','not','tgol','ort','u15','u25','u35','kg','ht00','w25','iy1','iyx','iy2','htu15','iykg','ayni','kor','sonuclar','skorlar']
};

function baslikYap(){
 const kol=GORUNUM[mod].map(id=>KOL.find(x=>x.id===id));
 let g1='',g2='',i=0;
 while(i<kol.length){
  let j=i; while(j<kol.length&&kol[j].g===kol[i].g) j++;
  const span=j-i;
  g1+= kol[i].g? `<th class="grup" colspan="${span}">${kol[i].g}</th>` : `<th colspan="${span}"></th>`;
  i=j;
 }
 for(const c of kol){
  const ok=(c.k&&sir===c.k)?(ters?' ▼':' ▲'):'';
  const cls=(c.k?'sir ':'')+(c.st?'stk ':'')+(c.son?'son':'');
  const sty=`width:${c.w}`+(c.st?`;left:${c.st}`:'');
  g2+=`<th class="${cls}" ${c.k?`data-k="${c.k}"`:''} style="${sty}" ${c.ip?`title="${c.ip}"`:''}>${c.t}${ok}</th>`;
 }
 const th=$('thead');
 th.innerHTML=`<tr class="grupSatir">${g1}</tr><tr>${g2}</tr>`;
 th.querySelectorAll('th.sir').forEach(x=>x.onclick=()=>{const k=x.dataset.k; if(sir===k)ters=!ters; else {sir=k;ters=true;} ciz();});
}
const SABIT={sec:'0px',s:'30px',l:'86px',mac:'186px',macb:'30px'};
const SITE=__SITE__;
const ETIKET={durum:'Durum',oran:'Oran',hareket:'Hareket',n:'Aynı oranlı',tgol:'Takım gol ort.',ad:'Öne çıkan',edge:'Fark',guv:'Güven',not:'Not',sonuclar:'Sonuçlar',skorlar:'En sık skor',tol:'Hassasiyet',ci:'GA',roi:'ROI',kelly:'Kelly',ort:'Ort.gol',u15:'1.5Ü',u25:'2.5Ü',u35:'3.5Ü',kg:'KG',ht00:'İY 0-0',iy1:'İY 1',d:'Ev/Ber/Dep'};
function satir(r){
 let h=`<tr class="${r.sinyal?'sin':''}" data-i="${r.__i}" onclick="det(this,${r.__i})">`;
 for(const id of GORUNUM[mod]){
  let c=HUC[id](r);
  if(SABIT[id]!==undefined){
   c=c.replace('<td class="',`<td class="stk ${id==='mac'?'son ':''}`);
   c=c.replace('<td',`<td style="left:${SABIT[id]}"`);
  }
  c=c.replace('<td',`<td data-c="${id}"${ETIKET[id]?` data-etiket="${ETIKET[id]}:"`:""}`);
  h+=c;
 }
 return h+'</tr>';
}
function _bitti(r){
 const b=$('guncl'); if(b&&!b.checked) return false;
 if(r.gk) return false;                       // Türkiye saatiyle ertesi gün = henüz oynanmadı
 if(!/^\d{2}:\d{2}$/.test(r.s||'')) return false;
 const n=new Date(), [h,m]=r.s.split(':').map(Number);
 const k=new Date(n.getFullYear(),n.getMonth(),n.getDate(),h,m,0,0);
 return (n-k)/60000>120;
}
function ciz(){
 const q=($('q').value||'').toLowerCase().trim(), f=$('flt').value, lg=$('lig').value;
 const ZAMAN_AKTIF=D.some(r=>!_bitti(r));
 const minn=+($('minn').value||0), iyonly=$('iyonly')&&$('iyonly').checked, kuponly=$('kupononly')&&$('kupononly').checked;
 const s1=($('sa1')&&$('sa1').value)||'00:00', s2=($('sa2')&&$('sa2').value)||'23:59';
 let L=D.filter(r=>{
  if(ZAMAN_AKTIF&&_bitti(r)) return false;
  if(f=='sinyal'&&!r.sinyal) return false;
  if(f=='kar'&&!r.n) return false;
  if(f=='iy'&&!(r.det&&r.det.htn)) return false;
  if(f=='hareket'&&!(r.ha&&Math.abs(r.ha_buyuk)>=1)) return false;
  if(f=='kapk'&&!r.kk) return false;
  if(f=='siki'&&!(r.n&&r.tol<=0.15)) return false;
  if(f=='oransiz'&&r.n) return false;
  if(minn&&(r.n||0)<minn) return false;
  if(iyonly&&!(r.det&&r.det.htn)) return false;
  if(kuponly&&!SEC.has(r.__i)) return false;
  if($('ligonly')&&$('ligonly').checked&&!(r.lig_cmp&&r.lig_cmp.n)) return false;
  if(r.s&&!r.gk&&(r.s<s1||r.s>s2)) return false;
  if(r.gk&&('24:'+String(r.s).slice(3)<s1||'24:'+String(r.s).slice(3)>s2)&&!(s1<='00:00'&&s2>='23:59')) return false;
  if(lg&&r.l!==lg) return false;
  if(q&&!((r.h+' '+r.a+' '+r.l+' '+(r.lt||'')).toLowerCase().includes(q))) return false;
  return true;});
 L.sort((a,b)=>{const x=dg(a,sir),y=dg(b,sir);
  if(typeof x=='string'||typeof y=='string'){const X=String(x),Y=String(y);return ters?Y.localeCompare(X,'tr'):X.localeCompare(Y,'tr');}
  return ters?y-x:x-y;});
 baslikYap();
 let h='';
 for(const r of L) h+=satir(r);
 $('tb').innerHTML=h;
 $('sayac').textContent=L.length+' maç';
 kuponGuncelle();
}
function yogunluk(){const k=$('tabloKap'); if(!k)return;
 k.classList.toggle('densSiki'); k.classList.toggle('densRahat');
 const b=$('densBtn'); if(b){const siki=k.classList.contains('densSiki'); b.textContent=siki?'🔎 Rahat görünüm':'🔍 Sıkı görünüm';}}
function araclarAc(){const d=$('aracKat'); if(d){d.open=true; d.scrollIntoView({block:'start'});} }
function modSec(m){mod=m; document.querySelectorAll('.modlar button').forEach(b=>b.classList.toggle('aktif',b.dataset.m===m)); ciz();}
function secim(i){ if(SEC.has(i))SEC.delete(i); else SEC.add(i); ciz(); }

/* --- kupon --- */
function kuponListe(){
 const L=[];
 for(const i of SEC){const r=D[i]; if(!r) continue;
  const side={'Ev':0,'Beraberlik':1,'Deplasman':2}[r.ad];
  const oran=r.o[side], isabet=(r.hist||0)/100;
  const kelly=(isabet*oran-1)/(oran-1);
  L.push({i,r,oran,isabet,kel:r.kelly||0,kelly});}
 return L;
}
function kuponGuncelle(){
 const bar=$('kuponBar'), L=kuponListe();
 if(!L.length){bar.style.display='none'; return;}
 let oran=1,isabet=1,kel=0;
 for(const x of L){oran*=x.oran; isabet*=x.isabet; kel+=x.kel;}
 const beklenti=isabet*oran;
 bar.style.display='flex';
 bar.innerHTML=`<span>🛒 <b>${L.length}</b> maç seçildi</span>
  <span>Toplam oran <b>${oran.toFixed(2)}</b></span>
  <span>Tarihsel isabet <b>%${(isabet*100).toFixed(1)}</b></span>
  <span>Beklenen dönüş <b>${beklenti.toFixed(2)}x</b> (${beklenti>1?'+':''}${((beklenti-1)*100).toFixed(0)}%)</span>
  <span class="mini">Kelly toplam %${kel.toFixed(1)}</span>
  <button onclick="kuponGoster()">Kuponu gör</button>
  <button onclick="kuponTemizle()">Temizle</button>`;
}
function kuponGoster(){
 const L=kuponListe();
 let h=`<div class="pbox" style="margin:10px 0"><b>🧾 KUPON DETAYI (${L.length} maç)</b>
 <table class="pt"><tr><th>Saat</th><th>Maç</th><th>Seçim</th><th>Oran</th><th>Tarihsel isabet</th><th>Kelly</th><th>Değer farkı</th></tr>`;
 let oran=1,isabet=1,txt='';
 for(const x of L){
  oran*=x.oran; isabet*=x.isabet;
  h+=`<tr><td>${esc(x.r.s)}</td><td>${esc(x.r.h)} - ${esc(x.r.a)}</td><td><b>${esc(x.r.ad)}</b></td><td>${x.oran.toFixed(2)}</td>
   <td>%${(x.isabet*100).toFixed(1)}</td><td>${x.kel}%</td><td>${x.r.edge>0?'+':''}${(x.r.edge||0).toFixed(1)}</td></tr>`;
  txt+=`${x.r.s} | ${x.r.h} - ${x.r.a} | ${x.r.ad} | ${x.oran.toFixed(2)} | tarihsel %${(x.isabet*100).toFixed(1)}\n`;}
 const beklenti=isabet*oran;
 h+=`</table><div style="margin-top:8px">Toplam oran <b>${oran.toFixed(2)}</b> · birleşik tarihsel isabet <b>%${(isabet*100).toFixed(2)}</b> ·
  beklenen dönüş <b>${beklenti.toFixed(2)}x</b> · ROI <b>${((beklenti-1)*100).toFixed(0)}%</b></div>
  <div class="mini" style="margin-top:6px">Not: bacaklar bağımsız kabul edilir; gerçek korelasyon daha yüksek/düşük olabilir.</div>`;
 txt+=`\nToplam oran: ${oran.toFixed(2)} | birleşik isabet: %${(isabet*100).toFixed(2)} | beklenen dönüş: ${beklenti.toFixed(2)}x`;
 h+=`<textarea style="width:100%;height:96px;margin-top:8px;background:var(--pn2);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:8px" onclick="this.select()">${esc(txt)}</textarea></div>`;
 let k=$('kuponPanel');
 if(!k){k=document.createElement('div'); k.id='kuponPanel'; ($('altAlan')||$('tabloUst')).appendChild(k);}
 k.innerHTML=h;
}
function enIyiKupon(){
 const L=D.filter(r=>r.sinyal&&r.not!==null&&!r.sonuc).sort((a,b)=>b.not-a.not).slice(0,3);
 if(!L.length){alert('Bugün için bekleyen sinyal yok.');return;}
 SEC.clear(); for(const r of L) SEC.add(r.__i);
 ciz(); kuponGoster();
}
function kuponTemizle(){SEC.clear(); $('kuponPanel')&&$('kuponPanel').remove(); ciz();}
function kuponKopyala(ta){ta.select(); try{document.execCommand('copy');}catch(e){}}

/* --- en iyi 5 --- */
function enIyiKartlari(){
 const L=D.filter(r=>r.sinyal&&r.not!==null).sort((a,b)=>b.not-a.not).slice(0,5);
 $('kartlar').innerHTML=L.map((r,n)=>`<div class="kart" onclick="git(${r.__i})">
  <div class="bas">#${n+1} · Öneri notu ${Math.round(r.not)} · ${esc(r.l)}</div>
  <div class="mac">${esc(r.h)} - ${esc(r.a)}</div>
  <div class="sat"><span>🎯 <b>${esc(r.ad)}</b> @ ${r.oran.toFixed(2)}</span><span>Tarihsel %${r.hist}</span><span class="git">Fark ${r.edge>0?'+':''}${r.edge.toFixed(1)}</span></div>
  <div class="mini" style="margin-top:4px">${r.n} maç · GA %${(r.ci||[0,0])[0].toFixed(0)}–${(r.ci||[0,0])[1].toFixed(0)} · ${esc(r.s)}</div></div>`).join('');
}
function git(i){
 $('q').value=''; $('flt').value='hepsi'; $('lig').value=''; $('minn').value=0;
 if($('iyonly'))$('iyonly').checked=false; if($('kupononly'))$('kupononly').checked=false;
 ciz();
 setTimeout(()=>{const tr=document.querySelector(`tr[data-i="${i}"]`);
  if(tr){tr.scrollIntoView({block:'center'}); det(tr,i); tr.classList.add('vurgu');}},60);
}
/* --- detay --- */
function nedenPanel(r){
 const t=r.det||{};
 let L=[['Aynı oranlı maç',r.n||'–']];
 if(r.tol!==null&&r.tol!==undefined)L.push(['Eşleşme toleransı','±'+r.tol]);
 if(r.ci)L.push(['%95 güven aralığı',r.ci[0].toFixed(0)+'–'+r.ci[1].toFixed(0)+'%']);
 if(r.roi!==undefined&&r.roi!==null)L.push(['ROI',(r.roi>0?'+':'')+r.roi.toFixed(0)+'%']);
 if(r.kelly!==undefined&&r.kelly!==null)L.push(['Kelly',r.kelly+'%']);
 if(r.not!==null&&r.not!==undefined)L.push(['Öneri notu',Math.round(r.not)+'/100']);
 if(r.bst)L.push(['Bootstrap %95',r.bst[0].toFixed(1)+'–'+r.bst[1].toFixed(1)+'%']);
 if(r.pdeger!==undefined)L.push(['Farkın şans olma olasılığı','%'+r.pdeger.toFixed(1)]);
 let h=`<div class="pbox" style="grid-column:1/-1;background:linear-gradient(90deg,#10322a,#16273a)">
  <b>🧠 NEDEN BU SİNYAL?</b><div style="margin-top:6px">${r.neden||''}</div>
  <table class="pt" style="margin-top:7px"><tr>${L.map(x=>`<th>${x[0]}</th>`).join('')}</tr>
  <tr>${L.map(x=>`<td>${x[1]}</td>`).join('')}</tr></table>`;
 if(r.uyari&&r.uyari.length)h+=`<div class="mini uyk" style="margin-top:6px">⚠ Dikkat: ${esc(r.uyari.join(' · '))}</div>`;
 if(r.bilgi&&r.bilgi.length)h+=`<div class="mini" style="margin-top:4px">ⓘ ${esc(r.bilgi.join(' · '))}</div>`;
 return h+'</div>';
}
function modelPanel(r){
 const p=r.poi; if(!p) return '';
 const d=r.det||{}, mk=d.ms||[0,0,0];
 let h=`<div class="pbox"><b>📈 POISSON MODELİ</b> <span class="mini">maçın gol beklentisi: ev ${d.ev_g} · dep ${d.dep_g}</span>
  <table class="pt"><tr><th>Kaynak</th><th>Ev</th><th>Beraberlik</th><th>Deplasman</th><th>2.5Ü</th><th>KG</th></tr>
  <tr><th>Tarihsel</th><td>%${(mk[0]||0).toFixed(0)}</td><td>%${(mk[1]||0).toFixed(0)}</td><td>%${(mk[2]||0).toFixed(0)}</td><td>${pc(d.u25)}</td><td>${pc(d.kg)}</td></tr>
  <tr><th>Poisson</th><td>%${p[0]}</td><td>%${p[1]}</td><td>%${p[2]}</td><td>%${p[3]}</td><td>%${p[4]}</td></tr></table>`;
 if(r.ad&&r.poi_fark!==undefined){const mi={'Ev':0,'Beraberlik':1,'Deplasman':2}[r.ad];
  h+=`<div class="mini" style="margin-top:6px">Model <b>${esc(r.ad)}</b> için %${p[mi]} veriyor; piyasa %${r.piy} →
   <b class="${r.poi_fark>0?'git':'kit'}">${r.poi_fark>0?'+':''}${r.poi_fark} puan</b></div>`;}
 return h+'</div>';
}
function canliPanel(r){
 const c=r.canli||{}; if(c.durum!=='canlı') return '';
 const t=r.det||{}; if(!t.ort) return '';
 const p=c.ms?c.ms.split(':').map(Number):[0,0];
 const dk=c.dk?+c.dk:55, kal=Math.max(1,90-dk);
 const lam=t.ort*kal/90, pa=(t.ev_g||0)/(t.ort||1), pb=1-pa;
 const N=7,f=[1],g=[1];
 for(let i=1;i<N;i++){f.push(f[i-1]*lam*pa/i);g.push(g[i-1]*lam*pb/i);}
 let ev=0,be=0,de=0;
 for(let i=0;i<N;i++)for(let j=0;j<N;j++){const p2=f[i]*g[j];
  const H=p[0]+i,A=p[1]+j; if(H>A)ev+=p2;else if(H===A)be+=p2;else de+=p2;}
 const T=ev+be+de; ev=100*ev/T;be=100*be/T;de=100*de/T;
 const ad={'Ev':ev,'Beraberlik':be,'Deplasman':de}[r.ad];
 let h=`<div class="pbox" style="grid-column:1/-1;background:linear-gradient(90deg,#3a1414,#16273a)"><b style="font-size:15px">🔴 CANLI MOTOR (bet365 tarzı)</b>
  <span class="mini">skor ${c.ms}${c.iy?` (İY ${c.iy})`:''} · varsayılan ${dk}. dk · kalan ${kal} dk · kalan gol beklentisi ${lam.toFixed(2)}</span>
  <div style="display:flex;gap:22px;flex-wrap:wrap;margin-top:8px">
   <div><div class="mini">Şu andan itibaren sonuç şansı</div><b style="font-size:15px">Ev %${ev.toFixed(0)} · Ber %${be.toFixed(0)} · Dep %${de.toFixed(0)}</b></div>`;
 if(r.ad) h+=`<div><div class="mini">${r.ad} (öne çıkan taraf)</div><b style="font-size:17px" class="${ad>=50?'git':'kit'}">%${ad.toFixed(1)}</b>
   <div class="mini">tahmini canlı oran: <b>${ad>0?((100/ad)*1.064).toFixed(2):'–'}</b></div></div>`;
 h+=`<div><div class="mini">Kalan sürede gol olasılığı</div><b style="font-size:15px">%${(100*(1-Math.exp(-lam))).toFixed(0)}</b></div>
  <div><div class="mini">Açılış oranı → canlı değer</div><b style="font-size:15px">${r.oran?r.oran.toFixed(2):'–'}</b>
   <div class="mini">${(r.oran&&ad>0)?(((r.oran*ad/100)-1)*100).toFixed(0)+'%':'–'}</div></div>`;
 return h+'</div><div class="mini" style="margin-top:6px">Model: mevcut skor sabitken kalan sürede Poisson gol dağılımı.</div></div>';
}
function formPanel(r){
 const f=r.form; if(!f) return '';
 const sayi=v=>{const n=Number(v); return Number.isFinite(n)?n.toFixed(2):'–';};
 const toplam=x=>x?(x.top!==undefined?x.top:Number(x.at||0)+Number(x.ye||0)):null;
 const blok=(ad,x)=>{ if(!x) return `<div class="mini">${ad}: arşivde son maç bulunamadı</div>`;
  return `<div style="margin-bottom:8px"><b>${ad}${x.ev?' (ev)':''}</b> <span class="mini">son ${x.n} maç</span>
   <div>${x.seri.split('').map(s=>`<span class="pill" style="background:${s=='G'?'#3fb95033':(s=='B'?'#8b949e33':'#f8514922')}">${s}</span>`).join('')}
    <span class="mini">· ${x.g}G ${x.b}B ${x.m}M · attığı <b>${sayi(x.at)}</b> · yediği <b>${sayi(x.ye)}</b> · toplam gol ort. <b>${sayi(toplam(x))}</b> · KG %${x.kg} · 2.5Ü %${x.u25}</span></div>
   <table class="pt"><tr><th>Tarih</th><th>Rakip</th><th>Yer</th><th>Sonuç</th></tr>
   ${x.maclar.map(m=>`<tr><td>${m.d}</td><td>${esc(m.r)}</td><td>${m.ev?'Ev':'Dep'}</td><td><b>${m.sk}</b> ${m.s}</td></tr>`).join('')}</table></div>`;};
 return `<div class="pbox"><b>📊 TAKIMLARIN GOL ORTALAMASI</b> <span class="mini">son form maçları · maç başına</span>
  <div class="golOzet">${f.h?`<span class="golKart"><b>${esc(r.h)}</b> <strong>${sayi(f.h.at)}</strong><span class="mini">attı</span> / <strong>${sayi(f.h.ye)}</strong><span class="mini">yedi</span></span>`:''}${f.a?`<span class="golKart"><b>${esc(r.a)}</b> <strong>${sayi(f.a.at)}</strong><span class="mini">attı</span> / <strong>${sayi(f.a.ye)}</strong><span class="mini">yedi</span></span>`:''}</div>
  <div class="mini" style="margin-bottom:8px">Attı / yedi değerleri takımın son ${Math.max(f.h&&f.h.n||0,f.a&&f.a.n||0)} maçındaki maç başına ortalamadır; toplam gol ortalaması detayda gösterilir.</div>
  ${blok(esc(r.h),f.h)}${blok(esc(r.a),f.a)}</div>`;
}
function skorVurguPanel(r){
 const t=r.det||{}; const sp=t.skor_pct||[]; const si=t.skor_iy_pct||[];
 if(!sp.length&&!si.length) return '';
 const bar=(x,ad)=>{const w=Math.max(4,Math.min(100,x[1]*3.4));
  return `<div style="display:flex;align-items:center;gap:8px;margin:3px 0">
   <span style="width:74px;font-weight:800;font-size:15px;text-align:right">${x[0]}</span>
   <span style="flex:1;background:var(--pn2);border-radius:6px;height:16px;position:relative">
     <span style="position:absolute;left:0;top:0;bottom:0;width:${w}%;background:linear-gradient(90deg,#2ea043,#3fb950);border-radius:6px"></span></span>
   <b style="width:58px;text-align:right;font-size:13px">%${x[1].toFixed(1)}</b></div>`;};
 return `<div class="pbox" style="grid-column:1/-1"><b style="font-size:15px">🎯 EN SIK SKORLAR</b>
  <span class="mini">bu oranla oynanan ${r.n||t.n||''} maçtan en sık çıkan sonuçlar</span>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:8px">
   <div><b>Maç sonucu</b>${sp.slice(0,6).map(x=>bar(x)).join('')}
     <div class="mini" style="margin-top:4px">İlk 3 skor maçların <b>%${sp.slice(0,3).reduce((a,b)=>a+b[1],0).toFixed(1)}</b>'inde geldi.</div></div>
   <div><b>İlk yarı</b>${si.slice(0,6).map(x=>bar(x)).join('')||'<div class="mini">İY verisi yok</div>'}</div>
  </div></div>`;
}
function katSec(btn,k){
 const root=btn.closest?btn.closest('.pbox'):null; if(!root) return;
 root.querySelectorAll('tr[data-kat]').forEach(tr=>{tr.style.display=(k==='hepsi'||tr.getAttribute('data-kat')===k)?'':'none';});
 root.querySelectorAll('.katBar button').forEach(b=>b.classList.remove('aktif'));
 btn.classList.add('aktif');
}
function tumPanel(r){
 const P=r.paz; if(!P||!P.length) return '';
 let kat='', h=`<div class="pbox" style="grid-column:1/-1"><b style="font-size:15px">🧾 TÜM OLASILIKLAR — TEK BAKIŞTA</b>
  <span class="mini">${r.n||0} aynı oranlı maçtan çıkan gerçek yüzdeler · adil oran = 100/% · model = Poisson tahmini</span>
  <div class="katBar">${[...new Set(P.map(x=>x[0]))].map((k,i)=>`<button class="${i===0?'aktif':''}" onclick="katSec(this,'${k}')">${k}</button>`).join('')}
   <button onclick="katSec(this,'hepsi')">Hepsi</button></div>
  <table class="pt" style="margin-top:8px;font-size:12.5px"><tr><th style="width:170px">Market</th><th style="width:70px">Tarihsel</th>
  <th style="width:76px" title="Bayesçi küçültme: küçük örneklem, tüm-veri ortalamasına çekilir">Düzeltilmiş</th>
  <th style="width:62px">Adil</th><th style="width:70px" title="Dixon-Coles düzeltmeli Poisson">Model</th>
  <th style="width:78px" title="%55 düzeltilmiş tarihsel + %45 model">Konsensüs</th><th style="width:72px">Fark</th><th>Dağılım</th></tr>`;
 for(const x of P){
  const [k,ad,p,adil,m,pa,ko]=x;
  if(k!==kat){kat=k; h+=`<tr data-kat="${k}" ${(k===P[0][0])?'':'style="display:none"'}><th colspan="9" style="text-align:left">${k}</th></tr>`;}
  const fark=(ko===null||ko===undefined)?null:(ko-p);
  const farkC=fark===null?'mini':(Math.abs(fark)>=8?'uyk':'mini');
  const farkT=fark===null?'–':((fark>0?'+':'')+fark.toFixed(1));
  const gen=(ko||p)>=55?'git':((ko||p)<=30?'kit':'');
  const w=Math.max(3,Math.min(100,ko||p));
  const adilK=ko? (100/ko).toFixed(2) : (adil||'–');
  const ilk=(k===P[0][0])?'':'style="display:none"';
  h+=`<tr data-kat="${k}" ${ilk}><td style="text-align:left">${ad}</td><td class="od">%${p.toFixed(1)}</td>
   <td class="od ${(pa&&Math.abs(pa-p)>=4)?'uyk':''}">${pa?('%'+pa.toFixed(1)):'–'}</td>
   <td class="od">${adilK}</td><td class="od">${(m===undefined||m===null)?'–':('%'+m.toFixed(1))}</td>
   <td class="od"><b class="${gen}">%${ko?ko.toFixed(1):'–'}</b></td>
   <td class="od ${farkC}">${farkT}</td>
   <td><span style="display:inline-block;background:var(--pn2);border-radius:4px;height:12px;width:100%;position:relative">
     <span style="position:absolute;left:0;top:0;bottom:0;width:${w}%;background:${w>=55?'#3fb950':(w<=30?'#f85149':'#58a6ff')};border-radius:4px"></span></span></td></tr>`;
 }
 h+=`</table><div class="mini" style="margin-top:6px">Düzeltilmiş = Bayesçi küçültme (küçük örneklemde tüm-veri ortalamasına çekilir, 4 puandan fazla oynarsa sarı). Model = Dixon-Coles düzeltmeli Poisson. <b>Konsensüs</b> = %55 düzeltilmiş tarihsel + %45 model; <b>Adil</b> sütunu konsensüsten hesaplanır. Fark = konsensüs − tarihsel.</div></div>`;
 return h;
}
function ligPanel(r){
 const L=r.lig_cmp; if(!L||!L.n) return '';
 const ligAd=(L.lig||'').split('/').filter(Boolean).slice(1).join(' / ');
 const sk=(L.skor||[]).map(x=>`<span class="skorCip">${x[0]} %${x[1].toFixed(0)}</span>`).join('');
 let h=`<div class="pbox" style="grid-column:1/-1"><b>🏟️ AYNI LİGDE AYNI ORAN</b>
  <span class="mini">${esc(ligAd)} · bu oranla oynanan <b>${L.n}</b> maç (lig-içi kontrol grubu)</span>
  <div style="display:flex;gap:22px;flex-wrap:wrap;margin-top:8px">
   <div><div class="mini">Maç sonucu Ev / Ber / Dep</div><b style="font-size:15px">%${L.ms[0]} / %${L.ms[1]} / %${L.ms[2]}</b></div>
   <div><div class="mini">Ort. gol</div><b style="font-size:15px">${L.ort}</b></div>
   <div><div class="mini">2.5 Üst</div><b style="font-size:15px">%${L.u25}</b></div>
   <div><div class="mini">KG</div><b style="font-size:15px">%${L.kg}</b></div>`;
 if(L.iy) h+=`<div><div class="mini">İY (${L.iy.n} maç)</div><b style="font-size:15px">0-0 %${L.iy['00']} · 1.5Ü %${L.iy.u15} · KG %${L.iy.kg}</b></div>`;
 h+=`</div><div style="margin-top:8px"><span class="mini">En sık skorlar:</span> ${sk}</div>`;
 const oo=L.ornek||[];
 if(oo.length){
  h+=`<div style="margin-top:12px"><b>Bu oranla aynı ligde oynanan maçlar</b>
   <span class="mini">${L.n} maç${oo.length<L.n?` (ilk ${oo.length} tanesi)`:''} · en yeni → en eski · kaydırarak hepsini gör</span>
   <div class="tblSar"><table class="pt" style="margin-top:5px"><thead><tr><th>Tarih</th><th>Ev</th><th>Deplasman</th><th>MS</th><th>İY</th><th>Oran 1/X/2</th><th>Sonuç</th></tr></thead><tbody>`+
   oo.map(c=>{const p=c.sk.split('-').map(Number);
    const son=p[0]>p[1]?'1':(p[0]==p[1]?'X':'2');
    const cls=son==='1'?'s1':(son==='X'?'sx':'s2');
    return `<tr><td>${c.d}</td><td>${esc(c.h)}</td><td>${esc(c.a)}</td><td class="od"><b>${c.sk}</b></td>
     <td class="od">${c.iy||'–'}</td><td class="od mini">${c.o[0].toFixed(2)}/${c.o[1].toFixed(2)}/${c.o[2].toFixed(2)}</td>
     <td class="od"><span class="sk ${cls}">${son}</span></td></tr>`;}).join('')+`</tbody></table></div></div>`;
 }
 h+=`<div class="mini" style="margin-top:6px">Tolerans ±${L.tol_l} · karşılaştırma sadece bu ligde oynanan maçlarla yapıldı (lig etkisi izole edilir).</div>`;
 const U=r.ulke_cmp;
 if(U&&U.n&&!(L&&L.n)){h+=`<div class="mini" style="margin-top:6px">Bu ligde aynı oranlı maç bulunamadı, yukarıdaki liste ÜLKE GENELİNDEN (tüm ligler) geliyor.</div>`;}
 else if(U&&U.n){h+=`<div style="margin-top:8px;border-top:1px solid var(--line);padding-top:8px">
  <b class="mini">ÜLKE GENELİ (tüm ligler) aynı oran:</b> ${U.n} maç · Ev %${U.ms[0]} / Ber %${U.ms[1]} / Dep %${U.ms[2]} · ort ${U.ort} gol · 2.5Ü %${U.u25} · KG %${U.kg}</div>`;}
 return h+'</div>';
}
function uzmanPanel(r){
 const t=r.det||{}, tr=t.trend||{}, P=r.paz||[];
 let h=`<div class="pbox" style="grid-column:1/-1;background:linear-gradient(90deg,#1a1030,#16273a)"><b style="font-size:15px">🧠 UZMAN MOTORU</b>
  <span class="mini">öngörülebilirlik · trend · model düzeltmesi · güvenli market seçimi</span>
  <div style="display:flex;gap:20px;flex-wrap:wrap;margin-top:8px">`;
 const kutu=(b,d2,m)=>`<div style="min-width:130px"><div class="mini">${b}</div><div style="font-size:16px;font-weight:800">${d2}</div>
  <div class="mini">${m||''}</div></div>`;
 if(t.ongorulebilirlik!==undefined){
  const o=t.ongorulebilirlik, renk=o>=45?'#3fb950':(o>=30?'#f0b429':'#f85149');
  h+=kutu('Öngörülebilirlik', `<span style="color:${renk}">%${o}</span>`, o>=45?'yüksek (kalıp belirgin)':(o>=30?'orta':'düşük (kaotik grup)'));
  h+=kutu('Favori kaybetme riski', `%${t.favori_kaybeder}`, `favori: <b>${t.favori}</b> (%${t.favori_p})`);
 }
 if(t.rho!==undefined) h+=kutu('Dixon-Coles ρ', t.rho.toFixed(2), Math.abs(t.rho)>=0.05?'düşük skor bağımlılığı var':'bağımsıza yakın');
 if(tr.u25_delta!==undefined) h+=kutu('2.5Ü trendi (2 yıl)', `${tr.u25_delta>0?'+':''}${tr.u25_delta} puan`,
   `yeni %${tr.u25_yeni} ← eski %${tr.u25_eski} · <b>${tr.yon}</b>`);
 if(tr.ht00_delta!==undefined) h+=kutu('İY 0-0 trendi', `${tr.ht00_delta>0?'+':''}${tr.ht00_delta} puan`, `yeni %${tr.ht00_yeni} ← eski %${tr.ht00_eski}`);
 h+='</div>';
 const GUVEN=['0.5 Üst','1.5 Üst','2.5 Alt','İY 0.5 Üst','KG Var','1X','X2','İY 0-0','İY 1.5 Alt'];
 const guv=P.filter(x=>GUVEN.includes(x[1])&&x[6]>=60).sort((a,b)=>b[6]-a[6]).slice(0,6);
 if(guv.length) h+=`<div style="margin-top:10px"><b class="mini">💚 GRUBUN EN GÜVENLİ MARKETLERİ (konsensüs ≥ %60)</b><br>`+
  guv.map(x=>`<span class="pill" style="border-color:#3fb95088"><b>${x[1]}</b> %${x[6].toFixed(1)} <span class="mini">adil ${x[6]?(100/x[6]).toFixed(2):'–'}</span></span>`).join('')+'</div>';
 const risk=P.filter(x=>x[2]>=25&&x[2]<=40).sort((a,b)=>Math.abs(b[6]-b[2])-Math.abs(a[6]-a[2])).slice(0,4);
 if(risk.length) h+=`<div style="margin-top:6px"><b class="mini">⚠️ MODELİN TARİHSELDEN AYRIŞTIĞI MARKETLER</b><br>`+
  risk.map(x=>`<span class="pill" style="border-color:#f0b42988">${x[1]} tarihsel %${x[2]} · model %${x[4]!==null?x[4].toFixed(1):'–'} · konsensüs %${x[6].toFixed(1)}</span>`).join('')+'</div>';
 return h+'</div>';
}
function ozetPanel(r){
 const t=r.det||{}, c=r.canli||{};
 const ms=t.ms||[0,0,0], sp=t.skor_pct||[], si=t.skor_iy_pct||[];
 const en=Math.max(...ms), idx=ms.indexOf(en);
 const adlar=['EV','BERABERLİK','DEPLASMAN'];
 const adil=(t.adil||{});
 const kutu=(b,d2)=>`<div style="min-width:118px"><div class="mini">${b}</div><div style="font-size:17px;font-weight:800">${d2}</div></div>`;
 let h=`<div class="pbox" style="grid-column:1/-1;background:linear-gradient(90deg,#12283a,#1b2a3f)">
  <b style="font-size:15px">⚡ TEK BAKIŞTA</b><div style="display:flex;gap:20px;flex-wrap:wrap;margin-top:8px">`;
 h+=kutu('En olası sonuç', ms.length?`${adlar[idx]} %${en.toFixed(1)} <span class="mini">(adil ${adil[['1','X','2'][idx]]||'–'})</span>`:'–');
 h+=kutu('En olası skor', sp.length?`<span class="skorCip one">${sp[0][0]}</span> %${sp[0][1].toFixed(1)}`:'–');
 h+=kutu('En olası İY skor', si.length?`<span class="skorCip">${si[0][0]}</span> %${si[0][1].toFixed(0)}`:'–');
 h+=kutu('Gol beklentisi', t.ort!==undefined?`${t.ort} <span class="mini">gol</span>`:'–');
 h+=kutu('2.5 Üst', t.u25!==undefined?`%${t.u25} <span class="mini">(adil ${adil.u25||'–'})</span>`:'–');
 h+=kutu('KG', t.kg!==undefined?`%${t.kg} <span class="mini">(adil ${adil.kg||'–'})</span>`:'–');
 if(c.ms) h+=kutu('Bugünkü skor', `${c.ms}${c.iy?` <span class="mini">İY ${c.iy}</span>`:''}${r.sonuc?` · ${r.sonuc=='KAZANDI'?'✅':'❌'}`:''}`);
 h+='</div>';
 if(sp.length>1){const ilk3=(sp.slice(0,3).reduce((a,b)=>a+b[1],0)); h+=`<div class="mini" style="margin-top:7px">En olası 3 skor maçların <b>%${ilk3.toFixed(1)}</b>'inde; ${sp[0][0]} en sık, ${sp.length>1?sp[1][0]:''} ikinci.</div>`;}
 return h+'</div>';
}
function skorIzgaraPanel(r){
 const g=(r.det||{}).grid; if(!g) return '';
 const bos='&nbsp;';
 let enb=0; g.forEach(row=>row.forEach(v=>{if(v>enb)enb=v;}));
 let h=`<div class="pbox"><b>🧮 TAM SKOR IZGARASI</b> <span class="mini">satır = ev golü, kolon = deplasman golü (5+ dahil). Kutu içi: maçların yüzdesi · üstüne gel → adil oran</span>
  <table class="pt" style="font-size:12px"><tr><th>Ev ↓ / Dep →</th>`;
 for(let j=0;j<6;j++) h+=`<th>${j===5?'5+':j}</th>`;
 h+='<th>Toplam</th></tr>';
 for(let i=0;i<6;i++){
  const top=g[i].reduce((a,b)=>a+b,0);
  h+=`<tr><th>${i===5?'5+':i}</th>`;
  for(let j=0;j<6;j++){const v=g[i][j]; const a=v>0?(100/v).toFixed(2):'–';
   const alfa=enb?Math.min(0.85,v/enb):0;
   h+=`<td style="background:rgba(63,185,80,${alfa.toFixed(2)})" title="${i}-${j}: maçların %${v} · adil oran ${a}">${v?v.toFixed(1):'·'}</td>`;}
  h+=`<td class="mini">${top.toFixed(1)}</td></tr>`;}
 h+='</table><div class="mini" style="margin-top:5px">Koyu yeşil = en sık skorlar. Örnek: bir kutu %8 ise o skorun adil oranı 12.50 olur.</div></div>';
 return h;
}
function kosulPanel(r){
 const k=(r.det||{}).kosul; if(!k||!k.length) return '';
 let h=`<div class="pbox"><b>🔄 İLK YARI SKORUNA GÖRE MAÇ NASIL BİTİYOR?</b> <span class="mini">koşullu dağılım</span><table class="pt">
  <tr><th>İY skoru</th><th>Maç</th><th>Ev</th><th>Ber</th><th>Dep</th><th>En sık MS</th><th>Ort. gol</th></tr>`;
 for(const x of k){
  const b=(v)=>`<div style="background:var(--pn2);border-radius:4px;height:14px;position:relative;min-width:52px">
    <div style="position:absolute;left:0;top:0;bottom:0;width:${Math.min(100,v*2)}%;background:${v>=50?'#3fb950':(v>=30?'#f0b429':'#58a6ff')};border-radius:4px"></div>
    <span style="position:relative;font-size:11px;font-weight:700">%${v.toFixed(0)}</span></div>`;
  h+=`<tr><td><b>${x.iy}</b></td><td>${x.n}</td><td>${b(x.ms[0])}</td><td>${b(x.ms[1])}</td><td>${b(x.ms[2])}</td>
   <td>${x.top.map(t=>`<span class="skorCip">${t[0]} %${t[1]}</span>`).join('')}</td><td>${x.ort}</td></tr>`;}
 h+='</table><div class="mini" style="margin-top:5px">Örnek okuma: "İY 0:0 satırı, %X ev kazanır" → 0-0 devreye girerse maçın ev galibiyetiyle bitme şansı.</div></div>';
 return h;
}
function trendPanel(r){
 const t=r.det||{}; const w=t.w_skor||[]; const sp=t.skor_pct||[]; const ss=t.sonuc_skor||{};
 if(!w.length&&!sp.length) return '';
 const bar=(x,maks)=>`<div style="display:flex;align-items:center;gap:6px"><span class="skorCip">${x[0]}</span>
  <span style="flex:1;background:var(--pn2);height:10px;border-radius:5px;position:relative"><span style="position:absolute;left:0;top:0;bottom:0;width:${(x[1]/maks*100).toFixed(0)}%;background:#58a6ff;border-radius:5px"></span></span>
  <span class="mini">%${x[1].toFixed(1)}</span></div>`;
 const wm=Math.max(...w.map(x=>x[1]),1), sm=Math.max(...sp.map(x=>x[1]),1);
 let h=`<div class="pbox"><b>📈 SKOR TRENDİ VE SONUÇ-PROFİLİ</b>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:6px">
   <div><b class="mini">SON 3 YIL AĞIRLIKLI (yakın maçlar önemli)</b>${w.map(x=>bar(x,wm)).join('')||'<div class="mini">–</div>'}</div>
   <div><b class="mini">TÜM DÖNEM</b>${sp.slice(0,5).map(x=>bar(x,sm)).join('')}</div>
  </div>`;
 const grup=(ad,L)=>`<div><b>${ad} gelirse</b><br>${(L||[]).map(x=>`<span class="skorCip">${x[0]} %${x[1].toFixed(1)}</span>`).join('')||'<span class="mini">–</span>'}</div>`;
 if(ss.Ev) h+=`<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:10px;font-size:12.5px">
  ${grup('Ev kazanırsa',ss.Ev)}${grup('Berabere biterse',ss.Ber)}${grup('Deplasman kazanırsa',ss.Dep)}</div>`;
 if(r.poi_skor&&r.poi_skor.length) h+=`<div style="margin-top:10px"><b class="mini">MODEL (Poisson) EN OLASI SKORLAR</b><br>`+
  r.poi_skor.map(x=>`<span class="skorCip two" title="adil oran ${x[2]}">${x[0]} %${x[1]}</span>`).join('')+'</div>';
 return h+'</div>';
}
function macListesiPanel(r){
 const o=r.ornek; if(!o||!o.length) return '';
 const L=[...o].reverse();
 let kaz=0;
 let satir=L.map(c=>{const p=c.sk.split(':').map(Number);
  const son=p[0]>p[1]?'1':(p[0]==p[1]?'X':'2');
  const tut={'Ev':p[0]>p[1],'Beraberlik':p[0]==p[1],'Deplasman':p[0]<p[1]}[r.ad];
  if(tut) kaz++;
  return `<tr><td>${c.d}</td><td>${esc(c.h)}</td><td>${esc(c.a)}</td>
   <td class="od"><b>${c.sk}</b></td><td class="od">${c.iy||'–'}</td>
   <td class="od mini">${c.o[0].toFixed(2)}/${c.o[1].toFixed(2)}/${c.o[2].toFixed(2)}</td>
   <td class="od"><span class="sk ${son=='1'?'s1':(son=='X'?'sx':'s2')}">${son}</span></td>
   <td class="od">${tut&&r.ad?'✅':'·'}</td></tr>`;}).join('');
 return `<div class="pbox" style="grid-column:1/-1"><b>📋 BU ORANLA OYNANAN MAÇLAR VE SONUÇLARI</b>
  <span class="mini">son ${o.length} maç · toplam ${r.n} · tolerans ±${r.tol}${r.ad?` · öne çıkan <b>${esc(r.ad)}</b> bu ${L.length} maçın <b>${kaz}</b> tanesinde geldi`:''}</span>
  <table class="pt"><tr><th>Tarih</th><th>Ev</th><th>Deplasman</th><th>MS</th><th>İY</th><th>Oran 1/X/2</th><th>Sonuç</th><th>Öne çıkan?</th></tr>
  ${satir}</table></div>`;
}
function kapanisKiyasPanel(r){
 const K=r.kk;
 if(!K) return '<div class="pbox mini">Bu maç için kapanış oranı henüz yok. Kapanış oranı, maç başlamadan önceki son fiyattır; takipçi (takip.py) maç başlarken otomatik yakalar. Oran alanındaki “son fiyat” ile de kıyas yapılır.</div>';
 const blok=(L,bas,ek)=>L? `<div style="border-top:1px solid var(--line);margin-top:8px;padding-top:8px">
   <b>${bas}</b> <span class="mini">${ek||''} · ${L.n} maç · MS Ev %${L.ms[0]} / Ber %${L.ms[1]} / Dep %${L.ms[2]} · ort ${L.ort} gol · 2.5Ü %${L.u25} · KG %${L.kg}</span>
   <div style="margin-top:4px">${(L.skor||[]).map(x=>`<span class="skorCip">${x[0]} <b>%${x[1]}</b></span>`).join(' ')}</div>
   ${L.iy?`<div class="mini" style="margin-top:5px;border-top:1px dashed var(--line);padding-top:5px">
     <b>İLK YARI</b> — ${L.iy.n} maçta İY verisi (kapsam %${L.iy.kaps}): İY sonuç <b>Ev %${L.iy.ms[0]} / Ber %${L.iy.ms[1]} / Dep %${L.iy.ms[2]}</b> ·
     İY 0-0 <b>%${L.iy.s00}</b> · İY 1.5 ÜST <b>%${L.iy.s15}</b> · İY KG <b>%${L.iy.kg}</b> · ort <b>${L.iy.ort}</b> gol ·
     İY=MS yönü <b>%${L.iy.ayni}</b>
     <div style="margin-top:3px">${(L.iy.skor||[]).map(x=>`<span class="skorCip">İY ${x[0]} <b>%${x[1]}</b></span>`).join(' ')}</div></div>`:''}</div>`:'';
 const orn=(K.ornek||[]).map(z=>`<tr><td class="mini">${esc(z[0])}</td><td>${esc(z[1])} - ${esc(z[2])}</td><td><b>${esc(z[3])}</b></td><td>${z[5]?`<b>${esc(z[5])}</b>`:'<span class="mini">–</span>'}</td><td class="mini">${z[4].join('/')}</td></tr>`).join('');
 return `<div class="pbox"><b>📉 KAPANIŞ ORANI KIYASI</b>
  <div class="mini">Kullanılan oran: <b>${K.o.join(' / ')}</b> · <b>${esc(K.kyn)}</b> · tolerans: kendi ligi ±%${K.tolg} · tüm ligler ±%${K.tol}</div>
  ${blok(K.k, 'KENDİ LİGİ — '+(K.ln||''), K.lu||'')}
  ${blok(K.t, 'TÜM LİGLER (ülke/lig fark etmez)', '')}
  ${orn? `<div class="mini" style="margin-top:8px"><b>Aynı kapanış oranıyla biten son maçlar</b> (kaynak: ${K.ok=='lig'?'kendi ligi':'tüm ligler'})</div>
   <table style="margin-top:4px"><thead><tr><th>Tarih</th><th>Maç</th><th>MS</th><th>İY</th><th>Kapanış</th></tr></thead><tbody>${orn}</tbody></table>`:''}
 </div>`;}
function hareketPanel(r){
 if(!r.ha) return '';
 const L=['Ev (1)','X','Dep (2)'], s=r.ha_simdi||[], ac=r.o||[];
 let ic='';
 for(let i=0;i<3;i++){const v=r.ha[i], d=v<0;
  ic+=`<div class="hkKart"><b>${L[i]}</b><div class="mini">açılış ${ac[i]?ac[i].toFixed(2):'–'} → şimdi ${s[i]?s[i].toFixed(2):'–'}</div>
   <span class="${Math.abs(v)>=1?(d?'git':'kit'):'mini'}">${d?'↓':'↑'} ${v>0?'+':''}${v.toFixed(1)}%</span></div>`;}
 const yon=r.ha_yon, bk=r.ha_buyuk;
 const yorum=(Math.abs(bk)<1)?'Belirgin hareket yok — oranlar açılışta kalmış.'
  :(bk<0?`Piyasa <b>${yon}</b> tarafına para koyuyor (oran düştü). Bu taraf piyasanın en güvendiği taraf.`
       :`<b>${yon}</b> tarafından para çıkıyor (oran yükseldi) — piyasa o taraftan uzaklaşıyor.`);
 return `<div class="pbox"><b>🔀 ORAN HAREKETİ (açılış → şimdi)</b>
  <div class="hkSat">${ic}</div>
  <div class="mini" style="margin-top:6px">${yorum}</div>
  ${r.ha_iyi?`<div class="mini">Şu an en iyi oranlar: <b>${r.ha_iyi.join(' / ')}</b></div>`:''}</div>`;}
/* ---------------- ANLAŞILIR ANALİZ PANELİ ---------------- */
function b3(ms, et){
 if(!ms) return '';
 const en=Math.max(...ms), K=['Ev','Beraberlik','Deplasman'], S=['one','two','uc'];
 return '<div class="b3">'+ms.map((v,i)=>`<div class="b3i ${S[i]}" title="${K[i]}: %${v}">
   <i></i><b>${(et||K)[i]}</b><br>%${v.toFixed(0)}${v===en?' ⭐':''}</div>`).join('')+'</div>';
}
function cipler(L,onek,en){
 if(!L||!L.length) return '<span class="mini">veri yok</span>';
 return L.slice(0,en||6).map(x=>`<span class="skorCip">${onek||''}${x[0]} <b>%${x[1]}</b></span>`).join(' ');
}
function mK(L){
 return '<div class="miniK">'+L.filter(x=>x[1]!==null&&x[1]!==undefined&&x[1]!=='').map(x=>`<span>${x[0]}</span><b>${x[1]}</b>`).join('')+'</div>';
}
function blok(bas,rozet,ic,genis){
 return `<div class="anaBlok${genis?' genis':''}"><div class="anaBas">${bas}${rozet?`<span class="rozet">${rozet}</span>`:''}</div><div class="anaIc">${ic}</div></div>`;
}
function ornekTab(L, bas, not_){
 if(!L||!L.length) return '';
 const r=L.map(z=>`<tr><td class="mini" style="white-space:nowrap">${esc(z[0])}</td><td>${esc(z[1])} - ${esc(z[2])}</td>
   <td class="b">${esc(z[3])}</td><td class="b">${z[5]?esc(z[5]):'<span class="mini">–</span>'}</td>
   <td class="mini" style="white-space:nowrap">${esc(z[4])}</td>${z[6]!==undefined?`<td class="mini">${esc(z[6]||'')}</td>`:''}</tr>`).join('');
 return `<div class="skorKut"><div class="b">${bas||'MAÇLAR'} <span class="mini">${not_||''}</span></div>
  <div class="tblSar"><table><thead><tr><th>Tarih</th><th>Maç</th><th>MS</th><th>İY</th><th>Oran</th>${L[0]&&L[0][6]!==undefined?'<th>Lig</th>':''}</tr></thead><tbody>${r}</tbody></table></div></div>`;
}

function analizPanel(r){
 const t=r.det||{}, K=r.kk||{}, c=r.canli||{}, o=r.o||[0,0,0];
 const S=[];
 /* --- 1) MAÇ KÜNYESİ --- */
 S.push(blok('⚡ MAÇ', esc(r.l||''), mK([
   ['Saat', esc(r.s||'')],
   ['Durum', c.durum==='canlı'?('🔴 canlı'+(c.ms?' '+c.ms:'')):(r.sonuc?r.sonuc:(r.basladi?'🔴 canlı':'🟢 yaklaşan'))],
   ['Açılış oranı 1/X/2', o.map(x=>x.toFixed(2)).join(' / ')],
   ['Son oran', (r.ha_simdi&&r.ha_simdi.length)?r.ha_simdi.map(x=>x.toFixed(2)).join(' / '):'–'],
   ['Hareket', r.ha?['Ev','X','Dep'].map((x,i)=>x+' '+(r.ha[i]>0?'+':'')+r.ha[i]+'%').join(' · '):'–'],
   ['Öne çıkan', r.ad?`${esc(r.ad)} @ ${(r.oran||0).toFixed(2)}`:'–'],
   ['Değer farkı', (r.edge!==undefined&&r.edge!==null)?((r.edge>0?'+':'')+r.edge.toFixed(1)+' puan'):'–'],
   ['Öneri notu', (r.not!==null&&r.not!==undefined)?Math.round(r.not)+'/100':'–']])));
 /* --- 2) AÇILIŞ ORANIYLA BENZER MAÇLAR --- */
 if(t.ms){
  S.push(blok('📊 AÇILIŞ ORANIYLA BENZER MAÇLAR',
   (r.n?r.n+' maç':'–')+(r.tol!==null&&r.tol!==undefined?` · ±${r.tol}`:''),
   b3(t.ms)+
   `<div class="skorKut"><div class="b">MAÇ SONU EN SIK SKORLAR</div><div style="margin-top:3px">${cipler(t.skor_pct,'')}</div></div>`+
   `<div class="skorKut"><div class="b">İLK YARI (İY) SONUÇLARI ${t.htn?`· ${t.htn} maç`:''}</div>`+
   (t.ht00!==undefined?b3([t.iy1||0,t.iyx||0,t.iy2||0],['İY 1','İY X','İY 2'])+
     mK([['İY 0-0 %',t.ht00],['İY 1.5 ÜST %',t.htu15],['İY KG %',t.htkg],['İY = MS %',t.ayni]]):'<div class="mini">İY verisi yok</div>')+
   `<div style="margin-top:4px" class="mini">İY skorları:</div><div>${cipler(t.skor_iy_pct,'İY ')}</div></div>`+
   mK([['Ortalama gol',t.ort],['2.5 ÜST %',t.u25],['KG %',t.kg],['Öngörülebilirlik',t.ongorulebilirlik]])+
   (r.ornek&&r.ornek.length?ornekTab(r.ornek, 'BU ORANLA OYNANAN MAÇLAR',
      `${r.ornek.length} maçın tamamı listeleniyor · en yeni → en eski · kaydırarak hepsini gör`):''),
   false));
 }
 /* --- 3) KAPANIŞ ORANIYLA BENZER MAÇLAR --- */
 if(K&&(K.k||K.t)){
  const kk=K.k, tu=K.t;
  const g1=kk?`<div class="b" style="font-size:12px;margin-top:4px">KENDİ LİGİ — ${esc(K.ln||'')} ${K.lu?'('+esc(K.lu)+')':''}</div>`+b3(kk.ms)+
    (kk.iy?`<div class="mini">İY: ${kk.iy.n} maç (kapsam %${kk.iy.kaps}) → İY 0-0 <b>%${kk.iy.s00}</b> · İY 1.5Ü <b>%${kk.iy.s15}</b> · İY KG <b>%${kk.iy.kg}</b> · İY=MS <b>%${kk.iy.ayni}</b></div>
      <div style="margin-top:3px">${cipler(kk.iy.skor,'İY ')}</div>`:'')+
    `<div style="margin-top:4px">${cipler(kk.skor,'')}</div>
     <div class="mini">ort ${kk.ort} gol · 2.5Ü %${kk.u25} · KG %${kk.kg}</div>`:'';
  const g2=tu?`<div class="b" style="font-size:12px;margin-top:8px;border-top:1px dashed var(--line);padding-top:6px">TÜM LİGLER (ülke fark etmez)</div>`+b3(tu.ms)+
    (tu.iy?`<div class="mini">İY: ${tu.iy.n} maç (kapsam %${tu.iy.kaps}) → İY sonuç Ev %${tu.iy.ms[0]} / Ber %${tu.iy.ms[1]} / Dep %${tu.iy.ms[2]} · İY 0-0 <b>%${tu.iy.s00}</b> · İY 1.5Ü <b>%${tu.iy.s15}</b> · ort ${tu.iy.ort} gol</div>
      <div style="margin-top:3px">${cipler(tu.iy.skor,'İY ')}</div>`:'')+
    `<div style="margin-top:4px">${cipler(tu.skor,'')}</div>
     <div class="mini">ort ${tu.ort} gol · 2.5Ü %${tu.u25} · KG %${tu.kg}</div>`:'';
  const tamBag=r.mid?`<a class="tamA" href="${SITE?('kiyas/'+esc(r.mid)+'.html'):('/kiyas?mid='+esc(r.mid))}" ${SITE?'':'target="_blank"'}>${SITE?'🔎 Bu maçın tam kıyas sayfası':'🔎 Tamamını aç (yeni sekme)'}</a>`:'';
  S.push(blok('📉 KAPANIŞ ORANIYLA BENZER MAÇLAR', `oran ${K.o.join(' / ')} · ±%${K.tol}`, g1+g2+
    (K.ornL&&K.ornL.length?ornekTab(K.ornL, `KENDİ LİGİ — ${esc(K.ln||'')} aynı kapanış oranıyla biten maçlar`,
      `${K.nL} maç${K.nL>(K.ornL||[]).length?` · ilk ${K.ornL.length} tanesi burada`:''} ${K.nL<=(K.ornL||[]).length?'· tamamı listeleniyor':''}`):'')+
    (K.ornT&&K.ornT.length?ornekTab(K.ornT, 'TÜM LİGLER — aynı kapanış oranıyla biten maçlar',
      K.nT>K.ornT.length?`${K.nT} maç var · ilk ${K.ornT.length} tanesi burada${tamBag?' · <b>tamamı için sağdaki bağlantı</b>':''}`:`${K.nT} maçın tamamı listeleniyor`):'')+
    `<div class="tamNot"><span class="mini">Sıralama: en yeni → en eski · tablo içinde kaydırarak hepsini görebilirsin.</span>${tamBag}</div>`, false));
 }
 /* --- 4) NEDEN / UYARI --- */
 const _nz=r.neden; const nz=(Array.isArray(_nz)?_nz:(_nz?[_nz]:[])).slice(0,4).map(x=>`<li>${esc(typeof x==='string'?x:((x&&(x.m||x.t))||String(x)))}</li>`).join('');
 const uy=(r.uyari&&r.uyari.length)?`<div class="uyarKut">⚠ ${r.uyari.map(esc).join(' · ')}</div>`:'';
 if(nz||uy){
  S.push(blok('🧠 GEREKÇE', '', (nz?`<ul style="margin:2px 0 0 16px;padding:0;font-size:12.5px;line-height:1.6">${nz}</ul>`:'')+uy, false));
 }
 return `<div class="anaKap">${S.join('')}</div>`;
}
function detayPanel(r){
 return canliPanel(r)+analizPanel(r)+hareketPanel(r)
  +`<details class="altKat" open><summary>📊 <b>Tüm marketler</b> (71 market, gerçek sonuç yüzdeleri)</summary>${tumPanel(r)}${ligPanel(r)}</details>`
  +`<details class="altKat"><summary>📉 <b>Kapanış oranı kıyası</b> — aynı KAPANIŞ oranıyla bitmiş maçlar (kendi ligi + tüm ligler)</summary>${kapanisKiyasPanel(r)}</details>`
  +`<details class="altKat"><summary>🔬 <b>Daha fazla analiz</b> — özet · skor vurgusu · neden · skor ızgarası · koşullu İY · trend · model · form · maç listesi</summary>`
  +ozetPanel(r)+skorVurguPanel(r)+nedenPanel(r)+macListesiPanel(r)+skorIzgaraPanel(r)+kosulPanel(r)+trendPanel(r)+modelPanel(r)+formPanel(r)+uzmanPanel(r)+zenginPanel(r)+`</details>`;
}
function det(tr,i){
 const r=D[i]; if(!r) return;
 const nx=tr.nextElementSibling;
 if(nx&&nx.classList.contains('det')){nx.remove(); tr.classList.remove('acik'); return;}
 document.querySelectorAll('tr.det').forEach(x=>x.remove());
 document.querySelectorAll('tr.acik').forEach(x=>x.classList.remove('acik'));
 const n=GORUNUM[mod].length;
 const y=document.createElement('tr'); y.className='det';
 y.innerHTML=`<td colspan="${n}"><div class="paneller">${detayPanel(r)}</div></td>`;
 tr.after(y); tr.classList.add('acik');
}
/* --- diğer --- */
function sifirla(){ $('q').value=''; $('flt').value='hepsi'; $('lig').value=''; $('minn').value=0;
 if($('iyonly'))$('iyonly').checked=false; if($('kupononly'))$('kupononly').checked=false; ciz(); }
function tema(){const t=document.documentElement; t.dataset.tema=(t.dataset.tema=='acik')?'koyu':'acik';}
function csvIndir(){
 const kol=GORUNUM[mod], L=[];
 const head=['Saat','Lig','Ev','Deplasman','1','X','2','Aynı oranlı','Tolerans','Ev%','Ber%','Dep%','Öne çıkan','Fark','GA alt','GA üst','ROI','Kelly','Öneri notu'];
 L.push(head.join(';'));
 document.querySelectorAll('#tb tr').forEach(tr=>{
  const tds=[...tr.querySelectorAll('td')].map(td=>td.innerText.replace(/[\n;]/g,' ').trim());
  if(tds.length) L.push(tds.join(';'));
 });
 const veri=L.join('\n');
 try{
  const a=document.createElement('a');
  a.href='data:text/csv;charset=utf-8,'+encodeURIComponent('\ufeff'+veri);
  a.download='bulten_'+mod+'.csv'; a.click();
 }catch(e){
  let k=$('csvKutu');
  if(!k){k=document.createElement('div'); k.id='csvKutu'; ($('altAlan')||$('tabloUst')).appendChild(k);}
  k.innerHTML=`<div class="pbox" style="margin:8px 0"><b>CSV (kopyala)</b><textarea style="width:100%;height:150px;background:var(--pn2);color:var(--tx);border:1px solid var(--line)">${esc(veri)}</textarea></div>`;
 }
}
document.addEventListener('keydown',e=>{if(e.key=='Escape'){document.querySelectorAll('tr.det').forEach(x=>x.remove());}});
$('q').oninput=ciz; $('flt').onchange=ciz; $('lig').onchange=ciz;
if($('minn'))$('minn').oninput=ciz;
if($('sa1'))$('sa1').oninput=ciz;
if($('sa2'))$('sa2').oninput=ciz;
if($('iyonly'))$('iyonly').onchange=ciz;
if($('ligonly'))$('ligonly').onchange=ciz;
if($('kupononly'))$('kupononly').onchange=ciz;
if($('temaBtn'))$('temaBtn').onclick=tema;
if($('yazdirBtn'))$('yazdirBtn').onclick=()=>window.print();
if($('csvBtn'))$('csvBtn').onclick=csvIndir;
document.querySelectorAll('.modlar button').forEach(b=>b.onclick=()=>modSec(b.dataset.m));
enIyiKartlari(); ciz();
"""

HTML_BAS = """<!DOCTYPE html><html lang="tr" data-tema="acik"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>TAM BULTEN v3 — {tarih}</title><style>__CSS__</style></head><body><div class="wrap">
__HEAD__
<div class="arac">
  <span class="modlar">
    <button data-m="sade" class="aktif">Sade</button><button data-m="deger">Değer</button><button data-m="gol">Gol</button><button data-m="ilkyari">İlk yarı</button><button data-m="tum">Tümü</button>
  </span>
  <button id="aracBtn" onclick="araclarAc()">⚙️ Araçlar</button>
  <button id="densBtn" onclick="yogunluk()">🔍 Sıkı görünüm</button>
  <span class="mini" id="sayac"></span>
</div>
<div id="tabloUst"></div>
<div class="tabloKap densRahat" id="tabloKap"><table><thead id="thead">__BASLIK__</thead><tbody id="tb">__SATIRLAR__</tbody></table></div>
<div id="altAlan"></div>
<details class="panelKat" id="aracKat"><summary>⚙️ <b>Filtreler ve araçlar</b> — arama · lig · saat · örnek · kupon · CSV · yazdır <span class="mini">(aç/kapa)</span></summary>
 <div class="aracIc">
  <input type="text" id="q" placeholder="Takım / lig ara…">
  <select id="flt">__FILTRE__</select>
  <select id="lig"><option value="">Tüm ligler</option>__LIGLER__</select>
  <span class="mini">Saat:</span><input type="text" id="sa1" value="00:00" style="width:62px"><input type="text" id="sa2" value="23:59" style="width:62px">
  <span class="mini">En az örnek:</span><input type="number" id="minn" value="0" min="0" step="5">
  <label class="mini"><input type="checkbox" id="iyonly"> İY verisi olanlar</label>
  <label class="mini"><input type="checkbox" id="ligonly"> Ligde karşılaştırması olanlar</label>
  <label class="mini"><input type="checkbox" id="guncl" checked onchange="ciz()"> ⏱ Güncel (başlamış/biten maçları gizle)</label>
  <label class="mini"><input type="checkbox" id="kupononly"> Kupon seçilenler</label>
  <button class="ana" onclick="enIyiKupon()">🎟️ En iyi 3'lü kupon</button>
  <button id="csvBtn">⬇ CSV</button>
  <button id="yazdirBtn">🖨️ Yazdır</button>
  <button id="temaBtn">🌓 Tema</button>
  <button onclick="sifirla()">↺ Sıfırla</button>
 </div>
</details>
<details class="panelKat" id="panelKat"><summary>📊 <b>Analiz panelleri</b> — günün özeti · performans · kalibrasyon · oran bandı · lig özeti · yarın önizleme · form rehberi <span class="mini">(aç/kapa)</span></summary>
<div class="kartlar" id="kartlar"></div>
__PANELLER__
</details>
<div class="mini" style="margin-top:12px">__DIPNOT__</div></div>
<div id="kuponBar"></div>
<script>const D=__VERI__;__JS__</script></body></html>"""


def head_html(K):
    n = len(K)
    n_oran = sum(1 for r in K if r.get("o"))
    n_kars = sum(1 for r in K if r.get("n"))
    n_sin = sum(1 for r in K if r.get("sinyal"))
    n_iy = sum(1 for r in K if (r.get("det") or {}).get("htn"))
    n_kor = sum(1 for r in K if r.get("kor"))
    n_bitti = sum(1 for r in K if r.get("sonuc"))
    n_kaz = sum(1 for r in K if r.get("sonuc") == "KAZANDI")
    return (f"<h1>📋 TAM BULTEN — {BUGUN_TR}</h1>"
            f"<div class='sub'>{n} maç · <b>{n_oran}</b> oranlı · <b>{n_kars}</b> karşılaştırıldı · "
            f"<b class='git'>{n_sin}</b> değer sinyali · İY verili <b>{n_iy}</b> · korner <b>{n_kor}</b> · "
            f"biten <b>{n_bitti}</b> (sinyal {n_kaz} tuttu) — <b>satıra tıkla</b> → derin analiz"
            + (f"<br>🕒 <b>{GUNCEL_NOT[0]}</b> itibarıyla listede yalnızca <b>BUGÜNÜN güncel</b> maçları var"
               f" (başlamış/bitmiş <b>{GUNCEL_NOT[1]}</b> maç gizlendi · dünkü maçlar gösterilmez)"
               if GUNCEL_NOT else "") + "</div>")


def hareket_ozet(K):
    """Sayfa altı: en büyük oran hareketleri (para akışı)."""
    L = sorted([r for r in K if r.get("ha") and abs(r.get("ha_buyuk") or 0) >= 1],
               key=lambda r: -abs(r["ha_buyuk"]))
    if not L:
        return ""
    duser = sum(1 for r in L if r["ha_buyuk"] < 0)
    sat = []
    for r in L[:12]:
        ac, sm, s2 = r.get("o") or [0, 0, 0], r.get("ha") or [0, 0, 0], r.get("ha_simdi") or [0, 0, 0]
        har = " ".join((f'<span class="{"git" if v < 0 else "kit"}">{"↓" if v < 0 else "↑"} %.1f%%</span>' % abs(v))
                       for v in s2)
        sat.append(f'<tr><td class="mini">{_esc(r.get("s",""))}</td>'
                   f'<td>{_esc(r.get("h",""))} - {_esc(r.get("a",""))}</td>'
                   f'<td class="mini">{ac[0]:.2f}/{ac[1]:.2f}/{ac[2]:.2f}</td>'
                   f'<td class="mini">{sm[0]:.2f}/{sm[1]:.2f}/{sm[2]:.2f}</td>'
                   f'<td>{har}</td><td><b>{_esc(r.get("ha_yon",""))}</b></td></tr>')
    return ('<div class="pbox"><b>🔀 ORAN HAREKETİ — açılış → şimdi</b> '
            f'<span class="mini">({len(L)} maçta en az %1 hareket · {duser} maçta yukarı · '
            f'{len(L)-duser} maçta aşağı) ↓ = oran düştü = para o tarafa geliyor</span>'
            '<table style="margin-top:8px"><thead><tr><th>Saat</th><th>Maç</th><th>Açılış</th><th>Şimdi</th>'
            '<th>Hareket</th><th>Para yönü</th></tr></thead><tbody>' + "".join(sat) + '</tbody></table></div>')


def paneller_html(K, yarin=None, yarin13=None):
    return (gunun_ozeti(K) + hareket_ozet(K) + "<div class='paneller' style='margin-bottom:10px'>" + performans_panel(K) + kalibrasyon(K) + bantlar(K) + lig_ozeti(K) + taraf_panel(K) +
            yarin_panel(yarin or [], yarin13 or []) + "<div class='pbox'><b>🧭 NASIL OKUNUR?</b><ul style='margin:6px 0 0 16px;padding:0;font-size:12.5px;line-height:1.7'>"
            "<li><b>Aynı oranlı maç</b> = bugünkü maçın açılış oranlarıyla (±tolerans) geçmişte oynanmış maç sayısı</li>"
            "<li><b>Değer farkı</b> = tarihte gerçekleşen % − piyasanın verdiği % (pozitifse piyasa düşük fiyatlıyor)</li>"
            "<li><b>Öneri notu</b> = fark + örneklem + eşleşme hassasiyeti + güven aralığı + ROI bileşimi (0-100)</li>"
            "<li><b>Nokta renkleri</b>: 🟢 çok sıkı · 🔵 iyi · 🟡 geniş · 🔴 gevşek eşleşme</li>"
            "<li>⚠ işareti = zayıf örneklem / gevşek eşleşme / İY verisi yok gibi uyarı</li></ul></div></div>")


DIPNOT = ("<b>Yöntem:</b> arşivdeki 76.208 maç (2011→bugün) açılış oranlarına göre taranır; kapanış kıyası ise "
          "161.110 maçlık kapanış arşivinden (football-data.co.uk, ilk yarı skorları dahil) hesaplanır; hedef maçın oranıyla ±tolerans içinde eşleşen "
          "tüm maçlar bulunur ve market kırılımları bu kümeden hesaplanır. Yüzdeler gerçek sonuçlardan türetilmiştir; "
          "İY verisi kapsamı yeterli olmayan gruplarda İY marketleri boş bırakılır. Yatırım tavsiyesi değildir.")


def yarin_kayitlari(gun):
    """Gelecek günler için hafif kayıtlar (derin panel yok, önizleme için)."""
    d = json.load(open("/home/user/veri/tam_tarama.json", encoding="utf-8"))
    out = []
    for m in d:
        if m.get("gun") != gun or not m.get("o"):
            continue
        r = {"s": m.get("saat", ""), "l": m.get("lig", ""), "h": m.get("home", ""), "a": m.get("away", ""),
             "o": [round(x, 2) for x in m["o"]], "n": m.get("n", 0), "tol": m.get("tol_k"),
             "lnk": "https://www.betexplorer.com" + m.get("link", "")}
        p = m.get("en_iyi")
        if p and m.get("n"):
            r.update(ad=p["ad"], oran=round(p["oran"], 2), piy=round(p["piyasa"], 1), hist=round(p["hist"], 1),
                     edge=round(p["edge"], 1), ci=[round(p["ci"][0], 1), round(p["ci"][2], 1)],
                     roi=round(p["roi"], 1), kelly=round(p.get("kelly", 0), 1),
                     sinyal=int(m["n"] >= 18 and p["ci"][0] > p["piyasa"] and p["edge"] >= 3
                                and (m.get("tol_k") or 9) <= 0.20))
        out.append(r)
    return out


def guvenli_marketler(ms):
    """Konsensüs + model uyumu yüksek, örneklemi yeterli marketleri seçer."""
    return None


GUNCEL_NOT = None   # (render saati, çıkarılan maç sayısı)


def guncel_suz(K, simdi=None):
    """Bugünün SADECE güncel maçlarını bırakır: başlaması 120 dk+ geçmiş (bitmiş) maçlar çıkarılır.
    Dünkü/gece maçları (00:00-04:xx) ve bugün oynanıp bitenler listede görünmez."""
    from datetime import datetime
    from zoneinfo import ZoneInfo
    simdi = simdi or datetime.now(ZoneInfo("Europe/Istanbul"))
    out, atilan = [], 0
    for r in K:
        s = (r.get("s") or "").strip()
        try:
            hh, mm = s.split(":")
            k = simdi.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
        except Exception:
            out.append(r); continue
        fark = (simdi - k).total_seconds() / 60.0     # + ise başlamış
        if fark > 120:                                # bitmiş → listeden çıkar
            atilan += 1; continue
        if fark >= 0:                                 # şu an oynanıyor
            r["basladi"] = 1
            r["dakika"] = int(fark)
        out.append(r)
    return out, atilan


def render3(K, dosya="/home/user/BULTEN.html", yarin=None, yarin13=None):
    zenginlestir(K, TT.arsiv())
    veri = json.dumps(K, ensure_ascii=False, separators=(",", ":"))
    filtre = (f'<option value="hepsi">Tüm maçlar ({len(K)})</option>'
              f'<option value="sinyal">🟩 Değer sinyalleri ({sum(1 for r in K if r.get("sinyal"))})</option>'
              f'<option value="iy">İY verisi olanlar ({sum(1 for r in K if (r.get("det") or {}).get("htn"))})</option>'
              f'<option value="kar">Karşılaştırılanlar ({sum(1 for r in K if r.get("n"))})</option>'
              f'<option value="hareket">🔀 Oran hareketi olanlar ({sum(1 for r in K if abs(r.get("ha_buyuk") or 0) >= 1)})</option>'
              f'<option value="kapk">📉 Kapanış kıyası olanlar ({sum(1 for r in K if r.get("kk"))})</option>'
              f'<option value="siki">Sıkı eşleşme (≤0.15)</option>'
              f'<option value="oransiz">Karşılaştırılamayanlar ({sum(1 for r in K if not r.get("n"))})</option>')
    ligler = sorted({r["l"] for r in K if r.get("l")})
    ligopt = "".join(f'<option value="{H.escape(l)}">{H.escape(l)}</option>' for l in ligler)
    doc = (HTML_BAS.replace("{tarih}", BUGUN_TR).replace("__CSS__", CSS)
           .replace("__HEAD__", head_html(K)).replace("__FILTRE__", filtre).replace("__LIGLER__", ligopt)
           .replace("__PANELLER__", paneller_html(K, yarin, yarin13)).replace("__BASLIK__", statik_baslik())
           .replace("__SATIRLAR__", statik_satirlar(K)).replace("__VERI__", veri)
           .replace("__JS__", DEVRALINAN + "\n" + JS.replace("__SITE__", "true" if os.environ.get("SITE_MOD") else "false")).replace("__DIPNOT__", DIPNOT))
    open(dosya, "w", encoding="utf-8").write(doc)
    return doc


def disa_aktar3(K):
    import csv as _csv
    bas = ["Saat", "Lig", "Ev", "Deplasman", "1", "X", "2", "Aynı oranlı", "Tolerans", "Ev%", "Ber%", "Dep%",
           "Öne çıkan", "Öneri notu", "Fark", "GA alt", "GA üst", "Güven", "ROI%", "Kelly%", "Sinyal", "Uyarı", "Gerekçe",
           "Ort.gol", "Ev attığı gol ort.", "Ev yediği gol ort.", "Dep attığı gol ort.", "Dep yediği gol ort.", "Takımlar toplam gol ort.",
           "1.5Ü%", "2.5Ü%", "3.5Ü%", "KG%", "İY 0-0%", "İY 0.5Ü%", "İY 1.5Ü%", "İY KG%",
           "İY 1%", "İY X%", "İY 2%", "İY=MS%", "İY ort.gol", "2Y ort.gol",
           "Poisson Ev%", "Poisson X%", "Poisson Dep%", "Poisson 2.5Ü%", "Poisson KG%", "Model fark",
           "Gol dağılımı 0/1/2/3/4/5+", "En sık skorlar", "En sık İY skorlar", "Korner", "Korner sinyal", "Link",
           "Pazar-tablo (market: tarihsel% / adil / model)", "Lig-içi aynı oran n", "Lig-içi MS%", "Lig-içi 2.5Ü%", "Lig-içi KG%", "Lig-içi en sık skorlar", "Lig-içi tolerans",
           "Ülke geneli n", "Ülke geneli MS%"]

    def sat(r):
        d = r.get("det") or {}
        g = "YÜKSEK" if (r.get("n", 0) >= 40 and r.get("sinyal")) else ("ORTA" if (r.get("n", 0) >= 18 and r.get("sinyal")) else ("DÜŞÜK" if r.get("sinyal") else ""))
        p = r.get("poi") or ["", "", "", "", ""]
        import re as _re
        return [r["s"], r["l"], r["h"], r["a"], r["o"][0], r["o"][1], r["o"][2], r.get("n", ""), r.get("tol", ""),
                *(r.get("d") or ["", "", ""]), r.get("ad", ""), r.get("not", ""), r.get("edge", ""),
                (r.get("ci") or ["", ""])[0], (r.get("ci") or ["", ""])[1], g, r.get("roi", ""), r.get("kelly", ""),
                "DEĞERLİ" if r.get("sinyal") else "", " · ".join(r.get("uyari") or []), _re.sub("<[^>]+>", "", r.get("neden", "")),
                d.get("ort", ""),
                (r.get("form") or {}).get("h", {}).get("at", ""), (r.get("form") or {}).get("h", {}).get("ye", ""),
                (r.get("form") or {}).get("a", {}).get("at", ""), (r.get("form") or {}).get("a", {}).get("ye", ""),
                (r.get("form") or {}).get("h", {}).get("top", "") + (r.get("form") or {}).get("a", {}).get("top", "")
                if (r.get("form") or {}).get("h") and (r.get("form") or {}).get("a") else "",
                d.get("u15", ""), d.get("u25", ""), d.get("u35", ""), d.get("kg", ""),
                d.get("ht00", ""), d.get("htu05", ""), d.get("htu15", ""), d.get("htkg", ""),
                d.get("iy1", ""), d.get("iyx", ""), d.get("iy2", ""), d.get("ayni", ""), d.get("htort", ""), d.get("h2ort", ""),
                p[0], p[1], p[2], p[3], p[4], r.get("poi_fark", ""),
                "/".join(f"{x:.0f}" for x in (d.get("gol") or [])) if d.get("gol") else "",
                " ".join(d.get("skor") or []), " ".join(d.get("htskor") or []),
                (r.get("kor") or {}).get("tot", ""), (r.get("kor") or {}).get("pick", ""), r.get("lnk", ""),
                " | ".join(f"{ad}: tarihsel %{p} · düzeltilmiş %{pa} · model {('%.1f' % m) if m is not None else '-'} · konsensüs %{ko}"
                            for _, ad, p, a, m, pa, ko in (r.get("paz") or [])),
                (r.get("lig_cmp") or {}).get("n", ""),
                "/".join(str(x) for x in (r.get("lig_cmp") or {}).get("ms", [])),
                (r.get("lig_cmp") or {}).get("u25", ""), (r.get("lig_cmp") or {}).get("kg", ""),
                " ".join(f"{x[0]} %{x[1]}" for x in (r.get("lig_cmp") or {}).get("skor", [])),
                (r.get("lig_cmp") or {}).get("tol_l", ""),
                (r.get("ulke_cmp") or {}).get("n", ""),
                "/".join(str(x) for x in (r.get("ulke_cmp") or {}).get("ms", []))]

    with open("/home/user/BULTEN.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = _csv.writer(f, delimiter=";")
        w.writerow(bas)
        for r in K:
            w.writerow(sat(r))
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        wb = Workbook(); ws = wb.active; ws.title = "Bulten"
        ws.append(bas)
        for c in range(1, len(bas) + 1):
            cell = ws.cell(1, c); cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1F4E79"); cell.alignment = Alignment(horizontal="center")
        yesil = PatternFill("solid", fgColor="C6EFCE"); mavi = PatternFill("solid", fgColor="DDEBF7")
        for r in K:
            ws.append(sat(r))
            if r.get("sinyal"):
                for c in range(1, len(bas) + 1): ws.cell(ws.max_row, c).fill = yesil
            elif (r.get("det") or {}).get("htn"):
                for c in range(24, 38): ws.cell(ws.max_row, c).fill = mavi
        ws.freeze_panes = "A2"; ws.auto_filter.ref = ws.dimensions
        for i in range(1, len(bas) + 1):
            ws.column_dimensions[ws.cell(1, i).column_letter].width = 12 if i < 9 else 10
        wb.save("/home/user/BULTEN.xlsx")
        return "xlsx ok"
    except Exception as ex:
        return f"xlsx: {ex}"


BUGUN_G = "2026-09-11"
YARIN_G = "2026-09-12"
OBUR_G = "2026-09-13"

if __name__ == "__main__":
    t0 = time.time()
    _ms, _o1s = TT.arsiv()
    pazar_prior(_ms)
    K = kayit_uret([BUGUN_G])
    _fark = SA.fark_ogren()
    for _r in K:
        _yeni, _gun = SA.tr(_r.get("s"), _fark)
        _r["s"] = _yeni
        if _gun:
            _r["gk"] = 1
    # --- ORANLAR GÜNCELLENDİĞİNDE 'n' BAYAT KALMASIN: karşılaştırmayı yeniden hesapla ---
    try:
        _ms0, _o1s0 = TT.arsiv()
        _ham = json.load(open("/home/user/veri/tam_tarama.json", encoding="utf-8"))
        _deg = 0
        for _m in _ham:
            if _m.get("gun") == BUGUN_G and _m.get("o"):
                _onceki = _m.get("n")
                TT.karsilastir(_m, _ms0, _o1s0)
                if _m.get("n") != _onceki:
                    _deg += 1
        if _deg:
            _tmp = "/home/user/veri/tam_tarama.json.tmp"
            json.dump(_ham, open(_tmp, "w", encoding="utf-8"), ensure_ascii=False)
            os.replace(_tmp, "/home/user/veri/tam_tarama.json")
        print("karşılaştırma tazeleme: %d maçta sayı güncellendi (bayat n düzeltildi)" % _deg)
    except Exception as _e:
        print("karşılaştırma tazeleme atlandı:", str(_e)[:80])
    print("saat: BetExplorer +%d saat → Türkiye saati (%s)" % (
        _fark, ", ".join(sorted({(r.get("s") or "") for r in K})[:4])))
    _ham = len(K)
    K, _atilan = guncel_suz(K)
    # --- şüpheli açılış oranı (1X2 kolonu kaynakta yok) → kıyas payload'ını düşür ---
    _sup = 0
    for r in K:
        o = r.get("o") or []
        if len(o) == 3 and not (1.005 <= sum(1.0 / x for x in o) <= 1.35):
            for k in ("n", "tol", "kalite", "lig_cmp", "ulke_cmp", "ad", "edge", "not", "sinyal", "hist",
                      "piy", "ci", "roi", "kelly", "d", "det", "ornek", "kor", "paz", "poi", "poi_skor",
                      "poi_fark", "bst", "pdeger", "form", "sonuc", "neden"):
                r.pop(k, None)
            r.setdefault("uyari", []).append("Açılış oranı kaynakta eksik (1X2 kolonu gelmiyor) → kıyas yapılmadı")
            r["oransup"] = 1
            _sup += 1
    # --- ORAN HAREKETİ (açılış → şimdi) ---
    try:
        _hrk = (json.load(open("/home/user/veri/hareket.json", encoding="utf-8")) or {}).get("hareket", {})
    except Exception:
        _hrk = {}
    _kimlik = {}
    for _m in json.load(open("/home/user/veri/tam_tarama.json", encoding="utf-8")):
        if _m.get("id") and _m["id"] in _hrk:
            _s_tr = SA.tr(_m.get("saat"), _fark)[0]
            _kimlik["%s|%s|%s" % (_s_tr, _m.get("home", ""), _m.get("away", ""))] = _hrk[_m["id"]]
    for r in K:
        _v = _kimlik.get("%s|%s|%s" % (r.get("s", ""), r.get("h", ""), r.get("a", "")))
        if _v:
            r["ha"] = _v["hareket"]
            r["ha_yon"] = _v["yon"]
            r["ha_buyuk"] = _v["buyuk"]
            r["ha_simdi"] = _v.get("simdi")
            r["ha_iyi"] = _v.get("en_iyi")
            if abs(_v["buyuk"]) >= 1 and not r.get("oransup"):
                r.setdefault("bilgi", []).append(
                    "Oran hareketi: %s tarafı %%%.1f (açılış → şimdi)" % (_v["yon"], abs(_v["buyuk"])))
    # --- KAPANIŞ ORANI KIYASI: aynı kapanış oranıyla bitmiş maçlar ---
    try:
        _KAPO = KK.KAPO()
    except Exception:
        _KAPO = None
    try:
        _krec = json.load(open("/home/user/veri/kapanis.json", encoding="utf-8")).get("kapanis", {})
    except Exception:
        _krec = {}
    _kik = {}
    for _m in json.load(open("/home/user/veri/tam_tarama.json", encoding="utf-8")):
        if _m.get("id") and _m["id"] in _krec:
            _s_tr = SA.tr(_m.get("saat"), _fark)[0]
            _kik["%s|%s|%s" % (_s_tr, _m.get("home", ""), _m.get("away", ""))] = _krec[_m["id"]]
    _kn = 0
    if _KAPO:
        for r in K:
            if r.get("oransup") or len(r.get("o") or []) != 3:
                continue
            _k = "%s|%s|%s" % (r.get("s", ""), r.get("h", ""), r.get("a", ""))
            _r = _kik.get(_k) or {}
            if _r.get("kapanis"):
                odds_, kaynak = _r["kapanis"], "ölçülen kapanış (%s)" % _r.get("son_cekim", "")
            elif r.get("ha_simdi"):
                odds_, kaynak = r["ha_simdi"], "son fiyat (%s itibarıyla)" % r.get("ha_yon", "") and "son fiyat"
            else:
                continue
            try:
                _t = _KAPO.kiyas(odds_, lig=r.get("l"), ulke=None)
            except Exception:
                continue
            if not (_t.get("lig") or _t.get("tum")):
                continue
            _ok = "lig" if _t.get("lig") else "tum"
            def _sade(L):
                if not L:
                    return None
                d = {"n": L["n"], "ms": L["ms"], "ort": L["ort"], "u25": L["u25"], "kg": L["kg"],
                     "skor": L["skor"][:3]}
                if L.get("iy"):
                    i = L["iy"]
                    d["iy"] = {"n": i["n"], "kaps": i["kaps"], "ms": i["ms"], "ort": i["ort"],
                               "s00": i["s00"], "s15": i["s15"], "kg": i["kg"], "ayni": i["ayni"],
                               "skor": i["skor"][:3]}
                return d
            _lig_sat = _t.get("ornek") or []
            _tum_sat = _t.get("ornek_t") or []
            r["kk"] = {"o": [round(x, 2) for x in odds_], "tol": _t["tol"], "tolg": _t.get("tolg"),
                       "kyn": kaynak, "k": _sade(_t.get("lig")), "t": _sade(_t.get("tum")),
                       "ln": _t.get("lig_adi", ""), "lu": _t.get("lig_ulke", ""), "ok": _ok,
                       "nL": len(_lig_sat), "nT": len(_tum_sat),
                       "ornL": _lig_sat[:200],      # kendi ligi → tamamı (200'e kadar)
                       "ornT": _tum_sat[:120]}      # tüm ligler → ilk 120 + tamamı için bağlantı
            _kn += 1
    print("kapanış kıyası: %d maç (lig: %d · tüm ligler: %d)" % (
        _kn, sum(1 for r in K if (r.get("kk") or {}).get("k")), sum(1 for r in K if (r.get("kk") or {}).get("t"))))
    print("hareket: %d maç verili · ≥%%1: %d · şüpheli açılış oranı: %d"
          % (sum(1 for r in K if r.get("ha")), sum(1 for r in K if abs(r.get("ha_buyuk") or 0) >= 1), _sup))
    import datetime as _d
    from zoneinfo import ZoneInfo
    globals()["GUNCEL_NOT"] = (_d.datetime.now(ZoneInfo("Europe/Istanbul")).strftime("%H:%M"), _atilan)
    print(f"güncel filtre: {_ham} → {len(K)} (başlamış/bitmiş {_atilan} çıkarıldı)")
    KY = yarin_kayitlari(YARIN_G)
    K13 = yarin_kayitlari(OBUR_G)
    for _l in (KY, K13):
        for _r in _l:
            _y, _g = SA.tr(_r.get("s"), _fark)
            _r["s"] = _y
            if _g:
                _r["gk"] = 1
    doc = render3(K, yarin=KY, yarin13=K13)
    print(f"BULTEN.html | {len(K)} maç | {sum(1 for r in K if r.get('sinyal'))} sinyal | "
          f"İY verili {sum(1 for r in K if (r.get('det') or {}).get('htn'))} | {len(doc)//1024} KB | {round(time.time()-t0,1)}s")
    print(disa_aktar3(K))
