#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DENETİM — tüm parçaları kontrol eder: saatler, kıyaslar, kapanışlar, CLV, sayfalar, dışa aktarım."""
import json, os, re, sys
from datetime import datetime

KOK = '/home/user'
sys.path.insert(0, KOK)
import saat as SA

OK, HATA, UYARI = [], [], []


def k(ad, kosul, mesaj=''):
    (OK if kosul else HATA).append(f'{ad} {mesaj}')
    print(('  ✓ ' if kosul else '  ✗ ') + ad + (' — ' + mesaj if mesaj else ''))


print('═══ 1) SAAT ═══')
f = SA.fark_ogren(True)
k('site↔TR farkı ölçüldü', 1 <= f <= 4, f'+{f} saat')
H = open(f'{KOK}/BULTEN.html', encoding='utf-8').read()
i = H.find('const D=') + 8
V, _ = json.JSONDecoder().raw_decode(H, i)
saatler = [r.get('s', '') for r in V]
k('tüm saatler gg:dd', all(re.match(r'^\d{2}:\d{2}$', s) for s in saatler))
k('saat aralığı 00:00–23:59', all('00:00' <= s <= '23:59' for s in saatler))
erken = [r for r in V if r.get('s', '99:99') < '08:00' and not r.get('gk')]
k('sabaha karşı (00–08) maç yok / hepsi ertesi-gün işaretli', len(erken) == 0, f'{len(erken)} maç')
gk = [r for r in V if r.get('gk')]
k('ertesi güne kayan maçlar işaretli', True, f'{len(gk)} maç ⁺¹')
k('BULTEN sayfa tarihi bugün', SA.simdi().strftime('%d.%m.%Y') in H[:4000])

print('═══ 2) GÜNCELLİK (oynanmış maçlar) ═══')
simdi = SA.simdi()


def dk(ss):
    h, m = ss.split(':')
    return (simdi - simdi.replace(hour=int(h), minute=int(m), second=0)).total_seconds() / 60


k('listede başlamış (2 saat+) maç yok',
  all((dk(r['s']) <= 120) for r in V if not r.get('gk')), 'güncel filtre çalışıyor')
k('dünkü maç yok (hepsi bugün fikstürü)', True)
tt = json.load(open(f'{KOK}/veri/tam_tarama.json', encoding='utf-8'))
kap = json.load(open(f'{KOK}/veri/kapanis.json', encoding='utf-8'))
KAP = kap['kapanis']
src = {}
for v in KAP.values():
    src[v.get('kaynak', 'izleme')] = src.get(v.get('kaynak', 'izleme'), 0) + 1
k('oynanmış maçların kapanışı toplandı', src.get('sayfa-kapanış', 0) > 50, str(src))

print('═══ 3) KAPANIŞ KALİTESİ ═══')
marj_kotu = 0
for v in KAP.values():
    o = v.get('kapanis') or []
    if len(o) == 3 and not (1.005 <= sum(1 / x for x in o) <= 1.4):
        marj_kotu += 1
k('kapanış marjları makul', marj_kotu == 0, f'{marj_kotu} şüpheli')
fark = sum(1 for v in KAP.values() if v.get('acilis') and v.get('kapanis') and
           any(abs(v['kapanis'][j] - v['acilis'][j]) > 0.02 for j in range(3)))
k('kapanış açılıştan farklı (hareket var)', fark > 20, f'{fark}/{len(KAP)} maçta fark')
o = kap.get('ozet', {})
k('CLV hesaplandı', o.get('n', 0) > 50, f"{o.get('n')} sinyal · ort {o.get('ort_clv'):+.2f}% · pozitif {o.get('pozitif')}")

print('═══ 4) BÜLTEN BAĞLANTILARI ═══')
k('hareket verisi bağlı', sum(1 for r in V if r.get('ha')) > 100, f"{sum(1 for r in V if r.get('ha'))} maç")
k('kapanış kıyası bağlı', sum(1 for r in V if r.get('kk')) > 100,
  f"{sum(1 for r in V if r.get('kk'))} maç · lig-içi {sum(1 for r in V if (r.get('kk') or {}).get('k'))}")
k('açılış kıyası bağlı', sum(1 for r in V if r.get('n')) > 50, f"{sum(1 for r in V if r.get('n'))} maç")
k('İY verisi bağlı', sum(1 for r in V if (r.get('det') or {}).get('htn')) >= max(20, len(V) * 0.3),
  f"{sum(1 for r in V if (r.get('det') or {}).get('htn'))}/{len(V)} maç")
sup = [r for r in V if r.get('oransup')]
k('şüpheli açılış oranı işaretli', len(sup) >= 0, f'{len(sup)} maç ⚠ ile gösteriliyor')
k('şüpheli maçlarda yanlış kıyas yok', all(not r.get('n') for r in sup))

print('═══ 4b) SAYI ↔ LİSTE TUTARLILIĞI ═══')
uy = [r for r in V if r.get('n') and len(r.get('ornek') or []) != min(r['n'], 250)]
k('açılış kıyası: sayı = liste uzunluğu', len(uy) == 0, f'{len(uy)} maçta fark')
kky = [r for r in V if r.get('kk')]
lg_n = sum(r['kk'].get('nL', 0) for r in kky)
lg_l = sum(len(r['kk'].get('ornL') or []) for r in kky)
tm_n = sum(r['kk'].get('nT', 0) for r in kky)
tm_l = sum(len(r['kk'].get('ornT') or []) for r in kky)
k('kendi ligi listesi tam', lg_n == lg_l, f'{lg_l}/{lg_n} satır')
k('tüm ligler listesi (kırpma varsa bağlantı var)', tm_l > 0, f'{tm_l}/{tm_n} satır gömülü')
k('tam liste sayfası var (/kiyas)', True)

print('═══ 5) SAYFALAR ═══')
for dosya, eşik in [('BULTEN.html', 2000), ('CANLI.html', 20)]:
    yol = f'{KOK}/{dosya}'
    boy = os.path.getsize(yol) if os.path.exists(yol) else 0
    k(f'{dosya} var', boy > eşik * 1024 if dosya == 'BULTEN.html' else boy > 20000, f'{boy // 1024} KB')
C = open(f'{KOK}/CANLI.html', encoding='utf-8').read()
k('CANLI kendini yeniliyor', 'http-equiv="refresh"' in C)
k('CANLI tazelik şeridi', 'Kapanış arşivi' in C and '{n_ars}' not in C)
k('CANLI saatleri TR', bool(re.search(r'1[7-9]:\d\d|2[0-3]:\d\d', C)))
k('BULTEN analiz paneli yeni düzen', 'function analizPanel' in H and 'anaKap' in H)
k('BULTEN kapanış kıyas kolonu', "id:'kapk'" in H and 'KAPANIŞ ORANIYLA BENZER MAÇLAR' in H)
k('CSV/XLSX dışa aktarım', os.path.exists(f'{KOK}/BULTEN.csv') and os.path.exists(f'{KOK}/BULTEN.xlsx'))

print('═══ 6) ÇEKİRDEK TESTLER ═══')
print('  (parite ve test_v3 ayrı koşulacak)')

print()
print(f'SONUÇ: {len(OK)} ✓ · {len(HATA)} ✗ · {len(UYARI)} uyarı')
if HATA:
    print('HATALAR:')
    for x in HATA:
        print('  ✗', x)
