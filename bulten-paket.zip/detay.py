#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DERİN GRUP İSTATİSTİĞİ — aynı oranla oynanan maçlar için tam market kırılımı:
  • Toplam gol dağılımı (0-5+)
  • Alt/Üst 1.5 / 2.5 / 3.5 (üst ve alt yüzdeleri)
  • KG (karşılıklı gol) var/yok
  • İlk yarı: 0-0, 1.5 üst/alt, KG, İY sonucu (1/X/2)
  • İY/MS matrisi (3x3)
  • 2. yarı gol ortalaması + 2Y 0.5 üst/alt
  • En sık skorlar
Zaman ağırlıklı (yarı ömür 3 yıl) ve ham yüzdeler birlikte.
"""
import json, math, os
from collections import Counter
from datetime import datetime

HT_CACHE = "/home/user/veri/ht_cache.json"
BUGUN = datetime(2026, 9, 11)
_HT = None

def ht():
    global _HT
    if _HT is None:
        _HT = json.load(open(HT_CACHE, encoding="utf-8")) if os.path.exists(HT_CACHE) else {}
    return _HT

def _yas(d):
    try: return max(0.0, (BUGUN - datetime.strptime(d, "%d.%m.%Y")).days / 365.25)
    except Exception: return 99.0

def _w(d, hl=3.0): return 0.5 ** (_yas(d) / hl)

def _wr(lst, pred, hl=3.0):
    num = den = 0.0
    for c in lst:
        w = _w(c.get("date", ""), hl); den += w
        if pred(c): num += w
    return 100 * num / den if den else 0.0

def grup_detay(eslesen, ht_veri=None):
    """eslesen: arşiv maç kayıtları (hg, ag, date, ht_h, ht_a olabilir)."""
    if not eslesen: return None
    ht_veri = ht_veri if ht_veri is not None else ht()
    ms = []
    for c in eslesen:
        r = dict(c)
        if "ht_h" not in r:
            v = ht_veri.get(r["id"])
            if v: r["ht_h"], r["ht_a"], r["h2_h"], r["h2_a"] = v
        ms.append(r)
    n = len(ms)
    tot = [c["hg"] + c["ag"] for c in ms]
    d = {}
    # --- toplam gol ---
    dag = Counter(min(t, 5) for t in tot)
    d["gol"] = [round(100 * dag.get(k, 0) / n, 1) for k in range(6)]     # 0,1,2,3,4,5+
    d["ort"] = round(sum(tot) / n, 2)
    d["u15"] = round(100 * sum(1 for t in tot if t > 1.5) / n, 1)
    d["u25"] = round(100 * sum(1 for t in tot if t > 2.5) / n, 1)
    d["u35"] = round(100 * sum(1 for t in tot if t > 3.5) / n, 1)
    d["u45"] = round(100 * sum(1 for t in tot if t > 4.5) / n, 1)
    d["w_u15"] = round(_wr(ms, lambda c: c["hg"] + c["ag"] > 1.5), 1)
    d["w_u25"] = round(_wr(ms, lambda c: c["hg"] + c["ag"] > 2.5), 1)
    d["w_u35"] = round(_wr(ms, lambda c: c["hg"] + c["ag"] > 3.5), 1)
    d["kg"] = round(100 * sum(1 for c in ms if c["hg"] > 0 and c["ag"] > 0) / n, 1)
    d["kg_yok"] = round(100 - d["kg"], 1)
    d["ev_g"] = round(sum(c["hg"] for c in ms) / n, 2)
    d["dep_g"] = round(sum(c["ag"] for c in ms) / n, 2)
    d["skor"] = [f"{k}×{v}" for k, v in Counter(f"{c['hg']}-{c['ag']}" for c in ms).most_common(6)]
    d["ms"] = [round(100 * sum(1 for c in ms if c["hg"] > c["ag"]) / n, 1),
               round(100 * sum(1 for c in ms if c["hg"] == c["ag"]) / n, 1),
               round(100 * sum(1 for c in ms if c["hg"] < c["ag"]) / n, 1)]
    # --- ilk yarı ---
    htli = [c for c in ms if "ht_h" in c]
    if len(htli) >= max(5, 0.45 * n):     # yeterli kapsam yoksa İY istatistiği üretme
        m = len(htli)
        d["htn"] = m
        d["ht00"] = round(100 * sum(1 for c in htli if c["ht_h"] == 0 and c["ht_a"] == 0) / m, 1)
        d["htu15"] = round(100 * sum(1 for c in htli if c["ht_h"] + c["ht_a"] > 1.5) / m, 1)
        d["htu05"] = round(100 * sum(1 for c in htli if c["ht_h"] + c["ht_a"] > 0.5) / m, 1)
        d["htkg"] = round(100 * sum(1 for c in htli if c["ht_h"] > 0 and c["ht_a"] > 0) / m, 1)
        d["htev"] = round(100 * sum(1 for c in htli if c["ht_h"] > c["ht_a"]) / m, 1)
        d["htber"] = round(100 * sum(1 for c in htli if c["ht_h"] == c["ht_a"]) / m, 1)
        d["htdep"] = round(100 * sum(1 for c in htli if c["ht_a"] > c["ht_h"]) / m, 1)
        d["htort"] = round(sum(c["ht_h"] + c["ht_a"] for c in htli) / m, 2)
        d["h2ort"] = round(sum((c["hg"] + c["ag"]) - (c["ht_h"] + c["ht_a"]) for c in htli) / m, 2)
        d["h2u05"] = round(100 * sum(1 for c in htli if (c["hg"] + c["ag"]) - (c["ht_h"] + c["ht_a"]) > 0.5) / m, 1)
        d["h2u15"] = round(100 * sum(1 for c in htli if (c["hg"] + c["ag"]) - (c["ht_h"] + c["ht_a"]) > 1.5) / m, 1)
        # İY/MS matrisi (3x3) + İY→MS aynı sonuç
        M = [[0] * 3 for _ in range(3)]
        def kod(a, b): return 0 if a > b else (1 if a == b else 2)
        for c in htli:
            M[kod(c["ht_h"], c["ht_a"])][kod(c["hg"], c["ag"])] += 1
        d["matrix"] = [[round(100 * x / m, 1) for x in row] for row in M]
        d["matrix_n"] = M
        d["ayni"] = round(100 * sum(M[i][i] for i in range(3)) / m, 1)
        d["ht_koruma"] = round(100 * (M[0][0] + M[2][2]) / max(1, sum(M[0]) + sum(M[2])), 1)  # İY önde bitirme
        d["donus"] = round(100 * (sum(M[0]) - M[0][0] + sum(M[2]) - M[2][2]) / max(1, sum(M[0]) + sum(M[2])), 1)
        # İY skor dağılımı
        d["htskor"] = [f"{k}×{v}" for k, v in Counter(f"{c['ht_h']}-{c['ht_a']}" for c in htli).most_common(5)]
        # ilk gol hangi yarıda (kaba): İY 0-0 olup maçta gol olan / tersi
        d["gol_2y"] = round(100 * sum(1 for c in htli if (c["hg"] + c["ag"]) > (c["ht_h"] + c["ht_a"])) / m, 1)
    d.update(ek_metrikler(ms))
    d.update(skor_derin(ms))
    try:
        d["pazar"], d["pazar_n"] = tum_pazar(ms)
    except Exception:
        d["pazar"] = []
    try:
        lh = d.get("ev_g") or 0.0; la = d.get("dep_g") or 0.0
        if lh > 0.05 and la > 0.05:
            d["rho"] = dixon_coles_rho(ms, lh, la)
            pri = globals().get("_PRIOR") or {}
            if pri:
                d["pazar_k"] = kucult(ms, d["pazar"], pri)
            d.update(entropi(ms))
            tr = trend(ms)
            if tr:
                d["trend"] = tr
    except Exception:
        pass
    return d




# ------------------------------------------------------------------ TÜM PAZARLAR (tek bakışta)
def _fa(p):
    return round(100.0 / p, 2) if p and p > 0 else None



PAZAR_TANIM = [
    ("MAÇ SONUCU", False, [("1 (Ev)", lambda h, a, hh, ha: h > a), ("X (Beraberlik)", lambda h, a, hh, ha: h == a), ("2 (Dep)", lambda h, a, hh, ha: h < a)]),
    ("ÇİFTE ŞANS", False, [("1X", lambda h, a, hh, ha: h >= a), ("12", lambda h, a, hh, ha: h != a), ("X2", lambda h, a, hh, ha: h <= a)]),
    ("ALT / ÜST", False, [("0.5 Üst", lambda h, a, hh, ha: h + a > 0.5), ("0.5 Alt", lambda h, a, hh, ha: h + a < 0.5),
                          ("1.5 Üst", lambda h, a, hh, ha: h + a > 1.5), ("1.5 Alt", lambda h, a, hh, ha: h + a < 1.5),
                          ("2.5 Üst", lambda h, a, hh, ha: h + a > 2.5), ("2.5 Alt", lambda h, a, hh, ha: h + a < 2.5),
                          ("3.5 Üst", lambda h, a, hh, ha: h + a > 3.5), ("3.5 Alt", lambda h, a, hh, ha: h + a < 3.5),
                          ("4.5 Üst", lambda h, a, hh, ha: h + a > 4.5), ("4.5 Alt", lambda h, a, hh, ha: h + a < 4.5)]),
    ("KG & TAKIM GOLLERİ", False, [("KG Var", lambda h, a, hh, ha: h > 0 and a > 0), ("KG Yok", lambda h, a, hh, ha: h == 0 or a == 0),
                                   ("Ev 0.5 Üst", lambda h, a, hh, ha: h > 0.5), ("Ev 1.5 Üst", lambda h, a, hh, ha: h > 1.5),
                                   ("Dep 0.5 Üst", lambda h, a, hh, ha: a > 0.5), ("Dep 1.5 Üst", lambda h, a, hh, ha: a > 1.5)]),
    ("GOL ARALIĞI", False, [("0-1 gol", lambda h, a, hh, ha: h + a <= 1), ("2-3 gol", lambda h, a, hh, ha: 2 <= h + a <= 3),
                            ("4+ gol", lambda h, a, hh, ha: h + a >= 4)]),
    ("İLK YARI", True, [("İY 1 (Ev)", lambda h, a, hh, ha: hh > ha), ("İY X", lambda h, a, hh, ha: hh == ha), ("İY 2 (Dep)", lambda h, a, hh, ha: hh < ha),
                        ("İY 0-0", lambda h, a, hh, ha: hh == 0 and ha == 0), ("İY 0.5 Üst", lambda h, a, hh, ha: hh + ha > 0.5),
                        ("İY 1.5 Üst", lambda h, a, hh, ha: hh + ha > 1.5), ("İY KG", lambda h, a, hh, ha: hh > 0 and ha > 0)]),
    ("2. YARI", True, [("2Y 0.5 Üst", lambda h, a, hh, ha: (h + a) - (hh + ha) > 0.5), ("2Y 1.5 Üst", lambda h, a, hh, ha: (h + a) - (hh + ha) > 1.5),
                       ("2Y Ev gol atar", lambda h, a, hh, ha: h - hh > 0), ("2Y Dep gol atar", lambda h, a, hh, ha: a - ha > 0),
                       ("2Y KG", lambda h, a, hh, ha: h - hh > 0 and a - ha > 0)]),
    ("bet365 TARZI", False, [
        ("Beraberlikte İade (Ev)", lambda h, a, hh, ha: h >= a),
        ("Beraberlikte İade (Dep)", lambda h, a, hh, ha: a >= h),
        ("Handikap Ev -1", lambda h, a, hh, ha: h - 1 > a),
        ("Handikap Dep +1", lambda h, a, hh, ha: a + 1 > h),
        ("Kazanma farkı: Ev 1 gol", lambda h, a, hh, ha: h - a == 1),
        ("Kazanma farkı: Ev 2+ gol", lambda h, a, hh, ha: h - a >= 2),
        ("Kazanma farkı: Dep 1 gol", lambda h, a, hh, ha: a - h == 1),
        ("Kazanma farkı: Dep 2+ gol", lambda h, a, hh, ha: a - h >= 2),
        ("Tek gol (toplam)", lambda h, a, hh, ha: (h + a) % 2 == 1),
        ("Çift gol (toplam)", lambda h, a, hh, ha: (h + a) % 2 == 0),
        ("Ev 2+ gol atar", lambda h, a, hh, ha: h >= 2),
        ("Dep 2+ gol atar", lambda h, a, hh, ha: a >= 2)]),
    ("YARI BAZLI", True, [
        ("Her iki yarıda 0.5Ü", lambda h, a, hh, ha: hh + ha > 0.5 and (h + a) - (hh + ha) > 0.5),
        ("En çok gol 2. yarıda", lambda h, a, hh, ha: (h + a) - (hh + ha) > hh + ha),
        ("En çok gol 1. yarıda", lambda h, a, hh, ha: hh + ha > (h + a) - (hh + ha)),
        ("İY KG Yok → MS KG Var", lambda h, a, hh, ha: (hh == 0 or ha == 0) and h > 0 and a > 0),
        ("İY 0-0 → 2Y gol var", lambda h, a, hh, ha: hh == 0 and ha == 0 and (h + a) > 0)]),
    ("BAHİS KOMBİNASYONLARI", False, [("2.5Ü + KG", lambda h, a, hh, ha: h + a > 2.5 and h > 0 and a > 0),
                                      ("2.5A + KG Yok", lambda h, a, hh, ha: h + a < 2.5 and (h == 0 or a == 0)),
                                      ("1.5Ü + İY 0-0", lambda h, a, hh, ha: h + a > 1.5 and hh == 0 and ha == 0),
                                      ("MS 1 + 2.5Ü", lambda h, a, hh, ha: h > a and h + a > 2.5)]),
]


def tum_pazar(ms):
    """Tüm marketlerin tarihsel yüzdeleri. İY gerektirenler İY verisi varsa hesaplanır."""
    if not ms:
        return [], 0
    htli = [c for c in ms if "ht_h" in c]
    KAT = PAZAR_TANIM
    out = []
    for kat, iy_gerek, rows in KAT:
        kaynak = htli if iy_gerek else ms
        if not kaynak:
            continue
        L = len(kaynak)
        for ad, f in rows:
            pct = round(100 * sum(1 for c in kaynak if f(c["hg"], c["ag"], c.get("ht_h", 0), c.get("ht_a", 0))) / L, 1)
            out.append([kat, ad, pct, _fa(pct)])
    if htli:
        L = len(htli)
        LBL = ["1", "X", "2"]
        for i in range(3):
            for j in range(3):
                def f(h, a, hh, ha, i=i, j=j):
                    ki = 0 if hh > ha else (1 if hh == ha else 2)
                    kj = 0 if h > a else (1 if h == a else 2)
                    return ki == i and kj == j
                pct = round(100 * sum(1 for c in htli if f(c["hg"], c["ag"], c["ht_h"], c["ht_a"])) / L, 1)
                out.append(["İY → MS", f"İY {LBL[i]} → MS {LBL[j]}", pct, _fa(pct)])
        for ad, f in [("İY 0-0 → 2.5Ü", lambda c: c["ht_h"] == 0 and c["ht_a"] == 0 and c["hg"] + c["ag"] > 2.5),
                      ("İY 0-0 → KG", lambda c: c["ht_h"] == 0 and c["ht_a"] == 0 and c["hg"] > 0 and c["ag"] > 0),
                      ("İY 1-0 → Ev kazanır", lambda c: c["ht_h"] > c["ht_a"] and c["hg"] > c["ag"]),
                      ("İY 0-1 → Dep kazanır", lambda c: c["ht_a"] > c["ht_h"] and c["ag"] > c["hg"])]:
            pct = round(100 * sum(1 for c in htli if f(c)) / L, 1)
            out.append(["İY → MS", ad, pct, _fa(pct)])
    return out, len(htli)


# ------------------------------------------------------------------ UZMAN ALGORİTMALARI
def dixon_coles_rho(ms, lh, la, N=8, adim=0.01):
    """Gözlenen 0-0/1-0/0-1/1-1 oranlarına en uygun rho (Dixon-Coles bağımlılık parametresi)."""
    if len(ms) < 12:
        return 0.0
    n = len(ms)
    f = [math.exp(-lh) * lh ** i / math.factorial(i) for i in range(N)]
    g = [math.exp(-la) * la ** j / math.factorial(j) for j in range(N)]
    p00, p10, p01, p11 = f[0] * g[0], f[1] * g[0], f[0] * g[1], f[1] * g[1]
    o00 = sum(1 for c in ms if c["hg"] == 0 and c["ag"] == 0) / n
    o10 = sum(1 for c in ms if c["hg"] == 1 and c["ag"] == 0) / n
    o01 = sum(1 for c in ms if c["hg"] == 0 and c["ag"] == 1) / n
    o11 = sum(1 for c in ms if c["hg"] == 1 and c["ag"] == 1) / n
    en, en_rho = None, 0.0
    r = -0.20
    while r <= 0.2001:
        t00 = 1 - lh * la * r
        t10 = 1 + la * r
        t01 = 1 + lh * r
        t11 = 1 - r
        if min(t00, t10, t01, t11) > 0:
            h = ((p00 * t00 - o00) ** 2 + (p10 * t10 - o10) ** 2 +
                 (p01 * t01 - o01) ** 2 + (p11 * t11 - o11) ** 2)
            if en is None or h < en:
                en, en_rho = h, round(r, 3)
        r += adim
    return en_rho


def entropi(ms):
    """Sonuç belirsizliği: 1X2 dağılımının entropisi (0-100 öngörülebilirlik)."""
    n = len(ms)
    if not n:
        return {}
    p = [sum(1 for c in ms if c["hg"] > c["ag"]) / n, sum(1 for c in ms if c["hg"] == c["ag"]) / n,
         sum(1 for c in ms if c["hg"] < c["ag"]) / n]
    H = -sum(x * math.log2(x) for x in p if x > 0)
    return {"entropi": round(H, 3), "ongorulebilirlik": round(100 * (1 - H / 1.58496), 1),
            "favori_kaybeder": round(100 * (1 - max(p)), 1),
            "favori": ["Ev", "Beraberlik", "Deplasman"][p.index(max(p))], "favori_p": round(100 * max(p), 1)}


def trend(ms, esik_yil=2):
    """Son 2 yıl ile öncesini karşılaştırır: 2.5Ü ve İY 0-0 eğilimi."""
    from datetime import datetime as _dt
    yeni, eski = [], []
    for c in ms:
        try:
            d = _dt.strptime(c.get("date", ""), "%d.%m.%Y")
        except Exception:
            continue
        (yeni if (BUGUN - d).days <= esik_yil * 365 else eski).append(c)
    if len(yeni) < 8 or len(eski) < 8:
        return {}
    def oran(L, f):
        return round(100 * sum(1 for c in L if f(c)) / len(L), 1)
    u25_y, u25_e = oran(yeni, lambda c: c["hg"] + c["ag"] > 2.5), oran(eski, lambda c: c["hg"] + c["ag"] > 2.5)
    hty = [c for c in yeni if "ht_h" in c]
    hte = [c for c in eski if "ht_h" in c]
    d = {"n_yeni": len(yeni), "n_eski": len(eski), "u25_yeni": u25_y, "u25_eski": u25_e,
         "u25_delta": round(u25_y - u25_e, 1),
         "ort_yeni": round(sum(c["hg"] + c["ag"] for c in yeni) / len(yeni), 2),
         "ort_eski": round(sum(c["hg"] + c["ag"] for c in eski) / len(eski), 2)}
    if len(hty) >= 6 and len(hte) >= 6:
        d["ht00_yeni"] = round(100 * sum(1 for c in hty if c["ht_h"] == 0 and c["ht_a"] == 0) / len(hty), 1)
        d["ht00_eski"] = round(100 * sum(1 for c in hte if c["ht_h"] == 0 and c["ht_a"] == 0) / len(hte), 1)
        d["ht00_delta"] = round(d["ht00_yeni"] - d["ht00_eski"], 1)
    d["yon"] = "artıyor" if d["u25_delta"] > 5 else ("azalıyor" if d["u25_delta"] < -5 else "stabil")
    return d


def kucult(ms, pazar, prior, k=12.0):
    """Ampirik Bayes küçültme: p_adj = (n·p + k·prior)/(n+k) — küçük örneklemi düzeltir."""
    n = len(ms)
    if not n or not pazar:
        return []
    out = []
    for kat, ad, p, adil in pazar:
        pr = prior.get(ad)
        if pr is None:
            out.append([kat, ad, p, adil, p])
            continue
        out.append([kat, ad, p, adil, round((n * p + k * pr) / (n + k), 1)])
    return out

def skor_derin(ms):
    """Tam skor ızgarası, sonuç-bazlı skor profili, zaman ağırlıklı skor trendi."""
    from collections import Counter
    n = len(ms)
    if not n: return {}
    d = {}
    G = [[0] * 6 for _ in range(6)]          # 0..5+ (5 = 5+)
    for c in ms:
        G[min(5, c["hg"])][min(5, c["ag"])] += 1
    d["grid"] = [[round(100 * x / n, 1) for x in row] for row in G]
    cs = Counter(f"{c['hg']}-{c['ag']}" for c in ms)
    def top(pred, k=4):
        return [[sk, round(100 * v / n, 1)] for sk, v in cs.most_common(60)
                if pred(int(sk.split("-")[0]), int(sk.split("-")[1]))][:k]
    d["sonuc_skor"] = {"Ev": top(lambda a, b: a > b), "Ber": top(lambda a, b: a == b), "Dep": top(lambda a, b: a < b)}
    w, tot = Counter(), 0.0
    for c in ms:
        ww = _w(c.get("date", "")); tot += ww; w[f"{c['hg']}-{c['ag']}"] += ww
    d["w_skor"] = [[sk, round(100 * v / tot, 1)] for sk, v in w.most_common(6)] if tot else []
    return d


def kosul_iy(htli):
    """İlk yarı skoruna göre maç sonu dağılımı (koşullu olasılık)."""
    from collections import Counter
    if not htli: return []
    g = {}
    for c in htli:
        g.setdefault(f"{c['ht_h']}-{c['ht_a']}", []).append(c)
    out = []
    for k, v in sorted(g.items(), key=lambda z: -len(z[1]))[:6]:
        m = len(v)
        cs = Counter(f"{c['hg']}-{c['ag']}" for c in v)
        ev = 100 * sum(1 for c in v if c["hg"] > c["ag"]) / m
        be = 100 * sum(1 for c in v if c["hg"] == c["ag"]) / m
        out.append({"iy": k.replace("-", ":"), "n": m,
                    "ms": [round(ev, 1), round(be, 1), round(100 - ev - be, 1)],
                    "top": [[sk, round(100 * x / m, 1)] for sk, x in cs.most_common(3)],
                    "ort": round(sum(c["hg"] + c["ag"] for c in v) / m, 2)})
    return out

def ek_metrikler(ms):
    """İY/MS yüzdeleri, skor tabloları, 0-0 sonrası, 2Y, clean sheet ve adil oranlar."""
    htli=[c for c in ms if "ht_h" in c]
    n=len(ms); t=sum(c["hg"]+c["ag"] for c in ms)
    d={"adil":{}, "iyms":{}, "skor_pct":[], "skor_iy_pct":[]}
    # --- adil oranlar (tarihsel) ---
    def fa(p): return round(100.0/p,2) if p>0 else None
    u15=100*sum(1 for c in ms if c["hg"]+c["ag"]>1.5)/n
    u25=100*sum(1 for c in ms if c["hg"]+c["ag"]>2.5)/n
    u35=100*sum(1 for c in ms if c["hg"]+c["ag"]>3.5)/n
    kg=100*sum(1 for c in ms if c["hg"]>0 and c["ag"]>0)/n
    hw=100*sum(1 for c in ms if c["hg"]>c["ag"])/n; dr=100*sum(1 for c in ms if c["hg"]==c["ag"])/n
    aw=100-hw-dr
    d["adil"]={"1":fa(hw),"X":fa(dr),"2":fa(aw),"u15":fa(u15),"u25":fa(u25),"u35":fa(u35),
               "kg":fa(kg),"kg_yok":fa(100-kg),"a15":fa(100-u15),"a25":fa(100-u25),"a35":fa(100-u35)}
    d["cs"]=round(100*sum(1 for c in ms if c["ag"]==0)/n,1)      # ev sahibi gol yemedi
    d["fts"]=round(100*sum(1 for c in ms if c["hg"]==0)/n,1)     # ev sahibi gol atamadı
    d["cs_dep"]=round(100*sum(1 for c in ms if c["hg"]==0)/n,1)
    d["fts_dep"]=round(100*sum(1 for c in ms if c["ag"]==0)/n,1)
    # --- skor yüzdeleri (MS) ---
    from collections import Counter
    cs=Counter(f"{c['hg']}-{c['ag']}" for c in ms)
    d["skor_pct"]=[[k, round(100*v/n,1)] for k,v in cs.most_common(12)]
    # --- ev/dep galibiyet skorları ---
    d["en_sik_ev"]=[[k,round(100*v/n,1)] for k,v in cs.most_common(30) if int(k.split("-")[0])>int(k.split("-")[1])][:5]
    d["en_sik_ber"]=[[k,round(100*v/n,1)] for k,v in cs.most_common(30) if k.split("-")[0]==k.split("-")[1]][:5]
    d["en_sik_dep"]=[[k,round(100*v/n,1)] for k,v in cs.most_common(30) if int(k.split("-")[0])<int(k.split("-")[1])][:5]
    if len(htli)>=max(5,0.45*n):
        m=len(htli)
        def kod(a,b): return 0 if a>b else (1 if a==b else 2)
        LBL=["1","X","2"]
        # --- 9 kombinasyon İY/MS yüzdesi + adil oran ---
        cnt=Counter((kod(c["ht_h"],c["ht_a"]),kod(c["hg"],c["ag"])) for c in htli)
        for i in range(3):
            for j in range(3):
                v=cnt.get((i,j),0); p=100*v/m
                d["iyms"][f"{LBL[i]}/{LBL[j]}"]={"n":v,"p":round(p,1),"adil":fa(p)}
        d["kosul"] = kosul_iy(htli)
        # İY sonuç yüzdeleri
        d["iy1"]=round(100*sum(1 for c in htli if kod(c["ht_h"],c["ht_a"])==0)/m,1)
        d["iyx"]=round(100*sum(1 for c in htli if kod(c["ht_h"],c["ht_a"])==1)/m,1)
        d["iy2"]=round(100*sum(1 for c in htli if kod(c["ht_h"],c["ht_a"])==2)/m,1)
        d["iy_adil"]={"1":fa(d["iy1"]),"X":fa(d["iyx"]),"2":fa(d["iy2"])}
        # --- İY skor yüzdeleri ---
        ci=Counter(f"{c['ht_h']}-{c['ht_a']}" for c in htli)
        d["skor_iy_pct"]=[[k, round(100*v/m,1)] for k,v in ci.most_common(10)]
        # --- İY 0-0 sonrası ---
        sifir=[c for c in htli if c["ht_h"]==0 and c["ht_a"]==0]
        if sifir:
            z=len(sifir)
            d["z00_n"]=z
            d["z00_u05"]=round(100*sum(1 for c in sifir if c["hg"]+c["ag"]>0.5)/z,1)
            d["z00_u15"]=round(100*sum(1 for c in sifir if c["hg"]+c["ag"]>1.5)/z,1)
            d["z00_u25"]=round(100*sum(1 for c in sifir if c["hg"]+c["ag"]>2.5)/z,1)
            d["z00_kg"]=round(100*sum(1 for c in sifir if c["hg"]>0 and c["ag"]>0)/z,1)
            d["z00_gol"]=round(sum(c["hg"]+c["ag"] for c in sifir)/z,2)
        # --- İY önde götürenin MS dağılımı ---
        for i,lbl in ((0,"ev"),(2,"dep")):
            grp=[c for c in htli if kod(c["ht_h"],c["ht_a"])==i]
            if len(grp)>=3:
                g=len(grp)
                d[f"onde_{lbl}_kazandi"]=round(100*sum(1 for c in grp if kod(c["hg"],c["ag"])==i)/g,1)
                d[f"onde_{lbl}_beraber"]=round(100*sum(1 for c in grp if kod(c["hg"],c["ag"])==1)/g,1)
                d[f"onde_{lbl}_kaybetti"]=round(100*sum(1 for c in grp if kod(c["hg"],c["ag"])==(2 if i==0 else 0))/g,1)
        # --- 2. yarı istatistikleri ---
        h2=[(c["hg"]+c["ag"])-(c["ht_h"]+c["ht_a"]) for c in htli]
        d["h2_0"]=round(100*sum(1 for x in h2 if x==0)/m,1)
        d["h2_gt1"]=round(100*sum(1 for x in h2 if x>1)/m,1)     # 2Y'de 2+ gol
        d["ev_2y"]=round(100*sum(1 for c in htli if c["hg"]>c["ht_h"])/m,1)
        d["dep_2y"]=round(100*sum(1 for c in htli if c["ag"]>c["ht_a"])/m,1)
        d["her_iki_2y"]=round(100*sum(1 for c in htli if c["hg"]>c["ht_h"] and c["ag"]>c["ht_a"])/m,1)
        # --- İY/MS piyasa olasılığı (en olası 4) ---
        d["iyms_top"]=sorted([(k,v) for k,v in d["iyms"].items()], key=lambda z:-z[1]["p"])[:5]
    return d

if __name__ == "__main__":
    import sys
    sys.path.insert(0, "/home/user")
    import tam_tarama as TT
    ms, o1s = TT.arsiv()
    e = TT.eslesen(ms, o1s, [2.27, 3.60, 2.73], 0.08)
    d = grup_detay(e)
    print(f"örnek grup n={len(e)}")
    for k in ("ort", "u15", "u25", "u35", "kg", "ht00", "htu15", "htkg", "ayni", "h2ort"):
        print(f"  {k}: {d.get(k)}")
