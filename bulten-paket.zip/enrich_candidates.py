#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Aday maçlar: gerçek bet365 1X2 oranları + İY skoru + (varsa) açılış oranı"""
import json, re, subprocess, time, html as H
from concurrent.futures import ThreadPoolExecutor

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
COOKIE="age_verified=true; js_cookie=1; my_timezone=%2B1"
BASE="https://www.betexplorer.com"; OUT="/home/user/veri"

def curl(u,n=25):
    for _ in range(3):
        try:
            r=subprocess.run(["curl","-s","-m",str(n),"-A",UA,"-H","Cookie: "+COOKIE,u],capture_output=True,timeout=n+8)
            s=r.stdout.decode("utf-8","ignore")
            if s and len(s)>150 and '"error"' not in s[:60]: return s
        except Exception: pass
        time.sleep(0.3)
    return s if 's' in dir() else ""

def b365_1x2(eid, ref):
    """bet365 satırından (1,X,2) oranları + açılış oranı (varsa)"""
    raw=curl(f"{BASE}/match-odds/{eid}/1/1x2/odds/?lang=en",25)
    try:
        h=json.loads(raw)["odds"]
    except Exception:
        return None
    rows=re.findall(r'<tr[^>]*>(.*?)</tr>',h,re.S)
    for row in rows:
        if 'bet365' not in row.lower(): continue
        cells=re.findall(r'<td[^>]*data-odd="[^"]*"[^>]*>',row)
        if len(cells)<3: continue
        res={}
        for td in cells:
            pos=re.search(r'data-pos="([^"]*)"',td)
            odd=re.search(r'data-odd="([^"]*)"',td)
            oid=re.search(r'data-oid="([^"]*)"',td)
            cr=re.search(r'data-created="([^"]*)"',td)
            bt=re.search(r'data-bt="([^"]*)"',td)
            sc=re.search(r'data-sc="([^"]*)"',td)
            hcp=re.search(r'data-hcp="([^"]*)"',td)
            op=re.search(r'data-opening-odd="([^"]*)"',td)
            if not pos or not odd: continue
            res[pos.group(1)]={"odd":odd.group(1),"oid":oid.group(1) if oid else "",
                               "created":cr.group(1) if cr else "","bt":bt.group(1) if bt else "",
                               "sc":sc.group(1) if sc else "","hcp":hcp.group(1) if hcp else "",
                               "open":op.group(1) if op else ""}
        if len(res)>=3: return res
    return None

def page_info(link):
    h=curl(BASE+link,30)
    d={}
    m=re.search(r'id="js-partial">(.*?)</div>',h,re.S)
    if m:
        t=re.sub(r'<[^>]+>','',m.group(1)).strip()
        mm=re.match(r'\((\d+):(\d+),\s*(\d+):(\d+)\)',t)
        if mm: d.update(ht_h=int(mm.group(1)),ht_a=int(mm.group(2)),ft_h=int(mm.group(3)),ft_a=int(mm.group(4)))
    m=re.search(r'<h1[^>]*>([^<]*)</h1>',h)
    d['title']=H.unescape(m.group(1)).strip() if m else ''
    return d

def work(m):
    ref=BASE+m["link"]
    b=b365_1x2(m["id"],ref)
    p=page_info(m["link"])
    m.update(p)
    if b: m["b365"]=b
    return m

if __name__=="__main__":
    ms=json.load(open(f"{OUT}/all_matches.json"))
    T={"o1":4.33,"ox":3.75,"o2":1.76}
    cand=[m for m in ms if abs(m['o1']-T['o1'])<=0.22 and abs(m['ox']-T['ox'])<=0.22 and abs(m['o2']-T['o2'])<=0.22]
    print("aday:",len(cand),flush=True)
    t0=time.time()
    with ThreadPoolExecutor(max_workers=12) as ex:
        res=list(ex.map(work,cand))
    json.dump(res,open(f"{OUT}/candidates.json","w",encoding="utf-8"),ensure_ascii=False)
    ok=sum(1 for r in res if 'b365' in r)
    print(f"bet365 alınan: {ok}/{len(res)} | İY skoru: {sum(1 for r in res if 'ht_h' in r)} | {round(time.time()-t0)}s",flush=True)
