#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kısa listedeki maçlar için: İY skoru + ek market oranları (OU/BTTS/DNB/DC)"""
import json, re, subprocess, time, sys
from concurrent.futures import ThreadPoolExecutor

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
COOKIE="age_verified=true; js_cookie=1; my_timezone=%2B1; be_lang=en"
BASE="https://www.betexplorer.com"; OUT="/home/user/veri"

def curl(u,n=25):
    for _ in range(3):
        try:
            r=subprocess.run(["curl","-s","-m",str(n),"-A",UA,"-H","Cookie: "+COOKIE,u],capture_output=True,timeout=n+8)
            s=r.stdout.decode("utf-8","ignore")
            if len(s)>500 and "idade" not in s: return s
        except Exception: pass
        time.sleep(0.4)
    return ""

def ht_of(link):
    h=curl(BASE+link)
    p=re.search(r'id="js-partial">(.*?)</div>',h,re.S)
    if not p: return None
    txt=re.sub(r'<[^>]+>','',p.group(1)).strip()
    m=re.match(r'\((\d+):(\d+),\s*(\d+):(\d+)\)',txt)
    if not m: return None
    return {"ht_h":int(m.group(1)),"ht_a":int(m.group(2)),"ft_h":int(m.group(3)),"ft_a":int(m.group(4)),"raw":txt}

if __name__=="__main__":
    sel=json.load(open(f"{OUT}/shortlist.json",encoding="utf-8"))
    print("kısa liste:",len(sel),flush=True)
    def w(m):
        r=ht_of(m["link"])
        if r: m.update(r)
        return m
    t0=time.time()
    with ThreadPoolExecutor(max_workers=10) as ex:
        res=list(ex.map(w,sel))
    ok=[m for m in res if "ht_h" in m]
    json.dump(res,open(f"{OUT}/shortlist_ht.json","w",encoding="utf-8"),ensure_ascii=False)
    print(f"İY skoru alınan: {len(ok)}/{len(sel)} | {round(time.time()-t0)}s",flush=True)
