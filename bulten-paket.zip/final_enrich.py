#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Seçili adaylar: bet365 açılış oranı (archive-odds) + İY skoru + tüm sonuç verisi"""
import json, re, subprocess, time, html as H
from concurrent.futures import ThreadPoolExecutor

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
COOKIE="age_verified=true; js_cookie=1; my_timezone=%2B1"
BASE="https://www.betexplorer.com"; OUT="/home/user/veri"

def curl(u,n=25):
    s=""
    for _ in range(4):
        try:
            r=subprocess.run(["curl","-s","-m",str(n),"-A",UA,"-H","Cookie: "+COOKIE,u],capture_output=True,timeout=n+8)
            s=r.stdout.decode("utf-8","ignore")
            if s and len(s)>60: return s
        except Exception: pass
        time.sleep(0.5)
    return s

def archive(oid,bid,bt,sc,hcp):
    u=f"{BASE}/archive-odds/{oid}/{bid}/{bt}/{sc}/{hcp}/"
    try:
        j=json.loads(curl(u,20))
        return j if isinstance(j,list) else None
    except Exception: return None

def page_extra(link):
    h=curl(BASE+link,30)
    d={}
    m=re.search(r'id="js-partial">(.*?)</div>',h,re.S)
    if m:
        t=re.sub(r'<[^>]+>','',m.group(1)).strip()
        mm=re.match(r'\((\d+):(\d+),\s*(\d+):(\d+)\)',t)
        if mm:
            d.update(ht_h=int(mm.group(1)),ht_a=int(mm.group(2)),ft_h2=int(mm.group(3)),ft_a2=int(mm.group(4)))
    return d

def work(c):
    # 3 sonuç için açılış/kapanış geçmişi
    opens={}
    for pos in ('1','0','2'):
        b=c['b365'].get(pos) or {}
        if b.get('oid') and b.get('sc') and b.get('hcp'):
            h=archive(b['oid'],'549',b.get('bt','1'),b['sc'],b['hcp'])
            if h:
                opens[pos]={"open":h[-1],"close":h[0],"n":len(h)}
    if opens: c['open_hist']=opens
    x=page_extra(c['link'])
    if x: c.update(x)
    return c

if __name__=="__main__":
    C=json.load(open(f"{OUT}/candidates.json"))
    b=[c for c in C if 'b365' in c]
    T={"1":4.33,"0":3.75,"2":1.76}
    def vals(c): return {p:float(d['odd']) for p,d in c['b365'].items() if p in ('1','0','2')}
    sel=[c for c in b if all(abs(vals(c)[k]-T[k])<=0.15 for k in T)]
    print("seçilen maç:",len(sel),flush=True)
    t0=time.time()
    with ThreadPoolExecutor(max_workers=8) as ex:
        res=list(ex.map(work,sel))
    json.dump(res,open(f"{OUT}/shortlist_final.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
    ok=sum(1 for r in res if 'open_hist' in r); ht=sum(1 for r in res if 'ht_h' in r)
    print(f"açılış verisi: {ok}/{len(res)} | İY: {ht} | {round(time.time()-t0)}s",flush=True)
