#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GÜN TAZELE — mevcut tarama verisini kaybetmeden bugünün fikstürünü yeniler:
  • yeni maçlar eklenir (oranı yoksa tamamlanır, karşılaştırma yapılır)
  • mevcut maçlarda saat / skor / İY skoru / durum (bekliyor · canlı · bitti) güncellenir
  • oranlar korunur (biten maçlarda sitede oran görünmediği için yeniden çekilmez)
Kullanım: python3 gun_tazele.py [YYYY-MM-DD ...]
"""
import json, sys, datetime

sys.path.insert(0, "/home/user")
import tam_tarama as TT

# BetExplorer ?date= parametresini yok sayıyor → yalnızca BUGÜN işlenir (gün damgası asla değiştirilmez)
gunler = [datetime.date(2026, 9, 11).isoformat()]
d = json.load(open("/home/user/veri/tam_tarama.json", encoding="utf-8"))
by_id = {m["id"]: m for m in d}
ms, o1s = TT.arsiv()

rapor = []
for gs in gunler:
    g = datetime.date.fromisoformat(gs)
    taze = TT.gun_maclari(g)
    if not taze:
        rapor.append(f"{gs}: sayfa alınamadı"); continue
    TT.oran_tamamla(taze)                      # önbellekli oran tamamlama
    yeni = guncel = oran_geri = 0
    for m in taze:
        m["gun"] = gs                      # canlı sayfa her zaman BUGÜNÜN fikstürüdür
        e = by_id.get(m["id"])
        if e is None:
            if m.get("o"):
                TT.karsilastir(m, ms, o1s)     # n, tol_k, en_iyi, marj, ornek…
            m.setdefault("durum", "bekliyor")
            by_id[m["id"]] = m
            yeni += 1
        else:
            for k in ("saat", "skor", "iy", "durum", "gun", "link", "lig", "lig_tam", "ulke", "home", "away"):
                if m.get(k) not in (None, ""):
                    e[k] = m[k]
            if m.get("o"):
                e["o"] = m["o"]
            elif not e.get("o"):
                oran_geri += 1
            e.setdefault("durum", "bekliyor")
            guncel += 1
    rapor.append(f"{gs}: {len(taze)} maç (yeni {yeni} · güncellenen {guncel} · oransız kalan {oran_geri})")

out = list(by_id.values())
import os as _os, shutil as _sh
_tmp = "/home/user/veri/tam_tarama.json.tmp"
json.dump(out, open(_tmp, "w", encoding="utf-8"), ensure_ascii=False)
_sh.copy2("/home/user/veri/tam_tarama.json", "/home/user/veri/tam_tarama.bak.json")
_os.replace(_tmp, "/home/user/veri/tam_tarama.json")
print("\n".join(rapor), flush=True)
for gs in gunler:
    x = [m for m in out if m.get("gun") == gs]
    print(f"  {gs}: toplam {len(x)} | oranlı {sum(1 for m in x if m.get('o'))} | "
          f"skorlu {sum(1 for m in x if m.get('skor'))} | karşılaştırılan {sum(1 for m in x if m.get('n'))}", flush=True)

TT.skorlar()      # canlı skor önbelleğini de tazele
print("skor.json güncellendi", flush=True)
