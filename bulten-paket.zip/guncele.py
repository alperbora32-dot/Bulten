#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GÜNCEL SEZON YENİLEME — bugün/yarın maçı olan liglerin sonuç sayfalarını yeniden tarar,
arşive son günlerin (10-11.09.2026) maçlarını ekler. Idempotent: aynı maçı iki kez eklemez.
Çalıştırma: python3 guncele.py [saniye_bütçesi]
"""
import json, sys, time
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, "/home/user")
from arsiv_genislet import curl, parse_results, ARCH

BUDGET = float(sys.argv[1]) if len(sys.argv) > 1 else 420.0
TT = json.load(open("/home/user/veri/tam_tarama.json", encoding="utf-8"))

# bugün + gelecek 2 gün maçı olan ligler (bültenin kapsadığı tüm ligler)
lig_baz = set()
for m in TT:
    p = m.get("link") or ""
    seg = [s for s in p.split("/") if s]
    if len(seg) >= 3 and seg[0] == "football":
        lig_baz.add("/" + "/".join(seg[:3]) + "/")

taban = json.load(open(ARCH, encoding="utf-8"))
var = {m["id"] for m in taban}
gorevler = [l + "results/" for l in sorted(lig_baz)]
print(f"Arşiv: {len(taban)} maç | yenilenecek lig sayfası: {len(gorevler)}", flush=True)

yeni, sayac, t0 = [], 0, time.time()
CH = 60


def is_yap(u):
    for _ in range(2):
        h = curl(u)
        if h:
            try:
                return u, parse_results(h, u)
            except Exception:
                return u, []
        time.sleep(1.5)
    return u, []


for i in range(0, len(gorevler), CH):
    if time.time() - t0 > BUDGET:
        print("bütçe doldu", flush=True)
        break
    with ThreadPoolExecutor(max_workers=6) as ex:
        for u, rows in ex.map(is_yap, gorevler[i:i + CH]):
            sayac += 1
            for r in rows:
                if r["id"] not in var:
                    var.add(r["id"]); yeni.append(r)
    print(f"  {sayac}/{len(gorevler)} sayfa | +{len(yeni)} yeni maç | {round(time.time()-t0)}s", flush=True)
    json.dump(taban + yeni, open(ARCH, "w", encoding="utf-8"), ensure_ascii=False)

json.dump(taban + yeni, open(ARCH, "w", encoding="utf-8"), ensure_ascii=False)
tarih = {}
for r in yeni:
    tarih[r["date"]] = tarih.get(r["date"], 0) + 1
print(f"BİTTİ: {len(taban)} → {len(taban)+len(yeni)} maç (+{len(yeni)}) | {round(time.time()-t0)}s", flush=True)
print("yeni maç tarihleri:", dict(sorted(tarih.items(), key=lambda z: -z[1])[:12]), flush=True)
