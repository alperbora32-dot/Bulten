#!/bin/bash
# TEK KOMUT GÜNCELLEME — fikstür/skor tazele → oran doğrula → bülteni yeniden üret
cd /home/user
echo "═══ 1/4 fikstür + skor tazeleme ═══"
python3 onar.py | tail -3
echo "═══ 2/4 İY verisi (eksikler) ═══"
python3 -u ht_topla.py 8 2>&1 | tail -2
echo "═══ 3/4 oran doğrulama (canlı sayfa) ═══"
python3 oran_dogrula2.py 2>&1 | tail -3
echo "═══ 4/6 oran hareketi (açılış → şimdi) ═══"
python3 -u oran_hareket.py devam 2>&1 | tail -2
echo "═══ 5/6 bülten üretimi ═══"
python3 bulten_v3.py | tail -2
echo "═══ + canlı takip tazeleme ═══"
python3 takip.py 2>&1 | tail -1
echo "✔ hazır: /home/user/BULTEN.html  (sayfayı yenile)"
