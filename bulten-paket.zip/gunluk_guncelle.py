#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GÜNLÜK GÜNCELLE — bugünün maçlarını çeker, bülteni yeniler.
Kullanım:  python3 gunluk_guncelle.py
Ürettikleri:  BULTEN.html (tek dosya, aranabilir) · BULTEN.xlsx · BULTEN.csv · Bugun_Bulteni.html
"""
import json, subprocess, sys, time, os
sys.path.insert(0, "/home/user")
import tarama as T, bulten as B

def main():
    t0 = time.time()
    print(f"📡 {T.BUGUN} maçları çekiliyor…", flush=True)
    sonuc = T.tarama(0.15, verbose=True)
    B.zenginlestir(sonuc)
    B.bulten_html(sonuc, 0.15, "/home/user/Bugun_Bulteni.html")
    import bulten_tek_dosya as S
    S.uret("/home/user/BULTEN.html")
    # xlsx + csv
    h = open("/home/user/BULTEN.html", encoding="utf-8").read()
    i = h.find("const D=") + 8; j = h.find(";", i)
    veri = json.loads(h[i:j])
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill
        wb = Workbook(); ws = wb.active; ws.title = "Bülten"
        bas = ["Saat", "Lig", "Ev", "Deplasman", "Oran 1", "X", "2", "Örnek", "Ev%", "Ber%", "Dep%",
               "Değerli taraf", "Fark", "GA alt", "GA üst", "Güven", "ROI%", "Ort.gol", "2.5Ü%", "KG%", "Sinyal", "Link"]
        ws.append(bas)
        for c in range(1, len(bas) + 1):
            ws.cell(1, c).font = Font(bold=True, color="FFFFFF")
            ws.cell(1, c).fill = PatternFill("solid", fgColor="1F4E79")
        for r in veri:
            ws.append([r["s"], r["l"], r["h"], r["a"], r["o"][0], r["o"][1], r["o"][2], r["n"],
                       r["d"][0], r["d"][1], r["d"][2], r.get("ad", ""), r.get("edge", ""),
                       (r.get("ci") or [""])[0], (r.get("ci") or ["", ""])[1], r.get("guv", ""),
                       r.get("roi", ""), r["ag"], r["o25"], r["kg"], "DEĞERLİ" if r.get("sinyal") else "", r["lnk"]])
        ws.freeze_panes = "A2"; ws.auto_filter.ref = ws.dimensions
        wb.save("/home/user/BULTEN.xlsx")
    except Exception as e:
        print("xlsx atlandı:", e)
    import csv
    with open("/home/user/BULTEN.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";"); w.writerow(bas)
        for r in veri:
            w.writerow([r["s"], r["l"], r["h"], r["a"], r["o"][0], r["o"][1], r["o"][2], r["n"],
                        r["d"][0], r["d"][1], r["d"][2], r.get("ad", ""), r.get("edge", ""),
                        (r.get("ci") or [""])[0], (r.get("ci") or ["", ""])[1], r.get("guv", ""),
                        r.get("roi", ""), r["ag"], r["o25"], r["kg"], "DEĞERLİ" if r.get("sinyal") else "", r["lnk"]])
    n_sin = sum(1 for r in veri if r.get("sinyal"))
    print(f"\n✅ BİTTİ ({round(time.time()-t0)} sn) — {len(veri)} maç, {n_sin} değer sinyali")
    print("   📋 /home/user/BULTEN.html   ← tarayıcıda aç (tek dosya, internet gerekmez)")
    print("   📊 /home/user/BULTEN.xlsx   ← Excel (sinyaller yeşil)")
    print("   📄 /home/user/BULTEN.csv    ← CSV")

if __name__ == "__main__":
    main()
