#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
İY (ilk yarı) ve 2. YARI skorlarını TOPLU çek — kalıcı önbellek.
Match sayfasından: (İY_h:İY_a, 2Y_h:2Y_a)
Kullanım: python3 ht_topla.py [işçi_sayısı]
Kaldığı yerden devam eder.
"""
import json, os, re, sys, time
sys.path.insert(0, "/home/user")
import analiz_motoru as M
from concurrent.futures import ThreadPoolExecutor

CACHE = "/home/user/veri/ht_cache.json"
GEREKLI = "/home/user/veri/ht_gerekli.json"

def yukle():
    return json.load(open(CACHE, encoding="utf-8")) if os.path.exists(CACHE) else {}

def kaydet(c):
    tmp = CACHE + ".tmp"
    json.dump(c, open(tmp, "w", encoding="utf-8"))
    os.replace(tmp, CACHE)

def cek(mid):
    """(ht_h, ht_a, h2_h, h2_a) döndür; bulunamazsa None."""
    try:
        h = M.curl(M.BASE + "/football/x/y/z/" + mid + "/", 20)  # yolu sadece id ile denemek çalışmıyor → tam link gerekli
    except Exception:
        return None
    return None

def cek_link(link):
    try:
        h = M.curl(M.BASE + link, 20)
        if not h: return None
        h = h.replace("&nbsp;", " ")
        x = re.search(r'id="js-partial">(.*?)</div>', h, re.S)
        if x:
            t = re.sub(r"<[^>]+>", "", x.group(1)).strip()
            mm = re.match(r"\((\d+):(\d+),\s*(\d+):(\d+)\)", t)
            if mm:
                return [int(mm.group(1)), int(mm.group(2)), int(mm.group(3)), int(mm.group(4))]
        # alternatif: <span> içinde
        mm = re.search(r'>\s*(\d+):(\d+)\s*\(\s*(\d+):(\d+),\s*(\d+):(\d+)\s*\)', h)
        if mm:
            return [int(mm.group(3)), int(mm.group(4)), int(mm.group(5)), int(mm.group(6))]
    except Exception:
        pass
    return None

def main():
    isci = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    cache = yukle()
    ids = json.load(open(GEREKLI, encoding="utf-8"))
    # link eşlemesi: all_matches.json'dan
    idx = {m["id"]: m["link"] for m in json.load(open("/home/user/veri/all_matches.json", encoding="utf-8"))}
    eksik = [i for i in ids if i not in cache]
    print(f"Toplam gerekli: {len(ids)} | önbellekte: {len(cache)} | çekilecek: {len(eksik)}", flush=True)
    t0 = time.time()
    n = 0
    while n < len(eksik):
        parca = eksik[n:n + 200]
        import random
        def w(i):
            time.sleep(random.uniform(0, 0.25))
            return i, cek_link(idx.get(i, ""))
        with ThreadPoolExecutor(max_workers=isci) as ex:
            for i, v in ex.map(w, parca):
                cache[i] = v
        n += len(parca)
        kaydet(cache)
        hz = n / max(1e-9, time.time() - t0)
        kal = (len(eksik) - n) / hz if hz else 0
        print(f"  {n}/{len(eksik)} | {hz:.1f} maç/s | kalan ~{int(kal/60)} dk {int(kal%60)} sn", flush=True)
    bulunan = sum(1 for v in cache.values() if v)
    print(f"BİTTİ: {len(cache)} kayıt, {bulunan} geçerli İY | {round(time.time()-t0)} sn", flush=True)

if __name__ == "__main__":
    main()
