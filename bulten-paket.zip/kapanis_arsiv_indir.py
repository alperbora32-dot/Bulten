#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""KAPANIŞ ARŞİVİ — football-data.co.uk'den açılış + KAPANIŞ oranları + sonuçlar.
Çıktı: veri/kapanis_arsiv.json → [{u,l,t,e,d,ac:[3],kp:[3],h,a}] (h/a = goller)
"""
import csv, io, json, os, sys, urllib.request, concurrent.futures as cf

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'}
KOK = '/home/user'
MAIN = {  # Div kodu → (ülke, lig)
    'E0': ('England', 'Premier League'), 'E1': ('England', 'Championship'),
    'E2': ('England', 'League One'), 'E3': ('England', 'League Two'), 'EC': ('England', 'National League'),
    'SC0': ('Scotland', 'Premiership'), 'SC1': ('Scotland', 'Championship'), 'SC2': ('Scotland', 'League One'),
    'SC3': ('Scotland', 'League Two'),
    'D1': ('Germany', 'Bundesliga'), 'D2': ('Germany', '2. Bundesliga'),
    'I1': ('Italy', 'Serie A'), 'I2': ('Italy', 'Serie B'),
    'SP1': ('Spain', 'LaLiga'), 'SP2': ('Spain', 'LaLiga 2'),
    'F1': ('France', 'Ligue 1'), 'F2': ('France', 'Ligue 2'),
    'N1': ('Netherlands', 'Eredivisie'), 'B1': ('Belgium', 'Pro League'),
    'P1': ('Portugal', 'Primeira Liga'), 'T1': ('Turkey', 'Super Lig'), 'G1': ('Greece', 'Super League'),
}
SEZONLAR = ['1314', '1415', '1516', '1617', '1718', '1819', '1920', '2021', '2122', '2223', '2324', '2425', '2526']
NEW = {
    'ARG': ('Argentina', 'Primera Division'), 'AUT': ('Austria', 'Bundesliga'),
    'BRA': ('Brazil', 'Serie A'), 'CHN': ('China', 'Super League'),
    'DNK': ('Denmark', 'Superliga'), 'FIN': ('Finland', 'Veikkausliiga'),
    'IRL': ('Ireland', 'Premier Division'), 'JPN': ('Japan', 'J1 League'),
    'MEX': ('Mexico', 'Liga MX'), 'NOR': ('Norway', 'Eliteserien'),
    'POL': ('Poland', 'Ekstraklasa'), 'ROU': ('Romania', 'Liga I'),
    'RUS': ('Russia', 'Premier League'), 'SWE': ('Sweden', 'Allsvenskan'),
    'SWZ': ('Switzerland', 'Super League'), 'USA': ('Usa', 'Mls'),
}


def sayi(x):
    try:
        v = float(str(x).strip())
        return v if 1.005 <= v <= 200 else None
    except Exception:
        return None


def uc3(row, adaylar):
    """Verilen kolon adaylarından ilk üçlü oran grubunu döndürür."""
    for a in adaylar:
        v = [sayi(row.get(a + s)) for s in ('H', 'D', 'A')]
        if all(v):
            m = sum(1 / x for x in v)
            if 1.005 <= m <= 1.35:
                return [round(x, 2) for x in v]
    return None


def csv_oku(veri):
    try:
        return list(csv.DictReader(io.StringIO(veri)))
    except Exception:
        return []


def isle(veri, ulke, lig):
    out = []
    for r in csv_oku(veri):
        try:
            hg, ag = int(r.get('FTHG') or r.get('HG')), int(r.get('FTAG') or r.get('AG'))
        except Exception:
            continue
        # tarih
        t = (r.get('Date') or r.get('MatchDate') or '').strip()
        sezon = (r.get('Season') or '').strip()
        ev = (r.get('HomeTeam') or r.get('Home') or '').strip()
        dp = (r.get('AwayTeam') or r.get('Away') or '').strip()
        if not (ev and dp and t):
            continue
        ih = ia = None
        try:
            ih, ia = int(r.get('HTHG')), int(r.get('HTAG'))
        except Exception:
            ih = ia = None
        kp = uc3(r, ['AvgC', 'PSCH', 'B365CH', 'MaxC', 'PSC', 'B365C', 'AvgCA']) or \
            uc3(r, ['PSCH', 'B365CH', 'AvgCH', 'PSCD', 'B365CD', 'AvgCD']) if False else \
            uc3(r, ['AvgC', 'PSCH', 'B365CH', 'AvgCA', 'PSC', 'B365C'])
        ac = uc3(r, ['Avg', 'PS', 'B365', 'Max', 'BFE', 'BMGM', 'CL', 'BV', 'BW', 'LB', 'BFD'])
        if not kp:
            continue
        out.append({'u': ulke, 'l': lig, 't': t, 's': sezon, 'e': ev, 'd': dp,
                    'ac': ac, 'kp': kp, 'hg': hg, 'ag': ag, 'ih': ih, 'ia': ia})
    return out


def indir(u):
    try:
        return urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=40).read().decode('utf-8', 'ignore')
    except Exception as e:
        return ''


def main():
    isler = []
    for kod, (ulke, lig) in MAIN.items():
        for sz in SEZONLAR:
            isler.append((f'https://football-data.co.uk/mmz4281/{sz}/{kod}.csv', ulke, lig))
    for kod, (ulke, lig) in NEW.items():
        isler.append((f'https://football-data.co.uk/new/{kod}.csv', ulke, lig))

    out, hata = [], 0
    with cf.ThreadPoolExecutor(10) as ex:
        futs = {ex.submit(indir, u): (u, ulke, lig) for u, ulke, lig in isler}
        for i, f in enumerate(cf.as_completed(futs), 1):
            v = f.result()
            if not v:
                hata += 1
                continue
            _, ulke, lig = futs[f]
            out.extend(isle(v, ulke, lig))
            if i % 40 == 0:
                print(f'  {i}/{len(isler)} dosya · {len(out)} maç', flush=True)
    json.dump(out, open(f'{KOK}/veri/kapanis_arsiv.json', 'w', encoding='utf-8'), ensure_ascii=False)
    from collections import Counter
    print(f'BİTTİ: {len(out)} maç · {len({(x["u"],x["l"]) for x in out})} lig · hata {hata}')
    print('ligler:', Counter((x['u'] + '/' + x['l']) for x in out).most_common(8))
    n_kp = sum(1 for x in out if x['kp'])
    n_ac = sum(1 for x in out if x['ac'])
    n_ht = sum(1 for x in out if x.get('ih') is not None)
    print('kapanış oranlı:', n_kp, '| açılış oranlı:', n_ac, '| İY skorlu:', n_ht,
          '(%%%.0f)' % (n_ht * 100.0 / max(1, len(out))))


if __name__ == '__main__':
    main()
