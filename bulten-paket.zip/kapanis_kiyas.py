#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""KAPANIŞ ORANI KIYAS MOTORU — "aynı kapanış oranıyla açılmış/bitmiş maçlar".
Açılış bazlı motorun (tam_tarama.eslesen) kapanış eşdeğeri:
hedef maçın kapanış oranına ±tolerans içinde kapanan TÜM maçlar bulunur,
sonuçları (MS, gol, KG, skorlar) kendi ligi ve tüm ligler için özetlenir.
"""
import bisect, json, re

YOL = '/home/user/veri/kapanis_arsiv.json'

# bülten lig adı → arşiv (ülke, lig) eşlemesi
SYN = {
    'premier league': ('England', 'Premier League'), 'championship': ('England', 'Championship'),
    'league one': ('England', 'League One'), 'league two': ('England', 'League Two'),
    'national league': ('England', 'National League'), 'efl trophy': None,
    'laliga': ('Spain', 'LaLiga'), 'la liga': ('Spain', 'LaLiga'), 'primera division': ('Spain', 'LaLiga'),
    'laliga 2': ('Spain', 'LaLiga 2'), 'segunda division': ('Spain', 'LaLiga 2'),
    'serie a': ('Italy', 'Serie A'), 'serie b': ('Italy', 'Serie B'),
    'bundesliga': ('Germany', 'Bundesliga'), '2. bundesliga': ('Germany', '2. Bundesliga'),
    'ligue 1': ('France', 'Ligue 1'), 'ligue 2': ('France', 'Ligue 2'),
    'eredivisie': ('Netherlands', 'Eredivisie'), 'pro league': ('Belgium', 'Pro League'),
    'primeira liga': ('Portugal', 'Primeira Liga'), 'liga portugal': ('Portugal', 'Primeira Liga'),
    'super lig': ('Turkey', 'Super Lig'), 'süper lig': ('Turkey', 'Super Lig'),
    'super league': ('Greece', 'Super League'), 'superliga': ('Denmark', 'Superliga'),
    'premiership': ('Scotland', 'Premiership'), 'mls': ('Usa', 'Mls'), 'major league soccer': ('Usa', 'Mls'),
    'liga mx': ('Mexico', 'Liga MX'), 'brasileirao': ('Brazil', 'Serie A'), 'j1 league': ('Japan', 'J1 League'),
    'allsvenskan': ('Sweden', 'Allsvenskan'), 'eliteserien': ('Norway', 'Eliteserien'),
    'ekstraklasa': ('Poland', 'Ekstraklasa'), 'liga i': ('Romania', 'Liga I'),
    'veikkausliiga': ('Finland', 'Veikkausliiga'), 'a-league': None,
}
ULKE_TR = {'england': 'İngiltere', 'scotland': 'İskoçya', 'germany': 'Almanya', 'italy': 'İtalya',
           'spain': 'İspanya', 'france': 'Fransa', 'netherlands': 'Hollanda', 'belgium': 'Belçika',
           'portugal': 'Portekiz', 'turkey': 'Türkiye', 'greece': 'Yunanistan', 'argentina': 'Arjantin',
           'austria': 'Avusturya', 'brazil': 'Brezilya', 'china': 'Çin', 'denmark': 'Danimarka',
           'finland': 'Finlandiya', 'ireland': 'İrlanda', 'japan': 'Japonya', 'mexico': 'Meksika',
           'norway': 'Norveç', 'poland': 'Polonya', 'romania': 'Romanya', 'russia': 'Rusya',
           'sweden': 'İsveç', 'switzerland': 'İsviçre', 'usa': 'ABD'}


def _tarih_k(z):
    """Tarihi sıralanabilir hale getirir (gg/aa/yyyy, yyyy-aa-gg, aa/gg/yyyy)."""
    t = (z[5] or '').strip()
    for bicim in ('%d/%m/%Y', '%Y-%m-%d', '%m/%d/%Y', '%d/%m/%y'):
        try:
            from datetime import datetime as _d
            return _d.strptime(t, bicim).toordinal()
        except Exception:
            pass
    return 0


def norm(s):
    return re.sub(r'[^a-z0-9]', '', (s or '').lower())


class KAPO:
    """Kapanış oranı arşivi + hızlı kıyas."""

    def __init__(self, yol=YOL):
        self.m = json.load(open(yol, encoding='utf-8'))
        self.sat = []
        for x in self.m:
            kp = x.get('kp')
            if not kp:
                continue
            self.sat.append((kp[0], kp[1], kp[2], norm(x['l']), norm(x['u']), x.get('t', ''),
                             x.get('e', ''), x.get('d', ''), x.get('hg', 0), x.get('ag', 0), kp,
                             x.get('ih'), x.get('ia'), x.get('l', ''), ULKE_TR.get((x.get('u') or '').lower(), x.get('u', ''))))
        self.sat.sort(key=lambda z: z[0])
        self.ilk = [z[0] for z in self.sat]
        self.lig_sat = {}
        for z in self.sat:
            self.lig_sat.setdefault(z[3], []).append(z)
        self.lig_ilk = {k: [z[0] for z in v] for k, v in self.lig_sat.items()}
        self._onbellek = {}

    # ---------------------------------------------------------------- kıyas
    def _ozet(self, L):
        if not L:
            return None
        n = len(L)
        ev = sum(1 for z in L if z[8] > z[9])
        ber = sum(1 for z in L if z[8] == z[9])
        dep = n - ev - ber
        goller = [z[8] + z[9] for z in L]
        u25 = sum(1 for g in goller if g > 2.5) * 100.0 / n
        kg = sum(1 for z in L if z[8] and z[9]) * 100.0 / n
        from collections import Counter
        sk = Counter(f'{z[8]}-{z[9]}' for z in L).most_common(3)
        # --- İLK YARI (İY) istatistikleri ---
        iyL = [z for z in L if z[11] is not None]
        iy = None
        if len(iyL) >= 5:
            ni = len(iyL)
            evi = sum(1 for z in iyL if z[11] > z[12])
            beri = sum(1 for z in iyL if z[11] == z[12])
            depi = ni - evi - beri
            gi = [z[11] + z[12] for z in iyL]
            ski = Counter(f'{z[11]}-{z[12]}' for z in iyL).most_common(3)
            iy = {'n': ni, 'kaps': int(round(ni * 100.0 / n)),
                  'ms': [round(evi * 100.0 / ni, 1), round(beri * 100.0 / ni, 1), round(depi * 100.0 / ni, 1)],
                  'ort': round(sum(gi) / ni, 2),
                  's00': round(sum(1 for z in iyL if z[11] == 0 and z[12] == 0) * 100.0 / ni, 1),
                  's15': round(sum(1 for x in gi if x > 1.5) * 100.0 / ni, 1),
                  'kg': round(sum(1 for z in iyL if z[11] and z[12]) * 100.0 / ni, 1),
                  'ayni': round(sum(1 for z in iyL if ((z[11] > z[12]) == (z[8] > z[9])) and
                                  ((z[11] == z[12]) == (z[8] == z[9]))) * 100.0 / ni, 1),
                  'skor': [[s2, round(p * 100.0 / ni, 1)] for s2, p in ski]}
        return {'n': n,
                'ms': [round(ev * 100.0 / n, 1), round(ber * 100.0 / n, 1), round(dep * 100.0 / n, 1)],
                'ort': round(sum(goller) / n, 2), 'u25': round(u25, 1), 'kg': round(kg, 1),
                'skor': [[s, round(p * 100.0 / n, 1)] for s, p in sk],
                        'kaporan': [round(sum(z[10][0] for z in L) / n, 2), round(sum(z[10][1] for z in L) / n, 2),
                            round(sum(z[10][2] for z in L) / n, 2)],
                'iy': iy}

    def _aday_lig(self, kap, tol, lig_n):
        """Sadece o ligin içinde ara (hızlı)."""
        sat = self.lig_sat.get(lig_n)
        if not sat:
            return []
        ilk = self.lig_ilk[lig_n]
        a = bisect.bisect_left(ilk, kap[0] * (1 - tol))
        b = bisect.bisect_right(ilk, kap[0] * (1 + tol))
        s1, s2 = max(kap[1] * tol, 0.06), max(kap[2] * tol, 0.06)
        return [z for z in sat[a:b] if abs(z[1] - kap[1]) <= s1 and abs(z[2] - kap[2]) <= s2]

    def _aday(self, kap, tol):
        """Göreli tolerans: her bacak ±tol (en az 0.06 mutlak)."""
        a = bisect.bisect_left(self.ilk, kap[0] * (1 - tol))
        b = bisect.bisect_right(self.ilk, kap[0] * (1 + tol))
        s1 = max(kap[1] * tol, 0.06)
        s2 = max(kap[2] * tol, 0.06)
        return [z for z in self.sat[a:b] if abs(z[1] - kap[1]) <= s1 and abs(z[2] - kap[2]) <= s2]

    def kiyas(self, kap, lig=None, ulke=None, en_az=12, en_buyuk_tol=0.35):
        """kap = [1,X,2] kapanış oranı. Kendi lig + tüm ligler özeti döndürür."""
        kap = [round(float(x), 2) for x in kap]
        anahtar = (tuple(kap), norm(lig), norm(ulke))
        if anahtar in self._onbellek:
            return self._onbellek[anahtar]
        hedef = SYN.get((lig or '').strip().lower())
        if hedef is None and lig:
            hedef = (ulke, lig) if ulke else None
        sonuc = {'kap': kap, 'lig': None, 'tum': None, 'tol': None, 'tolg': None}
        # --- tüm ligler: en sıkı toleranstan başla, en fazla %6 ---
        A, tol = [], 0.02
        for tol in (0.02, 0.03, 0.045, 0.06):
            A = self._aday(kap, tol)
            if len(A) >= 25 or tol == 0.06:
                break
        # --- kendi ligi: lig indeksinde ara, %13'e kadar genişlet ---
        lig_n = norm(hedef[1]) if hedef else norm(lig)
        L, tolg = [], 0.02
        for tolg in (0.02, 0.03, 0.045, 0.06, 0.09, 0.13):
            L = self._aday_lig(kap, tolg, lig_n) if lig_n else []
            if len(L) >= 8 or tolg == 0.13:
                break
        if A or L:
            sonuc['tol'] = int(round(tol * 100))
            sonuc['tolg'] = int(round(tolg * 100))
            if len(L) >= 6:
                sonuc['lig'] = self._ozet(L)
                sonuc['lig_adi'] = (hedef[1] if hedef else lig)
                sonuc['lig_ulke'] = ULKE_TR.get((hedef[0] if hedef else ulke or '').lower(), (hedef[0] if hedef else ulke or ''))
            if len(A) >= 25:
                sonuc['tum'] = self._ozet(A)
            def _satir(S, cap):
                return [[z[5], z[6], z[7], f'{z[8]}-{z[9]}',
                         '/'.join(f'{v:.2f}' for v in z[10]),
                         (f'{z[11]}-{z[12]}' if z[11] is not None else ''), (z[13] or '')]
                        for z in sorted(S, key=_tarih_k, reverse=True)[:cap]]
            sonuc['ornek'] = _satir(L, 800)          # kendi ligi → tamamı
            sonuc['ornek_t'] = _satir(A, 3000)       # tüm ligler → tamamı (üst sınır çok yüksek)
            sonuc['ornek_kaynak'] = 'lig' if L else 'tum'
        for k in ('lig', 'tum'):
            pass
        if len(self._onbellek) > 4000:
            self._onbellek.clear()
        self._onbellek[anahtar] = sonuc
        return sonuc


if __name__ == '__main__':
    k = KAPO()
    print('arşiv:', len(k.sat), 'maç')
    t = k.kiyas([2.35, 3.20, 3.00], lig='Serie B', ulke='Italy')
    print('Serie B örneği:', json.dumps(t, ensure_ascii=False)[:400])
    t2 = k.kiyas([1.80, 3.60, 4.20], lig='Premier League', ulke='England')
    print('PL örneği → lig:', t2.get('lig', {}).get('n'), 'tüm:', t2.get('tum', {}).get('n'), 'tol', t2.get('tol'))
    print('örnekler:', t2.get('ornek', [])[:3])
