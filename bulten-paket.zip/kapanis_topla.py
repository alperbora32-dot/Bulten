#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OYNANMIŞ MAÇLARIN KAPANIŞ ORANLARINI TOPLA (geri doldurma).

Bugün oynanmış/başlamış olup kapanış kaydı olmayan maçlar için BetExplorer oran
sayfasındaki güncel ortalamayı çeker ve kapanış olarak kaydeder:
  · maç bitti/bitmek üzere (başlaması 150 dk+)  → "sayfa-kapanış" (gerçek kapanış)
  · maç hâlâ oynanıyor                          → "canlı-sayfa"   (yaklaşık, etiketli)
Kayıtlar veri/kapanis.json içine yazılır; CLV de yeniden hesaplanır.
"""
import json, os, re, sys, time, random, urllib.request, concurrent.futures as cf
from datetime import datetime

KOK = '/home/user'
sys.path.insert(0, KOK)
import saat as SA

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'}
KAPANIS = f'{KOK}/veri/kapanis.json'
ISCI = 3


def oku(yol, v):
    try:
        return json.load(open(yol, encoding='utf-8'))
    except Exception:
        return v


def oran_cek(mid):
    for d in range(3):
        try:
            h = json.loads(urllib.request.urlopen(
                urllib.request.Request('https://www.betexplorer.com/match-odds/%s/1/1x2/odds/' % mid, headers=UA),
                timeout=25).read().decode('utf-8', 'ignore'))['odds']
            ort = [x for x in re.findall(r'oddsComparisonAll__average_text"\s+data-odd="([\d.]*)"', h) if x]
            if len(ort) >= 3:
                o = [round(float(x), 2) for x in ort[:3]]
            else:
                ucl = []
                for tr in re.findall(r'<tr[\s\S]*?</tr>', h):
                    v = re.findall(r'data-odd="([\d.]+)"', tr)
                    if len(v) == 3:
                        ucl.append([float(v[0]), float(v[1]), float(v[2])])
                if not ucl:
                    return None
                o = [round(sum(x[i] for x in ucl) / len(ucl), 2) for i in range(3)]
            return o if 1.005 <= sum(1 / x for x in o) <= 1.4 else None
        except Exception:
            time.sleep(1.2 + d * 1.5 + random.random())
    return None


def main(hepsi=False):
    simdi = SA.simdi()
    f = SA.fark_ogren()
    ms = [m for m in oku(f'{KOK}/veri/tam_tarama.json', []) if m.get('o') and m.get('id')]
    kap = oku(KAPANIS, {'kapanis': {}, 'ozet': {}})
    KAP = kap.get('kapanis', {})
    hedef = []
    for m in ms:
        saat, gk = SA.tr(m.get('saat'), f)
        try:
            hh, mm = saat.split(':')
            ko = simdi.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
        except Exception:
            continue
        if gk:                       # ertesi gün sabaha karşı → henüz oynanmadı
            continue
        gecen = (simdi - ko).total_seconds() / 60.0
        if gecen < 0:                # başlamadı
            continue
        kayit = KAP.get(m['id'])
        if kayit and not hepsi:
            continue
        hedef.append((m, gecen, saat))
    print(f'hedef: {len(hedef)} oynanmış maç · TR {simdi.strftime("%H:%M")}', flush=True)

    yeni = 0
    with cf.ThreadPoolExecutor(ISCI) as ex:
        futs = {ex.submit(oran_cek, m['id']): (m, gecen, saat) for m, gecen, saat in hedef}
        for i, fu in enumerate(cf.as_completed(futs), 1):
            o = fu.result()
            m, gecen, saat = futs[fu]
            if o:
                p = m.get('en_iyi')
                kayit = {'kapanis': o, 'acilis': [round(x, 2) for x in m['o']],
                         'hareket': [round((o[j] / m['o'][j] - 1) * 100, 1) if m['o'][j] else 0.0 for j in range(3)],
                         'saat': saat, 'h': m.get('home', ''), 'a': m.get('away', ''),
                         'lig': m.get('lig', ''),
                         'kaynak': ('sayfa-kapanış' if gecen >= 150 else 'canlı-sayfa'),
                         'son_cekim': simdi.strftime('%H:%M')}
                if m.get('gk'):
                    kayit['gk'] = 1
                if p:
                    j = {'Ev': 0, 'Beraberlik': 1, 'Deplasman': 2}.get(p.get('ad'))
                    if j is not None and o[j]:
                        kayit.update(sinyal=p.get('ad'), sinyal_oran=round(p.get('oran', 0), 2),
                                     clv=round((p.get('oran', 0) / o[j] - 1) * 100, 1))
                KAP[m['id']] = kayit
                yeni += 1
            if i % 40 == 0:
                json.dump({'kapanis': KAP, 'ozet': kap.get('ozet', {})}, open(KAPANIS, 'w', encoding='utf-8'),
                          ensure_ascii=False)
                print(f'  {i}/{len(hedef)} · kaydedilen {yeni}', flush=True)

    clv = [k['clv'] for k in KAP.values() if k.get('clv') is not None]
    ozet = {'n': len(clv), 'ort_clv': round(sum(clv) / len(clv), 2) if clv else 0,
            'pozitif': sum(1 for x in clv if x > 0), 'guncelleme': simdi.strftime('%d.%m %H:%M')}
    json.dump({'kapanis': KAP, 'ozet': ozet}, open(KAPANIS, 'w', encoding='utf-8'), ensure_ascii=False)
    src = {}
    for k in KAP.values():
        src[k.get('kaynak', 'izleme')] = src.get(k.get('kaynak', 'izleme'), 0) + 1
    print(f'BİTTİ: yeni {yeni} · toplam kapanış {len(KAP)} · kaynak dağılımı {src}')
    print(f'CLV: {ozet["n"]} sinyal · ortalama {ozet["ort_clv"]:+.2f}% · pozitif {ozet["pozitif"]}')


if __name__ == '__main__':
    main('hepsi' in sys.argv)
