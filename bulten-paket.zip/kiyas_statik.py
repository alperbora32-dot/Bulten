#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""KİYAS STATİK — bugünün maçları için /kiyas sayfalarını statik dosya olarak üretir.

Her maç için: açılış oranı kıyası (tüm maçlar) + kapanış oranı kıyası (kendi ligi + tüm ligler).
Çıktı: <hedef>/kiyas/<mid>.html   (hedef varsayılan: _site)
"""
import html as H, json, os, sys
from datetime import datetime

KOK = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, KOK)

CSS = ("body{margin:0;background:#f6f7f9;color:#16212e;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif}"
       ".wrap{max-width:1100px;margin:0 auto;padding:14px 12px 60px}"
       ".card{background:#fff;border:1px solid #e3e8ee;border-radius:12px;padding:12px 14px;margin:10px 0}"
       ".mini{font-size:11.5px;color:#68788a}h3{margin:0 0 8px;font-size:14px;color:#0d5c3a}"
       "table.kt{width:100%;border-collapse:collapse}table.kt th{background:#f2f5f8;text-align:left;padding:6px 7px;font-size:12px;position:sticky;top:0}"
       "table.kt td{padding:5px 7px;border-bottom:1px solid #eef1f4;font-size:12.5px}table.kt tr:hover td{background:#f6fbff}"
       "td.b{font-weight:700}a{color:#0969da}.sar{max-height:70vh;overflow:auto}")


def _tr(es, ht, cap=None):
    L = sorted(es, key=lambda z: z.get("date", ""), reverse=True)
    if cap:
        L = L[:cap]
    return "".join(
        "<tr><td>%s</td><td>%s - %s</td><td class='b'>%d:%d</td><td class='b'>%s</td>"
        "<td>%.2f / %.2f / %.2f</td><td class='mini'>%s</td></tr>"
        % (H.escape(c.get("date", "")), H.escape(c.get("home", "")), H.escape(c.get("away", "")),
           c.get("hg", 0), c.get("ag", 0),
           (("%d:%d" % (ht[c["id"]][0], ht[c["id"]][1])) if ht.get(c["id"]) else ""),
           c.get("o1", 0), c.get("ox", 0), c.get("o2", 0),
           H.escape((c.get("league") or "").strip("/").split("/")[2].replace("-", " ").title()
                    if len((c.get("league") or "").strip("/").split("/")) > 2 else ""))
        for c in L)


def kp_tablo(ad, L, notu=""):
    if not L:
        return ""
    return ("<div class='card'><h3>%s — %d maç</h3><div class='mini'>%s</div>"
            "<div class='sar'><table class='kt'><thead><tr><th>Tarih</th><th>Maç</th><th>MS</th><th>İY</th>"
            "<th>Kapanış oranı</th><th>Lig</th></tr></thead><tbody>%s</tbody></table></div></div>"
            % (ad, len(L), notu,
               "".join("<tr><td>%s</td><td>%s - %s</td><td class='b'>%s</td><td class='b'>%s</td><td>%s</td>"
                       "<td class='mini'>%s</td></tr>"
                       % (H.escape(z[0]), H.escape(z[1]), H.escape(z[2]), H.escape(z[3]),
                          H.escape(z[5] or "–"), H.escape(z[4]), H.escape(z[6] or "")) for z in L)))


def uret(hedef="_site", en_az=25, ust_sinir=60):
    import tam_tarama as TT
    import detay as DE
    kdir = os.path.join(hedef, "kiyas")
    os.makedirs(kdir, exist_ok=True)
    bugun = datetime.now().strftime("%d.%m.%Y")
    tt = [m for m in json.load(open(f"{KOK}/veri/tam_tarama.json", encoding="utf-8"))
          if m.get("o") and m.get("n") and m.get("gun") and m["gun"].endswith("-11")]
    try:
        krec = json.load(open(f"{KOK}/veri/kapanis.json", encoding="utf-8")).get("kapanis", {})
    except Exception:
        krec = {}
    ms, o1s = TT.arsiv()
    ht = DE.ht()
    aday = sorted(tt, key=lambda m: -(m.get("n") or 0))[:ust_sinir]
    yapilan = 0
    for m in aday:
        if (m.get("n") or 0) < en_az:
            continue
        es = TT.eslesen(ms, o1s, m["o"], m.get("tol_k") or 0.12)
        kk = krec.get(m["id"]) or {}
        g = ["<div class='card'><h2 style='margin:0;font-size:18px'>%s - %s</h2>"
             "<div class='mini'>%s · %s · açılış %.2f / %.2f / %.2f%s</div></div>"
             % (H.escape(m.get("home", "")), H.escape(m.get("away", "")), H.escape(m.get("lig", "")),
                H.escape(m.get("saat", "")), m["o"][0], m["o"][1], m["o"][2],
                ((" · kapanış " + " / ".join("%.2f" % x for x in kk["kapanis"])) if kk.get("kapanis") else ""))]
        g.append("<div class='card'><h3>AÇILIŞ ORANI KIYASI — %d maç</h3>"
                 "<div class='sar'><table class='kt'><thead><tr><th>Tarih</th><th>Maç</th><th>MS</th><th>İY</th>"
                 "<th>Açılış oranı</th><th>Lig</th></tr></thead><tbody>%s</tbody></table></div></div>"
                 % (len(es), _tr(es, ht)))
        try:
            import kapanis_kiyas as KK
            if kk.get("kapanis"):
                kap = KK.KAPO().kiyas(kk["kapanis"], lig=m.get("lig"), ulke=None)
                g.append("<div class='card'><h3>📉 KAPANIŞ ORANI KIYASI — kapanış %.2f / %.2f / %.2f (±%%%s)</h3></div>"
                         % (kap["o"][0], kap["o"][1], kap["o"][2], kap.get("tol")))
                g.append(kp_tablo("KENDİ LİGİ — %s" % H.escape(kap.get("lig_adi", "")), kap.get("ornek") or [],
                                  "aynı kapanış oranıyla biten maçlar"))
                g.append(kp_tablo("TÜM LİGLER", kap.get("ornek_t") or [],
                                  "ülke/lig fark etmeksizin aynı kapanış oranıyla biten maçlar"))
        except Exception:
            pass
        nav = ("<div style='max-width:1100px;margin:0 auto;padding:10px 12px 0'>"
               "<a href='../index.html'>← bülten</a> · <a href='../canli.html'>🔴 canlı</a></div>")
        belge = ("<!DOCTYPE html><html lang='tr'><head><meta charset='utf-8'>"
                 "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                 "<title>Kıyas — %s</title><style>%s</style></head><body>%s<div class='wrap'>%s</div></body></html>"
                 % (H.escape(m.get("home", "")), CSS, nav, "".join(g)))
        open(os.path.join(kdir, "%s.html" % m["id"]), "w", encoding="utf-8").write(belge)
        yapilan += 1
    print("kiyas sayfası: %d maç (%s) → %s" % (yapilan, bugun, kdir))
    return yapilan


if __name__ == "__main__":
    uret(sys.argv[1] if len(sys.argv) > 1 else "_site")
