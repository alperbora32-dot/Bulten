#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""KORNER VERİSİ — soccerstats'tan ülke bazlı takım korner ortalamaları (kalıcı önbellek)."""
import json, os, re, subprocess, sys, time, html as H
from concurrent.futures import ThreadPoolExecutor

CACHE = "/home/user/veri/korner_cache.json"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
SLUG = {"england": "england", "spain": "spain", "italy": "italy", "germany": "germany", "france": "france",
        "turkey": "turkey", "netherlands": "netherlands", "portugal": "portugal", "belgium": "belgium",
        "scotland": "scotland", "russia": "russia", "greece": "greece", "austria": "austria",
        "switzerland": "switzerland", "denmark": "denmark", "norway": "norway", "sweden": "sweden",
        "poland": "poland", "czech-republic": "czechrepublic", "romania": "romania", "ukraine": "ukraine",
        "croatia": "croatia", "serbia": "serbia", "bulgaria": "bulgaria", "hungary": "hungary",
        "slovakia": "slovakia", "finland": "finland", "ireland": "ireland", "israel": "israel",
        "japan": "japan", "south-korea": "southkorea", "china": "china", "australia": "australia",
        "brazil": "brazil", "argentina": "argentina", "usa": "usa", "mexico": "mexico",
        "chile": "chile", "colombia": "colombia", "peru": "peru", "uruguay": "uruguay", "ecuador": "ecuador",
        "saudi-arabia": "saudiarabia", "egypt": "egypt", "morocco": "morocco", "tunisia": "tunisia",
        "algeria": "algeria", "south-africa": "southafrica", "nigeria": "nigeria", "india": "india",
        "indonesia": "indonesia", "thailand": "thailand", "vietnam": "vietnam", "iceland": "iceland",
        "cyprus": "cyprus", "belarus": "belarus", "slovenia": "slovenia", "bosnia-and-herzegovina": "bosnia",
        "kazakhstan": "kazakhstan", "iran": "iran", "qatar": "qatar", "united-arab-emirates": "uae",
        "canada": "canada", "costa-rica": "costarica", "honduras": "honduras", "guatemala": "guatemala"}

def curl(u, n=25):
    try:
        r = subprocess.run(["curl", "-sL", "-m", str(n), "-A", UA, u], capture_output=True, timeout=n + 8)
        return r.stdout.decode("utf-8", "ignore")
    except Exception:
        return ""

def _yukle():
    return json.load(open(CACHE, encoding="utf-8")) if os.path.exists(CACHE) else {}

def _kaydet(c):
    json.dump(c, open(CACHE, "w", encoding="utf-8"))

def ulke_korner(slug):
    """Bir ülkenin lig korner tablosu: {takım_adı: {for, ag, tot, n}}"""
    h = curl(f"https://www.soccerstats.com/table.asp?league={slug}&tid=cr")
    if len(h) < 50000: return None
    data = {}
    for r in re.findall(r"<tr[^>]*>(.*?)</tr>", h, re.S):
        if "Statistics" in r: continue
        cells = [H.unescape(re.sub(r"<[^>]+>", "", c)).replace("\xa0", " ").strip()
                 for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", r, re.S)]
        cells = [c for c in cells if c]
        if len(cells) < 4: continue
        nm = cells[0]
        if not nm or nm[0].isdigit(): continue
        nums = []
        for c in cells[1:]:
            if re.fullmatch(r"\d+\.\d+", c) or re.fullmatch(r"\d+", c): nums.append(float(c))
        if len(nums) < 4: continue
        k = nm.lower()
        if k not in data or nums[0] > data[k]["n"]:
            data[k] = {"name": nm, "n": nums[0], "for": nums[1], "ag": nums[2], "tot": nums[3]}
    return data or None

def topla(ulkeler=None, isci=8):
    c = _yukle()
    hedef = ulkeler or [v for v in set(SLUG.values())]
    eksik = [s for s in hedef if s not in c or not c[s]]
    print(f"korner: önbellekte {len(c)} ülke, çekilecek {len(eksik)}", flush=True)
    if eksik:
        def w(s): return s, ulke_korner(s)
        with ThreadPoolExecutor(max_workers=isci) as ex:
            for s, v in ex.map(w, eksik):
                c[s] = v
        _kaydet(c)
        print(f"  bitti: {sum(1 for v in c.values() if v)} ülke verisi", flush=True)
    return c

def bul(ulke_slug, ev, dep, veri=None):
    """(beklenen_toplam, ev_for, ev_ag, dep_for, dep_ag, lig_ort) veya None"""
    veri = veri if veri is not None else _yukle()
    ss = SLUG.get((ulke_slug or "").lower())
    if not ss: return None
    d = veri.get(ss)
    if not d: return None
    def m(ad):
        if not ad: return None
        a = H.unescape(ad).lower().replace(".", " ").replace("'", "")
        a = re.sub(r"\b(fc|sc|ac|cf|if|fk|sk|bk|cd|ca|club|de|the)\b", " ", a)
        a = re.sub(r"\s+", " ", a).strip()
        if a in d: return d[a]
        for k, v in d.items():
            kk = re.sub(r"\b(fc|sc|ac|cf|if|fk|sk|bk|cd|ca|club|de|the)\b", " ", k)
            kk = re.sub(r"\s+", " ", kk).strip()
            if a[:6] and (kk.startswith(a[:6]) or a.startswith(kk[:6])): return v
        return None
    A, B = m(ev), m(dep)
    lig_ort = round(sum(v["tot"] for v in d.values()) / len(d), 1) if d else None
    if not A or not B:
        # lig ortalamasına düş (kaba ama kullanılabilir tahmin)
        if lig_ort:
            return {"lig_ort": lig_ort, "takim_yok": True,
                    "ev": A["name"] if A else None, "dep": B["name"] if B else None,
                    "tot": lig_ort, "pick": ("ÜST 9.5" if lig_ort >= 9.5 else "ALT 9.5"),
                    "guc": round(abs(lig_ort - 9.5), 1), "kaynak": "lig ortalaması"}
        return {"lig_ort": lig_ort, "ev": A["name"] if A else None, "dep": B["name"] if B else None}
    ev_k = round((A["for"] + B["ag"]) / 2, 1)
    dep_k = round((B["for"] + A["ag"]) / 2, 1)
    tot = round(ev_k + dep_k, 1)
    return {"ev": A["name"], "dep": B["name"], "ev_k": ev_k, "dep_k": dep_k, "tot": tot,
            "ev_for": A["for"], "ev_ag": A["ag"], "dep_for": B["for"], "dep_ag": B["ag"],
            "lig_ort": lig_ort,
            "pick": "ÜST 9.5" if tot >= 9.5 else "ALT 9.5",
            "guc": round(abs(tot - 9.5), 1)}

if __name__ == "__main__":
    t0 = time.time()
    c = topla()
    print(f"{round(time.time()-t0)}s | örnek:", bul("england", "Liverpool", "Crystal Palace", c))
    print("             ", bul("turkey", "Galatasaray", "Fenerbahce", c))
    print("             ", bul("japan", "Kyoto", "Kashiwa Reysol", c))
