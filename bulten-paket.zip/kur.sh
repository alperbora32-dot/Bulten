#!/bin/bash
# ============================================================================
#  KUR — paketi bulunduğun dizine uyarlar (tek seferlik)
#  Kullanım:  bash kur.sh
#  Ne yapar:  betiklerdeki sabit yolları (/home/user) kurulum dizinine çevirir,
#             numpy kontrolü yapar, ilk veri tazelemesini önerir.
# ============================================================================
set -e
HEDEF="$(cd "$(dirname "$0")" && pwd)"
cd "$HEDEF" || exit 1

echo "═══ KURULUM DİZİNİ: $HEDEF ═══"

if [ "$HEDEF" = "/home/user" ]; then
  echo "✓ Yollar zaten doğru (varsayılan dizin)."
else
  echo "→ Betiklerdeki yollar güncelleniyor: /home/user → $HEDEF"
  N=0
  for f in *.py; do
    if grep -q "/home/user" "$f" 2>/dev/null; then
      sed -i.bak "s|/home/user|$HEDEF|g" "$f" && rm -f "$f.bak"
      N=$((N + 1))
    fi
  done
  echo "✓ $N dosya güncellendi"
fi

echo "→ gerekli paketler kontrolü…"
if python3 -c "import numpy" 2>/dev/null; then
  echo "✓ numpy var"
else
  echo "  numpy yok, kuruluyor…"
  if echo "$PREFIX" | grep -q com.termux; then
    pkg install -y python-numpy || pip install --quiet numpy || { echo "✗ kurulamadı"; exit 1; }
  else
    pip install --quiet numpy || pip3 install --quiet numpy || { echo "✗ kurulamadı — elle: pip install numpy"; exit 1; }
  fi
fi
if python3 -c "import openpyxl" 2>/dev/null; then
  echo "✓ openpyxl var (Excel çıktısı açık)"
else
  pip install --quiet openpyxl 2>/dev/null && echo "✓ openpyxl kuruldu (Excel çıktısı açık)" || echo "· openpyxl yok — sorun değil, sadece .xlsx üretilmez"
fi

# ---- ilk kurulumda veri dosyaları yerinde mi? ----
for f in veri/kapanis_arsiv.json veri/all_matches.json veri/tam_tarama.json; do
  if [ ! -f "$f" ]; then
    echo "⚠ eksik veri dosyası: $f"
    echo "  → pakette olduğundan emin ol; ya da 'python3 baslat.py --taze' ile yeniden çekilir"
  fi
done
echo "→ veri dosyaları kontrol edildi"

echo
echo "✔ Kurulum tamam. Sıradaki adım:"
echo "    bash baslat.sh --taze        # veriyi tazele + sunucuyu başlat  (Windows: python baslat.py --taze)"
echo "  Tarayıcıdan:  http://localhost:8000/bulten"
echo
echo "  Günlük tazeleme:  bash guncelle.sh"
