#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ANALİZ MOTORU v2.0 — genişletilmiş algoritma katmanı
v1'e eklenenler:
  • AÇILIŞ oranına göre ekran + birebir açılış eşleşmesi (bet365 arşiv timeline'ından doğrulanır)
  • Uyum skoru (0-100): oranların göreli yakınlığı
  • Zaman ağırlıklı istatistik (yarı ömür 3 yıl) — eski maçlar daha az etkiler
  • Wilson %95 güven aralığı (küçük örneklemde dürüst bant)
  • Güven skoru (örneklem × etki × yıllar arası tutarlılık)
  • Kelly kriteri ile önerilen stake (¼ Kelly)
  • Lig / yıl / skor / gol dağılım kırılımları
  • Oran hareketi isabet testi (açılış→kapanış yönü sonucu tahmin ediyor mu?)
  • Hareket şiddeti, volatilite, piyasa uzlaşması metrikleri
"""
import json, math, re, time, os, html as H
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from collections import Counter, defaultdict
import analiz_motoru as M

BUGUN = datetime(2026, 9, 11)
OUT = "/home/user/veri"

# ------------------------------------------------------------------ yardımcı
def pdate(s):
    try: return datetime.strptime(str(s).strip(), "%d.%m.%Y")
    except Exception: return None

def yas_yil(s):
    d = pdate(s)
    return 99.0 if not d else max(0.0, (BUGUN - d).days / 365.25)

def rec_w(s, half_life=3.0):
    return 0.5 ** (yas_yil(s) / half_life)

def wrate(ms, pred, half_life=3.0):
    """Zaman ağırlıklı yüzde."""
    num = den = 0.0
    for c in ms:
        w = rec_w(c.get("date", ""), half_life)
        den += w
        if pred(c): num += w
    return 100.0 * num / den if den else 0.0

def wilson(k, n, z=1.96):
    """%95 Wilson güven aralığı → (alt, nokta, üst) yüzde."""
    if n <= 0: return (0.0, 0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    m = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (100 * max(0, c - m), 100 * p, 100 * min(1, c + m))

def kelly(p, o, frac=0.25):
    """p: gerçek olasılık (0-1), o: oran → önerilen stake %'si (¼ Kelly)."""
    b = o - 1.0
    if b <= 0: return 0.0
    f = (b * p - (1 - p)) / b
    return max(0.0, f * frac * 100)

def sim_score(t, c):
    """Uyum skoru 0-100 — 1X2 oranlarının göreli yakınlığı (üssel azalma)."""
    try:
        rel = sum(abs(t[k] - c[k]) / t[k] for k in ("1", "0", "2")) / 3.0
    except Exception:
        return 0.0
    return round(100 * math.exp(-12 * rel), 1)

# ------------------------------------------------------------------ açılış oranı
def opening_1x2(eid):
    """bet365 1X2 açılış oranları (arşiv timeline'ının en eski kaydı) + hareket özeti."""
    row = M.b365_row(eid)
    if not row: return None
    def w(pos):
        rec = row.get(pos)
        if not rec: return pos, None
        h = M.archive_odds(rec)
        if not h: return pos, None
        o = [float(x.get("odd") or 0) for x in h if x.get("odd")]
        o = [x for x in o if x > 1.0]
        if not o: return pos, None
        return pos, {"open": o[-1], "close": o[0], "min": min(o), "max": max(o), "n": len(o)}
    with ThreadPoolExecutor(max_workers=3) as ex:
        res = dict(ex.map(w, ["1", "0", "2"]))
    if any(v is None for v in res.values()): return None
    return res

def mov_metrics(oa, market="1x2"):
    """Oran hareketi metrikleri: hareket sayısı, volatilite, yön."""
    cells = [x for x in oa if x["market"] == market and x.get("hist")]
    n = sum(len(x["hist"]) for x in cells)
    vol = []
    for x in cells:
        o = [float(t["odd"]) for t in x["hist"]]
        if len(o) > 1 and o[-1] > 0:
            vol.append(abs(o[0] - o[-1]) / o[-1])
    return {"hucre": len(cells), "hareket": n, "volatilite": 100 * (sum(vol) / len(vol)) if vol else 0.0}

def steam(oa, thr=0.04):
    """Sert kaymalar: açılıştan kapanışa %4'ten fazla değişen hücreler."""
    out = []
    for x in oa:
        if not x.get("hist") or len(x["hist"]) < 2: continue
        o = [float(t["odd"]) for t in x["hist"]]
        if o[-1] <= 1: continue
        ch = 100 * (o[0] - o[-1]) / o[-1]
        if abs(ch) >= 100 * thr:
            out.append({"market": x["market"], "line": x["line"], "pos": x["pos"],
                        "open": o[-1], "close": o[0], "chg": ch, "n": len(o),
                        "min": min(o), "max": max(o), "last": x["hist"][0].get("date", "")})
    return sorted(out, key=lambda z: -abs(z["chg"]))

# ------------------------------------------------------------------ istatistik v2
def stats2(ms, half_life=3.0):
    if not ms: return {}
    n = len(ms)
    hw = sum(1 for c in ms if c["hg"] > c["ag"]); dr = sum(1 for c in ms if c["hg"] == c["ag"]); aw = n - hw - dr
    tot = [c["hg"] + c["ag"] for c in ms]
    d = dict(n=n, hw=hw, dr=dr, aw=aw, hwp=100*hw/n, drp=100*dr/n, awp=100*aw/n,
             w_hw=wrate(ms, lambda c: c["hg"] > c["ag"], half_life),
             w_dr=wrate(ms, lambda c: c["hg"] == c["ag"], half_life),
             w_aw=wrate(ms, lambda c: c["hg"] < c["ag"], half_life),
             ci_hw=wilson(hw, n), ci_dr=wilson(dr, n), ci_aw=wilson(aw, n),
             avg=sum(tot)/n, o15=100*sum(1 for t in tot if t > 1.5)/n,
             o25=100*sum(1 for t in tot if t > 2.5)/n, o35=100*sum(1 for t in tot if t > 3.5)/n,
             btts=100*sum(1 for c in ms if c["hg"] > 0 and c["ag"] > 0)/n,
             gg=100*sum(1 for t in tot if t == 0)/n,
             ev_g=sum(c["hg"] for c in ms)/n, dep_g=sum(c["ag"] for c in ms)/n,
             scores=Counter(f"{c['hg']}-{c['ag']}" for c in ms).most_common(10),
             gol_dag=Counter(min(t, 6) for t in tot))
    # gol dağılımı yüzdeleri
    d["gol_dag_p"] = {k: 100*v/n for k, v in d["gol_dag"].items()}
    ht = [c for c in ms if "ht_h" in c]
    if ht:
        nh = len(ht)
        d.update(htn=nh, ht00=100*sum(1 for c in ht if c["ht_h"] == 0 and c["ht_a"] == 0)/nh,
                 ht15=100*sum(1 for c in ht if c["ht_h"] + c["ht_a"] > 1.5)/nh,
                 htkg=100*sum(1 for c in ht if c["ht_h"] > 0 and c["ht_a"] > 0)/nh,
                 htw=100*sum(1 for c in ht if c["ht_h"] > c["ht_a"])/nh,
                 htx=100*sum(1 for c in ht if c["ht_h"] == c["ht_a"])/nh,
                 hta=100*sum(1 for c in ht if c["ht_a"] > c["ht_h"])/nh,
                 same=100*sum(1 for c in ht if (c["ht_h"] > c["ht_a"]) - (c["ht_h"] < c["ht_a"])
                              == (c["hg"] > c["ag"]) - (c["hg"] < c["ag"]))/nh,
                 matrix=Counter((('1' if c["ht_h"] > c["ht_a"] else 'X' if c["ht_h"] == c["ht_a"] else '2'),
                                 ('1' if c["hg"] > c["ag"] else 'X' if c["hg"] == c["ag"] else '2')) for c in ht))
    return d

def yearly(ms):
    """Yıl bazlı kırılım — istikrar kontrolü."""
    g = defaultdict(list)
    for c in ms:
        d = pdate(c.get("date", ""))
        g[d.year if d else 0].append(c)
    out = []
    for y in sorted(g):
        if y == 0: continue
        v = g[y]; n = len(v)
        out.append({"yil": y, "n": n,
                    "ev": 100*sum(1 for c in v if c["hg"] > c["ag"])/n,
                    "ber": 100*sum(1 for c in v if c["hg"] == c["ag"])/n,
                    "dep": 100*sum(1 for c in v if c["hg"] < c["ag"])/n})
    return out

def lig_kirilim(ms):
    g = defaultdict(list)
    for c in ms: g[c.get("league", "?")].append(c)
    out = []
    for lg, v in g.items():
        n = len(v)
        out.append({"lig": lg.strip('/').split('/')[-1], "n": n,
                    "ev": 100*sum(1 for c in v if c["hg"] > c["ag"])/n,
                    "ber": 100*sum(1 for c in v if c["hg"] == c["ag"])/n,
                    "dep": 100*sum(1 for c in v if c["hg"] < c["ag"])/n})
    return sorted(out, key=lambda z: -z["n"])

def consistency(yb):
    """Yıllar arası tutarlılık 0-1 (dep. oranlarının sapması)."""
    if len(yb) < 2: return 0.5
    vals = [y["dep"] for y in yb if y["n"] >= 3]
    if len(vals) < 2: return 0.5
    m = sum(vals) / len(vals)
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / len(vals))
    return max(0.0, min(1.0, 1 - sd / 40.0))

def conf_score(n, edge_pts, cons):
    """0-100 güven skoru: örneklem hacmi × etki büyüklüğü × istikrar."""
    vol = 1 - math.exp(-n / 15.0)
    eff = min(abs(edge_pts) / 12.0, 1.0)
    return round(100 * vol * (0.35 + 0.45 * eff + 0.20 * cons))

def hareket_testi(ms):
    """Açılış→kapanış yönü sonucu tahmin ediyor mu? (yalnız açılış verisi olan maçlar)"""
    rows = [c for c in ms if c.get("open_hist") and c["open_hist"].get("1")]
    if len(rows) < 4: return None
    kisa_ev = [c for c in rows if c["open_hist"]["1"]["close"] < c["open_hist"]["1"]["open"] - 1e-9]
    uzun_ev = [c for c in rows if c["open_hist"]["1"]["close"] > c["open_hist"]["1"]["open"] + 1e-9]
    def rate(v): return (100*sum(1 for c in v if c["hg"] > c["ag"])/len(v), len(v)) if v else (0, 0)
    ke, kn = rate(kisa_ev); ue, un = rate(uzun_ev)
    return {"kisa_n": kn, "kisa_ev": ke, "uzun_n": un, "uzun_ev": ue,
            "fark": (ke - ue) if kn >= 3 and un >= 3 else None}

# ------------------------------------------------------------------ ANA PIPELINE v2
def analyze2(ref, progress=print, max_open=20):
    t0 = time.time()
    P = M.analyze(ref, progress=progress, do_corner=True, do_form=True, do_candidates=False)
    info = P["info"]; eid = info["eid"]
    close = P["close_1x2"]
    oa = P["odds"]

    # --- hedefin AÇILIŞ oranı (bet365 arşivinden) ---
    tgt_open = None
    for x in oa:
        if x["market"] == "1x2" and x["pos"] in ("1", "0", "2") and x.get("hist"):
            tgt_open = tgt_open or {"1": None, "0": None, "2": None}
            tgt_open[x["pos"]] = float(x["hist"][-1]["odd"])
    if tgt_open and None in tgt_open.values(): tgt_open = None
    P["tgt_open"] = tgt_open

    # --- HAVUZ: kapanış ekranı + açılış ekranı (açılış öncelikli sıralama) ---
    pool = {}
    for c in M.screen(close, 0.22, eid):
        pool[c["id"]] = c
    if tgt_open:
        for c in M.screen(tgt_open, 0.20, eid):
            pool.setdefault(c["id"], c)
    ref_o = tgt_open or close
    def yakin(c, r):
        return abs(c["o1"] - r["1"]) + abs(c["ox"] - r["0"]) + abs(c["o2"] - r["2"])
    # iki koldan seçim: hedef AÇILIŞA en yakınlar + hedef KAPANIŞA en yakınlar
    pl = list(pool.values())
    sec = []
    for c in sorted(pl, key=lambda z: yakin(z, ref_o))[:30] + sorted(pl, key=lambda z: yakin(z, close))[:30]:
        if c["id"] not in {x["id"] for x in sec}: sec.append(c)
    havuz = sec
    progress(f"Aday havuzu {len(havuz)} → bet365 doğrulaması (ilk 100)")
    ver = M.verify_candidates(havuz, limit=55, target=close, ht_limit=30)
    ver2 = []
    for c in ver:
        b = c["b365"]
        c["d_close"] = max(abs(b[k] - close[k]) for k in ("1", "0", "2"))
        c["d_open"] = max(abs(b[k] - tgt_open[k]) for k in ("1", "0", "2")) if tgt_open else None
        c["sim"] = sim_score(close, b)
        c["sim_open"] = sim_score(tgt_open, b) if tgt_open else None
        ver2.append(c)
    cands = sorted(ver2, key=lambda c: (c["d_open"] if c["d_open"] is not None else c["d_close"],))

    # --- en benzer adayların GERÇEK açılış oranlarını doğrula (birebir eşleşme) ---
    # açılış doğrulaması için iki koldan seçim: kapanışı hedef AÇILIŞA yakın olanlar +
    # kapanışı hedef KAPANIŞA yakın olanlar (gerçek açılış eşleşmesini yakalama şansı en yüksek grup)
    orta = {k: (ref_o[k] + close[k]) / 2 for k in ("1", "0", "2")}
    def uzak_orta(c):
        return abs(c["o1"] - orta["1"]) + abs(c["ox"] - orta["0"]) + abs(c["o2"] - orta["2"])
    def uzak_acilis(c):
        return abs(c["o1"] - ref_o["1"]) + abs(c["ox"] - ref_o["0"]) + abs(c["o2"] - ref_o["2"])
    a1 = sorted(cands, key=uzak_acilis)[:max_open//2]
    a2 = sorted(cands, key=uzak_orta)[:max_open - max_open//2]
    top = []
    for c in a1 + a2:
        if c not in top: top.append(c)
    top = top[:max_open]
    def w(c):
        o = opening_1x2(c["id"])
        if o: c["open"] = {k: v["open"] for k, v in o.items()}; c["open_hist"] = o
        return c
    progress(f"En benzer {len(top)} maçın bet365 AÇILIŞ oranları çekiliyor...")
    with ThreadPoolExecutor(max_workers=6) as ex:
        list(ex.map(w, top))
    for c in cands:
        if c.get("open"):
            c["d_open_real"] = max(abs(c["open"][k] - tgt_open[k]) for k in ("1", "0", "2")) if tgt_open else None

    def kat(t, key):
        return [c for c in cands if c.get(key) is not None and c[key] <= t + 1e-9]
    P["cands"] = cands
    P["kat"] = {"0.00": kat(1e-9, "d_open_real"), "0.02": kat(0.02, "d_open_real"),
                "0.05": kat(0.05, "d_open_real"), "0.10": kat(0.10, "d_open_real"),
                "0.15": kat(0.15, "d_open_real"), "0.20": kat(0.20, "d_open_real"), "kapanis0": kat(0.02, "d_close"),
                "kapanis": kat(0.10, "d_close")}

    if os.environ.get("V2DEBUG"):
        print("DEBUG cands:", len(cands), "| d_close var:", sum(1 for c in cands if c.get("d_close") is not None),
              "| örnek:", [round(c.get("d_close"), 3) for c in cands[:4]], flush=True)
    # --- istatistikler (kapanış ±0.10 temel alınır) ---
    ana = P["kat"]["kapanis"] or cands
    st = stats2(ana); yb = yearly(ana)
    P["yb"] = yb
    P["cons"] = consistency(yb)
    P["lig_kirilim"] = lig_kirilim(ana)
    P["hareket"] = hareket_testi([c for c in cands if c.get("open")])
    P["steam"] = steam(oa)
    P["mov"] = mov_metrics(oa)

    # --- değer + Kelly ---
    mk = {"1": P["poisson"]["p1"], "0": P["poisson"]["px"], "2": P["poisson"]["p2"]}
    poi = {"1": P["poisson"]["p1"], "0": P["poisson"]["px"], "2": P["poisson"]["p2"]}
    piyasa, marj = M.implied([close["1"], close["0"], close["2"]])
    hist = {"1": st.get("hwp", 0), "0": st.get("drp", 0), "2": st.get("awp", 0)}
    wh = {"1": st.get("w_hw", 0), "0": st.get("w_dr", 0), "2": st.get("w_aw", 0)}
    edges = {}
    for k, lbl in (("1", "Ev"), ("0", "Beraberlik"), ("2", "Deplasman")):
        pm = piyasa[{"1": 0, "0": 1, "2": 2}[k]]
        e_h = hist[k] - pm
        e_z = 100 * poi[k] - pm
        edges[k] = {"lbl": lbl, "piyasa": pm, "poi": 100*poi[k], "hist": hist[k], "whist": wh[k],
                    "edge_hist": e_h, "edge_poi": e_z,
                    "kelly": kelly(hist[k]/100.0, close[k]) if hist[k] > 0 else 0.0,
                    "ci": st.get(f"ci_{ {'1':'hw','0':'dr','2':'aw'}[k] }", (0, 0, 0))}
    P["edges"] = edges
    P["marj"] = marj
    P["piyasa"] = piyasa
    P["conf"] = {k: conf_score(st.get("n", 0), edges[k]["edge_hist"], P["cons"]) for k in edges}
    P["elapsed2"] = round(time.time() - t0, 1)
    progress(f"v2 tamam ({P['elapsed2']}s) | aday {len(cands)} | açılış eşleşmesi: "
             f"birebir {len(P['kat']['0.00'])} ±0.05 {len(P['kat']['0.05'])} ±0.10 {len(P['kat']['0.10'])}")
    return P
