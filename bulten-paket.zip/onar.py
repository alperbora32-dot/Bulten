#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ONARIM + GÜN TAŞIMA — bugünün maçlarını doğru güne damgalar, eksik oran/karşılaştırmaları tamamlar, atomik yazar."""
import json, os, shutil, sys, datetime
sys.path.insert(0, "/home/user")
import tam_tarama as TT

BUGUN = datetime.date(2026, 9, 11)
YOL = "/home/user/veri/tam_tarama.json"

d = json.load(open(YOL, encoding="utf-8"))
print("başlangıç kayıt:", len(d))
canli = {m["id"]: m for m in TT.gun_maclari(BUGUN)}
print("canlı fikstür:", len(canli))

taşınan = 0
for m in d:
    if m["id"] in canli and m.get("gun") != "2026-09-11":
        m["gun"] = "2026-09-11"
        taşınan += 1
print("doğru güne taşınan:", taşınan)

by_id = {m["id"]: m for m in d}
yeni = 0
for mid, c in canli.items():
    if mid not in by_id:
        by_id[mid] = c
        yeni += 1
print("eksik fikstürden eklenen:", yeni)

bugun = [m for m in by_id.values() if m.get("gun") == "2026-09-11"]
eksik_oran = [m for m in bugun if not m.get("o")]
print("oranı eksik:", len(eksik_oran), "→ tamamlanıyor")
TT.oran_tamamla(eksik_oran)

eksik_kars = [m for m in bugun if m.get("o") and not m.get("n")]
print("karşılaştırması eksik:", len(eksik_kars), "→ hesaplanıyor")
ms, o1s = TT.arsiv()
for m in eksik_kars:
    TT.karsilastir(m, ms, o1s)

out = list(by_id.values())
gecici = YOL + ".tmp"
json.dump(out, open(gecici, "w", encoding="utf-8"), ensure_ascii=False)
shutil.copy2(YOL, YOL + ".bak")
os.replace(gecici, YOL)

g = [m for m in out if m.get("gun") == "2026-09-11"]
print(f"SONUÇ: dosya {len(out)} kayıt | bugün {len(g)} maç · oranlı {sum(1 for m in g if m.get('o'))} · "
      f"karşılaştırılan {sum(1 for m in g if m.get('n'))} · skorlu {sum(1 for m in g if m.get('skor'))}")
