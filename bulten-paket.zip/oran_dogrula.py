#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ORAN DOĞRULAMA — bültendeki oranlar BetExplorer'ın açılış oranlarıyla birebir mi?
Rastgele örnek maçların oranını canlı servisten yeniden çeker ve karşılaştırır.
"""
import json, random, sys, time
sys.path.insert(0, "/home/user")
import tam_tarama as TT

d = json.load(open("/home/user/veri/tam_tarama.json", encoding="utf-8"))
aday = [m for m in d if m.get("gun") == "2026-09-11" and m.get("o")]
random.seed(11)
ornek = random.sample(aday, min(24, len(aday)))

tam = yakin = uzak = 0
en_buyuk = 0
satir = []
for m in ornek:
    yeni = TT.excel_odds_cek if hasattr(TT, "excel_odds_cek") else None
    html = TT.curl(f"{TT.BASE}/match-odds/{m['id']}/1/1x2/odds/?lang=en")
    if not html:
        satir.append((m["home"], m["away"], m["o"], None, "sayfa yok")); continue
    try:
        import re
        vals = [float(x) for x in re.findall(r'data-odd="([\d.]+)"', html)[:3]]
    except Exception:
        vals = []
    if len(vals) != 3:
        satir.append((m["home"], m["away"], m["o"], None, "oran bulunamadı")); continue
    farklar = [abs(vals[i] - m["o"][i]) for i in range(3)]
    mx = max(farklar); en_buyuk = max(en_buyuk, mx)
    if mx < 0.001:
        tam += 1; durum = "BİREBİR"
    elif mx <= 0.02:
        yakin += 1; durum = f"~yuvarlama ({mx:.3f})"
    else:
        uzak += 1; durum = f"FARKLILIK {mx:.3f}"
    satir.append((m["home"], m["away"], m["o"], vals, durum))
    time.sleep(0.15)

print("=" * 78)
print(f"ORAN DOĞRULAMA — {len(satir)} maç canlı servisten yeniden çekildi")
print("=" * 78)
for h, a, o, v, d2 in satir:
    print(f"{h[:26]:28s} {str(o):24s} {str(v):24s} {d2}")
print("-" * 78)
print(f"Birebir aynı: {tam} | ~yuvarlama: {yakin} | farklı: {uzak} | en büyük sapma: {en_buyuk:.3f}")
oran = 100 * (tam + yakin) / max(1, len(satir))
print(f"TUTARLILIK: %{oran:.1f}")
