#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ORAN DOĞRULAMA v2 — canlı /results/ sayfasındaki data-odd ile bültendeki oranları karşılaştırır."""
import json, re, sys
sys.path.insert(0, "/home/user")
import tam_tarama as TT

h = TT.curl(f"{TT.BASE}/results/")
sayfa = {}
for tr in re.findall(r"<tr[^>]*>(.*?)</tr>", h, re.S):
    if "table-main__tt" not in tr:
        continue
    m = re.search(r"/([A-Za-z0-9]{8})/\">", tr)
    if not m:
        continue
    odds = re.findall(r'data-odd="([\d.]+)"', tr)
    if len(odds) >= 3:
        sayfa[m.group(1)] = [float(x) for x in odds[:3]]

d = json.load(open("/home/user/veri/tam_tarama.json", encoding="utf-8"))
bugun = [m for m in d if m.get("gun") == "2026-09-11" and m.get("o")]
kesisen = [m for m in bugun if m["id"] in sayfa]

print("=" * 80)
print(f"ORAN DOĞRULAMA — canlı sayfada oranı olan maç: {len(sayfa)} | bizde eşleşen: {len(kesisen)}")
print("=" * 80)
tam = yakin = uzak = 0
sapmalar = []
for m in kesisen[:40]:
    s = sayfa[m["id"]]
    f = [abs(s[i] - m["o"][i]) for i in range(3)]
    mx = max(f); sapmalar.append(mx)
    if mx < 0.001: tam += 1; t = "BİREBİR"
    elif mx <= 0.05: yakin += 1; t = f"yakın ({mx:.2f})"
    else: uzak += 1; t = f"farklı ({mx:.2f})"
    print(f"{m['home'][:24]:26s} biz {str(m['o']):22s} canlı {str(s):22s} {t}")
print("-" * 80)
n = max(1, len(kesisen[:40]))
print(f"Birebir: {tam} | yakın: {yakin} | farklı: {uzak} | ortalama sapma: {sum(sapmalar)/n:.3f}")
print(f"UYUM: %{100*(tam+yakin)/n:.1f}")
