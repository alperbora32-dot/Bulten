"""Bugünün maçları için AÇILIŞ → ŞİMDİKİ oran hareketi (BetExplorer oran sayfası).

Kurallar:
  - Sadece 1-X-2 üçlüsü tam olan (3 kolonlu) bookmaker satırları kullanılır.
  - Marj 1.005–1.35 dışındaysa veya hareket %60'ı aşarsa maç "atlanan" listesine girer.
  - Yavaş çalışır (3 işçi, tekrar denemeli) ve 25 maçta bir diske yazar → kesilse de kayıp olmaz.
  - `python3 oran_hareket.py devam` → zaten çekilmiş maçları atlar.
Çıktı: veri/hareket.json → {"hareket": {id: {...}}, "atlanan": {id: ["ATLA", neden]}, "zamani": "..."}
"""
import json, os, re, sys, time, random, urllib.request, concurrent.futures as cf
from datetime import datetime
from zoneinfo import ZoneInfo

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
      'Accept-Language': 'tr,en;q=0.9'}
KOK = '/home/user'
CIKTI = f'{KOK}/veri/hareket.json'
ISCI = 3


def guncel_maçlar():
    import saat as SA
    d = json.load(open(f'{KOK}/veri/tam_tarama.json', encoding='utf-8'))
    simdi = datetime.now(ZoneInfo('Europe/Istanbul'))
    _f = SA.fark_ogren()
    for _m in d:
        _y, _g = SA.tr(_m.get('saat'), _f)
        _m['saat'] = _y
        _m['gk'] = _g
    out = []
    for m in d:
        if not (m.get('o') and m.get('id')):
            continue
        try:
            hh, mm = (m.get('saat') or '').split(':')
            k = simdi.replace(hour=int(hh), minute=int(mm), second=0)
        except Exception:
            continue
        if m.get('gk') or (simdi - k).total_seconds() / 60.0 > 120:
            continue
        out.append(m)
    return out


def cek(m):
    u = 'https://www.betexplorer.com/match-odds/%s/1/1x2/odds/' % m['id']
    h = None
    for deneme in range(3):
        try:
            raw = urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=25).read().decode('utf-8', 'ignore')
            h = json.loads(raw)['odds']
            break
        except Exception as e:
            son = str(e)[:40]
            time.sleep(1.5 + deneme * 2 + random.random())
    if h is None:
        return m['id'], ('HATA', son)
    uclar = []
    for tr in re.findall(r'<tr[\s\S]*?</tr>', h):
        v = re.findall(r'data-odd="([\d.]+)"', tr)
        if len(v) == 3:
            try:
                uclar.append([float(v[0]), float(v[1]), float(v[2])])
            except Exception:
                pass
    ort_a = [x for x in re.findall(r'oddsComparisonAll__average_text"\s+data-odd="([\d.]*)"', h) if x]
    if len(uclar) == 0 and len(ort_a) < 3:
        return m['id'], ('ATLA', 'satir-yok')
    en_iyi = ([round(max(x[i] for x in uclar), 2) for i in range(3)] if uclar else
              [round(float(ort_a[i]), 2) for i in range(3)])
    n = len(uclar)
    if len(ort_a) >= 3:                       # sayfanın gösterdiği GÜNCEL ortalama
        ort = [round(float(x), 2) for x in ort_a[:3]]
    else:
        ort = [round(sum(x[i] for x in uclar) / n, 2) for i in range(3)]
    marj = sum(1 / x for x in ort)
    if not (1.005 <= marj <= 1.35):
        return m['id'], ('ATLA', 'marj %.2f' % marj)
    ac = m['o']
    har = [round((ort[i] / ac[i] - 1) * 100, 1) if ac[i] else 0.0 for i in range(3)]
    if max(abs(x) for x in har) > 60:
        return m['id'], ('ATLA', 'sicrama %.0f' % max(abs(x) for x in har))
    if sum(1 / x for x in ac) > 1.35:   # açılış oranımızın kendisi şüpheli
        return m['id'], ('ATLA', 'acilis-supheli')
    bk = max(range(3), key=lambda i: abs(har[i]))
    return m['id'], {'simdi': ort, 'en_iyi': en_iyi, 'hareket': har,
                     'yon': ['Ev', 'Ber', 'Dep'][bk], 'buyuk': har[bk], 'kitapci': n}


def main():
    devam = 'devam' in sys.argv
    onceki = {}
    if devam and os.path.exists(CIKTI):
        onceki = json.load(open(CIKTI, encoding='utf-8'))
    har = onceki.get('hareket', {})
    atla = onceki.get('atlanan', {})
    atla = {} if 'sifirla' in sys.argv else atla
    hedef = [m for m in guncel_maçlar() if m['id'] not in har and m['id'] not in atla]
    print(f'hedef {len(hedef)} maç (elde {len(har)} hareket + {len(atla)} atlanan)', flush=True)
    t0 = time.time()
    with cf.ThreadPoolExecutor(ISCI) as ex:
        for i, (mid, r) in enumerate(ex.map(cek, hedef), 1):
            if isinstance(r, tuple):
                (atla if r[0] == 'ATLA' else atla)[mid] = list(r)
            else:
                har[mid] = r
            if i % 25 == 0:
                json.dump({'hareket': har, 'atlanan': atla, 'zamani': datetime.now(ZoneInfo('Europe/Istanbul')).strftime('%H:%M')},
                          open(CIKTI, 'w', encoding='utf-8'), ensure_ascii=False)
                print(f'  {i}/{len(hedef)} · hareket {len(har)} · atlanan {len(atla)} · hata-gibi {len(atla)}', flush=True)
    json.dump({'hareket': har, 'atlanan': atla, 'zamani': datetime.now(ZoneInfo('Europe/Istanbul')).strftime('%H:%M')},
              open(CIKTI, 'w', encoding='utf-8'), ensure_ascii=False)
    buyuk = sorted([v for v in har.values() if abs(v['buyuk']) >= 1], key=lambda z: -abs(z['buyuk']))
    print(f"BİTTİ: {len(har)} maç · hareketli(≥%1) {len(buyuk)} · atlanan {len(atla)} · {round(time.time()-t0,1)}s")
    for v in buyuk[:5]:
        print('  ', v['simdi'], v['hareket'], v['yon'])


if __name__ == '__main__':
    main()
