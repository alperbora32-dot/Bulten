#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""RAPOR v2 — anlaşılır, açıklamalı, sekmeli HTML rapor üreticisi."""
import html as H
from collections import Counter

MK = {"1x2": "Maç Sonucu (1X2)", "ou": "Alt / Üst", "ah": "Asya Handikap", "bts": "Karşılıklı Gol",
      "dc": "Çift Şans", "ha": "Beraberlik İade"}
POS = {"1": "1 (Ev)", "0": "X (Beraberlik)", "2": "2 (Deplasman)", "y": "Var", "n": "Yok",
       "10": "1-X", "12": "1-2", "02": "X-2", "12_": "1-2"}

def e(x): return H.escape(str(x))
def pc(v, d=1): return f"{v:.{d}f}%"

def bar(v, color="#4fc3f7", maxv=100):
    w = max(0.0, min(100.0, v / maxv * 100 if maxv else 0))
    return (f"<div class='barwrap'><div class='bar' style='width:{w:.1f}%;background:{color}'></div>"
            f"<span class='bartxt'>{pc(v)}</span></div>")

def sec(num, icon, title, aciklama, body):
    return (f"<section class='sec'><h2><span class='num'>{num}</span>{icon} {e(title)}</h2>"
            f"<div class='how'><b>Bu bölüm ne söylüyor?</b> {aciklama}</div>{body}</section>")

def table(headers, rows, cls=""):
    th = "".join(f"<th>{h}</th>" for h in headers)
    tr = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)
    return f"<table class='{cls}'><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>"

CSS = """
*{box-sizing:border-box}
body{margin:0;background:#0a121e;color:#e8eef5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:14px;line-height:1.5}
.wrap{max-width:1180px;margin:0 auto;padding:20px 16px 70px}
h1{font-size:25px;margin:0 0 4px}
h2{font-size:17px;margin:0 0 10px;display:flex;align-items:center;gap:9px}
.num{background:#1f9d63;color:#fff;width:24px;height:24px;border-radius:7px;display:inline-flex;align-items:center;justify-content:center;font-size:13px;font-weight:700}
.sub{color:#8ba3b8;font-size:13px}
.sec{background:#0f1a27;border:1px solid #1d2d42;border-radius:14px;padding:16px 18px;margin:16px 0}
.how{background:#122234;border-left:3px solid #4fc3f7;border-radius:8px;padding:9px 12px;color:#a9c1d6;font-size:12.5px;margin-bottom:12px}
.how b{color:#7fd6ff}
table{width:100%;border-collapse:collapse;font-size:13px;margin:4px 0}
th,td{border:1px solid #1d2d42;padding:6px 8px;text-align:left}
th{background:#16273a;color:#9fd6ff;font-weight:600;font-size:12.5px;white-space:nowrap}
tbody tr:nth-child(even){background:#0c1622}
tbody tr:hover{background:#15263a}
td.c,th.c{text-align:center}
.od{font-variant-numeric:tabular-nums;text-align:center;font-weight:600}
.up{color:#ff8a8a}.down{color:#5ee7a0}.flat{color:#8ba3b8}
.barwrap{position:relative;background:#16273a;border-radius:6px;height:20px;min-width:110px;overflow:hidden}
.bar{height:100%;border-radius:6px}
.bartxt{position:absolute;right:6px;top:0;font-size:12px;line-height:20px;font-weight:700;text-shadow:0 0 3px #000}
.top{background:linear-gradient(135deg,#12243a,#0f1a27);border:1px solid #22405e;border-radius:16px;padding:18px 20px;margin-bottom:14px}
.oddsbox{display:flex;gap:10px;flex-wrap:wrap;margin:12px 0}
.ob{background:#0b1522;border:1px solid #223349;border-radius:10px;padding:9px 13px;min-width:120px}
.ob b{display:block;color:#8ba3b8;font-size:11px;font-weight:600;letter-spacing:.4px;text-transform:uppercase}
.ob span{font-size:17px;font-weight:700}
.verdict{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(215px,1fr));margin-top:12px}
.vc{background:#0b1522;border:1px solid #223349;border-radius:12px;padding:12px 14px}
.vc b{display:block;font-size:11px;color:#8ba3b8;letter-spacing:.4px;text-transform:uppercase;margin-bottom:5px}
.vc .big{font-size:26px;font-weight:800;line-height:1.1}
.vc .big2{font-size:17px;font-weight:700}
.tabs{display:flex;gap:7px;flex-wrap:wrap;margin:12px 0 4px}
.tab{padding:8px 14px;border-radius:999px;border:1px solid #223349;background:#0d1a28;color:#b8cde0;text-decoration:none;font-size:13px;cursor:pointer}
.tab.on{background:linear-gradient(90deg,#1f9d63,#0e8f8f);color:#fff;border-color:transparent;font-weight:700}
.tab:hover{border-color:#4fc3f7}
.badge{display:inline-block;padding:2px 8px;border-radius:6px;font-size:11.5px;font-weight:700}
.b-deger{background:#124a2e;color:#5ee7a0}
.b-pahali{background:#4a1c1c;color:#ff9a9a}
.b-notr{background:#24354a;color:#9fb4c7}
.b-ev{background:#1b3b5c;color:#7fc8ff}
.two{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(330px,1fr))}
.note{color:#8ba3b8;font-size:12px;margin-top:6px}
.pill{display:inline-block;background:#16273a;border:1px solid #24384f;border-radius:999px;padding:2px 10px;font-size:11.5px;color:#9fd6ff;margin:2px}
.kv{display:flex;justify-content:space-between;border-bottom:1px dashed #1d2d42;padding:5px 0;font-size:13px}
.kv span:last-child{font-weight:700}
.mx td{text-align:center}.mx th{text-align:center}
.zr{color:#3d4f63}
.hl{background:#16324a}
.git{color:#5ee7a0;font-weight:700}.yit{color:#ffd479;font-weight:700}.kit{color:#ff8a8a;font-weight:700}
a{color:#4fc3f7}
.mini{font-size:12px;color:#8ba3b8}
.tag{font-size:11px;padding:1px 6px;border-radius:5px;background:#16273a;color:#9fb4c7}
"""

def render(P, kat="0.10"):
    info = P["info"]; st = P["stats"]; close = P["close_1x2"]; to = P.get("tgt_open")
    K = P["kat"]
    sel = {"0.00": "Birebir aynı açılış", "0.02": "Açılış ±0.02", "0.05": "Açılış ±0.05", "0.10": "Açılış ±0.10",
           "0.15": "Açılış ±0.15", "0.20": "Açılış ±0.20", "kapanis0": "Kapanış ±0.02", "kapanis": "Kapanış ±0.10"}.get(kat, kat)
    # seçilen katman boşsa otomatik olarak veri olan katmana geç
    otomatik = False
    if not (K.get(kat) or []):
        for alt in ("kapanis", "kapanis0", "0.10", "0.15", "0.05", "0.02", "0.00"):
            if K.get(alt):
                kat = alt; otomatik = True; break
        else:
            kat = "kapanis"; otomatik = True
    ms = K.get(kat) or []
    s2 = P.get("_s2") or {}
    # seçili katman istatistikleri
    import motor_v2 as V
    s2 = V.stats2(ms) if ms else {}
    yb = V.yearly(ms) if ms else []
    cons = V.consistency(yb) if yb else 0.5

    out = ['<div class="wrap">']
    # ---------------- BAŞLIK ----------------
    skor = ""
    if info.get("score"): skor = f" · Oynandı: <b>{e(info['score'])}</b> {e(info.get('partial','') or '')}"
    out.append(f"""<div class="top">
<h1>⚽ {e(info.get('home'))} — {e(info.get('away'))}</h1>
<div class="sub">{e(info.get('league') or '')} · {e(info.get('date',''))}{skor} · <span class="pill">Maç ID {e(info.get('eid'))}</span></div>
<div class="oddsbox">
  <div class="ob"><b>Açılış (bet365)</b><span>{f"{to['1']:.2f} / {to['0']:.2f} / {to['2']:.2f}" if to else "—"}</span></div>
  <div class="ob"><b>Kapanış (bet365)</b><span>{close['1']:.2f} / {close['0']:.2f} / {close['2']:.2f}</span></div>
  <div class="ob"><b>Marj (komisyon)</b><span>{P['marj']:.1f}%</span></div>
  <div class="ob"><b>Hareket sayısı</b><span>{P['mov']['hareket']} hücre / {P['mov']['hucre']} market</span></div>
</div>""")

    # ---------------- HÜKÜM KARTLARI ----------------
    if ms:
        k = kat
        lbl = K and sel
        en_iyi = max(P["edges"].items(), key=lambda kv: kv[1]["edge_hist"])
        ek = en_iyi[1]
        n = s2["n"]
        lider = max((("Ev", s2["hwp"]), ("Beraberlik", s2["drp"]), ("Deplasman", s2["awp"])), key=lambda z: z[1])
        yorum = (f"Bu oran setiyle açılan {n} maçta en sık sonuç <b>{lider[0]}</b> (%{lider[1]:.0f}). "
                 f"Deplasman {s2['awp']:.0f}% (ağırlıklı {s2['w_aw']:.0f}%), beraberlik {s2['drp']:.0f}%, ev {s2['hwp']:.0f}%. "
                 f"Ortalama {s2['avg']:.2f} gol, 2.5 üst {s2['o25']:.0f}%, KG {s2['btts']:.0f}%.")
        out.append(f"""<div class="verdict">
  <div class="vc"><b>Aynı oranla açılan maç</b><span class="big">{n}</span><span class="mini">{e(sel)} tolerans</span></div>
  <div class="vc"><b>Sonuç dağılımı</b>
    <div style="margin:3px 0">Ev {bar(s2['hwp'],'#4fc3f7')}</div>
    <div style="margin:3px 0">Ber {bar(s2['drp'],'#ffd479')}</div>
    <div style="margin:3px 0">Dep {bar(s2['awp'],'#5ee7a0')}</div></div>
  <div class="vc"><b>Güven skoru</b><span class="big">{P['conf']['2']}/100</span><span class="mini">örneklem {n} · istikrar {cons*100:.0f}%</span></div>
  <div class="vc"><b>Değer sinyali</b><span class="big2">{ek['lbl']} <span class="badge {'b-deger' if ek['edge_hist']>2 else 'b-pahali' if ek['edge_hist']<-2 else 'b-notr'}">{ek['edge_hist']:+.1f} pt</span></span>
     <span class="mini">¼ Kelly öneri: %{ek['kelly']:.1f} banko</span></div>
</div>
<div class="how" style="margin-top:12px"><b>Özet:</b> {yorum}</div>""")
    out.append("</div>")

    if not to:
        out.append('<div class="sec"><div class="how" style="border-left-color:#ffd479"><b>Not:</b> Bu maçın bet365 <b>açılış</b> oranı arşivde bulunamadı (maç henüz oynanmamış ya da arşiv kaydı yok). '
                   'Bu yüzden "birebir açılış" katmanları boş; kapanış oranı katmanlarını kullan.</div></div>')

    # ---------------- KATMAN SEKMELERİ ----------------
    def sayi(t): return len(K.get(t, []))
    tabs = ""
    for t in ("0.00", "0.02", "0.05", "0.10", "0.15", "0.20", "kapanis0", "kapanis"):
        on = "on" if t == kat else ""
        ad = {"0.00": "🎯 Birebir aynı açılış", "0.02": "Açılış ±0.02", "0.05": "Açılış ±0.05",
              "0.10": "Açılış ±0.10", "0.15": "Açılış ±0.15", "0.20": "Açılış ±0.20", "kapanis0": "Kapanış ±0.02",
              "kapanis": "Kapanış ±0.10"}[t]
        tabs += f'<a class="tab {on}" href="?ref={H.escape(str(P["info"]["path"]))}&kat={t}">{ad} · {sayi(t)}</a>'
    out.append(f"""<div class="sec" style="padding:14px 18px">
<h2><span class="num">▸</span>Tolerans Katmanı Seç</h2>
<div class="how">Aradığın şey <b>"aynı oranla açılan maç"</b>: en soldaki katman <b>birebir aynı</b> açılış oranı
(0.00 fark) demektir. Sağa gidildikçe tolerans büyür, örneklem artar ama benzerlik azalır.
Her sekme anında açılır — veriler yeniden çekilmez.</div>
<div class="tabs">{tabs}</div>
<div class="note"><b>Açılış katmanları</b> yalnızca bet365 <b>açılış</b> oranı arşivde bulunan maçları kapsar (en net eşleşme).
Toleransı büyütünce örneklem artar. <b>Kapanış</b> katmanları her maç için doludur — karşılaştırma için onları kullan.</div>
<div class="note">Şu an gösterilen: <b>{e(sel)}</b> · {len(ms)} maç · bu katmandaki istatistikler aşağıdaki bölümlere yansıtıldı.{' <b style="color:#ffd479">(seçtiğin katmanda maç yoktu, veri bulunan katmana geçildi)</b>' if otomatik else ''}</div>
</div>""")

    # ---------------- 1. AYNI ORANLA AÇILAN MAÇLAR ----------------
    if ms:
        rows = []
        for c in sorted(ms, key=lambda z: (z.get("d_open_real") if z.get("d_open_real") is not None else 9, -z["sim"]))[:40]:
            o = c.get("open")
            oo = f"{o['1']:.2f} / {o['0']:.2f} / {o['2']:.2f}" if o else "—"
            dop = f"{c['d_open_real']:.2f}" if c.get("d_open_real") is not None else "—"
            sonuc = "Ev" if c["hg"] > c["ag"] else ("Beraberlik" if c["hg"] == c["ag"] else "Deplasman")
            cls = "git" if sonuc == "Ev" else ("yit" if sonuc == "Beraberlik" else "kit")
            iy = f"{c.get('ht_h')}:{c.get('ht_a')}" if "ht_h" in c else "—"
            rows.append([
                f'<a href="https://www.betexplorer.com{c["link"]}" target="_blank">{c["date"]}</a>',
                e(c["home"]), e(c["away"]),
                f'<span class="od"><b>{c["hg"]}:{c["ag"]}</b></span>', f'<span class="od">{iy}</span>',
                f'<span class="{cls}">{sonuc}</span>', f'<span class="od">{oo}</span>',
                f'<span class="od">{dop}</span>', f'<span class="od">{c["sim"]}</span>',
                f'<span class="tag">{e(c["league"].strip("/").split("/")[-1])}</span>'])
        body = table(["Tarih", "Ev", "Deplasman", "MS", "İY", "Sonuç", "Maçın açılış oranı", "Açılış farkı", "Uyum", "Lig"], rows)
        acik = ("Liste, <b>tam olarak senin maçın açılış oranlarıyla açılmış</b> maçları gösterir. "
                "«Açılış farkı» 0.00 ise oranlar birebir aynı. «Uyum» 100'e yakınsa oranlar neredeyse özdeş. "
                "Sonuç kolonu bu maçların gerçekte nasıl bittiğini gösterir.")
        out.append(sec(1, "🎯", f"Aynı Oranla Açılan Maçlar ({e(sel)})", acik, body))

    # ---------------- 2. SONUÇ DAĞILIMI ----------------
    if s2:
        rows = []
        for k2, lbl2 in (("1", "Ev"), ("0", "Beraberlik"), ("2", "Deplasman")):
            key = {"1": "hwp", "0": "drp", "2": "awp"}[k2]
            wkey = {"1": "w_hw", "0": "w_dr", "2": "w_aw"}[k2]
            ci = s2.get({"1": "ci_hw", "0": "ci_dr", "2": "ci_aw"}[k2], (0, 0, 0))
            cl = "#4fc3f7" if k2 == "1" else ("#ffd479" if k2 == "0" else "#5ee7a0")
            rows.append([f"<b>{lbl2}</b>", bar(s2[key], cl), f"<span class='od'>{s2[key]:.0f}%</span>",
                         f"<span class='od'>{s2[wkey]:.0f}%</span>",
                         f"<span class='od mini'>{ci[0]:.0f}% – {ci[2]:.0f}%</span>",
                         f"<span class='od'>{s2[key]:.0f}%</span>"])
        body = table(["Sonuç", "Oran", "Ham %", "Zaman ağırlıklı %", "%95 güven aralığı", "Piyasa tahmini"], rows)
        yillar = ""
        if yb:
            yillar = "<div class='two' style='margin-top:12px'><div><h2 style='font-size:14px'>📅 Yıl Bazlı İstikrar</h2>" + \
                table(["Yıl", "Maç", "Ev", "Ber", "Dep"],
                      [[y["yil"], f"<span class='od'>{y['n']}</span>", f"<span class='od'>{y['ev']:.0f}%</span>",
                        f"<span class='od'>{y['ber']:.0f}%</span>", f"<span class='od'>{y['dep']:.0f}%</span>"] for y in yb]) + \
                f"<div class='note'>Yıllar arası tutarlılık: <b>{cons*100:.0f}%</b> — yüksekse eğilim tesadüf değildir.</div></div>"
            lk = P.get("lig_kirilim") or []
            if lk:
                yillar += "<div><h2 style='font-size:14px'>🌍 Lig Kırılımı</h2>" + \
                    table(["Lig", "Maç", "Ev", "Ber", "Dep"],
                          [[e(l["lig"]), f"<span class='od'>{l['n']}</span>", f"<span class='od'>{l['ev']:.0f}%</span>",
                            f"<span class='od'>{l['ber']:.0f}%</span>", f"<span class='od'>{l['dep']:.0f}%</span>"] for l in lk[:12]]) + "</div>"
            yillar += "</div>"
        acik = ("Bu maçlar geçmişte nasıl sonuçlandı? <b>Zaman ağırlıklı %</b> sütunu yeni maçlara daha çok ağırlık verir "
                "(yarı ömür 3 yıl) — piyasa koşulları değiştiği için bu daha dürüst bir tahmindir. "
                "<b>Güven aralığı</b> ise küçük örneklemde yanılma payını gösterir: dar bant = güvenilir sonuç.")
        out.append(sec(2, "📊", "Sonuç Dağılımı ve İstikrar", acik, body + yillar))

    # ---------------- 3. GOL / İY / KG ----------------
    if s2:
        g = s2["gol_dag_p"]
        gol_rows = [[f"{k}+ gol" if k == 6 else f"{k} gol", bar(g.get(k, 0), "#7f7fff"), f"<span class='od'>{g.get(k,0):.0f}%</span>"]
                    for k in range(0, 7)]
        iy_rows = []
        if s2.get("htn"):
            for lbl3, val in (("İlk yarı 0-0", s2["ht00"]), ("İY 1.5 ÜST", s2["ht15"]), ("İY KG (iki takım da attı)", s2["htkg"]),
                              ("İY Ev önde", s2["htw"]), ("İY beraberlik", s2["htx"]), ("İY Dep önde", s2["hta"]),
                              ("Devre arası lideri maçı da kazandı", s2["same"])):
                iy_rows.append([lbl3, bar(val, "#ff9f43"), f"<span class='od'>{val:.0f}%</span>"])
        mtx = ""
        if s2.get("matrix"):
            m = s2["matrix"]; n = s2["htn"]
            rws = ""
            for a, lab in (('1', 'İY Ev önde'), ('X', 'İY Beraberlik'), ('2', 'İY Dep önde')):
                tot = sum(m[(a, b)] for b in '1X2')
                cells = "".join((f"<td class='hl'>{m[(a,b)]}<br><span class='mini'>{100*m[(a,b)]/n:.0f}%</span></td>"
                                 if m[(a, b)] else "<td class='zr'>–</td>") for b in '1X2')
                rws += f"<tr><th>{lab}</th>{cells}<td><b>{tot}</b> ({100*tot/n:.0f}%)</td></tr>"
            mtx = ("<h2 style='font-size:14px;margin-top:14px'>🔀 İlk Yarı → Maç Sonucu Matrisi</h2>"
                   "<table class='mx'><thead><tr><th>İY ↓ / MS →</th><th>Ev</th><th>Beraberlik</th><th>Deplasman</th><th>Toplam</th></tr></thead>"
                   f"<tbody>{rws}</tbody></table>")
        sk = ", ".join(f"<span class='pill'>{e(s)} · {c}×</span>" for s, c in s2["scores"][:8])
        body = (f"<div class='two'><div>{table(['Toplam Gol Dağılımı','',''], gol_rows)}</div>"
                f"<div>{table(['İlk Yarı Davranışı','',''], iy_rows) if iy_rows else '<div class=note>İY verisi yok</div>'}</div></div>"
                f"{mtx}"
                f"<div style='margin-top:12px'><b>Özet metrikler:</b> ort. gol <b>{s2['avg']:.2f}</b> · "
                f"ev {s2['ev_g']:.2f} / dep {s2['dep_g']:.2f} · 1.5Ü {s2['o15']:.0f}% · 2.5Ü {s2['o25']:.0f}% · "
                f"3.5Ü {s2['o35']:.0f}% · KG <b>{s2['btts']:.0f}%</b> · 0-0 {s2['gg']:.0f}%</div>"
                f"<div style='margin-top:8px'><b>En sık skorlar:</b> {sk}</div>")
        acik = ("Gollerin nasıl dağıldığını gösterir: kaç maç 0-0, kaç maç 4+ gol bitti. "
                "İY tablosu ilk yarıdaki davranışı özetler — <b>ilk yarı 0-0 oranı yüksekse</b> İY alt bahisleri değerli olabilir. "
                "Matris, ilk yarıda öne geçen takımın maçı bitirip bitirmediğini gösterir.")
        out.append(sec(3, "⚽", "Gol, İlk Yarı ve KG Analizi", acik, body))

    # ---------------- 4. KORNER ----------------
    c = P.get("corner")
    if c:
        body = (f"<div class='two'><div><div class='kv'><span>{e(c['home_name'])} korner üretiyor</span><span>{c['hf']}</span></div>"
                f"<div class='kv'><span>{e(c['home_name'])} korner yiyor</span><span>{c['ha_']}</span></div>"
                f"<div class='kv'><span>{e(c['away_name'])} korner üretiyor</span><span>{c['af']}</span></div>"
                f"<div class='kv'><span>{e(c['away_name'])} korner yiyor</span><span>{c['aa']}</span></div></div>"
                f"<div><div class='vc'><b>Beklenen toplam korner</b><span class='big'>{c['tot']}</span>"
                f"<span class='mini'>Sinyal: <b style='color:#5ee7a0'>KORNER {c['pick']}</b> (eşik 9.5)</span></div></div></div>")
        out.append(sec(4, "🟨", "Korner Analizi", "İki takımın korner üretme/yeme ortalamalarının toplamı beklenen korner sayısını verir. 9.5 üstü ise ÜST, altı ise ALT sinyali.", body))

    # ---------------- 5. ORAN HAREKETİ ----------------
    if P.get("steam") or P.get("hareket"):
        rows = []
        for s in P["steam"][:18]:
            cls = "down" if s["chg"] < 0 else "up"
            yon = "▼ düştü" if s["chg"] < 0 else "▲ yükseldi"
            rows.append([MK.get(s["market"], s["market"]), e(s["line"] or "-"), POS.get(s["pos"], s["pos"]),
                         f"<span class='od'>{s['open']:.2f}</span>", f"<span class='od'>{s['close']:.2f}</span>",
                         f"<span class='od'>{s['min']:.2f} / {s['max']:.2f}</span>",
                         f"<span class='{cls}'>{yon} {abs(s['chg']):.1f}%</span>", f"<span class='od'>{s['n']}</span>"])
        ht = P.get("hareket")
        htbl = ""
        if ht:
            htbl = ("<h2 style='font-size:14px;margin-top:14px'>🧪 Hareket İsabet Testi</h2>"
                    "<div class='note'>Ev sahibinin oranı kısaldıysa (para ev sahibine gelmişse) sonuç değişiyor mu?</div>"
                    + table(["Grup", "Maç", "Ev kazanma oranı"],
                            [["Oranı <b>kısalan</b> ev sahipleri", f"<span class='od'>{ht['kisa_n']}</span>", f"<span class='od'>{ht['kisa_ev']:.0f}%</span>"],
                             ["Oranı <b>uzayan</b> (para gelmeyen) ev sahipleri", f"<span class='od'>{ht['uzun_n']}</span>", f"<span class='od'>{ht['uzun_ev']:.0f}%</span>"]])
                    + (f"<div class='note'>Fark: <b>{ht['fark']:+.0f} puan</b> — pozitifse piyasa hareketi gerçekten bilgi taşıyor.</div>"
                       if ht.get("fark") is not None else "<div class='note'>Karşılaştırma için yeterli maç yok.</div>"))
        body = (table(["Market", "Handikap/Çizgi", "Seçim", "Açılış", "Kapanış", "En düşük / En yüksek", "Değişim", "Hareket"], rows)
                + htbl)
        acik = ("Bahisçiler oranı neden değiştirir? Para akışı. <b>▼ düşen oran</b> = o tarafa para geliyor (piyasa güveniyor). "
                "En sert hareketler «steam move» olarak bilinir. Test kısmı, bu hareketlerin gerçekten sonucu tahmin edip etmediğini ölçer.")
        out.append(sec(5, "📈", "Oran Hareketleri ve Piyasa Sinyali", acik, body))

    # ---------------- 6. DEĞER TABLOSU ----------------
    if s2:
        rows = []
        for k2 in ("1", "0", "2"):
            E = P["edges"][k2]
            skor_ = E["edge_hist"]
            cls = "b-deger" if skor_ > 2 else ("b-pahali" if skor_ < -2 else "b-notr")
            btn = "DEĞER" if skor_ > 2 else ("PAHALI" if skor_ < -2 else "NÖTR")
            rows.append([f"<b>{E['lbl']}</b>", f"<span class='od'>{close[k2]:.2f}</span>",
                         f"<span class='od'>{E['piyasa']:.1f}%</span>", f"<span class='od'>{E['hist']:.1f}%</span>",
                         f"<span class='od'>{E['whist']:.1f}%</span>", f"<span class='od'>{E['poi']:.1f}%</span>",
                         f"<span class='od'>{skor_:+.1f} pt</span>", f"<span class='badge {cls}'>{btn}</span>",
                         f"<span class='od'>{E['kelly']:.1f}%</span>", f"<span class='od'>{P['conf'][k2]}/100</span>"])
        body = table(["Seçim", "Kapanış oranı", "Piyasa olasılığı", "Tarihsel isabet", "Ağırlıklı isabet",
                      "Poisson olasılığı", "Değer farkı", "Karar", "¼ Kelly", "Güven"], rows)
        acik = ("«Piyasa olasılığı» oranın söylediği şeydir. «Tarihsel isabet» bu oranla açılan maçlarda gerçekte ne olduğudur. "
                "<b>Fark pozitifse o bahis DEĞERLİ</b> (piyasa olduğundan ucuz fiyatlıyor); negatifse PAHALI. "
                "Kelly sütunu, teorik olarak bankonun yüzde kaçının oynanması gerektiğini gösterir (¼ güvenlik payıyla).")
        out.append(sec(6, "💰", "Değer Tablosu — Nereye Bahis Yapılır?", acik, body))

    # ---------------- 6.5 GERİ TEST / ROI ----------------
    if ms:
        rows = []
        for k2, lbl2 in (("1", "Ev"), ("0", "Beraberlik"), ("2", "Deplasman")):
            stake = 100.0 * len(ms); ret = 0.0; win = 0
            for c in ms:
                o = c["b365"][k2]
                hit = (c["hg"] > c["ag"]) if k2 == "1" else ((c["hg"] == c["ag"]) if k2 == "0" else (c["hg"] < c["ag"]))
                if hit: ret += 100.0 * o; win += 1
            prof = ret - stake; roi = 100 * prof / stake if stake else 0
            cls = "b-deger" if roi > 0 else "b-pahali"
            rows.append([f"<b>{lbl2}</b>", f"<span class='od'>{win}/{len(ms)}</span>",
                         f"<span class='od'>{100*win/len(ms):.0f}%</span>", f"<span class='od'>{stake:.0f}</span>",
                         f"<span class='od'>{ret:.0f}</span>", f"<span class='od'>{prof:+.0f}</span>",
                         f"<span class='badge {cls}'>{roi:+.1f}%</span>"])
        # en değerli tarafta sabit strateji
        en = max(P["edges"].items(), key=lambda kv: kv[1]["edge_hist"])[0]
        st2 = 100.0 * len(ms); r2 = 0.0; w2 = 0
        for c in ms:
            o = c["b365"][en]
            hit = (c["hg"] > c["ag"]) if en == "1" else ((c["hg"] == c["ag"]) if en == "0" else (c["hg"] < c["ag"]))
            if hit: r2 += 100.0 * o; w2 += 1
        roi2 = 100 * (r2 - st2) / st2 if st2 else 0
        body = (table(["Bahis", "İsabet", "İsabet %", "Toplam bahis", "Getiri", "Kâr/Zarar", "ROI"], rows)
                + f"<div class='note'>Sadece <b>{P['edges'][en]['lbl']}</b> tarafına her maçta 100 birim oynandığında: "
                  f"{w2}/{len(ms)} isabet · kâr <b>{r2-st2:+.0f}</b> birim · ROI <b class='{'git' if roi2>0 else 'kit'}'>{roi2:+.1f}%</b>. "
                  f"(Kapanış oranından, komisyon hariç.)</div>")
        acik = ("Bu tablo en gerçekçi testtir: aynı oranla açılan maçlarda <b>her maça 100 birim</b> oynansaydı ne olurdu? "
                "Kapanış oranı kullanıldığı için marj zaten içindedir. <b>Pozitif ROI</b> = o taraf uzun vadede kârlı.")
        out.append(sec(7, "🧪", "Geri Test / ROI — Gerçekten Para Kazandırır mıydı?", acik, body))

    # ---------------- 7. H2H ----------------
    h2h = P.get("h2h") or []
    if h2h:
        hh = h2h[:20]
        hw = sum(1 for x in hh if (x.get("hg") or 0) > (x.get("ag") or 0))
        dr = sum(1 for x in hh if (x.get("hg") or 0) == (x.get("ag") or 0))
        aw = len(hh) - hw - dr
        rows = []
        for x in hh:
            iy = f"{x.get('ht_h')}:{x.get('ht_a')}" if x.get("ht_h") is not None else "—"
            o = x.get("odds") or []
            oo = " / ".join(f"{float(v):.2f}" for v in o[:3]) if len(o) >= 3 else "—"
            rows.append([f'<a href="https://www.betexplorer.com{x["link"]}" target="_blank">{e(x["dt"])}</a>',
                         e(x.get("home_name", "")), e(x.get("away_name", "")),
                         f"<span class='od'><b>{x['hg']}:{x['ag']}</b></span>", f"<span class='od'>{iy}</span>",
                         f"<span class='od'>{oo}</span>", f"<span class='tag'>{e(x.get('comp',''))}</span>"])
        body = (f"<div class='note'>Son {len(hh)} karşılaşmada: <b>{hw} ev / {dr} beraberlik / {aw} deplasman</b></div>"
                + table(["Tarih", "Ev", "Deplasman", "MS", "İY", "Oran (1/X/2)", "Turnuva"], rows))
        acik = ("İki takımın tarihinde birbirine karşı ne yaptığı. İY kolonu ilk yarı skorunu verir — "
                "geleneksel olarak bu eşleşmenin nasıl geçtiğini gösterir.")
        out.append(sec(8, "🤝", "Karşılıklı Tarihçe (H2H)", acik, body))

    # ---------------- 8. FORM ----------------
    def form_tbl(name, ms2):
        if not ms2: return ""
        rows = []
        for m in ms2[:10]:
            renk = "git" if m["result"] == "G" else ("yit" if m["result"] == "B" else "kit")
            iy = f"{m.get('ht','')}"
            rows.append([e(m["date"]), e(m["home"]), f"<span class='od'><b>{e(m['ft'])}</b></span>", e(m["away"]),
                         f"<span class='od'>{e(iy)}</span>", f"<span class='{renk}'>{m['result']}</span>"])
        return f"<h2 style='font-size:14px'>{e(name)}</h2>" + table(["Tarih", "Ev", "MS", "Deplasman", "İY", "Sonuç"], rows)

    fh = P.get("form_home") or ("", []); fa = P.get("form_away") or ("", [])
    if fh[1] or fa[1]:
        body = f"<div class='two'><div>{form_tbl(fh[0] or info.get('home'), fh[1])}</div><div>{form_tbl(fa[0] or info.get('away'), fa[1])}</div></div>"
        acik = ("İki takımın son maçları. G=galibiyet, B=beraberlik, M=mağlubiyet. İY kolonu ilk yarı skoru — "
                "takımların erken gol atma/alma eğilimini gösterir.")
        out.append(sec(9, "🔥", "Form Analizi", acik, body))

    # ---------------- 9. POISSON ----------------
    pm = P.get("poisson")
    if pm:
        rows = [[f"<b>{lbl}</b>", f"<span class='od'>{o:.2f}</span>", f"<span class='od'>{p*100:.1f}%</span>",
                 f"<span class='od'>{1/p:.2f}</span>"] for lbl, o, p in
                (("Ev", close["1"], pm["p1"]), ("Beraberlik", close["0"], pm["px"]), ("Deplasman", close["2"], pm["p2"]))]
        tops = " ".join(f"<span class='pill'>{i}-{j} · {v*100:.1f}%</span>" for (i, j), v in pm["top"][:8])
        body = (table(["Sonuç", "Kapanış oranı", "Model olasılığı", "Adil oran"], rows)
                + f"<div class='note'>Beklenen gol: ev <b>{pm['lh']:.2f}</b> · dep <b>{pm['la']:.2f}</b> · toplam <b>{pm['total']:.2f}</b> · "
                  f"modelde 2.5Ü %{pm['o25']:.0f} · KG %{pm['btts']:.0f}</div>"
                + f"<div style='margin-top:8px'><b>En olası skorlar:</b> {tops}</div>")
        acik = ("Oranlardan çıkarılan matematiksel model. Oranların ima ettiği olasılığı marjdan arındırır, "
                "sonra gol beklentisini (λ) hesaplayıp skor dağılımı üretir. Adil oran, komisyonsuz gerçek fiyatı gösterir.")
        out.append(sec(10, "🎲", "Poisson Modeli", acik, body))

    # ---------------- 10. TÜM BAHİSÇİLER ----------------
    markets = P.get("markets") or {}
    rows = []
    for mkt in ("1x2", "ou", "bts"):
        recs = markets.get(mkt) or []
        byb = {}
        for r in recs:
            byb.setdefault(r["bookmaker"] or "?", {})[r["pos"] + "|" + (r["line"] or "")] = r["odd"]
        for bk, dd in list(byb.items())[:26]:
            if bk.lower().startswith("bet365"):
                cls = "b-deger"
            else:
                cls = None
            satir = [f"<b>{e(bk)}</b>", MK.get(mkt, mkt)]
            for key in ("1|", "0|", "2|", "y|", "n|"):
                satir.append(f"<span class='od'>{e(dd[key]) if key in dd else '—'}</span>")
            rows.append(satir)
    if rows:
        acik = ("Maçtaki tüm bahisçilerin güncel oranları. bet365 kendi maç sayfasındakiyle aynıdır — "
                "diğerleriyle kıyaslayıp en iyi fiyatı bulabilirsin.")
        out.append(sec(11, "🏦", "Tüm Bahisçiler", acik,
                       table(["Bahisçi", "Market", "1", "X", "2", "KG Var", "KG Yok"], rows[:40])))

    out.append(f"<div class='note' style='text-align:center;margin-top:20px'>Analiz süresi {P.get('elapsed2', P.get('elapsed'))} sn · "
               f"arşiv {P.get('_arsiv', '55.605')} maç · veri: BetExplorer + soccerstats</div></div>")
    return f"""<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(info.get('home'))} - {e(info.get('away'))} · Derin Analiz</title>
<style>{CSS}</style></head><body>{''.join(out)}</body></html>"""
