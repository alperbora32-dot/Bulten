#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SAAT — BetExplorer saatlerini TÜRKİYE saatine çevirir.

Site, maç saatlerini kendi saat diliminde (şu an UTC+1) gösteriyor; Türkiye UTC+3.
Fark her koşuda site sayfasındaki `data-dt-now` ile ölçülüp önbelleğe alınır (12 saat).
"""
import json, os, re, time, urllib.request
from datetime import datetime
from zoneinfo import ZoneInfo

ONB = '/home/user/veri/saat_fark.json'
UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'}
TZ = ZoneInfo('Europe/Istanbul')


def simdi():
    return datetime.now(TZ)


def _site_saati():
    try:
        h = urllib.request.urlopen(urllib.request.Request('https://www.betexplorer.com/results/', headers=UA),
                                   timeout=20).read().decode('utf-8', 'ignore')
        m = re.search(r'data-dt-now="(\d+),(\d+),(\d+),(\d+),(\d+)"', h)
        if m:
            g, a, y, sa, dk = (int(x) for x in m.groups())
            return datetime(y, a, g, sa, dk)
    except Exception:
        pass
    return None


def fark_ogren(zorla=False):
    """Türkiye ile site arasındaki saat farkı (saat, tam sayı). Önbellekli."""
    try:
        c = json.load(open(ONB, encoding='utf-8'))
        if not zorla and time.time() - c.get('t', 0) < 12 * 3600:
            return c['fark']
    except Exception:
        c = {}
    f = 2                                   # güvenli varsayılan
    s = _site_saati()
    if s:
        f = int(round((simdi().replace(tzinfo=None) - s).total_seconds() / 3600))
        if not (0 <= f <= 5):
            f = 2
    try:
        json.dump({'fark': f, 'olcum': simdi().strftime('%d.%m.%Y %H:%M'), 't': time.time(),
                   'site': s.strftime('%d.%m %H:%M') if s else '-'}, open(ONB, 'w', encoding='utf-8'),
                  ensure_ascii=False)
    except Exception:
        pass
    return f


def tr(ss, fark=None):
    """Site saatini Türkiye saatine çevirir. Döner: (yeni_saat, gun_kaymasi)
    gun_kaymasi: 0 = aynı gün, 1 = ertesi gün (00:00'ı geçti)."""
    f = fark_ogren() if fark is None else fark
    m = re.match(r'^\s*(\d{1,2}):(\d{2})\s*$', str(ss or ''))
    if not m:
        return (str(ss or ''), 0)
    h, dk = int(m.group(1)) + f, int(m.group(2))
    gun = 0
    if h >= 24:
        h -= 24
        gun = 1
    return ('%02d:%02d' % (h, dk), gun)


def anahtarlari_cevir(K, fark=None):
    """Kayıt listesindeki 's' alanını Türkiye saatine çevirir (gun=1 ise işaretler)."""
    f = fark_ogren() if fark is None else fark
    for r in K:
        yeni, gun = tr(r.get('s'), f)
        r['s'] = yeni
        if gun:
            r['gun_kaydi'] = 1
    return K


if __name__ == '__main__':
    print('ölçülen fark (saat):', fark_ogren(True))
    print('şimdi TR:', simdi().strftime('%d.%m.%Y %H:%M'))
    for s in ('15:00', '22:30', '23:45', '00:30'):
        print(' site', s, '→ TR', tr(s))
