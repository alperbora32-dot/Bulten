#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TÜM LİGLERDE 2010+ maç taraması: oran + skor + maç linki (BetExplorer sonuç sayfaları)"""
import json, re, subprocess, sys, time, os
from concurrent.futures import ThreadPoolExecutor

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
CJ="/tmp/be_cookies.txt"; BASE="https://www.betexplorer.com"
OUT="/home/user/veri"

SELECT = {
 'england':['premier-league','championship','league-one','league-two'],
 'spain':['laliga','laliga2'],
 'italy':['serie-a','serie-b'],
 'germany':['bundesliga','2-bundesliga','3-liga'],
 'france':['ligue-1','ligue-2'],
 'netherlands':['eredivisie','eerste-divisie'],
 'portugal':['liga-nos','primeira-liga','liga-portugal','liga-sagres'],
 'turkey':['super-lig','1-lig'],
 'russia':['premier-league'],
 'greece':['super-league'],
 'belgium':['jupiler-pro-league','pro-league'],
 'scotland':['premiership','championship'],
 'austria':['bundesliga','2-liga'],
 'switzerland':['super-league','challenge-league'],
 'denmark':['superliga','superligaen'],
 'sweden':['allsvenskan','superettan'],
 'norway':['eliteserien','division-1','tippeligaen'],
 'poland':['ekstraklasa','division-1'],
 'brazil':['serie-a','serie-b'],
 'argentina':['liga-profesional','primera-nacional','torneo-inicial','primera-division'],
 'usa':['mls'],
 'mexico':['liga-mx'],
 'japan':['j1-league','j2-league','j3-league'],
 'south-korea':['k-league-1','k-league-2'],
 'china':['super-league'],
 'australia':['a-league'],
 'saudi-arabia':['saudi-professional-league','premier-league'],
 'europe':['champions-league','europa-league'],
}

COOKIE="age_verified=true; js_cookie=1; my_timezone=%2B1; be_lang=en"
def curl(u, n=30):
    for _ in range(3):
        try:
            r=subprocess.run(["curl","-s","-m",str(n),"-A",UA,"-H","Cookie: "+COOKIE,
                              "-H","Accept-Language: en-US,en;q=0.9",u],capture_output=True,timeout=n+10)
            s=r.stdout.decode("utf-8","ignore")
            if len(s)>3000 and ("data-odd" in s or "in-match" in s): return s
        except Exception: pass
        time.sleep(0.5)
    return ""

def parse_results(html_text, url):
    rows=[]
    for tr in re.findall(r'<tr[^>]*>(.*?)</tr>', html_text, re.S):
        if 'data-odd' not in tr: continue
        m=re.search(r'href="(/football/[^"]*/[A-Za-z0-9]{8}/)"[^>]*class="in-match"><span>(?:<strong>)?([^<]*)(?:</strong>)?</span> - <span>(?:<strong>)?([^<]*)(?:</strong>)?</span>', tr)
        if not m: continue
        link, home, away = m.group(1), m.group(2), m.group(3)
        sm=re.search(r'>(\d+):(\d+)</a>', tr)
        if not sm: continue
        odds=re.findall(r'data-odd="([\d\.]+)"', tr)
        if len(odds)<3: continue
        dm=re.search(r'h-text-right h-text-no-wrap">([^<]*)</td>', tr)
        rows.append({"url":url,"link":link,"id":link.strip('/').split('/')[-1],
                     "home":home,"away":away,"hg":int(sm.group(1)),"ag":int(sm.group(2)),
                     "o1":float(odds[0]),"ox":float(odds[1]),"o2":float(odds[2]),
                     "date":dm.group(1) if dm else "", "league":url})
    return rows

if __name__=="__main__":
    L=json.load(open(f"{OUT}/leagues.json"))
    urls=[]
    for country, slugs in SELECT.items():
        for slug in slugs:
            pat=re.compile(r'^/football/'+re.escape(country)+'/'+re.escape(slug)+r'(-\d{4}(-\d{4})?)?/$')
            for l in L:
                if not pat.match(l): continue
                yrs=[int(y) for y in re.findall(r'-(\d{4})(?:-\d{4})?/', l)]
                y=max(yrs) if yrs else 2026
                if y>=2010: urls.append(l)
    urls=sorted(set(urls))
    print("taranacak lig-dönem sayfası:",len(urls), flush=True)
    json.dump(urls,open(f"{OUT}/scan_urls.json","w"),indent=1)

    all_matches=[]
    done=0
    def work(u):
        h=curl(BASE+u+"results/")
        return parse_results(h,u) if h else []
    t0=time.time()
    with ThreadPoolExecutor(max_workers=12) as ex:
        for i,res in enumerate(ex.map(work,urls)):
            all_matches.extend(res); done+=1
            if i%40==0:
                print(f"  {i}/{len(urls)} sayfa | {len(all_matches)} maç | {round(time.time()-t0)}s", flush=True)
    json.dump(all_matches,open(f"{OUT}/all_matches.json","w",encoding="utf-8"),ensure_ascii=False)
    print("BİTTİ:",len(all_matches),"maç,",len(set(m['id'] for m in all_matches)),"tekil maç, süre",round(time.time()-t0),"sn",flush=True)
