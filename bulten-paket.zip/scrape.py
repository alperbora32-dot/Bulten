#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Kyoto Sanga - Kashiwa Reysol  |  BetExplorer oran arşivi scraper
Oranlar (bet365 dahil), açılış->güncel hareket, İY/MS skorları, tüm H2H tarihçesi.
"""
import subprocess, json, re, os, time, html

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
CJ = "/tmp/be_cookies.txt"
BASE = "https://www.betexplorer.com"
OUT = "/home/user/veri"
os.makedirs(OUT, exist_ok=True)


def curl(url, ref=None, tries=3):
    for i in range(tries):
        cmd = ["curl", "-s", "-m", "60", "-A", UA, "-b", CJ, "-c", CJ,
               "-H", "Accept-Language: en-US,en;q=0.9"]
        if ref:
            cmd += ["-e", ref]
        cmd.append(url)
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.stdout and len(r.stdout) > 50:
            return r.stdout
        time.sleep(1.5)
    return r.stdout

def parse_odds_html(h, market):
    """td hücrelerinden oranları + satır bağlamını (handikap/çizgi) çıkar."""
    out = []
    # table rows
    rows = re.findall(r'<tr[^>]*>(.*?)</tr>', h, re.S)
    for row in rows:
        if 'data-odd' not in row:
            continue
        # satır bağlamı: çizgi / handikap
        line = ''
        m = re.search(r'<td class="table-main__doubleparameter">([^<]*)</td>', row)
        if m:
            line = html.unescape(m.group(1)).strip()
        book = ''
        bm = re.search(r'data-bookie="([^"]*)"', row)
        bid = ''
        b2 = re.search(r'<tr\s+data-bid="(\d+)"', row)
        if b2:
            bid = b2.group(1)
        if not book:
            bm2 = re.search(r'class="in-bookmaker-logo-link[^"]*"[^>]*>([^<]*)<', row)
            if bm2:
                book = bm2.group(1)
        # her td
        for td in re.findall(r'<td[^>]*data-odd="[^"]*"[^>]*>', row):
            def g(k):
                mm = re.search(k + r'="([^"]*)"', td)
                return mm.group(1) if mm else ''
            out.append({
                "market": market,
                "line": line,
                "bookmaker": g('data-bookie') or book,
                "bid": g('data-bid') or bid,
                "odd": g('data-odd'),
                "created": g('data-created'),
                "pos": g('data-pos'),
                "oid": g('data-oid'),
                "bt": g('data-bt'),
                "sc": g('data-sc'),
                "hcp": g('data-hcp'),
            })
    return out

def match_odds(eid, bet, ref, variant=1):
    """bet: 1x2 | ou | ah | ha(dnb) | dc | bts ; kind: odds (tüm bahisçiler)"""
    url = f"{BASE}/match-odds/{eid}/{variant}/{bet}/odds/?lang=en"
    raw = curl(url, ref=ref)
    try:
        j = json.loads(raw)
        return parse_odds_html(j.get("odds", ""), bet)
    except Exception:
        return []

def archive_odds(rec, ref):
    url = f"{BASE}/archive-odds/{rec['oid']}/{rec['bid']}/{rec['bt']}/{rec['sc']}/{rec['hcp']}/"
    raw = curl(url, ref=ref)
    try:
        return json.loads(raw)
    except Exception:
        return []

def match_page(path):
    h = curl(BASE + path)
    d = {}
    m = re.search(r'data-dt="([^"]*)"', h)
    d['dt'] = m.group(1) if m else ''
    m = re.search(r'<p class="list-details__item__score" id="js-score">(.*?)</p>', h, re.S)
    d['score'] = re.sub(r'<[^>]+>', '', m.group(1)).strip() if m else ''
    m = re.search(r'id="js-partial">(.*?)</div>', h, re.S)
    d['partial'] = re.sub(r'<[^>]+>', '', m.group(1)).strip() if m else ''
    m = re.search(r'<h1[^>]*>([^<]*)</h1>', h)
    d['title'] = html.unescape(m.group(1)).strip() if m else ''
    m = re.search(r'<li class="breadcrumb__li breadcrumb__li__mobile"><a href="[^"]*"[^>]*>([^<]*)</a></li>', h)
    d['comp'] = html.unescape(m.group(1)).strip() if m else ''
    m = re.search(r'id="eventID"', h)
    d['has_page'] = bool(m)
    return d, h

if __name__ == "__main__":
    data = {}

    # ---------- 1) BUGÜNKÜ MAÇ ----------
    CUR = "/football/japan/j1-league/kyoto-kashiwa-reysol/69OvaPUj/"
    cur_ref = BASE + CUR
    page_html = curl(cur_ref)
    ts = re.search(r"match_load_tabs\('([^']+)', '([^']+)', '([^']+)', '([^']+)'", page_html)
    cur = {"id": ts.group(1) if ts else "69OvaPUj", "page": CUR}
    p, _ = match_page(CUR)
    cur["page_info"] = p
    cur["markets"] = {}
    for bt in ["1x2", "ou", "ah", "ha", "dc", "bts"]:
        recs = match_odds(cur["id"], bt, cur_ref)
        cur["markets"][bt] = recs
        print(f"[güncel] {bt}: {len(recs)} oran hücresi")
        time.sleep(0.6)
    # açılış oranları (bet365 + tüm bahisçiler)
    mo = []
    for bt, recs in cur["markets"].items():
        for r in recs:
            a = archive_odds(r, cur_ref)
            if a:
                mo.append({"market": bt, "line": r["line"], "bookmaker": r["bookmaker"],
                           "closed": r["odd"], "created": r["created"], "history": a})
            time.sleep(0.35)
    cur["movements"] = mo
    print("[güncel] hareket kaydı:", len(mo))
    data["current"] = cur

    # ---------- 2) H2H TARİHÇE (2010+) ----------
    h2h_page = curl(BASE + "/football/japan/j1-league/mutual-matches/?home=fZS33RAH&away=hEbtKvnM")
    links = sorted(set(re.findall(r'href="(/football/[a-z0-9\-]+/[a-z0-9\-]+/[a-z0-9\-]+/[A-Za-z0-9]{8}/)"', h2h_page)))
    def year_of(l):
        m = re.search(r'(?:league|cup|champions-league)?-?(\d{4})/$', l)
        return int(m.group(1)) if m else 0
    h2h = [l for l in links if year_of(l) >= 2010]
    data["h2h_links"] = h2h
    print("H2H maç sayısı (2010+):", len(h2h))
    matches = []
    for l in h2h:
        eid = l.strip('/').split('/')[-1]
        info, ph = match_page(l)
        rec = {"link": l, "id": eid, "info": info}
        rec["markets"] = {}
        for bt in ["1x2", "ou", "bts"]:
            rec["markets"][bt] = match_odds(eid, bt, BASE + l, variant=1)
            time.sleep(0.5)
        # bet365 açılış/kapanış hareketleri
        mo = []
        for bt, recs in rec["markets"].items():
            for r in recs:
                if r["bookmaker"].lower().startswith("bet365") or True:
                    a = archive_odds(r, BASE + l)
                    if a:
                        mo.append({"market": bt, "line": r["line"], "bookmaker": r["bookmaker"],
                                   "closed": r["odd"], "created": r["created"], "history": a})
                    time.sleep(0.3)
        rec["movements"] = mo
        matches.append(rec)
        print(f"  {info['dt']} {info['title']} {info['score']} {info['partial']} | odds:{ {k:len(v) for k,v in rec['markets'].items()} }")
    data["h2h_matches"] = matches

    json.dump(data, open(f"{OUT}/raw_data.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("KAYDEDİLDİ:", f"{OUT}/raw_data.json")
