#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""H2H arşivi (2010+) + lig verileri + korner istatistikleri"""
import subprocess, json, re, os, time, html

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
CJ = "/tmp/be_cookies.txt"
BASE = "https://www.betexplorer.com"
OUT = "/home/user/veri"

def set_cookie(name, val):
    subprocess.run(["curl","-s","-o","/dev/null","-A",UA,"-b",CJ,"-c",CJ,
                    "-H", f"Cookie: {name}={val}", BASE+"/"], capture_output=True)
    # doğrudan jar'a yaz
    with open(CJ,"a") as f:
        f.write(f"www.betexplorer.com\tFALSE\t/\tFALSE\t1900000000\t{name}\t{val}\n")

set_cookie("age_verified","true"); set_cookie("js_cookie","1")

def curl(url, ref=None, tries=6, minlen=0):
    last=""
    for i in range(tries):
        cmd=["curl","-s","-m","60","-A",UA,"-b",CJ,"-c",CJ,"-H","Accept-Language: en-US,en;q=0.9"]
        if ref: cmd+=["-e",ref]
        cmd.append(url)
        r=subprocess.run(cmd,capture_output=True,text=True)
        last=r.stdout
        if last and len(last)>max(minlen,100) and "idade" not in last and "Verificação" not in last:
            return last
        time.sleep(2+i)
    return last

def parse_odds_html(h, market):
    out=[]
    rows=re.findall(r'<tr[^>]*>(.*?)</tr>',h,re.S)
    for row in rows:
        if 'data-odd' not in row: continue
        line=''
        m=re.search(r'<td class="table-main__doubleparameter">([^<]*)</td>',row)
        if m: line=html.unescape(m.group(1)).strip()
        bid=''
        b2=re.search(r'<tr\s+data-bid="(\d+)"',row)
        if b2: bid=b2.group(1)
        book=''
        bm2=re.search(r'class="in-bookmaker-logo-link[^"]*"[^>]*>([^<]*)<',row)
        if bm2: book=bm2.group(1).strip()
        for td in re.findall(r'<td[^>]*data-odd="[^"]*"[^>]*>',row):
            def g(k):
                mm=re.search(k+r'="([^"]*)"',td); return mm.group(1) if mm else ''
            out.append({"market":market,"line":line,"bookmaker":g('data-bookie') or book,
                        "bid":g('data-bid') or bid,"odd":g('data-odd'),"created":g('data-created'),
                        "pos":g('data-pos'),"oid":g('data-oid'),"bt":g('data-bt'),
                        "sc":g('data-sc'),"hcp":g('data-hcp')})
    return out

def match_odds(eid, bet, ref):
    raw=curl(f"{BASE}/match-odds/{eid}/1/{bet}/odds/?lang=en", ref=ref, minlen=200)
    try: return parse_odds_html(json.loads(raw).get("odds",""), bet)
    except Exception: return []

def archive_odds(rec, ref):
    raw=curl(f"{BASE}/archive-odds/{rec['oid']}/{rec['bid']}/{rec['bt']}/{rec['sc']}/{rec['hcp']}/", ref=ref)
    try: return json.loads(raw)
    except Exception: return []

def match_page(path):
    h=curl(BASE+path, minlen=20000)
    d={}
    m=re.search(r'data-dt="([^"]*)"',h); d['dt']=m.group(1) if m else ''
    m=re.search(r'<p class="list-details__item__score" id="js-score">(.*?)</p>',h,re.S)
    d['score']=re.sub(r'<[^>]+>','',m.group(1)).strip() if m else ''
    m=re.search(r'id="js-partial">(.*?)</div>',h,re.S)
    d['partial']=re.sub(r'<[^>]+>','',m.group(1)).strip() if m else ''
    m=re.search(r'<h1[^>]*>([^<]*)</h1>',h); d['title']=html.unescape(m.group(1)).strip() if m else ''
    m=re.search(r'breadcrumb__li__mobile"><a href="[^"]*"[^>]*>([^<]*)</a></li>\s*<li[^>]*>\s*<span',h)
    d['comp']=html.unescape(m.group(1)).strip() if m else ''
    return d,h

data={}
# ---------- H2H linkleri ----------
h2h_page=curl(BASE+"/football/japan/j1-league/mutual-matches/?home=fZS33RAH&away=hEbtKvnM", minlen=60000)
links=sorted(set(re.findall(r'href="(/football/[a-z0-9\-]+/[a-z0-9\-]+/[a-z0-9\-]+/[A-Za-z0-9]{8}/)"',h2h_page)))
print("link sayısı:",len(links))
def year_of(l):
    m=re.search(r'-(\d{4})/',l); return int(m.group(1)) if m else 0
h2h=[l for l in links if year_of(l)>=2010]
print("2010+ maç:",len(h2h), h2h)

matches=[]
for l in h2h:
    eid=l.strip('/').split('/')[-1]
    info,_=match_page(l)
    rec={"link":l,"id":eid,"info":info,"markets":{}}
    for bt in ["1x2","ou","ah","ha","dc","bts"]:
        rec["markets"][bt]=match_odds(eid,bt,BASE+l)
        time.sleep(0.5)
    mov=[]
    for bt,recs in rec["markets"].items():
        for r in recs:
            if not r["bookmaker"].lower().startswith("bet365"): continue
            a=archive_odds(r,BASE+l)
            if a: mov.append({"market":bt,"line":r["line"],"bookmaker":r["bookmaker"],
                              "closed":r["odd"],"created":r["created"],"history":a})
            time.sleep(0.3)
    rec["movements"]=mov
    matches.append(rec)
    print(f"  {info.get('dt')} | {info.get('title')} | {info.get('score')} | Ä°Y:{info.get('partial')} | "
          f"1x2:{len(rec['markets']['1x2'])} ou:{len(rec['markets']['ou'])} bts:{len(rec['markets']['bts'])} mov:{len(mov)}")
data["h2h_matches"]=matches
json.dump(data,open(f"{OUT}/h2h_data.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
print("kaydedildi h2h_data.json")
