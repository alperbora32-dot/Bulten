#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HIZLI paralel H2H arşivi (2010+)"""
import subprocess, json, re, html, time
from concurrent.futures import ThreadPoolExecutor

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
CJ="/tmp/be_cookies.txt"; BASE="https://www.betexplorer.com"

def curl(url, ref=None):
    cmd=["curl","-s","-m","30","-A",UA,"-b",CJ,"-c",CJ,"-H","Accept-Language: en-US,en;q=0.9"]
    if ref: cmd+=["-e",ref]
    cmd.append(url)
    for _ in range(3):
        r=subprocess.run(cmd,capture_output=True,text=True).stdout
        if r and len(r)>200 and "idade" not in r: return r
        time.sleep(0.5)
    return r or ""

def parse_odds(h,market):
    out=[]
    for row in re.findall(r'<tr[^>]*>(.*?)</tr>',h,re.S):
        if 'data-odd' not in row: continue
        line=''
        m=re.search(r'<td class="table-main__doubleparameter">([^<]*)</td>',row)
        if m: line=html.unescape(m.group(1)).strip()
        book=''
        b=re.search(r'class="in-bookmaker-logo-link[^"]*"[^>]*>([^<]*)<',row)
        if b: book=b.group(1).strip()
        for td in re.findall(r'<td[^>]*data-odd="[^"]*"[^>]*>',row):
            g=lambda k:(re.search(k+r'="([^"]*)"',td).group(1) if re.search(k+r'="([^"]*)"',td) else '')
            out.append({"market":market,"line":line,"bookmaker":g('data-bookie') or book,
                        "odd":g('data-odd'),"created":g('data-created'),"pos":g('data-pos'),
                        "oid":g('data-oid'),"bid":g('data-bid'),"bt":g('data-bt'),
                        "sc":g('data-sc'),"hcp":g('data-hcp')})
    return out

def odds(eid,bt,ref,kind="odds"):
    raw=curl(f"{BASE}/match-odds/{eid}/1/{bt}/{kind}/?lang=en",ref)
    try: return parse_odds(json.loads(raw).get("odds",""),bt)
    except Exception: return []

def page(path):
    h=curl(BASE+path)
    d={"len":len(h)}
    m=re.search(r'data-dt="([^"]*)"',h); d['dt']=m.group(1) if m else ''
    m=re.search(r'id="js-score">(.*?)</p>',h,re.S); d['score']=re.sub(r'<[^>]+>','',m.group(1)).strip() if m else ''
    m=re.search(r'id="js-partial">(.*?)</div>',h,re.S); d['partial']=re.sub(r'<[^>]+>','',m.group(1)).strip() if m else ''
    m=re.search(r'<h1[^>]*>([^<]*)</h1>',h); d['title']=html.unescape(m.group(1)).strip() if m else ''
    return d

H2H = ["/football/japan/j1-league-2026/kashiwa-reysol-kyoto/Ek0sTI1D/",
"/football/japan/j1-league-2026/kyoto-kashiwa-reysol/6PdZUvX0/",
"/football/japan/j1-league-2025/kashiwa-reysol-kyoto/vB57u2no/",
"/football/japan/j1-league-2025/kyoto-kashiwa-reysol/Cjpzcutn/",
"/football/japan/j1-league-2024/kashiwa-reysol-kyoto/S0HFunVa/",
"/football/japan/j1-league-2024/kyoto-kashiwa-reysol/WxlWA0pe/",
"/football/japan/j1-league-2023/kashiwa-reysol-kyoto/jqKk8FQG/",
"/football/japan/j1-league-2023/kyoto-kashiwa-reysol/U9yn8Ur7/",
"/football/japan/j1-league-2022/kashiwa-reysol-kyoto/C60SBYZm/",
"/football/japan/j1-league-2022/kyoto-kashiwa-reysol/bk9ohdds/",
"/football/japan/ybc-levain-cup-2022/kashiwa-reysol-kyoto/C8ZSqybh/",
"/football/japan/ybc-levain-cup-2022/kyoto-kashiwa-reysol/KlsKSN53/",
"/football/japan/emperors-cup-2021/kashiwa-reysol-kyoto/nyFbIOBQ/",
"/football/japan/j2-league-2019/kashiwa-reysol-kyoto/IspGlLSk/",
"/football/japan/j2-league-2019/kyoto-kashiwa-reysol/8jgd1u0r/"]

def work(l):
    eid=l.strip('/').split('/')[-1]
    ref=BASE+l
    p=page(l)
    mk={}
    for bt in ["1x2","ou","bts","ha","dc"]:
        mk[bt]=odds(eid,bt,ref)
    best={}
    for bt,recs in mk.items():
        best[bt]=odds(eid,bt,ref,"bestOdds")
    return {"link":l,"id":eid,"info":p,"markets":mk,"bestOdds":best}

t0=time.time()
with ThreadPoolExecutor(max_workers=8) as ex:
    res=list(ex.map(work,H2H))
print("süre:",round(time.time()-t0,1),"sn")
json.dump({"h2h":res},open("/home/user/veri/h2h_data.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
for r in res:
    i=r["info"]
    print(i.get('dt'),"|",i.get('title'),"|",i.get('score'),"| İY:",i.get('partial'),
          "| odds:",{k:len(v) for k,v in r["markets"].items()})
