#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SİTE ÜRET — statik site klasörünü hazırlar (_site).

  index.html   → tam bülten (BULTEN.html)
  canli.html   → canlı takip (kendini 60 sn'de yeniler)
  telefon.html → kurulum kılavuzu
  kiyas/*.html → maç başına tam kıyas sayfaları
  .nojekyll    → GitHub Pages'in dosyaları olduğu gibi yayınlaması için
"""
import os, re, sqlite3, sys

KOK = os.path.dirname(os.path.abspath(__file__))
HEDEF = os.path.join(KOK, "_site")

NAV = ('<div style="max-width:1560px;margin:0 auto;padding:10px 14px 0;font-size:13px">'
       '<a href="index.html" style="font-weight:700">📋 Bülten</a> · '
       '<a href="canli.html">🔴 Canlı takip</a> · '
       '<a href="kurulum.html">📱 Nasıl kurulur?</a> · '
       '<a href="telefon.html">🧰 İleri seviye</a>'
       '<span style="float:right;color:#68788a">son üretim: {T}</span></div>')


def main():
    import site_uret as _  # noqa  (kendi kendine importu engelle)
    raise SystemExit


def _bulten_site_modu():
    """BULTEN.html'i SITE_MOD=1 ile yeniden üret (statik site için ŞART).

    Neden: bülten normal modda üretilirse kıyas bağlantıları '/kiyas?mid=...'
    (mutlak, sunucu gerektiren) biçimde olur ve statik sitede kırılır.
    Bu adım, iş akışındaki sıradan bağımsız olarak bayrağı garanti eder.
    """
    import subprocess
    try:
        r = subprocess.run([sys.executable, "bulten_v3.py"], cwd=KOK, timeout=900,
                           env={**os.environ, "SITE_MOD": "1"},
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("  ✓ BULTEN.html SITE_MOD=1 ile yenilendi" if r.returncode == 0
              else f"  ! bulten_v3 çıkış kodu {r.returncode} — mevcut dosya kullanılacak",
              flush=True)
    except Exception as e:
        print(f"  ! bulten_v3 koşulamadı ({e}) — mevcut dosya kullanılacak", flush=True)


def calistir():
    from datetime import datetime
    os.makedirs(HEDEF, exist_ok=True)
    _bulten_site_modu()
    t = datetime.now().strftime("%d.%m.%Y %H:%M")
    nav = NAV.replace("{T}", t)

    # --- bülten ---
    b = open(os.path.join(KOK, "BULTEN.html"), encoding="utf-8").read()
    # emniyet kemeri: bayrak ne olursa olsun statik modda sabitle
    b = b.replace("const SITE=false", "const SITE=true")
    b = b.replace("<body>", "<body>" + nav, 1)
    b = b.replace('href="/kiyas?mid=', 'href="kiyas/')          # statik mod: göreli yol
    b = re.sub(r'(href="kiyas/[A-Za-z0-9]{8})"', r'\1.html"', b)
    b = b.replace('target="_blank">🔎 Tamamını aç (yeni sekme)</a>',
                  '>🔎 Bu maçın tam kıyas sayfası</a>')
    open(os.path.join(HEDEF, "index.html"), "w", encoding="utf-8").write(b)

    # --- canlı ---
    c = open(os.path.join(KOK, "CANLI.html"), encoding="utf-8").read()
    open(os.path.join(HEDEF, "canli.html"), "w", encoding="utf-8").write(c)

    # --- kılavuz: kurulum (GitHub Pages yolu) ---
    if os.path.exists(os.path.join(KOK, "KURULUM.html")):
        open(os.path.join(HEDEF, "kurulum.html"), "w", encoding="utf-8").write(
            open(os.path.join(KOK, "KURULUM.html"), encoding="utf-8").read())

    # --- kılavuz: ileri seviye (kendi cihazında çalıştırma) ---
    if os.path.exists(os.path.join(KOK, "TELEFON.html")):
        open(os.path.join(HEDEF, "telefon.html"), "w", encoding="utf-8").write(
            open(os.path.join(KOK, "TELEFON.html"), encoding="utf-8").read())

    # --- otomasyon dosyasının metni (siteyi güncellerken kopyalamak için) ---
    _yml = os.path.join(KOK, "github", "guncelle.yml")
    if os.path.exists(_yml):
        open(os.path.join(HEDEF, "guncelle.yml.txt"), "w", encoding="utf-8").write(
            open(_yml, encoding="utf-8").read())

    open(os.path.join(HEDEF, ".nojekyll"), "w").write("")

    # --- kıyas sayfaları ---
    try:
        import kiyas_statik
        n = kiyas_statik.uret(HEDEF)
    except Exception as e:
        n = 0
        print("kiyas sayfaları atlandı:", str(e)[:90])

    boy = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(HEDEF) for f in fs)
    dosya = sum(len(fs) for _, _, fs in os.walk(HEDEF))
    print("SİTE HAZIR → %s · %d dosya · %.1f MB · kıyas %d" % (HEDEF, dosya, boy / 1048576, n))


if __name__ == "__main__":
    calistir()
