#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SÜREKLİ GÜNCELLEYİCİ (takip.py)

Her turda:
  1) Bugünün başlamamış maçları için GÜNCEL oranları çeker  → açılış → şimdi hareketi
  2) Maç başladığında SON görülen oranı **KAPANIŞ ORANI** olarak dondurur
  3) Sinyalimizin kapanışa göre değerini ölçer → **CLV (Closing Line Value)**
     CLV > 0  ⇒ kapanıştan daha iyi fiyat aldık ⇒ uzun vadede kâr beklentisi
  4) CANLI.html üretir (kendini 60 sn'de bir yenileyen tam ekran sayfa)

Kullanım:
  python3 takip.py            → tek tur + sayfa üret
  python3 takip.py dongu      → sürekli döngü (varsayılan 240 sn)
  python3 takip.py dongu 180  → 180 sn aralıkla döngü

Dosyalar: veri/hareket.json (anlık oran) · veri/kapanis.json (kapanış + CLV) · CANLI.html
"""
import json, os, re, sys, time, html as H, random, urllib.request, concurrent.futures as cf
from datetime import datetime
from zoneinfo import ZoneInfo

TZ = ZoneInfo('Europe/Istanbul')
import saat as SA   # site saatleri → Türkiye saati
UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
      'Accept-Language': 'tr,en;q=0.9'}
KOK = '/home/user'
HAREKET = f'{KOK}/veri/hareket.json'
KAPANIS = f'{KOK}/veri/kapanis.json'
CANLI = f'{KOK}/CANLI.html'
ISCI = 6
ONBELLEK = {}


def _oku(yol, varsayilan):
    try:
        return json.load(open(yol, encoding='utf-8'))
    except Exception:
        return varsayilan


def maclar():
    """Bugünün maçları — saatleri Türkiye saatine çevrilmiş olarak."""
    out = [m for m in _oku(f'{KOK}/veri/tam_tarama.json', []) if m.get('o') and m.get('id')]
    f = SA.fark_ogren()
    for m in out:
        y, g = SA.tr(m.get('saat'), f)
        m['saat'] = y
        m['gk'] = g
    return out


def _dk(simdi, saat):
    """Kickoff'a kalan/geçen dakika (+, geçti)."""
    try:
        hh, mm = (saat or '').split(':')
        k = simdi.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
    except Exception:
        return None
    return (simdi - k).total_seconds() / 60.0


def oran_cek(m):
    """Tek maçın güncel 1X2 ortalama oranı (BetExplorer oran sayfası)."""
    u = 'https://www.betexplorer.com/match-odds/%s/1/1x2/odds/' % m['id']
    h = None
    for d in range(2):
        try:
            h = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=20).read().decode('utf-8', 'ignore'))['odds']
            break
        except Exception:
            time.sleep(1 + d + random.random())
    if not h:
        return None
    ort_a = [x for x in re.findall(r'oddsComparisonAll__average_text"\s+data-odd="([\d.]*)"', h) if x]
    if len(ort_a) >= 3:
        o = [round(float(x), 2) for x in ort_a[:3]]
    else:
        uclar = []
        for tr in re.findall(r'<tr[\s\S]*?</tr>', h):
            v = re.findall(r'data-odd="([\d.]+)"', tr)
            if len(v) == 3:
                uclar.append([float(v[0]), float(v[1]), float(v[2])])
        if not uclar:
            return None
        o = [round(sum(x[i] for x in uclar) / len(uclar), 2) for i in range(3)]
    if not (1.005 <= sum(1 / x for x in o) <= 1.35):
        return None
    return o


def tek_tur(pencere=300, sari=60, yaz=True):
    t0 = time.time()
    simdi = datetime.now(TZ)
    ms = maclar()
    hrk = _oku(HAREKET, {'hareket': {}, 'atlanan': {}})
    har = hrk.get('hareket', {})
    kap = _oku(KAPANIS, {'kapanis': {}, 'ozet': {}})
    KAP = kap.get('kapanis', {})

    # ---- 1) güncel oranlar: başlamamış + yakın maçlar ----
    hedef = []
    for m in ms:
        d = _dk(simdi, m.get('saat'))
        if d is None:
            continue
        if 0 <= d <= pencere and m['id'] not in KAP and not m.get('gk'):
            hedef.append(m)
    yeni = 0
    if hedef:
        with cf.ThreadPoolExecutor(ISCI) as ex:
            for m, o in zip(hedef, ex.map(oran_cek, hedef)):
                if not o:
                    continue
                ac = m['o']
                hh = [round((o[i] / ac[i] - 1) * 100, 1) if ac[i] else 0.0 for i in range(3)]
                if max(abs(x) for x in hh) > 60:
                    continue
                bk = max(range(3), key=lambda i: abs(hh[i]))
                har[m['id']] = {'simdi': o, 'hareket': hh, 'yon': ['Ev', 'Ber', 'Dep'][bk],
                                'buyuk': hh[bk], 'cekim': simdi.strftime('%H:%M')}
                yeni += 1
        hrk['hareket'] = har
        hrk['atlanan'] = hrk.get('atlanan', {})
        json.dump(hrk, open(HAREKET, 'w', encoding='utf-8'), ensure_ascii=False)

    # ---- 2a) OYNANMIŞ maçların kapanışı yoksa sayfadan çek (geri doldurma) ----
    yeni_kapanis = 0
    eksik = []
    for m in ms:
        if m['id'] in KAP or m.get('gk'):
            continue
        d = _dk(simdi, m.get('saat'))
        if d is None or d < 0:
            continue
        eksik.append((m, d))
    if eksik:
        with cf.ThreadPoolExecutor(ISCI) as ex:
            futs = {ex.submit(oran_cek, m): (m, d) for m, d in eksik}
            for fu in cf.as_completed(futs):
                o = fu.result()
                m, d = futs[fu]
                if not o:
                    continue
                p = m.get('en_iyi')
                k = {'kapanis': o, 'acilis': [round(x, 2) for x in m['o']],
                     'hareket': [round((o[j] / m['o'][j] - 1) * 100, 1) if m['o'][j] else 0.0 for j in range(3)],
                     'saat': m.get('saat', ''), 'h': m.get('home', ''), 'a': m.get('away', ''),
                     'lig': m.get('lig', ''), 'son_cekim': simdi.strftime('%H:%M'),
                     'kaynak': ('sayfa-kapanış' if d >= 150 else 'canlı-sayfa')}
                if p:
                    j = {'Ev': 0, 'Beraberlik': 1, 'Deplasman': 2}.get(p.get('ad'))
                    if j is not None and o[j]:
                        k.update(sinyal=p.get('ad'), sinyal_oran=round(p.get('oran', 0), 2),
                                 clv=round((p.get('oran', 0) / o[j] - 1) * 100, 1))
                KAP[m['id']] = k
                yeni_kapanis += 1
        print('  ↻ oynanmış maç kapanışı toplandı: %d' % yeni_kapanis, flush=True)

    # ---- 2b) kapanış oranı dondur (maç başladı) ----
    for m in ms:
        mid = m['id']
        if mid in KAP:
            continue
        d = _dk(simdi, m.get('saat'))
        if d is None or d < 0:                 # henüz başlamadı
            continue
        v = har.get(mid)
        if not v:
            continue
        ck = v.get('cekim')
        _ko = m.get('saat') or '99:99'
        if m.get('gk'):
            _ko = '24:' + str(_ko)[3:]
        if not ck or ck > _ko:
            # bu maç için kapanış (kickoff öncesi son fiyat) yakalanamadı → CLV ölçülemez
            KAP[mid] = {'kapanis': None, 'acilis': [round(x, 2) for x in m['o']], 'saat': m.get('saat', ''),
                        'h': m.get('home', ''), 'a': m.get('away', ''), 'lig': m.get('lig', ''),
                        'gec': 1}
            yeni_kapanis += 1
            continue
        p = m.get('en_iyi')
        kayit = {'kapanis': v['simdi'], 'acilis': [round(x, 2) for x in m['o']],
                 'hareket': v['hareket'], 'son_cekim': v.get('cekim', ''), 'saat': m.get('saat', ''),
                 'h': m.get('home', ''), 'a': m.get('away', ''), 'lig': m.get('lig', '')}
        if p:
            i = {'Ev': 0, 'Beraberlik': 1, 'Deplasman': 2}.get(p.get('ad'))
            if i is not None and v['simdi'][i]:
                kayit.update(sinyal=p.get('ad'), sinyal_oran=round(p.get('oran', 0), 2),
                             clv=round((p.get('oran', 0) / v['simdi'][i] - 1) * 100, 1))
        KAP[mid] = kayit
        yeni_kapanis += 1
    if yeni_kapanis:
        clvler = [k['clv'] for k in KAP.values() if k.get('clv') is not None]
        kap['kapanis'] = KAP
        kap['ozet'] = {'n': len(clvler),
                       'ort_clv': round(sum(clvler) / len(clvler), 2) if clvler else 0,
                       'pozitif': sum(1 for x in clvler if x > 0),
                       'guncelleme': simdi.strftime('%d.%m %H:%M')}
        json.dump(kap, open(KAPANIS, 'w', encoding='utf-8'), ensure_ascii=False)

    # ---- 3) durum + sayfa ----
    _ars = f'{KOK}/veri/kapanis_arsiv.json'
    dur = {'son_tur': simdi.strftime('%d.%m.%Y %H:%M:%S'),
           'oran_tazeleme': yeni, 'kapanis_yakalanan': yeni_kapanis,
           'kapanis_toplam': len(KAP),
           'clv_olculen': kap.get('ozet', {}).get('n', 0),
           'clv_ort': kap.get('ozet', {}).get('ort_clv', 0),
           'arsiv_yasi_saat': round((time.time() - os.path.getmtime(_ars)) / 3600, 1) if os.path.exists(_ars) else None,
           'arsiv_tarih': datetime.fromtimestamp(os.path.getmtime(_ars), TZ).strftime('%d.%m.%Y %H:%M') if os.path.exists(_ars) else '-'}
    try:
        json.dump(dur, open(f'{KOK}/veri/takip_durum.json', 'w', encoding='utf-8'), ensure_ascii=False)
    except Exception:
        pass
    if yaz:
        yaz_canli(ms, har, KAP, kap.get('ozet', {}), simdi, dur)
    return {'oran': yeni, 'kapanis': yeni_kapanis, 'clv_n': dur['clv_olculen'], 'sure': round(time.time() - t0, 1)}


# ---------------------------------------------------------------- sayfa
def _o3(o):
    try:
        return ' / '.join(f'{x:.2f}' for x in o)
    except Exception:
        return '–'


def _hk(har):
    if not har:
        return '<span class="mini">–</span>'
    L = ['Ev', 'X', 'Dep']
    par = [(abs(v), i, v) for i, v in enumerate(har) if abs(v) >= 1]
    par.sort(reverse=True)
    if not par:
        return '<span class="mini">⇄ sabit</span>'
    return ' '.join(f'<span class="{"d" if v < 0 else "u"}">{L[i]} {"↓" if v < 0 else "↑"} {abs(v):.1f}%</span>' for _, i, v in par[:2])


def yaz_canli(ms, har, KAP, ozet, simdi, dur=None):
    def durum(m):
        d = _dk(simdi, m.get('saat'))
        if d is None:
            return ('', 99)
        if d < 0:
            return ('⏳ %d dk sonra' % int(-d), 1)
        if d <= 120:
            return ('🔴 %d. dk' % max(1, int(d)), 0)
        return ('✔ bitti/bitiyor', 2)

    L = [m for m in ms if (_dk(simdi, m.get('saat')) or -999) > -150]
    oynanan = sorted([m for m in L if 0 <= (_dk(simdi, m.get('saat')) or 0) <= 120], key=lambda m: m['saat'])
    sirada = sorted([m for m in L if 0 <= -(_dk(simdi, m.get('saat')) or 0) <= 90], key=lambda m: m['saat'])
    sinyalli = [m for m in L if m.get('en_iyi')]
    kap_satir = sorted([k for k in KAP.values() if k.get('clv') is not None], key=lambda k: -abs(k['clv']))
    gec = sum(1 for k in KAP.values() if k.get('gec'))

    def sat(m, K=None):
        mid = m['id']
        v = har.get(mid) or {}
        p = m.get('en_iyi')
        s = ''
        if p:
            i = {'Ev': 0, 'Beraberlik': 1, 'Deplasman': 2}.get(p.get('ad'))
            hh = v.get('hareket') or [0, 0, 0]
            y = hh[i] if i is not None else 0
            s = (f'<b>{H.escape(str(p.get("ad")))}</b> {p.get("oran"):.2f} '
                 f'<span class="mini">{p.get("edge"):+.1f} fark</span> ' +
                 (f'<span class="{"d" if y < 0 else "u"}">{y:+.1f}%</span>' if abs(y) >= 1 else ''))
        return (f'<tr><td class="mini">{H.escape(m.get("saat",""))}</td>'
                f'<td><b>{H.escape(m.get("home",""))}</b><br><span class="mini">{H.escape(m.get("away",""))} · '
                f'{H.escape(m.get("lig",""))}</span></td>'
                f'<td class="od">{_o3(v.get("simdi"))}<div class="mini">{H.escape(m.get("saat",""))} açılış: '
                f'{_o3(m.get("o"))}</div></td>'
                f'<td>{_hk(v.get("hareket"))}</td><td class="mini">{s or "–"}</td></tr>')

    clv_satir = []
    for k in kap_satir[:40]:
        c = k['clv']
        if not k.get('kapanis'):
            continue
        clv_satir.append(f'<tr><td class="mini">{H.escape(k.get("saat",""))}</td>'
                         f'<td><b>{H.escape(k.get("h",""))}</b> - {H.escape(k.get("a",""))}</td>'
                         f'<td class="od">{H.escape(str(k.get("sinyal","")))} {k.get("sinyal_oran",0):.2f}</td>'
                         f'<td class="od">{_o3(k.get("kapanis"))}</td>'
                         f'<td class="od {"d" if c>0 else "u"}"><b>{c:+.1f}%</b></td></tr>')

    css = """*{box-sizing:border-box}body{margin:0;background:#f6f7f9;color:#16212e;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif}
.wrap{max-width:1100px;margin:0 auto;padding:14px 12px 60px}
h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:18px 0 8px;color:#0d5c3a}
.mini{font-size:11.5px;color:#68788a}.od{font-variant-numeric:tabular-nums}
.d{color:#128a4b;font-weight:700}.u{color:#c0392b;font-weight:700}
.kart{background:#fff;border:1px solid #e3e8ee;border-radius:12px;padding:10px 12px;margin:10px 0;box-shadow:0 1px 2px #00000008}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e3e8ee;border-radius:10px;overflow:hidden}
th,td{padding:7px 8px;border-bottom:1px solid #eef1f4;text-align:left;font-size:13px;vertical-align:top}
th{background:#f2f5f8;font-size:12px}tfoot td{background:#fafbfc}
.tag{display:inline-block;background:#eaf5ef;color:#0d5c3a;border-radius:6px;padding:2px 7px;font-size:11.5px;margin-right:4px}
.ozet{display:flex;gap:8px;flex-wrap:wrap}.ozet div{background:#fff;border:1px solid #e3e8ee;border-radius:10px;padding:8px 12px;min-width:110px}
@media(max-width:640px){th:nth-child(4),td:nth-child(4){display:none}}"""
    oz = ozet or {}
    _st = dur or {}
    if not _st:
        try:
            _st = json.load(open(f'{KOK}/veri/takip_durum.json', encoding='utf-8'))
        except Exception:
            _st = {}
    try:
        _na = len(json.load(open(f'{KOK}/veri/kapanis_arsiv.json', encoding='utf-8')))
    except Exception:
        _na = 0
    html = f"""<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="60">
<title>🔴 Canlı Takip — {simdi.strftime('%H:%M')}</title><style>{css}</style></head><body><div class="wrap">
<h1>🔴 CANLI TAKİP <span class="mini">son güncelleme {simdi.strftime('%H:%M:%S')} · sayfa 60 sn'de bir kendini yeniler</span></h1>
<div class="mini" style="margin:6px 0">🗄️ Kapanış arşivi: <b>{{n_ars}}</b> maç (indirilme {{t_ars}}) · bugün ölçülen kapanış: <b>{{n_kap}}</b> · oranlar her <b>4 dk</b> yenilenir, sayfa her <b>60 sn</b> yenilenir · son tur {{t_tur}}</div>
<div class="ozet">
 <div><div class="mini">Şu an oynanan</div><b>{len(oynanan)} maç</b></div>
 <div><div class="mini">Önümüzdeki 90 dk</div><b>{len(sirada)} maç</b></div>
 <div><div class="mini">Değer sinyali</div><b>{len(sinyalli)} maç</b></div>
 <div><div class="mini">Ölçülen CLV</div><b>{oz.get('n',0)} sinyal</b></div>
 <div><div class="mini">Ortalama CLV</div><b class="{'d' if oz.get('ort_clv',0)>0 else 'u'}">{oz.get('ort_clv',0):+.2f}%</b></div>
</div>

<h2>🔴 ŞU AN OYNANANLAR</h2>
{'<table><thead><tr><th>Saat</th><th>Maç</th><th>Oran (şimdi / açılış)</th><th>Hareket</th><th>Sinyal</th></tr></thead><tbody>'+''.join(sat(m) for m in oynanan)+'</tbody></table>' if oynanan else '<div class="kart mini">Şu an oynanan maç yok.</div>'}

<h2>⏳ ÖNÜMÜZDEKİ 90 DAKİKA (kapanışa son fiyatlar)</h2>
{'<table><thead><tr><th>Saat</th><th>Maç</th><th>Oran (şimdi / açılış)</th><th>Hareket</th><th>Sinyal</th></tr></thead><tbody>'+''.join(sat(m) for m in sirada[:60])+'</tbody></table>' if sirada else '<div class="kart mini">Yaklaşan maç yok.</div>'}

<h2>📉 KAPANIŞ &amp; CLV — “kapanış oranı bize kazandırıyor mu?”</h2>
<div class="mini">Ölçülen {oz.get('n',0)} sinyal · kapanışı yakalanamayan (maç başladıktan sonra görülen) {gec} maç hariç tutuldu.</div>
<div class="kart mini">Bir sinyalin <b>CLV</b> değeri = (aldığımız oran ÷ kapanış oranı − 1). <b>Pozitifse</b> kapanışa göre daha iyi fiyat almışız ⇒ piyasa bizden sonra o tarafa kaymış ⇒ uzun vadede kâr beklentisi. Negatifse piyasa bizim seçtiğimiz taraftan uzaklaşmış.</div>
{'<table><thead><tr><th>Saat</th><th>Maç</th><th>Bizim sinyal</th><th>Kapanış (E/X/D)</th><th>CLV</th></tr></thead><tbody>'+''.join(clv_satir)+'</tbody></table>' if clv_satir else '<div class="kart mini">Bugün henüz kapanış yakalanmadı — maçlar başladıkça burada birikecek.</div>'}
<div class="kart mini" style="margin-top:10px">⚙️ Toplayıcı: <code>takip.py</code> · her turda oran tazeler, maç başlarken kapanışı dondurur · veri: veri/kapanis.json ·
skor canlı olarak JS ile yüklendiği için bu sayfada gösterilmiyor (yalnızca dakika/başladı bilgisi).</div>
</div></body></html>"""
    html = (html.replace('{n_ars}', f'{_na:,}'.replace(',', '.'))
                .replace('{t_ars}', str(_st.get('arsiv_tarih', '-')))
                .replace('{n_kap}', str(_st.get('kapanis_toplam', 0)))
                .replace('{t_tur}', str(_st.get('son_tur', simdi.strftime('%H:%M:%S')))))
    open(CANLI, 'w', encoding='utf-8').write(html)


def _log(satir):
    try:
        with open(f'{KOK}/veri/takip.log', 'a', encoding='utf-8') as f:
            f.write(datetime.now(TZ).strftime('%d.%m %H:%M:%S') + ' · ' + satir + '\n')
        if os.path.getsize(f'{KOK}/veri/takip.log') > 400_000:
            os.replace(f'{KOK}/veri/takip.log', f'{KOK}/veri/takip.log.1')
    except Exception:
        pass


def _bayat(yol, saat):
    try:
        return (time.time() - os.path.getmtime(yol)) > saat * 3600
    except Exception:
        return True


def dongu(aralik=240):
    print('takip döngüsü başladı · aralık %d sn' % aralik, flush=True)
    _log('döngü başladı (aralık %d sn)' % aralik)
    tur = 0
    while True:
        tur += 1
        try:
            r = tek_tur()
            satir = 'oran %d · yeni kapanış %d · CLV ölçülen %d · %.1fs' % (
                r['oran'], r['kapanis'], r.get('clv_n', 0), r['sure'])
            print(datetime.now(TZ).strftime('%H:%M:%S'), '·', satir, flush=True)
            if tur % 5 == 0:
                _log(satir)
            # --- alt görev 1: bülteni tazele (maç listesi/oranlar kaymasın) ---
            if tur % 10 == 1 and tur > 1:
                import subprocess
                subprocess.run(['python3', 'bulten_v3.py'], cwd=KOK, timeout=600,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                print('  ↻ BULTEN.html yenilendi', flush=True)
                _log('bülten yenilendi')
            # --- alt görev 2: kapanış arşivi bayatsa yenile (haftada 1 yeter) ---
            if _bayat(f'{KOK}/veri/kapanis_arsiv.json', 72):
                import subprocess
                print('  ↻ kapanış arşivi tazeleniyor…', flush=True)
                subprocess.run(['python3', 'kapanis_arsiv_indir.py'], cwd=KOK, timeout=900,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                _log('kapanış arşivi tazelendi')
        except Exception as e:
            print('HATA:', str(e)[:120], flush=True)
            _log('HATA ' + str(e)[:120])
        time.sleep(aralik)


if __name__ == '__main__':
    if 'dongu' in sys.argv:
        i = sys.argv.index('dongu')
        ar = int(sys.argv[i + 1]) if len(sys.argv) > i + 1 else 240
        dongu(ar)
    else:
        print(tek_tur())
