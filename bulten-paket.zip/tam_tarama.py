#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TAM GÜN TARAMASI — bir günün TÜM maçlarını (eksik oranları da tamamlayarak) çekip
her maç için "aynı oranla oynanan maçlar" karşılaştırması yapar.

Kullanım: python3 tam_tarama.py [gun_sayisi]
"""
import bisect, json, math, os, re, subprocess, sys, time, html as H
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

sys.path.insert(0, "/home/user")
import analiz_motoru as M

BASE = "https://www.betexplorer.com"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
COOKIE = "age_verified=true; js_cookie=1; my_timezone=%2B3; be_lang=en"
ARCH = "/home/user/veri/all_matches.json"
ORAN_CACHE = "/home/user/veri/oran_cache.json"
_today = datetime(2026, 9, 11)

def curl(u, n=35):
    for d in range(3):
        try:
            r = subprocess.run(["curl", "-s", "-m", str(n), "-H", "Accept-Encoding: gzip", "--compressed",
                                "-A", UA, "-H", "Cookie: " + COOKIE, "-H", "Accept-Language: en-US,en;q=0.9", u],
                               capture_output=True, timeout=n + 8)
            s = r.stdout.decode("utf-8", "ignore")
            if len(s) > 2000: return s
        except Exception: pass
        time.sleep(0.8)
    return ""

# ------------------------------------------------------------------ gün listesi
def gun_maclari(tarih):
    """O günün maçları — SADECE gerçekten o güne ait satırlar (data-dt filtresi).

    BetExplorer ?date= parametresini yok sayıp sayfada birkaç günü birden gösteriyor;
    bu yüzden satırın data-dt="g,а,y,sa,dk" özniteliği bugünle eşleşmiyorsa atlanır.
    Böylece dünkü maçlar ve eski skorlar bugüne karışmaz."""
    ds = tarih.strftime("%Y-%m-%d")
    dt_onek = "%d,%d,%d," % (tarih.day, tarih.month, tarih.year)   # site biçimi: 11,9,2026,
    h = curl(f"{BASE}/results/?date={ds}")
    if not h: return []
    h = h.replace("&nbsp;", " ")
    out, lig, atlanan = [], "", 0
    for tr in re.findall(r"<tr[^>]*>.*?</tr>", h, re.S):
        if "table-main__tt" not in tr:
            th = re.search(r"<th[^>]*>(.*?)</th>", tr, re.S)
            if th:
                t = H.unescape(re.sub(r"<[^>]+>", "", th.group(1))).strip()
                if t and t != "&nbsp;" and len(t) > 3: lig = t
            continue
        dt = re.search(r'data-dt="([\d,]+)"', tr)
        if not dt or not dt.group(1).startswith(dt_onek):     # başka güne ait satır → atla
            atlanan += 1
            continue
        m = re.search(r'<a href="(/football/([^/]+)/([^/"]+)/[^"]+/([A-Za-z0-9]{8})/)">(.*?)</a>', tr)
        if not m: continue
        ad = H.unescape(re.sub(r"<[^>]+>", "", m.group(5))).strip()
        if " - " not in ad: continue
        ev, dep = [x.strip() for x in ad.split(" - ", 1)]
        tm = re.search(r'table-main__time">([\d:]{4,5})<', tr)
        # saat span'ını çıkar; skor = (İY, MS) parantezi ya da h-text-center hücresi
        tr_t = re.sub(r'<span class="table-main__time">[\d:]{4,5}</span>', '', tr)
        pj = re.search(r'\((\d{1,2}):(\d{1,2}),\s*(\d{1,2}):(\d{1,2})\)', tr_t)
        sc = re.search(r'class="h-text-center"><a[^>]*>(\d{1,2}):(\d{1,2})</a>', tr_t)
        iy = f"{pj.group(1)}:{pj.group(2)}" if pj else ""
        skor = (f"{pj.group(3)}:{pj.group(4)}" if pj else (f"{sc.group(1)}:{sc.group(2)}" if sc else ""))
        canli = bool(re.search(r'\blive\b|in-play', tr, re.I))
        o = re.findall(r'data-odd="([\d.]+)"', tr)[:3]
        out.append({"gun": ds, "id": m.group(4), "link": m.group(1), "ulke": m.group(2),
                    "lig": m.group(3).replace("-", " ").title(), "lig_tam": lig,
                    "home": ev, "away": dep,
                    "saat": ("%02d:%02d" % (int(dt.group(1).split(",")[3]), int(dt.group(1).split(",")[4])))
                            if len(dt.group(1).split(",")) >= 5 else (tm.group(1) if tm else ""),
                    "dt_site": dt.group(1),
                    "skor": skor, "iy": iy, "durum": ("canlı" if canli else ("bitti" if skor else "bekliyor")),
                    "o": [float(x) for x in o] if len(o) == 3 else None})
    if atlanan:
        print("  (başka güne ait %d satır atlandı — sadece %s alındı)" % (atlanan, ds), flush=True)
    return out


SKOR_CACHE = "/home/user/veri/skor.json"


def skorlar(kaydet=True):
    """Bugünün maç sayfasından canlı/bitmiş skorları çeker: {id: {ms, iy, durum, dk}}."""
    h = curl(f"{BASE}/results/")
    out = {}
    if not h:
        return out
    h = h.replace("&nbsp;", " ")
    import datetime as _dt
    _bugun = _dt.date.today()
    _onek = "%d,%d,%d," % (_bugun.day, _bugun.month, _bugun.year)
    for tr in re.findall(r"<tr[^>]*>.*?</tr>", h, re.S):
        if "table-main__tt" not in tr:
            continue
        _dtm = re.search(r'data-dt="([\d,]+)"', tr)
        if not _dtm or not _dtm.group(1).startswith(_onek):
            continue                                   # eski günlerin skorları karışmasın
        m = re.search(r'/([A-Za-z0-9]{8})/">', tr)
        if not m:
            continue
        mid = m.group(1)
        pj = re.search(r"\((\d{1,2}):(\d{1,2}),\s*(\d{1,2}):(\d{1,2})\)", tr)     # (İY, MS)
        ms = (re.search(r'class="table-main__result"><a[^>]*>\s*<strong>(\d{1,2}):(\d{1,2})</strong>', tr)
              or re.search(r'class="h-text-center"><a[^>]*>(\d{1,2}):(\d{1,2})</a>', tr))
        canli = bool(re.search(r"(live|in-play|table-main__tt\slive)", tr, re.I))
        dk = re.search(r"(\d{1,3})'<", tr)
        if pj:
            _i = int(pj.group(1)) + int(pj.group(2))
            _m = int(pj.group(3)) + int(pj.group(4))
            if _i > _m:                                  # gol azalamaz → bozuk kayıt, at
                continue
            out[mid] = {"iy": f"{pj.group(1)}:{pj.group(2)}", "ms": f"{pj.group(3)}:{pj.group(4)}",
                        "durum": "canlı" if canli else "bitti", "dk": dk.group(1) if dk else ""}
        elif ms:
            out[mid] = {"iy": "", "ms": f"{ms.group(1)}:{ms.group(2)}",
                        "durum": "canlı" if canli else "bitti", "dk": dk.group(1) if dk else ""}
    if kaydet:
        json.dump(out, open(SKOR_CACHE, "w", encoding="utf-8"), ensure_ascii=False)
    return out


def skor_yukle():
    """Önbellekten skorlar; 5 dakikadan eskiyse yeniler."""
    import os as _os
    if _os.path.exists(SKOR_CACHE):
        try:
            if time.time() - _os.path.getmtime(SKOR_CACHE) < 300:
                return json.load(open(SKOR_CACHE, encoding="utf-8"))
        except Exception:
            pass
    try:
        return skorlar()
    except Exception:
        return {}

def oran_tamamla(maclar, workers=8):
    """Listede oranı olmayan maçların 1X2 oranını maç-odss servisinden çek (disk önbellekli)."""
    cache = json.load(open(ORAN_CACHE, encoding="utf-8")) if os.path.exists(ORAN_CACHE) else {}
    eksik = [m for m in maclar if not m["o"] and m["id"] not in cache]
    print(f"  oranı eksik maç: {len(eksik)} (önbellekte {sum(1 for m in maclar if m['id'] in cache)})", flush=True)
    def w(m):
        try:
            j = M.jsonget(f"{BASE}/match-odds/{m['id']}/1/1x2/odds/?lang=en", 20)
            o = re.findall(r'data-odd="([\d.]+)"', j.get("odds", "") if j else "")[:3]
            return m["id"], ([float(x) for x in o] if len(o) == 3 else None)
        except Exception:
            return m["id"], None
    if eksik:
        t0 = time.time()
        with ThreadPoolExecutor(max_workers=workers) as ex:
            for i, (k, v) in enumerate(ex.map(w, eksik)):
                cache[k] = v
                if i % 100 == 0:
                    print(f"   {i}/{len(eksik)} … {round(time.time()-t0)}s", flush=True)
        json.dump(cache, open(ORAN_CACHE, "w", encoding="utf-8"))
    for m in maclar:
        if not m["o"] and cache.get(m["id"]): m["o"] = cache[m["id"]]
    return maclar

# ------------------------------------------------------------------ arşiv karşılaştırma
_IDX = None
def arsiv():
    global _IDX
    if _IDX is None:
        ms = [m for m in json.load(open(ARCH, encoding="utf-8")) if m.get("o1") and m.get("ox") and m.get("o2")]
        ms.sort(key=lambda z: z["o1"])
        _IDX = (ms, [m["o1"] for m in ms])
    return _IDX

BUGUN_TR = "11.09.2026"      # bugünün maçları arşive eklense de karşılaştırmaya girmez (kendini sayma önyargısı)


def eslesen(ms, o1s, o, tol):
    lo = bisect.bisect_left(o1s, o[0] - tol); hi = bisect.bisect_right(o1s, o[0] + tol)
    return [m for m in ms[lo:hi] if abs(m["ox"] - o[1]) <= tol and abs(m["o2"] - o[2]) <= tol
            and m.get("date") != BUGUN_TR]

def implied(o):
    inv = [1 / x for x in o]; s = sum(inv)
    return [100 * x / s for x in inv], 100 * (s - 1)

def wilson(k, n, z=1.96):
    if n <= 0: return (0, 0, 0)
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    mm = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (100 * max(0, c - mm), 100 * p, 100 * min(1, c + mm))

def karsilastir(m, ms, o1s, min_n=12):
    """Kademeli tolerans: her maç için karşılaştırma bulunur."""
    for tol in (0.03, 0.05, 0.08, 0.12, 0.18, 0.28, 0.45, 0.70, 1.10):
        e = eslesen(ms, o1s, m["o"], tol)
        if len(e) >= min_n or tol >= 1.10:
            n = len(e)
            if n == 0:
                m.update(n=0, tol_k=None); return m
            hw = sum(1 for c in e if c["hg"] > c["ag"]); dr = sum(1 for c in e if c["hg"] == c["ag"]); aw = n - hw - dr
            tot = [c["hg"] + c["ag"] for c in e]
            piy, marj = implied(m["o"])
            hist = [100 * hw / n, 100 * dr / n, 100 * aw / n]
            ci = [wilson(hw, n), wilson(dr, n), wilson(aw, n)]
            roi = []
            for k in range(3):
                stake = 100.0 * n; ret = 0.0
                for c in e:
                    odd = [c["o1"], c["ox"], c["o2"]][k]
                    hit = (c["hg"] > c["ag"]) if k == 0 else ((c["hg"] == c["ag"]) if k == 1 else (c["hg"] < c["ag"]))
                    if hit: ret += 100.0 * odd
                roi.append(100 * (ret - stake) / stake if stake else 0)
            picks = []
            for k, ad in enumerate(("Ev", "Beraberlik", "Deplasman")):
                edge = hist[k] - piy[k]
                picks.append({"ad": ad, "oran": m["o"][k], "piyasa": piy[k], "hist": hist[k], "edge": edge,
                              "roi": roi[k], "ci": ci[k],
                              "guv": round(100 * (1 - math.exp(-n / 15)) * min(abs(edge) / 12.0, 1.0)),
                              "kelly": max(0.0, ((m["o"][k] - 1) * hist[k] / 100 - (1 - hist[k] / 100)) / (m["o"][k] - 1) * 25)})
            en = max(picks, key=lambda p: p["edge"] * (1 - math.exp(-n / 18.0)))
            m.update(n=n, tol_k=tol, picks=picks, en_iyi=en, dagilim=hist, marj=marj,
                     avg=sum(tot) / n, o25=100 * sum(1 for t in tot if t > 2.5) / n,
                     btts=100 * sum(1 for c in e if c["hg"] > 0 and c["ag"] > 0) / n,
                     ornek=sorted(e, key=lambda c: c.get("date", ""))[-6:])
            return m
    return m

def tam_tarama(gunler=1, min_n=12):
    ms, o1s = arsiv()
    hepsi = []
    for g in range(gunler):
        d = _today + timedelta(days=g)
        maclar = gun_maclari(d)
        print(f"📅 {d.strftime('%d.%m.%Y')} → {len(maclar)} maç", flush=True)
        maclar = oran_tamamla(maclar)
        with_o = [m for m in maclar if m["o"]]
        print(f"   oranı olan: {len(with_o)} / {len(maclar)} → karşılaştırma…", flush=True)
        for i, m in enumerate(with_o):
            karsilastir(m, ms, o1s, min_n)
        hepsi += maclar
    return hepsi

if __name__ == "__main__":
    gun = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    t0 = time.time()
    hepsi = tam_tarama(gun)
    with_o = [m for m in hepsi if m.get("o")]
    n_kar = sum(1 for m in with_o if m.get("n"))
    json.dump([{k: v for k, v in m.items() if k != "ornek"} | {"ornek": m.get("ornek", [])} for m in with_o],
              open("/home/user/veri/tam_tarama.json", "w", encoding="utf-8"), ensure_ascii=False)
    print(f"\n✅ {len(hepsi)} maç · {len(with_o)} oranlı · {n_kar} karşılaştırıldı · {round(time.time()-t0)} sn")
