#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GÜNLÜK TARAMA — bugünün TÜM maçlarını tara, "aynı oranla açılan" maçları bul,
değer (value) sinyali çıkar, ROI geri testi yap.

Kullanım:  python3 tarama.py [tolerans] [min_ornek]
"""
import bisect, json, math, re, subprocess, sys, time, html as H
from collections import Counter
from datetime import datetime

BASE = "https://www.betexplorer.com"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
COOKIE = "age_verified=true; js_cookie=1; my_timezone=%2B3; be_lang=en"
ARCH = "/home/user/veri/all_matches.json"
BUGUN = "11.09.2026"

def curl(u, n=35):
    for d in range(3):
        try:
            r = subprocess.run(["curl", "-s", "-m", str(n), "-A", UA, "-H", "Cookie: " + COOKIE,
                                "-H", "Accept-Language: en-US,en;q=0.9", u], capture_output=True, timeout=n + 8)
            s = r.stdout.decode("utf-8", "ignore")
            if len(s) > 3000: return s
        except Exception: pass
        time.sleep(1.0)
    return ""

def bugunun_maclari():
    """BetExplorer /results/ — bugünün tüm maçları + 1X2 oranları."""
    h = curl(BASE + "/results/")
    if not h: return []
    h = h.replace("&nbsp;", " ")
    out = []
    lig = ""
    for blok in re.split(r'(<tr[^>]*class="table-main__row[^"]*"[^>]*>.*?</tr>|<tr[^>]*>.*?</tr>)', h, flags=re.S):
        if not blok: continue
        t = re.search(r'table-main__tournament[^>]*>\s*(?:<i>.*?</i>)?\s*([^<]{3,60})<', blok, re.S)
        if t and 'in-match' not in blok:
            lig = H.unescape(t.group(1)).strip(); continue
        if 'table-main__tt' not in blok: continue
        m = re.search(r'<a href="(/football/([^/]+)/([^/"]+)/[^"]+)">([^<]+) - ([^<]+)</a>', blok)
        if not m: continue
        tm = re.search(r'table-main__time">([\d:]{4,5})<', blok)
        odds = re.findall(r'data-odd="([\d.]+)"', blok)[:3]
        if len(odds) < 3: continue
        try: o = [float(x) for x in odds]
        except Exception: continue
        if min(o) < 1.01: continue
        out.append({"link": m.group(1), "id": m.group(1).strip('/').split('/')[-1],
                    "country": m.group(2), "liga": m.group(3).replace('-', ' ').title(),
                    "home": H.unescape(m.group(4)).strip(), "away": H.unescape(m.group(5)).strip(),
                    "saat": tm.group(1) if tm else "", "o": o})
    return out

# ------------------------------------------------------------------ arşiv tarama
_IDX = None
def arsiv():
    global _IDX
    if _IDX is None:
        ms = json.load(open(ARCH, encoding="utf-8"))
        ms = [m for m in ms if m.get("o1") and m.get("ox") and m.get("o2")]
        ms.sort(key=lambda z: z["o1"])
        _IDX = (ms, [m["o1"] for m in ms])
    return _IDX

def eslesen(ms, o1s, o, tol):
    """o = [1, X, 2] → tol içindeki maçlar (hızlı: o1 üzerinden daralt)."""
    lo = bisect.bisect_left(o1s, o[0] - tol); hi = bisect.bisect_right(o1s, o[0] + tol)
    return [m for m in ms[lo:hi]
            if abs(m["ox"] - o[1]) <= tol and abs(m["o2"] - o[2]) <= tol]

def implied(o):
    inv = [1 / x for x in o]; s = sum(inv)
    return [100 * x / s for x in inv], 100 * (s - 1)

def wilson(k, n, z=1.96):
    if n <= 0: return (0, 0, 0)
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    m = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (100 * max(0, c - m), 100 * p, 100 * min(1, c + m))

def tarama(tol=0.15, min_n=5, verbose=True):
    maclar = bugunun_maclari()
    ms, o1s = arsiv()
    if verbose: print(f"Bugünün maçı: {len(maclar)} | arşiv: {len(ms)}", flush=True)
    sonuc = []
    for i, mc in enumerate(maclar):
        e = eslesen(ms, o1s, mc["o"], tol)
        if len(e) < min_n:
            e2 = eslesen(ms, o1s, mc["o"], tol * 1.6)
            if len(e2) >= min_n: e = e2
        n = len(e)
        if n == 0:
            mc.update(n=0, picks=[], en_iyi=None, skor=0); sonuc.append(mc); continue
        hw = sum(1 for c in e if c["hg"] > c["ag"]); dr = sum(1 for c in e if c["hg"] == c["ag"]); aw = n - hw - dr
        tot = [c["hg"] + c["ag"] for c in e]
        piy, marj = implied(mc["o"])
        hist = [100 * hw / n, 100 * dr / n, 100 * aw / n]
        ci = [wilson(hw, n), wilson(dr, n), wilson(aw, n)]
        # ROI: eşleşen maçlarda kendi oranından düz bahis
        roi = []
        for k in range(3):
            stake = 100.0 * n; ret = 0.0
            for c in e:
                odd = [c["o1"], c["ox"], c["o2"]][k]
                hit = (c["hg"] > c["ag"]) if k == 0 else ((c["hg"] == c["ag"]) if k == 1 else (c["hg"] < c["ag"]))
                if hit: ret += 100.0 * odd
            roi.append(100 * (ret - stake) / stake if stake else 0)
        picks = []
        for k, ad in enumerate(("Ev", "Beraberlik", "Deplasman")):
            edge = hist[k] - piy[k]
            guv = round(100 * (1 - math.exp(-n / 15)) * min(abs(edge) / 12.0, 1.0))
            picks.append({"ad": ad, "oran": mc["o"][k], "piyasa": piy[k], "hist": hist[k],
                          "edge": edge, "roi": roi[k], "ci": ci[k], "guv": guv,
                          "kelly": max(0.0, ((mc["o"][k] - 1) * hist[k] / 100 - (1 - hist[k] / 100)) / (mc["o"][k] - 1) * 25)})
        en = max(picks, key=lambda p: p["edge"] * (1 - math.exp(-n / 15)))
        mc.update(n=n, picks=picks, en_iyi=en, skor=round(en["edge"] * (1 - math.exp(-n / 15)), 2),
                  avg=sum(tot) / n, o25=100 * sum(1 for t in tot if t > 2.5) / n,
                  btts=100 * sum(1 for c in e if c["hg"] > 0 and c["ag"] > 0) / n,
                  marj=marj, ornek=e[:8])
        sonuc.append(mc)
        if verbose and (i + 1) % 40 == 0:
            print(f"  {i+1}/{len(maclar)} maç tarandı…", flush=True)
    return sonuc

def dogrula(maclar, tol=0.15, limit=24):
    """Değer listesindeki maçların GERÇEK bet365 kapanış oranını çekip yeniden tarar."""
    import analiz_motoru as M
    from concurrent.futures import ThreadPoolExecutor
    ms, o1s = arsiv()
    hedef = maclar[:limit]
    def w(m):
        try:
            b = M.b365_row(m["id"])
            if not b: m["dogrulama"] = "yok"; return m
            ger = [float(b[k]["odd"]) for k in ("1", "0", "2")]
            m["gercek_oran"] = ger
            e = eslesen(ms, o1s, ger, tol)
            if len(e) < 8:
                m["dogrulama"] = "zayif"; return m
            n = len(e)
            hw = sum(1 for c in e if c["hg"] > c["ag"]); dr = sum(1 for c in e if c["hg"] == c["ag"]); aw = n - hw - dr
            piy, _ = implied(ger)
            hist = [100 * hw / n, 100 * dr / n, 100 * aw / n]
            ci = [wilson(hw, n), wilson(dr, n), wilson(aw, n)]
            roi = []
            for k in range(3):
                stake = 100.0 * n; ret = 0.0
                for c in e:
                    odd = [c["o1"], c["ox"], c["o2"]][k]
                    hit = (c["hg"] > c["ag"]) if k == 0 else ((c["hg"] == c["ag"]) if k == 1 else (c["hg"] < c["ag"]))
                    if hit: ret += 100.0 * odd
                roi.append(100 * (ret - stake) / stake if stake else 0)
            picks = []
            for k, ad in enumerate(("Ev", "Beraberlik", "Deplasman")):
                edge = hist[k] - piy[k]
                picks.append({"ad": ad, "oran": ger[k], "piyasa": piy[k], "hist": hist[k], "edge": edge,
                              "roi": roi[k], "ci": ci[k],
                              "guv": round(100 * (1 - math.exp(-n / 15)) * min(abs(edge) / 12.0, 1.0)),
                              "kelly": max(0.0, ((ger[k] - 1) * hist[k] / 100 - (1 - hist[k] / 100)) / (ger[k] - 1) * 25)})
            en = max(picks, key=lambda p: p["edge"] * (1 - math.exp(-n / 15)))
            tutuyor = en["ci"][0] > en["piyasa"] and en["edge"] >= 3
            m.update(gercek_n=n, gercek_picks=picks, en_iyi=en, n=n, picks=picks,
                     skor=round(en["edge"] * (1 - math.exp(-n / 15)), 2),
                     avg=sum(c["hg"] + c["ag"] for c in e) / n,
                     o25=100 * sum(1 for c in e if c["hg"] + c["ag"] > 2.5) / n,
                     dogrulama="ok" if tutuyor else "zayif", ornek=e[:8])
            return m
        except Exception:
            m["dogrulama"] = "yok"; return m
    with ThreadPoolExecutor(max_workers=8) as ex:
        return list(ex.map(w, hedef))

def rapor_html(sonuc, tol, dosya="/home/user/Bugunun_Tarama.html"):
    def guvenilir(m):
        if not m.get("en_iyi") or m.get("n", 0) < 8: return False
        p = m["en_iyi"]
        alt = p["ci"][0]                      # Wilson %95 alt sınır
        return (alt > p["piyasa"]) and (p["edge"] >= 3)
    degerli = [m for m in sonuc if guvenilir(m)]
    def seviye(m):
        p = m["en_iyi"]; n = m["n"]; alt = p["ci"][0]
        if n >= 40 and alt > p["piyasa"] + 2: return 3, "YÜKSEK"
        if n >= 18 and alt > p["piyasa"]: return 2, "ORTA"
        return 1, "DÜŞÜK"
    for m in degerli: m["seviye"], m["seviye_ad"] = seviye(m)
    degerli.sort(key=lambda m: (-m["seviye"], -m["skor"]))
    dogrula(degerli)
    degerli = [m for m in degerli if m.get("dogrulama") != "zayif"]
    degerli.sort(key=lambda m: ({"ok": 0, "yok": 1}.get(m.get("dogrulama"), 2), -m.get("skor", 0)))
    CSS = """body{margin:0;background:#0a121e;color:#e8eef5;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;font-size:13.5px}
.wrap{max-width:1250px;margin:0 auto;padding:22px 16px 60px}
h1{font-size:25px;margin:0 0 4px}.sub{color:#8ba3b8;font-size:13px;margin-bottom:16px}
.card{background:#0f1a27;border:1px solid #1d2d42;border-radius:14px;padding:16px 18px;margin:14px 0}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{border:1px solid #1d2d42;padding:6px 8px;text-align:left}
th{background:#16273a;color:#9fd6ff;font-size:12.5px}tbody tr:nth-child(even){background:#0c1622}tbody tr:hover{background:#15263a}
.od{text-align:center;font-variant-numeric:tabular-nums;font-weight:600}
.git{color:#5ee7a0}.yit{color:#ffd479}.kit{color:#ff8a8a}
.badge{display:inline-block;padding:2px 8px;border-radius:6px;font-size:11.5px;font-weight:700}
.b-deger{background:#124a2e;color:#5ee7a0}.b-zayif{background:#24354a;color:#9fb4c7}
.mini{color:#8ba3b8;font-size:11.5px}.stat{display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}
.stat div{background:#0c1622;border:1px solid #1d2d42;border-radius:10px;padding:10px 12px}
.stat b{display:block;color:#8ba3b8;font-size:11px;text-transform:uppercase;margin-bottom:4px}
.stat span{font-size:19px;font-weight:800}"""
    out = [f"<div class='wrap'><h1>🔎 GÜNLÜK TARAMA — {BUGUN}</h1>",
           f"<div class='sub'>Bugünün <b>{len(sonuc)}</b> maçı, <b>{67_464}</b> maçlık arşivde tarandı · tolerans ±{tol} · "
           f"eşleşme = o maçla <b>aynı oranla açılan/kapanan</b> maçlar</div>"]
    out.append("<div class='card'><h3 style='margin:0 0 8px'>📌 En değerli fırsatlar</h3>"
               "<div class='mini'>Değer = tarihsel isabet − piyasa olasılığı. Listeye girmek için: <b>8+ eşleşen maç</b>, "
               "<b>%95 güven aralığının alt sınırı piyasa olasılığından yüksek</b> ve fark ≥ 3 puan. "
               "Güven: YÜKSEK (40+ maç) · ORTA (18+ maç) · DÜŞÜK (daha az). "
               "<b>Doğrulama:</b> ✅ bet365 = fırsatı <b>gerçek bet365 oranıyla</b> yeniden tarayıp teyit ettik; ⚪ = hızlı tarama (doğrulanmamış).</div>")
    rows = ""
    for m in degerli[:25]:
        p = m["en_iyi"]
        R = m.get("ornek", [])[:4]
        roi_cls = "git" if p["roi"] > 0 else "kit"
        sv = m.get("seviye_ad", "DÜŞÜK")
        sv_cls = "b-deger" if sv == "YÜKSEK" else ("b-zayif" if sv == "ORTA" else "b-zayif")
        dgr = "✅ bet365" if m.get("dogrulama") == "ok" else ("⚪ hızlı" if m.get("dogrulama") == "yok" else "—")
        rows += (
            f"<tr><td>{m.get('saat','')}</td>"
            f"<td><b>{H.escape(m['home'])}</b> - {H.escape(m['away'])}</td>"
            f"<td class='mini'>{H.escape(m.get('liga',''))}</td>"
            f"<td class='od'>{m['o'][0]:.2f} / {m['o'][1]:.2f} / {m['o'][2]:.2f}</td>"
            f"<td class='od'><b>{p['ad']}</b></td>"
            f"<td class='od'>{p['oran']:.2f}</td>"
            f"<td><span class='badge {sv_cls}'>{sv}</span></td>"
            f"<td class='od'>{dgr}</td>"
            f"<td class='od'>{p['piyasa']:.0f}%</td>"
            f"<td class='od'>{p['hist']:.0f}%</td>"
            f"<td class='od git'>+{p['edge']:.1f} pt</td>"
            f"<td class='od'>{p['ci'][0]:.0f}–{p['ci'][2]:.0f}%</td>"
            f"<td class='od'>{p['guv']}/100</td>"
            f"<td class='od {roi_cls}'>{p['roi']:+.1f}%</td>"
            f"<td class='od'>{m['n']}</td>"
            f"<td class='od'>{m.get('avg',0):.2f}</td>"
            f"<td class='od'>{m.get('o25',0):.0f}%</td></tr>")
    out.append("<table><thead><tr><th>Saat</th><th>Maç</th><th>Lig</th><th>Oran (1/X/2)</th><th>Değerli taraf</th>"
               "<th>Oran</th><th>Güven</th><th>Doğrulama</th><th>Piyasa</th><th>Tarihsel</th><th>Fark</th><th>%95 GA</th><th>Güven</th><th>ROI</th>"
               "<th>Örnek</th><th>Ort.gol</th><th>2.5Ü</th></tr></thead><tbody>" + (rows or "<tr><td colspan=15>Değer kriterini geçen maç yok</td></tr>") + "</tbody></table></div>")
    # maç maç kırılım (ilk 40)
    det = ""
    for m in degerli[:15]:
        p = m["en_iyi"]
        e = m.get("ornek", [])
        sat = "".join(f"<tr><td>{c.get('date','')}</td><td>{H.escape(c.get('home',''))}</td>"
                      f"<td>{H.escape(c.get('away',''))}</td><td class='od'>{c['hg']}:{c['ag']}</td>"
                      f"<td class='od'>{c['o1']:.2f}/{c['ox']:.2f}/{c['o2']:.2f}</td>"
                      f"<td class='od'>{'Ev' if c['hg']>c['ag'] else ('Ber' if c['hg']==c['ag'] else 'Dep')}</td></tr>" for c in e)
        det += (f"<div class='card'><b>{H.escape(m['home'])} - {H.escape(m['away'])}</b> "
                f"<span class='mini'>{m['saat']} · {H.escape(m['liga'])} · {m['n']} eşleşen maç · "
                f"değer: {p['ad']} (+{p['edge']:.1f} pt)</span>"
                f"<table style='margin-top:8px'><thead><tr><th>Tarih</th><th>Ev</th><th>Deplasman</th><th>MS</th>"
                f"<th>Oran</th><th>Sonuç</th></tr></thead><tbody>{sat}</tbody></table></div>")
    out.append(f"<h3>📋 En değerli maçların eşleşme detayı</h3>{det}")
    out.append(f"<div class='card mini'>Yöntem: her maç için 1X2 oranları arşivde ±{tol} toleransla taranır; "
               "o maçların gerçek sonuçlarından isabet yüzdeleri, %95 Wilson güven aralığı, ROI (kendi oranından düz bahis) ve "
               "güven skoru (örneklem × fark) hesaplanır. Piyasa olasılığı marj arındırılmıştır. "
               "«Örnek» = eşleşen maç sayısı.</div></div>")
    html = f"<!DOCTYPE html><html lang='tr'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Günlük Tarama {BUGUN}</title><style>{CSS}</style></head><body>{''.join(out)}</body></html>"
    open(dosya, "w", encoding="utf-8").write(html)
    return dosya, degerli

if __name__ == "__main__":
    tol = float(sys.argv[1]) if len(sys.argv) > 1 else 0.15
    t0 = time.time()
    sonuc = tarama(tol)
    dosya, degerli = rapor_html(sonuc, tol)
    print(f"Rapor: {dosya} | {len(sonuc)} maç tarandı, {len(degerli)} değerli fırsat | {round(time.time()-t0)} sn")
    for m in degerli[:12]:
        p = m["en_iyi"]
        print(f"  {m['saat']} {m['home'][:22]:22} - {m['away'][:22]:22} | {p['ad']:10} {p['oran']:.2f} "
              f"piyasa %{p['piyasa']:.0f} vs tarihsel %{p['hist']:.0f} (+{p['edge']:.1f}pt) n={m['n']} ROI {p['roi']:+.1f}%")
