#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VERİ TEMİZLE — bugünün fikstürünü gerçekten bugüne ait satırlardan yeniden kurar.

Sorun: BetExplorer ?date= parametresini yok sayıyor ve sayfada birkaç günü birden gösteriyor;
eski tarayıcı tüm satırları "bugün" diye etiketlediği için dünkü/bitmiş maçlar ve eski skorlar
bugüne karışmıştı. Bu betik:
  1) bugünün maçlarını data-dt filtresiyle yeniden çeker,
  2) veri/tam_tarama.json içinde bugüne ait OLMAYAN kayıtları atar,
  3) kalan kayıtları taze bilgiyle (saat/skor/İY/durum) günceller, eksik oranları tamamlar,
  4) veri/skor.json'u temizler (yalnızca bugün + başlamış + İY ≤ MS olan kayıtlar).
"""
import json, os, shutil, sys, time

sys.path.insert(0, '/home/user')
import tam_tarama as TT
import saat as SA

KOK = '/home/user'
TAM = f'{KOK}/veri/tam_tarama.json'
SKOR = f'{KOK}/veri/skor.json'
BUGUN = SA.simdi().date()
fark = SA.fark_ogren()

print('1) bugünün fikstürü çekiliyor…', flush=True)
taze = TT.gun_maclari(BUGUN)
print('   gerçekten bugüne ait maç:', len(taze), flush=True)
if len(taze) < 50:
    raise SystemExit(f'DURDURULDU: bugünün fikstürü {len(taze)} maç geldi (şüpheli) — hiçbir dosya değiştirilmedi.')
tazeid = {m['id'] for m in taze}

eski = json.load(open(TAM, encoding='utf-8'))
bugunku = [m for m in eski if m.get('gun') == BUGUN.isoformat()]
diger = [m for m in eski if m.get('gun') != BUGUN.isoformat()]
atilan = [m for m in bugunku if m['id'] not in tazeid]
kalan = [m for m in bugunku if m['id'] in tazeid]
print(f'   kayıt: toplam {len(eski)} · bugün etiketli {len(bugunku)} · atılacak (başka gün) {len(atilan)} · kalan {len(kalan)}')

# kalanları taze bilgiyle güncelle
taze_by = {m['id']: m for m in taze}
for m in kalan:
    t = taze_by[m['id']]
    for k in ('saat', 'skor', 'iy', 'durum', 'link', 'lig', 'lig_tam', 'ulke', 'home', 'away', 'dt_site'):
        if k in ('skor', 'iy', 'durum'):        # bu alanlar ZORLA tazelenir (eski sahte skorlar kalmasın)
            m[k] = t.get(k, '')
        elif t.get(k) not in (None, ''):
            m[k] = t[k]
    if t.get('o'):
        m['o'] = t['o']

# yeni maçlar (bugünün listesinde olup elimizde olmayan)
var = {m['id'] for m in kalan}
yeni = [t for t in taze if t['id'] not in var]
print(f'   yeni maç: {len(yeni)}', flush=True)
if yeni:
    TT.oran_tamamla(yeni)                      # önbellekli oran tamamlama
    ms, o1s = TT.arsiv()
    for m in yeni:
        if m.get('o'):
            TT.karsilastir(m, ms, o1s)
    kalan += yeni

out = diger + kalan
tmp = TAM + '.tmp'
json.dump(out, open(tmp, 'w', encoding='utf-8'), ensure_ascii=False)
shutil.copy2(TAM, f'{KOK}/veri/tam_tarama.bak2.json')
os.replace(tmp, TAM)

# ---- skor.json temizliği ----
sk = json.load(open(SKOR, encoding='utf-8')) if os.path.exists(SKOR) else {}
yeni_sk, at_sk, bozuk = {}, 0, 0
for m in kalan:
    k = sk.get(m['id'])
    if not k:
        continue
    if k.get('durum') not in ('bitti', 'canlı'):
        at_sk += 1
        continue
    try:
        ih, ia = (int(x) for x in (k.get('iy') or '0:0').split(':'))
        mh, ma = (int(x) for x in (k.get('ms') or '0:0').split(':'))
        if (k.get('iy') and ih + ia > mh + ma) or (not k.get('ms')):
            bozuk += 1
            continue
    except Exception:
        bozuk += 1
        continue
    yeni_sk[m['id']] = k
eski_sk = len(sk)
json.dump(yeni_sk, open(SKOR, 'w', encoding='utf-8'), ensure_ascii=False)

print()
print(f'SONUÇ: maç listesi {len(eski)} → {len(out)} (bugüne ait {len(kalan)} + diğer gün {len(diger)})')
print(f'   oranlı: {sum(1 for m in out if m.get("o"))} · skorlu: {sum(1 for m in out if m.get("skor"))}')
print(f'   skor.json {eski_sk} → {len(yeni_sk)} (bozuk atıldı {bozuk}, başlamamış atıldı {at_sk})')
